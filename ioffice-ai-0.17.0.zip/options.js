const CATALOG = globalThis.IOFFICE_PROVIDER_CATALOG;
const PROVIDER_IDS = Object.keys(CATALOG);

function defaultProviderConfigs(){
  const out={};
  for(const [id,p] of Object.entries(CATALOG)) out[id]={apiKey:'',model:p.defaultModel||'',baseUrl:p.baseUrl||'',authMode:'bearer',customHeaderName:'',customHeaderValue:'',deployment:'',apiVersion:'2025-04-01-preview'};
  return out;
}

const defaults={
  providerOrder:['gemini','openai','anthropic','none'],retriesPerProvider:1,requestTimeoutMs:45000,fallbackRules:false,
  providerConfigs:defaultProviderConfigs(),webHandoffTarget:'gemini',webHandoffEnabled:true,webHandoffAutoSend:true,
  webHandoffOpenActive:true,webHandoffKeepTab:true,webGeminiAutoClose:false,webGeminiReuseTab:true,webGeminiWorkerWindow:false,
  analysisMode:'gemini-web',webGeminiTimeoutMs:150000,webGeminiMaxTurns:3,webGeminiForeground:false,
  readerConcurrency:0,readerTimeoutMs:30000,readerMaxFileSizeMb:10,readerIncludeRelated:false,readerDeduplicateContent:true,readerScanEnabled:false,aiRequireCompleteFiles:true,releaseUrl:''
};

let current=null,rulesWorking=null;
const $=id=>document.getElementById(id);
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const clone=v=>JSON.parse(JSON.stringify(v));
const listText=v=>(Array.isArray(v)?v:[]).join('\n');
const parseList=v=>[...new Set(String(v||'').split(/[\n;,]+/).map(x=>x.trim()).filter(Boolean))];
const fold=s=>String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/đ/g,'d').replace(/Đ/g,'D').toLowerCase();

function deepMerge(base,extra){const out={...base};for(const [k,v] of Object.entries(extra||{}))out[k]=(v&&typeof v==='object'&&!Array.isArray(v)&&base?.[k]&&typeof base[k]==='object'&&!Array.isArray(base[k]))?deepMerge(base[k],v):v;return out;}
function runtimeMessage(msg){return new Promise((resolve,reject)=>chrome.runtime.sendMessage(msg,r=>{if(chrome.runtime.lastError)reject(new Error(chrome.runtime.lastError.message));else resolve(r);}));}
function showMessage(text,ok=true){const m=$('msg');m.textContent=text;m.className=`msg ${ok?'ok':'err'}`;setTimeout(()=>{if(m.textContent===text)m.textContent='';},5000);}

function providerOptions(allowNone=true){
  const groups={};for(const [id,p] of Object.entries(CATALOG))(groups[p.group]||=[]).push([id,p]);
  let html=allowNone?'<option value="none">Không dùng</option>':'';
  for(const [group,items] of Object.entries(groups)) html+=`<optgroup label="${esc(group)}">${items.map(([id,p])=>`<option value="${id}">${esc(p.label)}</option>`).join('')}</optgroup>`;
  return html;
}
function renderOrder(){const labels=['AI chính','Dự phòng 1','Dự phòng 2','Dự phòng 3'];$('orderGrid').innerHTML=labels.map((label,i)=>`<div class="field"><label>${label}</label><select id="providerOrder${i}">${providerOptions(i>0)}</select></div>`).join('');}
function renderGroupFilter(){const groups=[...new Set(Object.values(CATALOG).map(p=>p.group))];$('groupFilter').innerHTML='<option value="">Tất cả nhóm</option>'+groups.map(g=>`<option>${esc(g)}</option>`).join('');}
function extraFields(id,p){if(p.type==='azure-openai')return `<div class="field"><label>Deployment</label><input data-field="deployment"></div><div class="field"><label>API version</label><input data-field="apiVersion"></div>`;if(id==='custom')return `<div class="field"><label>Kiểu xác thực</label><select data-field="authMode"><option value="bearer">Authorization: Bearer</option><option value="x-api-key">x-api-key</option><option value="none">Không xác thực</option></select></div><div class="field"><label>Header tùy chỉnh</label><input data-field="customHeaderName"></div><div class="field"><label>Giá trị header</label><input data-field="customHeaderValue" type="password"></div>`;return '';}
function renderProviders(){
  $('providers').innerHTML=Object.entries(CATALOG).map(([id,p])=>{const listId=`models-${id}`;return `<details class="provider" data-provider="${id}"><summary><span>${esc(p.label)}</span><span class="pill">${esc(p.vendor)} · ${esc(p.group)}</span></summary><div class="body">${p.type!=='gateway'?`<div class="field"><label>Model / Model ID</label><input data-field="model" list="${listId}"><datalist id="${listId}">${(p.presets||[]).map(m=>`<option value="${esc(m)}">`).join('')}</datalist></div>`:''}<div class="field"><label>${p.type==='gateway'?'Endpoint phân tích':'Base URL / Endpoint'}</label><input data-field="baseUrl"></div>${p.needsKey?`<div class="field"><label>API key / Token</label><div class="keyrow"><input data-field="apiKey" type="password" autocomplete="off"><button class="eye" type="button">👁</button></div></div>`:''}${extraFields(id,p)}<div class="miniActions">${p.canListModels?'<button class="btn small secondary listModels" type="button">Tải danh sách model</button>':''}<button class="btn small secondary testProvider" type="button">Kiểm tra kết nối</button></div><div class="status"></div></div></details>`;}).join('');
  document.querySelectorAll('.provider').forEach(bindProviderCard);
}
function getCard(id){return document.querySelector(`.provider[data-provider="${CSS.escape(id)}"]`);}
function cardConfig(id){const card=getCard(id),cfg={};card?.querySelectorAll('[data-field]').forEach(el=>cfg[el.dataset.field]=el.value.trim());return cfg;}
function setCardConfig(id,cfg){const card=getCard(id);if(!card)return;card.querySelectorAll('[data-field]').forEach(el=>{if(cfg?.[el.dataset.field]!==undefined)el.value=cfg[el.dataset.field]??'';});}
function status(card,text,ok=true){const el=card.querySelector('.status');el.textContent=text;el.className=`status ${ok?'ok':'err'}`;}
async function ensureCustomHostPermission(id,cfg){if(!cfg?.baseUrl)return true;const u=new URL(cfg.baseUrl);const origin=`${u.protocol}//${u.hostname}/*`;if(await chrome.permissions.contains({origins:[origin]}))return true;return await chrome.permissions.request({origins:[origin]});}
function appendModels(id,models){const dl=$(`models-${id}`);if(!dl)return;const existing=new Set([...dl.options].map(o=>o.value));for(const m of models||[]){if(existing.has(m.id))continue;const o=document.createElement('option');o.value=m.id;o.label=m.label||m.id;dl.appendChild(o);existing.add(m.id);}}
function bindProviderCard(card){
  const id=card.dataset.provider,eye=card.querySelector('.eye');
  if(eye)eye.addEventListener('click',()=>{const input=card.querySelector('[data-field="apiKey"]');input.type=input.type==='password'?'text':'password';eye.textContent=input.type==='password'?'👁':'🙈';});
  card.querySelector('.listModels')?.addEventListener('click',async()=>{status(card,'Đang tải model...');try{const cfg=cardConfig(id);if(!(await ensureCustomHostPermission(id,cfg)))throw new Error('Chưa cấp quyền truy cập endpoint.');const r=await runtimeMessage({type:'AI_LIST_MODELS',providerId:id,config:cfg});if(!r?.ok)throw new Error(r?.error||'Không tải được model');appendModels(id,r.models);status(card,`Đã tải ${r.models.length} model.`);}catch(e){status(card,e.message,false);}});
  card.querySelector('.testProvider')?.addEventListener('click',async()=>{status(card,'Đang kiểm tra...');try{const cfg=cardConfig(id);if(!(await ensureCustomHostPermission(id,cfg)))throw new Error('Chưa cấp quyền truy cập endpoint.');const r=await runtimeMessage({type:'AI_TEST_PROVIDER',providerId:id,config:cfg});if(!r?.ok)throw new Error(r?.error||'Kiểm tra thất bại');if(r.data?.models)appendModels(id,r.data.models);status(card,r.data?.message||'Kết nối được.');}catch(e){status(card,e.message,false);}});
}
function filterProviders(){const q=$('providerSearch').value.trim().toLowerCase(),g=$('groupFilter').value;document.querySelectorAll('.provider').forEach(card=>{const id=card.dataset.provider,p=CATALOG[id];const matchQ=!q||`${p.label} ${p.vendor} ${p.group} ${id}`.toLowerCase().includes(q);const matchG=!g||p.group===g;card.classList.toggle('hidden',!(matchQ&&matchG));});}

function recommendedConcurrency(){
  const hw=Math.max(2,Number(navigator.hardwareConcurrency||4));
  const mem=Number(navigator.deviceMemory||4);
  const cpuCap=hw>=12?6:hw>=8?5:hw>=6?4:hw>=4?3:2;
  const memCap=mem>=8?6:mem>=4?4:mem>=2?3:2;
  return Math.max(1,Math.min(6,cpuCap,memCap));
}
function renderHardwareHint(){const el=$('readerHardwareHint');if(!el)return;const hw=navigator.hardwareConcurrency||'?';const mem=navigator.deviceMemory?`${navigator.deviceMemory} GB`:'không xác định';el.textContent=`Máy hiện tại: CPU ${hw} luồng · RAM trình duyệt ~${mem} · chế độ Tự động đề xuất tối đa ${recommendedConcurrency()} luồng đọc file; viewer nặng vẫn được giới hạn riêng.`;}

function readForm(){
  const providerConfigs={};for(const id of PROVIDER_IDS)providerConfigs[id]=cardConfig(id);
  const rawConcurrency=Number($('readerConcurrency').value);
  return{
    webGeminiForeground:$('webGeminiForeground').value==='true',
    readerConcurrency:Number.isFinite(rawConcurrency)?Math.max(0,Math.min(6,rawConcurrency)):0,
    readerTimeoutMs:Math.max(10000,Math.min(60000,Number($('readerTimeoutSec').value||30)*1000)),
    readerMaxFileSizeMb:Math.max(1,Math.min(50,Number($('readerMaxFileSizeMb').value||10))),
    readerIncludeRelated:$('readerIncludeRelated').checked,readerDeduplicateContent:$('readerDeduplicateContent').checked,readerScanEnabled:false,
    aiRequireCompleteFiles:$('aiRequireCompleteFiles').checked,releaseUrl:$('releaseUrl').value.trim(),
    providerOrder:[0,1,2,3].map(i=>$(`providerOrder${i}`).value),retriesPerProvider:Number($('retriesPerProvider').value),
    requestTimeoutMs:Math.max(10000,Math.min(120000,Number($('requestTimeoutSec').value||45)*1000)),fallbackRules:false,providerConfigs,
    webHandoffEnabled:$('webHandoffEnabled').checked,webHandoffAutoSend:$('webHandoffAutoSend').checked,
    webHandoffOpenActive:$('webHandoffOpenActive').checked,webHandoffKeepTab:$('webHandoffKeepTab').checked,
    webGeminiAutoClose:false,webGeminiReuseTab:true,webGeminiWorkerWindow:false,
    analysisMode:['gemini-web','chatgpt-web','api','rules'].includes($('analysisMode').value)?$('analysisMode').value:'gemini-web',
    webGeminiTimeoutMs:Math.max(30000,Math.min(240000,Number($('webGeminiTimeoutSec').value||150)*1000)),
    webGeminiMaxTurns:Math.max(1,Math.min(10,Number($('webGeminiMaxTurns').value||3)))
  };
}
function writeForm(s){
  $('webGeminiForeground').value=String(s.webGeminiForeground===true);
  $('readerConcurrency').value=String(Number.isFinite(Number(s.readerConcurrency))?Number(s.readerConcurrency):0);
  if(!$('readerConcurrency').value)$('readerConcurrency').value='0';
  $('readerTimeoutSec').value=String(Math.round((s.readerTimeoutMs||30000)/1000));
  $('readerMaxFileSizeMb').value=String(Math.max(1,Math.min(50,Number(s.readerMaxFileSizeMb||10))));
  $('readerIncludeRelated').checked=s.readerIncludeRelated===true;$('readerDeduplicateContent').checked=s.readerDeduplicateContent!==false;$('readerScanEnabled').checked=false;$('readerScanEnabled').disabled=true;
  $('aiRequireCompleteFiles').checked=s.aiRequireCompleteFiles!==false;$('releaseUrl').value=s.releaseUrl||'';
  const order=[...(s.providerOrder||[]),'none','none','none','none'].slice(0,4);order.forEach((v,i)=>{$(`providerOrder${i}`).value=v;});
  $('retriesPerProvider').value=String(s.retriesPerProvider);$('requestTimeoutSec').value=String(Math.round((s.requestTimeoutMs||45000)/1000));
  $('webHandoffEnabled').checked=s.webHandoffEnabled!==false;$('webHandoffAutoSend').checked=s.webHandoffAutoSend!==false;$('webHandoffOpenActive').checked=s.webHandoffOpenActive!==false;$('webHandoffKeepTab').checked=s.webHandoffKeepTab!==false;
  $('analysisMode').value=['gemini-web','chatgpt-web','api','rules'].includes(s.analysisMode)?s.analysisMode:'gemini-web';
  $('webGeminiTimeoutSec').value=String(Math.round((s.webGeminiTimeoutMs||150000)/1000));$('webGeminiMaxTurns').value=String(s.webGeminiMaxTurns||3);
  for(const id of PROVIDER_IDS)setCardConfig(id,s.providerConfigs?.[id]||{});
}
function modeLabel(mode){return mode==='api'?'API':mode==='chatgpt-web'?'ChatGPT Web':mode==='rules'?'Quy tắc':'Gemini Web';}
function renderSummary(s){
  const order=(s.providerOrder||[]).filter(x=>x&&x!=='none').map(x=>`${CATALOG[x]?.label||x}${s.providerConfigs?.[x]?.model?` (${s.providerConfigs[x].model})`:''}`);
  const conc=Number(s.readerConcurrency)>0?`${s.readerConcurrency} luồng`:`Tự động (máy này ~${recommendedConcurrency()} luồng)`;
  $('summary').innerHTML=`<div><b>Phân tích:</b> ${modeLabel(s.analysisMode)} · ${s.aiRequireCompleteFiles!==false?'AI chặn khi thiếu tệp':'AI cho phép dữ liệu thiếu'}</div><div><b>Đọc tệp:</b> ${conc} · ${Math.round((s.readerTimeoutMs||30000)/1000)} giây/tệp · tối đa ${Math.max(1,Math.min(50,Number(s.readerMaxFileSizeMb||10)))} MB/tệp · Văn bản liên quan: ${s.readerIncludeRelated?'Có':'Không'} · Gộp tệp trùng: ${s.readerDeduplicateContent!==false?'Có':'Không'}</div><div><b>Quy tắc:</b> ${(rulesWorking?.rules||[]).filter(r=>r.enabled!==false).length}/${(rulesWorking?.rules||[]).length} đang bật · ${(rulesWorking?.units||[]).length} đơn vị</div><div><b>API dự phòng:</b> ${esc(order.join(' → ')||'chưa chọn')}</div>`;
}

function unitOptions(selected=''){return (rulesWorking?.units||[]).map(u=>`<option value="${esc(u.id)}" ${u.id===selected?'selected':''}>${esc(u.id)} · ${esc(u.name)}</option>`).join('');}
function renderUnits(){
  const host=$('unitEditor'),units=rulesWorking?.units||[];
  host.innerHTML=units.map((u,i)=>`<details class="unit-card" data-unit-index="${i}"><summary><span class="unit-code">${esc(u.id)}</span><span class="unit-name">${esc(u.name)}</span></summary><div class="unit-card-body"><div><label>Mã iOffice</label><input class="unit-code" data-f="id" value="${esc(u.id)}"></div><div><label>Tên đơn vị</label><input data-f="name" value="${esc(u.name)}"></div><div style="grid-column:1/-1"><label>Chức năng · mỗi dòng một ý</label><textarea data-f="functions">${esc(listText(u.functions))}</textarea></div></div></details>`).join('')+`<div><button id="addUnit" class="btn small secondary" type="button">＋ Thêm đơn vị</button></div>`;
  host.querySelectorAll('.unit-card').forEach(card=>{
    const i=Number(card.dataset.unitIndex),q=f=>card.querySelector(`[data-f="${f}"]`);
    const sync=()=>{const u=rulesWorking.units[i];u.id=q('id').value.trim();u.name=q('name').value.trim();u.functions=parseList(q('functions').value);card.querySelector('.unit-code').textContent=u.id||'—';card.querySelector('.unit-name').textContent=u.name||'Đơn vị chưa đặt tên';renderRulesStatus();};
    card.addEventListener('input',sync);card.addEventListener('change',()=>{sync();renderRules();});
  });
  $('addUnit').addEventListener('click',()=>{let n=900;const used=new Set(rulesWorking.units.map(x=>x.id));while(used.has(`U${n}`))n++;rulesWorking.units.push({id:`U${n}`,name:'Đơn vị mới',kind:'administrative',preferredMain:true,functions:[]});renderUnits();renderRules();renderRulesStatus();});
}

function ruleSearchText(rule){return fold(JSON.stringify(rule||{}));}
function filteredRuleEntries(){
  const q=fold($('ruleSearch')?.value||'').trim(),filter=$('ruleFilter')?.value||'all';
  return (rulesWorking?.rules||[]).map((rule,index)=>({rule,index})).filter(({rule})=>{
    if(filter==='enabled'&&rule.enabled===false)return false;if(filter==='disabled'&&rule.enabled!==false)return false;
    return !q||ruleSearchText(rule).includes(q);
  });
}
function ruleCard(rule,i){
  const m=rule.match||{},w=rule.weights||{},unit=(rulesWorking?.units||[]).find(u=>u.id===rule.mainUnit);
  return `<div class="rule-card" data-rule-index="${i}" data-open="false"><div class="rule-card-head"><input class="rule-toggle" type="checkbox" data-f="enabled" ${rule.enabled!==false?'checked':''} aria-label="Bật quy tắc"><button class="rule-expand" type="button" aria-expanded="false"><span class="rule-summary-main"><span class="rule-summary-name">${esc(rule.name||'Quy tắc chưa đặt tên')}</span><span class="rule-summary-meta"><span class="mini-pill">XLC: ${esc(unit?.name||rule.mainUnit||'—')}</span><span>Ưu tiên ${Number(rule.priority||0)}</span><span>Điểm tối thiểu ${Number(rule.minScore||0)}</span></span></span><span class="rule-caret">›</span></button></div><div class="rule-card-body">
    <details class="rule-group" open><summary>Định tuyến</summary><div class="rule-group-body rule-grid"><div class="span2"><label>Tên quy tắc</label><input data-f="name" value="${esc(rule.name||'')}"></div><div><label>Xử lý chính</label><select data-f="mainUnit">${unitOptions(rule.mainUnit)}</select></div><div><label>Điểm tối thiểu</label><input data-f="minScore" type="number" min="0" max="200" value="${Number(rule.minScore||0)}"></div><div><label>Phối hợp · mã, cách nhau dấu phẩy</label><input data-f="coordinationUnits" value="${esc((rule.coordinationUnits||[]).join(', '))}"></div><div><label>Xem để biết</label><input data-f="viewUnits" value="${esc((rule.viewUnits||[]).join(', '))}"></div><div><label>Ưu tiên</label><input data-f="priority" type="number" min="0" max="200" value="${Number(rule.priority||0)}"></div><div><label>Ý kiến đề xuất mặc định</label><textarea data-f="instruction">${esc(rule.instruction||'')}</textarea></div></div></details>
    <details class="rule-group"><summary>Điều kiện khớp</summary><div class="rule-group-body rule-grid"><div><label>Đơn vị ban hành · mỗi dòng một cụm</label><textarea data-f="senderAny">${esc(listText(m.senderAny))}</textarea></div><div><label>Trích yếu</label><textarea data-f="subjectAny">${esc(listText(m.subjectAny))}</textarea></div><div><label>Nội dung văn bản/tệp</label><textarea data-f="contentAny">${esc(listText(m.contentAny))}</textarea></div><div><label>Tên tệp</label><textarea data-f="attachmentAny">${esc(listText(m.attachmentAny))}</textarea></div><div class="span2"><label>Điều kiện loại trừ</label><textarea data-f="excludeAny">${esc(listText(m.excludeAny))}</textarea></div></div></details>
    <details class="rule-group"><summary>Trọng số nâng cao</summary><div class="rule-group-body"><div class="grid"><div><label>Đơn vị gửi</label><input data-f="wSender" type="number" value="${Number(w.sender??14)}"></div><div><label>Trích yếu</label><input data-f="wSubject" type="number" value="${Number(w.subject??16)}"></div><div><label>Nội dung</label><input data-f="wContent" type="number" value="${Number(w.content??10)}"></div><div><label>Tên tệp</label><input data-f="wAttachment" type="number" value="${Number(w.attachment??5)}"></div></div><div class="rule-help">Mỗi cụm khớp sẽ cộng điểm theo trọng số. Quy tắc có tổng điểm mạnh nhất góp vào đơn vị Xử lý chính.</div></div></details>
    <div class="rule-actions"><button class="btn small secondary duplicateRule" type="button">Nhân bản</button><button class="btn small danger deleteRule" type="button">Xóa</button></div>
  </div></div>`;
}
function syncRuleFromCard(card){
  const i=Number(card.dataset.ruleIndex),r=rulesWorking.rules[i],q=f=>card.querySelector(`[data-f="${f}"]`);if(!r)return;
  r.enabled=q('enabled').checked;r.name=q('name').value.trim();r.priority=Number(q('priority').value)||0;r.mainUnit=q('mainUnit').value;r.minScore=Math.max(0,Number(q('minScore').value)||0);
  r.coordinationUnits=parseList(q('coordinationUnits').value).filter(x=>/^U\d+$/.test(x));r.viewUnits=parseList(q('viewUnits').value).filter(x=>/^U\d+$/.test(x));r.instruction=q('instruction').value.trim();
  r.match={senderAny:parseList(q('senderAny').value),subjectAny:parseList(q('subjectAny').value),contentAny:parseList(q('contentAny').value),attachmentAny:parseList(q('attachmentAny').value),excludeAny:parseList(q('excludeAny').value)};
  r.weights={sender:Number(q('wSender').value)||0,subject:Number(q('wSubject').value)||0,content:Number(q('wContent').value)||0,attachment:Number(q('wAttachment').value)||0};
  card.querySelector('.rule-summary-name').textContent=r.name||'Quy tắc chưa đặt tên';
  const unit=(rulesWorking.units||[]).find(u=>u.id===r.mainUnit);const pill=card.querySelector('.mini-pill');if(pill)pill.textContent=`XLC: ${unit?.name||r.mainUnit||'—'}`;
  renderRulesStatus();
}
function renderRules(){
  const host=$('ruleList'),entries=filteredRuleEntries();
  host.innerHTML=entries.length?entries.map(({rule,index})=>ruleCard(rule,index)).join(''):'<div class="rule-empty">Không có quy tắc phù hợp bộ lọc hiện tại.</div>';
  host.querySelectorAll('.rule-card').forEach(card=>{
    const toggle=card.querySelector('.rule-toggle');toggle?.addEventListener('click',e=>e.stopPropagation());
    const expand=card.querySelector('.rule-expand');
    expand?.addEventListener('click',()=>{const open=card.dataset.open==='true';card.dataset.open=open?'false':'true';expand.setAttribute('aria-expanded',String(!open));});
    card.addEventListener('input',()=>syncRuleFromCard(card));card.addEventListener('change',()=>syncRuleFromCard(card));
    card.querySelector('.deleteRule')?.addEventListener('click',()=>{const i=Number(card.dataset.ruleIndex);rulesWorking.rules.splice(i,1);renderRules();renderRulesStatus();});
    card.querySelector('.duplicateRule')?.addEventListener('click',()=>{syncRuleFromCard(card);const i=Number(card.dataset.ruleIndex),copy=clone(rulesWorking.rules[i]);copy.id=`${copy.id||'rule'}-copy-${Date.now().toString(36)}`;copy.name=`${copy.name||'Quy tắc'} (bản sao)`;rulesWorking.rules.splice(i+1,0,copy);renderRules();renderRulesStatus();});
  });
}
function renderRulesStatus(text='',kind=''){
  const enabled=(rulesWorking?.rules||[]).filter(r=>r.enabled!==false).length;
  $('rulesVersion').textContent=rulesWorking?`${rulesWorking.version||'custom'} · ${(rulesWorking.units||[]).length} đơn vị`:'';
  const el=$('rulesStatus');el.textContent=text||`${enabled}/${(rulesWorking?.rules||[]).length||0} quy tắc đang bật · chỉnh xong bấm “Lưu toàn bộ cấu hình”.`;el.className=`status ${kind}`;
}
function validateRules(data){
  if(!data||typeof data!=='object'||!Array.isArray(data.units)||!Array.isArray(data.rules))throw new Error('Bộ quy tắc phải có units[] và rules[].');
  const ids=new Set();for(const u of data.units){if(!/^U\d+$/.test(String(u.id||'')))throw new Error(`Mã đơn vị không hợp lệ: ${u.id||'(trống)'}`);if(ids.has(u.id))throw new Error(`Trùng mã đơn vị ${u.id}`);ids.add(u.id);if(!String(u.name||'').trim())throw new Error(`Đơn vị ${u.id} chưa có tên.`);}
  for(const [i,r] of data.rules.entries()){if(!ids.has(r.mainUnit))throw new Error(`Quy tắc ${i+1} có XLC không tồn tại: ${r.mainUnit||'(trống)'}`);for(const id of [...(r.coordinationUnits||[]),...(r.viewUnits||[])])if(!ids.has(id))throw new Error(`Quy tắc ${i+1} tham chiếu mã không tồn tại: ${id}`);}
  return true;
}
async function loadRules(){const r=await runtimeMessage({type:'GET_ROUTING_RULES'});if(!r?.ok)throw new Error(r?.error||'Không tải được bộ quy tắc.');rulesWorking=clone(r.rules);renderUnits();renderRules();renderRulesStatus();}

async function load(){
  renderOrder();renderGroupFilter();renderProviders();renderHardwareHint();
  const raw=await chrome.storage.local.get(defaults);current={...defaults,...raw,providerConfigs:deepMerge(defaultProviderConfigs(),raw.providerConfigs||{})};writeForm(current);await loadRules();renderSummary(current);
}

$('providerSearch').addEventListener('input',filterProviders);$('groupFilter').addEventListener('change',filterProviders);
$('ruleSearch').addEventListener('input',renderRules);$('ruleFilter').addEventListener('change',renderRules);
$('addRule').addEventListener('click',()=>{const first=rulesWorking.units?.[0]?.id||'';rulesWorking.rules.push({id:`custom-${Date.now().toString(36)}`,name:'Quy tắc mới',enabled:true,priority:50,mainUnit:first,coordinationUnits:[],viewUnits:[],minScore:15,match:{senderAny:[],subjectAny:[],contentAny:[],attachmentAny:[],excludeAny:[]},weights:{sender:14,subject:16,content:10,attachment:5},instruction:''});$('ruleSearch').value='';$('ruleFilter').value='all';renderRules();renderRulesStatus();const cards=$('ruleList').querySelectorAll('.rule-card');const last=cards[cards.length-1];if(last){last.dataset.open='true';last.querySelector('.rule-expand')?.setAttribute('aria-expanded','true');}});
$('exportRules').addEventListener('click',()=>{try{validateRules(rulesWorking);const blob=new Blob([JSON.stringify(rulesWorking,null,2)],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=`Quy_tac_phan_luong_Ea_Ly_${new Date().toISOString().slice(0,10)}.json`;a.click();setTimeout(()=>URL.revokeObjectURL(url),1500);renderRulesStatus('Đã xuất bộ quy tắc.','ok');}catch(e){renderRulesStatus(e.message,'err');}});
$('importRules').addEventListener('click',()=>$('importRulesFile').click());
$('importRulesFile').addEventListener('change',async e=>{const file=e.target.files?.[0];if(!file)return;try{const data=JSON.parse(await file.text());validateRules(data);rulesWorking=clone(data);renderUnits();renderRules();renderRulesStatus('Đã nạp file JSON. Bấm “Lưu toàn bộ cấu hình” để áp dụng.','ok');}catch(err){renderRulesStatus(`Không nhập được: ${err.message}`,'err');}finally{e.target.value='';}});
$('refreshRulesJson').addEventListener('click',()=>{$('rulesJsonEditor').value=JSON.stringify(rulesWorking,null,2);renderRulesStatus('Đã đưa bộ quy tắc hiện tại vào ô JSON.','ok');});
$('loadRulesJson').addEventListener('click',()=>{try{const data=JSON.parse($('rulesJsonEditor').value||'');validateRules(data);rulesWorking=clone(data);renderUnits();renderRules();renderRulesStatus('Đã áp dụng JSON vào biểu mẫu. Bấm “Lưu toàn bộ cấu hình” để lưu.','ok');}catch(e){renderRulesStatus(`JSON chưa hợp lệ: ${e.message}`,'err');}});
$('resetRules').addEventListener('click',async()=>{if(!confirm('Khôi phục toàn bộ quy tắc mặc định của tiện ích?'))return;await chrome.storage.local.remove('routingRulesCustom');await loadRules();$('rulesJsonEditor').value='';renderRulesStatus('Đã khôi phục mặc định.','ok');renderSummary(readForm());});

$('save').addEventListener('click',async()=>{const s=readForm();try{validateRules(rulesWorking);const origins=[...new Set(s.providerOrder.filter(id=>id!=='none').map(id=>s.providerConfigs[id]?.baseUrl).filter(Boolean).map(url=>{const u=new URL(url);if(!['http:','https:'].includes(u.protocol))throw new Error('Endpoint phải là HTTP hoặc HTTPS.');return `${u.protocol}//${u.hostname}/*`;}))];if(s.analysisMode==='api'&&origins.length&&!(await chrome.permissions.request({origins})))throw new Error('Chưa được cấp quyền cho máy chủ API.');rulesWorking.version=`custom-${chrome.runtime.getManifest().version}`;await chrome.storage.local.set({...s,routingRulesCustom:rulesWorking});current=s;renderSummary(s);renderRulesStatus('Đã lưu bộ quy tắc và cấu hình.','ok');showMessage('Đã lưu. Có hiệu lực từ lần phân tích tiếp theo.');}catch(e){showMessage(e.message,false);renderRulesStatus(e.message,'err');}});
$('clearKeys').addEventListener('click',async()=>{const s=readForm();for(const id of PROVIDER_IDS){s.providerConfigs[id].apiKey='';s.providerConfigs[id].customHeaderValue='';}await chrome.storage.local.set(s);writeForm(s);renderSummary(s);showMessage('Đã xóa toàn bộ API key/token đã lưu.');});
$('openChatGPT').addEventListener('click',()=>window.open('https://chatgpt.com/','_blank','noopener'));$('openGemini').addEventListener('click',()=>window.open('https://gemini.google.com/app','_blank','noopener'));

$('version').textContent='v'+chrome.runtime.getManifest().version;
$('checkRelease').addEventListener('click',async()=>{const button=$('checkRelease');button.disabled=true;$('releaseDownload').classList.add('hidden');try{const url=new URL($('releaseUrl').value.trim());if(url.protocol!=='https:'||url.username||url.password)throw new Error('Nhập địa chỉ HTTPS của latest.json.');if(!(await chrome.permissions.request({origins:[url.protocol+'//'+url.hostname+'/*']})))throw new Error('Chưa cấp quyền đọc địa chỉ cập nhật.');const r=await runtimeMessage({type:'CHECK_RELEASE',url:url.href});if(!r?.ok)throw new Error(r?.error||'Không kiểm tra được cập nhật.');await chrome.storage.local.set({releaseUrl:url.href});const d=r.data;$('updateStatus').textContent=d.newer?`Có bản ${d.version}. ${d.notes}\nTải gói mới, thay tệp rồi Reload tiện ích.`:`Đang dùng bản mới nhất theo địa chỉ này (${d.version}).`;if(d.newer){$('releaseDownload').href=d.downloadUrl;$('releaseDownload').classList.remove('hidden');}}catch(e){$('updateStatus').textContent=e.message;}finally{button.disabled=false;}});
$('checkStore').addEventListener('click',async()=>{try{const r=await runtimeMessage({type:'CHECK_STORE_UPDATE'});if(!r?.ok)throw new Error(r?.error||'Không kiểm tra được.');$('updateStatus').textContent=r.data.message;}catch(e){$('updateStatus').textContent=e.message;}});

load().catch(e=>showMessage('Không tải được cấu hình: '+e.message,false));
