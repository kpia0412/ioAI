(() => {
  'use strict';

  const VERSION = '0.16.4-reader';
  const MAX_FILE_CHARS = 40000;
  const MAX_PRIMARY_CHARS = 18000;
  const MAX_SUPPORT_CHARS = 5000;
  const MAX_TOTAL_AI_CHARS = 28000;
  const MAX_PDF_PAGES = 80;
  const MAX_SCAN_FILE_BYTES = 8 * 1024 * 1024;
  const MAX_SCAN_TOTAL_BYTES = 12 * 1024 * 1024;
  const MAX_SCAN_ATTACHMENTS = 3;
  const MIN_TEXT_CHARS = 40;
  const NETWORK_CHANNEL = 'ioffice-file-network-v1';
  const observedNetwork = [];
  const capturedFiles = [];
  const pendingViewerResolvers = new Map();
  const capturedCopyTexts = [];
  const MAX_CAPTURE_CACHE_BYTES = 60 * 1024 * 1024;

  function trimCapturedFiles() {
    let total = capturedFiles.reduce((n, x) => n + Number(x.bytes?.byteLength || 0), 0);
    while (capturedFiles.length > 40 || total > MAX_CAPTURE_CACHE_BYTES) {
      const removed = capturedFiles.shift();
      total -= Number(removed?.bytes?.byteLength || 0);
    }
  }

  window.addEventListener('message', (event) => {
    if (event.origin !== location.origin || event.data?.channel !== NETWORK_CHANNEL) return;
    const type = String(event.data?.type || '');

    if (type === 'resolved-viewer') {
      const requestId = String(event.data?.requestId || '');
      const pending = pendingViewerResolvers.get(requestId);
      if (!pending) return;
      pendingViewerResolvers.delete(requestId);
      pending.resolve({
        ok: Boolean(event.data?.ok),
        url: String(event.data?.url || ''),
        error: String(event.data?.error || '')
      });
      return;
    }

    if (type === 'copy-text') {
      const text = cleanText(String(event.data?.text || ''));
      if (text.length >= MIN_TEXT_CHARS) {
        capturedCopyTexts.push({ text: text.slice(0, MAX_FILE_CHARS), frameUrl: String(event.data?.frameUrl || ''), ts: Date.now() });
        while (capturedCopyTexts.length > 30) capturedCopyTexts.shift();
      }
      return;
    }

    const url = String(event.data?.url || '');
    const frameUrl = String(event.data?.frameUrl || '');
    if (!url || !url.startsWith(location.origin + '/')) return;

    if (type === 'resource') {
      observedNetwork.push({
        url,
        frameUrl,
        initiatorType: String(event.data.initiatorType || ''),
        method: String(event.data.method || 'GET'),
        contentLength: Number(event.data.contentLength || 0),
        contentType: String(event.data.contentType || ''),
        disposition: String(event.data.disposition || ''),
        ts: Date.now()
      });
      while (observedNetwork.length > 900) observedNetwork.shift();
      return;
    }

    if (type === 'file-bytes' && event.data?.bytes != null) {
      try {
        const raw = event.data.bytes;
        let bytes = null;
        if (raw instanceof ArrayBuffer) bytes = new Uint8Array(raw);
        else if (ArrayBuffer.isView(raw)) bytes = new Uint8Array(raw.buffer, raw.byteOffset, raw.byteLength);
        else if (typeof raw?.byteLength === 'number') bytes = new Uint8Array(raw);
        if (!bytes?.byteLength) return;
        capturedFiles.push({
          url,
          frameUrl,
          filename: String(event.data.filename || ''),
          contentType: String(event.data.contentType || ''),
          disposition: String(event.data.disposition || ''),
          signature: String(event.data.signature || ''),
          initiatorType: String(event.data.initiatorType || ''),
          bytes,
          ts: Date.now()
        });
        trimCapturedFiles();
      } catch (_) {}
    }
  });

  function abortError() {
    try { return new DOMException('Đã dừng phân tích.', 'AbortError'); }
    catch (_) { const e = new Error('Đã dừng phân tích.'); e.name = 'AbortError'; return e; }
  }

  function assertNotAborted(signal) {
    if (signal?.aborted) throw abortError();
  }

  async function sleepAbortable(ms, signal) {
    assertNotAborted(signal);
    await new Promise((resolve, reject) => {
      const t = setTimeout(() => { signal?.removeEventListener('abort', onAbort); resolve(); }, ms);
      const onAbort = () => {
        clearTimeout(t);
        signal.removeEventListener('abort', onAbort);
        reject(abortError());
      };
      signal?.addEventListener('abort', onAbort, { once: true });
    });
    assertNotAborted(signal);
  }

  const normalizeInline = (value) => String(value || '')
    .replace(/\u00a0/g, ' ')
    .replace(/[ \t]+/g, ' ')
    .trim();

  const cleanText = (value) => String(value || '')
    .replace(/\u00a0/g, ' ')
    .replace(/\r/g, '')
    .split('\n')
    .map((line) => line.replace(/[ \t]+/g, ' ').trim())
    .filter(Boolean)
    .join('\n')
    .replace(/\n{3,}/g, '\n\n')
    .trim();

  function wordCount(value) {
    const text = cleanText(value);
    if (!text) return 0;
    return (text.match(/[\p{L}\p{N}]+(?:['’._-][\p{L}\p{N}]+)*/gu) || []).length;
  }

  const fold = (value) => normalizeInline(value)
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/đ/g, 'd')
    .replace(/Đ/g, 'D')
    .toLowerCase();

  const STOP = new Set([
    'cong','van','ve','viec','theo','cua','va','cac','cho','tai','tren','den','tu','so','ngay','nam','thang',
    'ubnd','hdnd','tinh','xa','signed','final','copy','ban','ky','da','file','dinh','kem'
  ]);

  function tokens(value) {
    return fold(value)
      .replace(/[^a-z0-9]+/g, ' ')
      .split(/\s+/)
      .filter((x) => x.length >= 3 && !STOP.has(x));
  }

  function jaccard(a, b) {
    const A = new Set(a);
    const B = new Set(b);
    if (!A.size || !B.size) return 0;
    let inter = 0;
    for (const x of A) if (B.has(x)) inter += 1;
    return inter / (A.size + B.size - inter);
  }

  function extensionOf(name) {
    const m = String(name || '').toLowerCase().match(/\.([a-z0-9]{2,5})$/);
    return m ? m[1] : '';
  }

  function canonicalStem(name) {
    return fold(String(name || '')
      .replace(/\.[a-z0-9]{2,5}$/i, '')
      .replace(/(?:\.signed)+/ig, '')
      .replace(/\bsigned\b/ig, '')
      .replace(/\bfinal\b/ig, '')
      .replace(/\bcopy\b/ig, '')
      .replace(/\bban\s*ky\b/ig, '')
      .replace(/\bda\s*ky\b/ig, '')
      .replace(/\bky\s*so\b/ig, '')
      .replace(/\(\s*\d+\s*\)$/g, ''))
      .replace(/[^a-z0-9]+/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
  }

  function fileNameSimilarity(a, b) {
    const sa = canonicalStem(a);
    const sb = canonicalStem(b);
    if (!sa || !sb) return 0;
    if (sa === sb) return 1;
    if (sa.includes(sb) || sb.includes(sa)) return Math.min(sa.length, sb.length) / Math.max(sa.length, sb.length);
    return jaccard(tokens(sa), tokens(sb));
  }

  function textSimilarity(a, b) {
    const ta = tokens(String(a || '').slice(0, 16000));
    const tb = tokens(String(b || '').slice(0, 16000));
    return jaccard(ta, tb);
  }

  function bytesToBase64(bytes) {
    if (!bytes?.length) return '';
    const chunk = 0x8000;
    let binary = '';
    for (let i = 0; i < bytes.length; i += chunk) {
      const slice = bytes.subarray(i, Math.min(bytes.length, i + chunk));
      binary += String.fromCharCode(...slice);
    }
    return btoa(binary);
  }

  function parseQuotedArgs(text) {
    const values = [];
    const re = /'((?:\\.|[^'])*)'|"((?:\\.|[^"])*)"/g;
    let m;
    while ((m = re.exec(text || ''))) {
      values.push((m[1] ?? m[2] ?? '').replace(/\\'/g, "'").replace(/\\"/g, '"'));
    }
    return values;
  }

  function stripActionWords(value) {
    let text = normalizeInline(value)
      .replace(/[|•·]+/g, ' ')
      .trim();
    // iOffice đôi khi ghép text nút trực tiếp vào tên tệp, ví dụ
    // "Xoá Đổi tên XemSố KH....docx". Chỉ bóc các nhãn hành động ở đầu chuỗi.
    const prefix = /^(?:(?:Xoá|Xóa)\s*|Đổi\s*tên\s*|Xem\s*tab\s*mới\s*|Xem\s*|Tải\s*tệp\s*tin\s*|Tải\s*file\s*|Tải\s*xuống\s*|Tải\s*về\s*|Ký\s*số\s*token\s*|Ký\s*SmartCA\s*|Ký\s*số\s*VGCA\s*|Ký\s*số\s*)+/i;
    for (let i = 0; i < 4; i++) {
      const next = text.replace(prefix, '').trim();
      if (next === text) break;
      text = next;
    }
    return text.replace(/\s+/g, ' ').trim();
  }

  function extractFilenameCandidate(value) {
    const text = stripActionWords(value);
    if (!text) return '';
    const matches = [];
    const re = /(?:^|[\s(])([^|<>]{1,240}?\.(?:pdf|docx?|xlsx?|xls|rtf|txt))(?:$|[\s)|])/gi;
    let m;
    while ((m = re.exec(` ${text} `))) {
      const name = normalizeInline(m[1] || '').replace(/^[\-–—:;,\s]+|[\-–—:;,\s]+$/g, '');
      if (name) matches.push(name);
    }
    if (!matches.length) return '';
    return matches.sort((a, b) => {
      const aa = /(?:signed|ký|ky)/i.test(a) ? 1 : 0;
      const bb = /(?:signed|ký|ky)/i.test(b) ? 1 : 0;
      return bb - aa || b.length - a.length;
    })[0];
  }

  function cleanFilenameFromNode(node) {
    if (!node) return '';

    try {
      const elements = node.matches?.('[onclick*="showFileNewTab"]')
        ? [node]
        : [...(node.querySelectorAll?.('[onclick*="showFileNewTab"]') || [])];
      for (const el of elements) {
        const args = parseQuotedArgs(el.getAttribute('onclick') || '');
        const fromArgs = extractFilenameCandidate(args[2] || '');
        if (fromArgs) return fromArgs;
      }
    } catch (_) {}

    try {
      for (const el of node.querySelectorAll?.('[data-file-name], [download], a[href], [title]') || []) {
        const candidates = [
          el.getAttribute('data-file-name'),
          el.getAttribute('download'),
          el.getAttribute('title'),
          (() => {
            try {
              const href = el.getAttribute('href') || '';
              const pathname = new URL(href, location.href).pathname;
              return decodeURIComponent(pathname.split('/').pop() || '');
            } catch (_) { return ''; }
          })(),
          el.childElementCount === 0 ? (el.textContent || '') : ''
        ];
        for (const value of candidates) {
          const name = extractFilenameCandidate(value || '');
          if (name) return name;
        }
      }
    } catch (_) {}

    return extractFilenameCandidate(node.innerText || node.textContent || '');
  }

  function looksLikeAttachmentName(text) {
    return /\.(?:pdf|docx?|xlsx?|xls|rtf|txt)(?:\s|$)/i.test(normalizeInline(text));
  }

  function sameDescriptorIdentity(a, b) {
    const aToken = String(a.viewerToken || '').trim();
    const bToken = String(b.viewerToken || '').trim();
    if (aToken && bToken && aToken === bToken) return true;

    const aFile = String(a.fileId || '').trim();
    const bFile = String(b.fileId || '').trim();
    if (aFile && bFile && aFile === bFile) return true;

    // Cùng đúng tên file thì chỉ là một tệp, dù iOffice render nó ở nhiều node/link khác nhau.
    const aName = fold(a.name || '');
    const bName = fold(b.name || '');
    // iOffice thường render cùng một tệp ở card + action/viewer khác token/id.
    // Tên file đầy đủ trùng nhau được xem là cùng một tệp để không bị 4 -> 8.
    if (aName && bName && aName === bName) return true;
    return false;
  }

  function addDescriptor(map, raw = {}) {
    const rawName = normalizeInline(raw.name || '');
    const name = extractFilenameCandidate(rawName) || rawName;
    if (!name || !looksLikeAttachmentName(name)) return;

    const item = {
      nodeId: raw.nodeId || '',
      fileId: raw.fileId || '',
      viewerToken: raw.viewerToken || '',
      viewerUrl: raw.viewerUrl || '',
      candidateUrls: Array.isArray(raw.candidateUrls) ? raw.candidateUrls : [],
      actionArgs: Array.isArray(raw.actionArgs) ? raw.actionArgs.map(x => String(x ?? '')) : [],
      name,
      date: raw.date || '',
      scopeKind: raw.scopeKind || 'attachment',
      ext: extensionOf(name),
      canonicalStem: canonicalStem(name)
    };

    for (const [key, existing] of map.entries()) {
      if (!sameDescriptorIdentity(existing, item)) continue;
      map.set(key, {
        ...existing,
        nodeId: existing.nodeId || item.nodeId,
        fileId: existing.fileId || item.fileId,
        viewerToken: existing.viewerToken || item.viewerToken,
        viewerUrl: existing.viewerUrl || item.viewerUrl,
        candidateUrls: [...new Set([...(existing.candidateUrls || []), ...(item.candidateUrls || [])])],
        actionArgs: (existing.actionArgs?.length ? existing.actionArgs : item.actionArgs),
        date: existing.date || item.date,
        scopeKind: existing.scopeKind === 'attachment' || item.scopeKind === 'attachment' ? 'attachment' : 'related'
      });
      return;
    }

    const key = item.viewerToken || item.fileId || `${item.scopeKind}|${fold(item.name)}`;
    map.set(key, item);
  }

  function collectUrlCandidates(node, args = []) {
    const values = [];
    const push = (value) => {
      value = String(value || '').trim();
      if (!value || /^(?:javascript:|#)/i.test(value)) return;
      // Tên tệp thuần trong argument không phải URL tải. Trước đây biến "abc.pdf" thành
      // URL tương đối của trang và tạo request rác/nhầm nguồn.
      if (/^[^/?#\\]+\.(?:pdf|docx?|xlsx?|xls|rtf|txt)$/i.test(value)) return;
      if (!/(?:https?:\/\/|^\/|^\.\.?\/|download|attachment|getfile|viewfile|viewer|filedownload|[?&](?:file|id)=)/i.test(value)) return;
      try { values.push(new URL(value, location.href).href); } catch (_) {}
    };
    for (const value of args) push(value);
    try {
      const elements = [node, ...(node?.querySelectorAll?.('a,button,[onclick],[href],[data-url],[data-href],[data-file-url],[data-download-url],[data-src]') || [])];
      for (const el of elements) {
        for (const attr of ['href','src','data-url','data-href','data-file-url','data-download-url','data-src']) push(el?.getAttribute?.(attr));
        const onclick = el?.getAttribute?.('onclick') || '';
        for (const value of parseQuotedArgs(onclick)) push(value);
        for (const match of onclick.matchAll(/(?:https?:\/\/|\/)[^'"\s)]+/g)) push(match[0]);
      }
    } catch (_) {}
    return [...new Set(values)];
  }

  function descriptorFromCard(node, scopeKind = 'attachment') {
    if (!node) return null;
    const actions = [];
    try {
      if (node.matches?.('[onclick*="showFileDinhKem"], [onclick*="showFileNewTab"]')) actions.push(node);
      actions.push(...(node.querySelectorAll?.('[onclick*="showFileDinhKem"], [onclick*="showFileNewTab"]') || []));
    } catch (_) {}

    let best = null;
    for (const el of actions) {
      const onclick = el?.getAttribute?.('onclick') || '';
      const args = parseQuotedArgs(onclick);
      const name = extractFilenameCandidate(args[2] || '');
      if (!name) continue;
      const score = (/showFileDinhKem/i.test(onclick) ? 20 : 10) + (args[0] ? 4 : 0) + (args[1] ? 4 : 0);
      if (!best || score > best.score) best = { el, onclick, args, name, score };
    }

    const hrefEl = node.querySelector?.('a[href*="viewer" i], iframe[src*="viewer" i]');
    const href = hrefEl?.getAttribute?.('href') || hrefEl?.getAttribute?.('src') || '';
    const args = best?.args || [];
    const name = best?.name || cleanFilenameFromNode(node);
    if (!name || !looksLikeAttachmentName(name)) return null;
    const candidateUrls = collectUrlCandidates(node, args);
    return {
      nodeId: node.id || '',
      fileId: args[0] || String(node.id || '').replace(/^file_/, '') || '',
      viewerToken: args[1] || '',
      viewerUrl: /viewer|pdf|file/i.test(href) ? href : '',
      candidateUrls,
      actionArgs: args,
      name: stripActionWords(name),
      date: args[3] || '',
      scopeKind
    };
  }

  function smallestFileContainerFromHeading(heading, maxDepth = 5) {
    if (!heading) return null;
    let best = null;
    let cur = heading.parentElement;
    for (let depth = 0; cur && depth < maxDepth; depth++, cur = cur.parentElement) {
      if (cur === document.body || cur === document.documentElement) break;
      const directCards = (() => {
        try { return [...cur.querySelectorAll(':scope > [id^="file_"]')]; } catch (_) { return []; }
      })();
      const anyCards = [...(cur.querySelectorAll?.('[id^="file_"]') || [])];
      const actions = [...(cur.querySelectorAll?.('[onclick*="showFileNewTab"]') || [])];
      const count = directCards.length || anyCards.length || actions.length;
      if (!count || count > 60) continue;
      // The nearest file section is authoritative; do not widen into neighboring documents.
      return cur;
    }
    return best;
  }

  function findExactSectionHeading(pattern) {
    for (const el of document.querySelectorAll('div,span,b,strong,h1,h2,h3,h4,h5,legend,th,td,label')) {
      if(el.childElementCount>2)continue;
      const text = normalizeInline(el.textContent || '');
      if (pattern.test(text)) return el;
    }
    return null;
  }

  function getDeclaredAttachmentCount() {
    const heading = findExactSectionHeading(/^(?:FILE|TỆP)\s+ĐÍNH\s+KÈM(?:\s*\((\d+)\))?$/i);
    if (heading) {
      const m = normalizeInline(heading.textContent || '').match(/\((\d+)\)/);
      if (m) return Math.max(0, Number(m[1]) || 0);
    }
    // Một số giao diện để số lượng ở node cha/cạnh tiêu đề. Chỉ đọc trong vùng chi tiết văn bản.
    const root = document.querySelector('#div_thongtin_chitiet, #rightContentDLK, #div_doc_detail');
    const text = normalizeInline(root?.innerText || '');
    const m = text.match(/(?:FILE|TỆP)\s+ĐÍNH\s+KÈM\s*\((\d+)\)/i);
    return m ? Math.max(0, Number(m[1]) || 0) : 0;
  }

  function getMainAttachmentRoot() {
    // Diagnostic iOffice Đắk Lắk xác nhận danh sách tệp chi tiết nằm ở #div_file_attach_dsvb.
    // Ưu tiên vùng này để tránh quét nhầm bản sao tệp trong modal/chuyển xử lý.
    for (const selector of ['#div_file_attach_dsvb', '#div_file_list']) {
      const direct = document.querySelector(selector);
      if (direct?.querySelector?.('[id^="file_"], [onclick*="showFileDinhKem"], [onclick*="showFileNewTab"]')) return direct;
    }

    // Một số màn hình không dùng các id trên: chỉ fallback theo đúng tiêu đề FILE/TỆP ĐÍNH KÈM.
    const heading = findExactSectionHeading(/^(?:FILE|TỆP)\s+ĐÍNH\s+KÈM(?:\s*\(\d+\))?$/i);
    return smallestFileContainerFromHeading(heading);
  }

  function getRelatedRoots() {
    // TUYỆT ĐỐI không dò theo id/class chứa "lienquan" vì iOffice có nhiều vùng nghiệp vụ
    // không phải danh sách tệp. Chỉ nhận vùng có tiêu đề hiển thị đúng "Văn bản liên quan".
    const roots = [];
    const headingPattern = /^VĂN\s+BẢN\s+LIÊN\s+QUAN(?:\s*\(\d+\))?$/i;
    for (const heading of document.querySelectorAll('div,span,b,strong,h1,h2,h3,h4,h5,legend,th,td,label')) {
      if(heading.childElementCount>2)continue;
      const text = normalizeInline(heading.textContent || '');
      if (!headingPattern.test(text)) continue;
      const root = smallestFileContainerFromHeading(heading);
      if (!root) continue;
      const main = getMainAttachmentRoot();
      if (main && (root === main || root.contains(main) || main.contains(root))) continue;
      if (!roots.some((x) => x === root || x.contains(root) || root.contains(x))) roots.push(root);
    }
    return roots;
  }

  function collectStrictRootDescriptors(root, scopeKind, found) {
    if (!root?.querySelectorAll) return;

    // iOffice thật đang render mỗi tệp thành một direct card #file_XXXXX bên trong #div_file_list.
    // Nếu đã có card direct thì chỉ đọc đúng các card này, TUYỆT ĐỐI không quét các link/action con lần nữa.
    let cards = [];
    try { cards = [...root.querySelectorAll(':scope > [id^="file_"]')]; } catch (_) {}
    if (root.id?.startsWith?.('file_')) cards.unshift(root);

    if (cards.length) {
      for (const card of cards) {
        const desc = descriptorFromCard(card, scopeKind);
        if (desc) addDescriptor(found, desc);
      }
      return;
    }

    // Với vùng "Văn bản liên quan" có thể không dùng #file_*. Khi đó mỗi showFileNewTab là một tệp.
    for (const el of root.querySelectorAll('[onclick*="showFileNewTab"], [onclick*="showFileDinhKem"]')) {
      const args = parseQuotedArgs(el.getAttribute('onclick') || '');
      const name = extractFilenameCandidate(args[2] || '');
      if (!name) continue;
      addDescriptor(found, {
        nodeId: el.closest('[id]')?.id || '',
        fileId: args[0] || '',
        viewerToken: args[1] || '',
        candidateUrls: collectUrlCandidates(el, args),
        actionArgs: args,
        name,
        date: args[3] || '',
        scopeKind
      });
    }
  }

  function getAttachmentDescriptors() {
    const found = new Map();
    const main = getMainAttachmentRoot();

    // Nguồn 1: chỉ đúng FILE/TỆP ĐÍNH KÈM của văn bản hiện tại.
    if (main) collectStrictRootDescriptors(main, 'attachment', found);

    // Nguồn 2: chỉ đúng VĂN BẢN LIÊN QUAN nếu thực sự có vùng này.
    for (const root of getRelatedRoots()) collectStrictRootDescriptors(root, 'related', found);

    return dedupeDescriptorList([...found.values()]);
  }

  function descriptorIdentityKey(desc) {
    const fileId = String(desc?.fileId || '').trim();
    const token = String(desc?.viewerToken || '').trim();
    const name = fold(stripActionWords(desc?.name || ''));
    if (fileId) return `id:${fileId}`;
    if (token) return `token:${token}`;
    return `name:${desc?.scopeKind || 'attachment'}:${name}`;
  }

  function mergeDescriptor(a, b) {
    return {
      ...a,
      nodeId: a.nodeId || b.nodeId,
      fileId: a.fileId || b.fileId,
      viewerToken: a.viewerToken || b.viewerToken,
      viewerUrl: a.viewerUrl || b.viewerUrl,
      candidateUrls: [...new Set([...(a.candidateUrls || []), ...(b.candidateUrls || [])])],
      actionArgs: a.actionArgs?.length ? a.actionArgs : (b.actionArgs || []),
      date: a.date || b.date,
      name: stripActionWords(a.name || b.name),
      scopeKind: a.scopeKind === 'attachment' || b.scopeKind === 'attachment' ? 'attachment' : 'related',
      ext: a.ext || b.ext,
      canonicalStem: a.canonicalStem || b.canonicalStem
    };
  }

  function dedupeDescriptorList(items) {
    const out = [];
    for (const raw of items || []) {
      const item = { ...raw, name: stripActionWords(raw?.name || '') };
      let index = out.findIndex((x) => sameDescriptorIdentity(x, item));
      if (index < 0) {
        const nk = fold(item.name || '');
        if (nk) index = out.findIndex((x) => fold(x.name || '') === nk);
      }
      if (index >= 0) out[index] = mergeDescriptor(out[index], item);
      else out.push(item);
    }
    return out;
  }

  function constrainDescriptorsToDeclared(items, declaredCount) {
    const list = dedupeDescriptorList(items || []);
    const declared = Math.max(0, Number(declaredCount) || 0);
    if (!declared) return list;
    const attachments = list.filter(x => x.scopeKind !== 'related');
    const related = list.filter(x => x.scopeKind === 'related');
    if (attachments.length <= declared) return list;
    // Tiêu đề FILE ĐÍNH KÈM (N) của iOffice là nguồn đếm chuẩn. Nếu DOM còn bản sao ẩn
    // (modal/chuyển xử lý), chỉ giữ đúng N descriptor đầu tiên từ vùng file chính.
    return [...attachments.slice(0, declared), ...related];
  }

  function getAttachmentNames() {
    return [...new Set(dedupeDescriptorList(getAttachmentDescriptors()).map((x) => x.name))];
  }

  const readMemory = new Map();
  const cacheKey = d => `${location.href}|${d.viewerToken||d.fileId}|${d.name}|${d.date}`;
  async function readCache(desc) {
    const item=readMemory.get(cacheKey(desc));
    return item && Date.now()-item.ts<300000 ? {...item,cached:true} : null;
  }
  async function writeCache(desc,value) {
    if(!value?.text || (!desc.viewerToken&&!desc.fileId))return;
    const key=cacheKey(desc);readMemory.delete(key);readMemory.set(key,{...value,ts:Date.now()});
    while(readMemory.size>30)readMemory.delete(readMemory.keys().next().value);
  }

  function makeViewerUrl(desc) {
    const direct = String(desc.viewerUrl || '').trim();
    if (direct) {
      try { return new URL(direct, location.href).href; } catch (_) {}
    }
    const token = String(desc.viewerToken || '').trim();
    if (!token) return '';
    if (/^https?:\/\//i.test(token)) return token;
    if (/viewer\.jsp\?/i.test(token)) return new URL(token, location.origin).href;
    // iOffice đang truyền chuỗi file-token vào showFileNewTab; giữ nguyên dấu & nếu token chứa tham số phụ.
    return `${location.origin}/qlvbdh_dlk/web/viewer.jsp?file=${token}`;
  }

  const MAX_ORIGINAL_FILE_BYTES = 50 * 1024 * 1024;

  function maxFileBytesFromOptions(options = {}) {
    const mb = Math.max(1, Math.min(50, Number(options.readerMaxFileSizeMb || 10)));
    return Math.round(mb * 1024 * 1024);
  }

  function tooLargeResult(desc, sizeBytes, options = {}, source = 'size-limit') {
    const mb = Math.max(1, Math.min(50, Number(options.readerMaxFileSizeMb || 10)));
    return { ...desc, text:'', chars:0, words:0, status:'file-too-large-skipped', source, sizeLimitSkipped:true, originalSizeBytes:Number(sizeBytes || 0), error:`Tệp vượt giới hạn ${mb} MB nên được bỏ qua.` };
  }

  function mimeForExt(ext) {
    return ({
      pdf:'application/pdf', doc:'application/msword', docx:'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      xls:'application/vnd.ms-excel', xlsx:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      rtf:'application/rtf', txt:'text/plain'
    })[String(ext || '').toLowerCase()] || 'application/octet-stream';
  }

  function observedCandidatesForDescriptor(desc, recentMs = 45000) {
    const now = Date.now();
    const token = String(desc.viewerToken || '').trim();
    const fileId = String(desc.fileId || '').trim();
    const foldedName = fold(desc.name || '');
    const stem = canonicalStem(desc.name || '');
    const scored = [];
    for (const item of observedNetwork) {
      if (now - item.ts > recentMs) continue;
      let decoded = '';
      try { decoded = decodeURIComponent(`${item.url} ${item.frameUrl}`); } catch (_) { decoded = `${item.url} ${item.frameUrl}`; }
      const f = fold(decoded);
      let score = 0;
      if (token && decoded.includes(token)) score += 8;
      if (fileId && new RegExp(`(?:[?&=/_-]|^)${fileId.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')}(?:[&#/_-]|$)`).test(decoded)) score += 7;
      if (foldedName && f.includes(foldedName)) score += 8;
      if (stem && stem.length >= 6 && f.includes(stem)) score += 5;
      let path = '';
      try { path = new URL(item.url, location.href).pathname.toLowerCase(); } catch (_) {}
      // CSS/JS/icon/locale của PDF.js không phải tài liệu. Không bao giờ đưa chúng
      // vào hàng đợi fetchOriginalFile, dù frameUrl có trùng viewer của tệp.
      if (/\/qlvbdh_dlk\/web\//i.test(path) && !/\/qlvbdh_dlk\/web\/viewer\.jsp$/i.test(path)) continue;
      if (/\/viewfile$|download|attachment|getfile|filedownload|document/i.test(path)) score += 2;
      if (score > 0) scored.push({ ...item, score });
    }
    return [...new Map(scored.sort((a,b)=>b.score-a.score||b.ts-a.ts).map(x=>[x.url,x])).values()].map(x=>x.url).slice(0,24);
  }


  function observedOversizeForDescriptor(desc, viewerUrl, maxBytes, notBefore = 0) {
    const now = Date.now();
    const token = String(desc.viewerToken || '').trim();
    const fileId = String(desc.fileId || '').trim();
    const nameFold = fold(desc.name || '');
    const stem = canonicalStem(desc.name || '');
    let viewerToken = '';
    try { viewerToken = viewerUrl ? (new URL(viewerUrl, location.href).searchParams.get('file') || '') : ''; } catch (_) {}
    let best = null;
    for (const item of observedNetwork) {
      const size = Number(item.contentLength || 0);
      if (!size || size <= maxBytes || now - item.ts > 180000 || (notBefore && item.ts < notBefore)) continue;
      let decoded = '';
      try { decoded = decodeURIComponent(`${item.url} ${item.frameUrl}`); } catch (_) { decoded = `${item.url} ${item.frameUrl}`; }
      const f = fold(decoded);
      let score = 0;
      if (viewerUrl && item.frameUrl === viewerUrl) score += 24;
      if (viewerToken) { try { if ((new URL(item.frameUrl || item.url, location.href).searchParams.get('file') || '') === viewerToken) score += 24; } catch (_) {} }
      if (token && decoded.includes(token)) score += 18;
      if (fileId && decoded.includes(fileId)) score += 14;
      if (nameFold && f.includes(nameFold)) score += 10;
      if (stem && stem.length >= 6 && f.includes(stem)) score += 5;
      if (/\/viewfile(?:[?#]|$)|download|attachment|getfile|filedownload/i.test(item.url || '')) score += 2;
      if (score >= 12 && (!best || score > best.score)) best = { sizeBytes:size, score, url:item.url };
    }
    return best;
  }

  function urlCandidatesForDescriptor(desc) {
    const out = [];
    const push = (value) => {
      value = String(value || '').trim();
      if (!value || /^(?:javascript:|#)/i.test(value)) return;
      try {
        const u = new URL(value, location.href);
        const path = u.pathname.toLowerCase();
        if (/\/qlvbdh_dlk\/web\//i.test(path) && !/\/qlvbdh_dlk\/web\/viewer\.jsp$/i.test(path)) return;
        out.push(u.href);
      } catch (_) {}
    };
    for (const u of desc.candidateUrls || []) push(u);
    for (const u of observedCandidatesForDescriptor(desc)) push(u);
    push(desc.viewerUrl);
    const token = String(desc.viewerToken || '').trim();
    if (/^(?:https?:\/\/|\/|\.\/|\.\.\/)/i.test(token) || /\.(?:pdf|docx?|xlsx?|xls|rtf|txt)(?:$|[?#])/i.test(token)) push(token);
    return [...new Set(out)];
  }

  function signatureKind(bytes) {
    if (!bytes?.length) return '';
    if (bytes.length >= 5 && String.fromCharCode(...bytes.slice(0,5)) === '%PDF-') return 'pdf';
    if (bytes.length >= 4 && bytes[0]===0x50 && bytes[1]===0x4b && [0x03,0x05,0x07].includes(bytes[2]) && [0x04,0x06,0x08].includes(bytes[3])) return 'zip';
    if (bytes.length >= 8 && bytes[0]===0xd0 && bytes[1]===0xcf && bytes[2]===0x11 && bytes[3]===0xe0 && bytes[4]===0xa1 && bytes[5]===0xb1 && bytes[6]===0x1a && bytes[7]===0xe1) return 'ole';
    const prefix = new TextDecoder('utf-8', {fatal:false}).decode(bytes.slice(0, Math.min(bytes.length, 500))).trimStart().toLowerCase();
    if (/^(?:<!doctype\s+html|<html|<head|<body)/.test(prefix)) return 'html';
    if (/^\{\\rtf/.test(prefix)) return 'rtf';
    return 'other';
  }

  function bytesCompatibleWithExt(bytes, ext, contentType = '') {
    const kind = signatureKind(bytes);
    ext = String(ext || '').toLowerCase();
    if (kind === 'html') return false;
    if (ext === 'pdf') return kind === 'pdf';
    if (ext === 'docx' || ext === 'xlsx') return kind === 'zip';
    if (ext === 'doc' || ext === 'xls') return kind === 'ole';
    if (ext === 'rtf') return kind === 'rtf' || /rtf/i.test(contentType);
    if (ext === 'txt') return kind !== 'pdf' && kind !== 'zip' && kind !== 'ole';
    return true;
  }

  async function readResponseLimited(response, maxBytes = MAX_ORIGINAL_FILE_BYTES, signal = null) {
    const len = Number(response.headers.get('content-length') || 0);
    if (len > maxBytes) throw new Error(`Tệp gốc lớn hơn ${(maxBytes/1024/1024).toFixed(0)} MB`);
    if (!response.body) {
      const buf = new Uint8Array(await response.arrayBuffer());
      if (buf.byteLength > maxBytes) throw new Error('Tệp gốc vượt giới hạn đọc');
      return buf;
    }
    const reader = response.body.getReader();
    const parts = []; let total = 0;
    try {
      while (true) {
        assertNotAborted(signal);
        const {done, value} = await reader.read();
        if (done) break;
        total += value.byteLength;
        if (total > maxBytes) { await reader.cancel(); throw new Error('Tệp gốc vượt giới hạn đọc'); }
        parts.push(value);
      }
    } finally { try { reader.releaseLock(); } catch (_) {} }
    const out = new Uint8Array(total); let off = 0;
    for (const part of parts) { out.set(part, off); off += part.byteLength; }
    return out;
  }

  function discoverFileUrlsFromHtml(html, baseUrl, fileName = '') {
    const values = [];
    const push = (value) => {
      value = String(value || '').replace(/&amp;/g,'&').trim();
      if (!value || /^(?:javascript:|#|data:)/i.test(value)) return;
      if (!/(?:download|file|document|attachment|view|\.pdf|\.docx?|\.xlsx?|\.xls|\.rtf|\.txt)/i.test(value)) return;
      try { values.push(new URL(value, baseUrl).href); } catch (_) {}
    };
    try {
      const doc = new DOMParser().parseFromString(html, 'text/html');
      for (const el of doc.querySelectorAll('[href],[src],[data-url],[data-file],[data-src],[data-download-url]')) {
        for (const attr of ['href','src','data-url','data-file','data-src','data-download-url']) push(el.getAttribute(attr));
      }
    } catch (_) {}
    for (const m of String(html || '').matchAll(/['\"]((?:https?:\/\/|\/|\.\/|\.\.\/)[^'\"]{3,500})['\"]/g)) push(m[1]);
    for (const m of String(html || '').matchAll(/['\"]([^'\"]{1,500}\.(?:pdf|docx?|xlsx?|xls|rtf|txt)(?:\?[^'\"]*)?)['\"]/gi)) push(m[1]);
    if (fileName) {
      const foldedName = fold(fileName);
      values.sort((a,b) => Number(fold(decodeURIComponent(b)).includes(foldedName)) - Number(fold(decodeURIComponent(a)).includes(foldedName)));
    }
    return [...new Set(values)].slice(0, 20);
  }

  function capturedFileForDescriptor(desc, options = {}) {
    const recentMs = Number(options.recentMs || 120000);
    const notBefore = Number(options.notBefore || 0);
    const allowConvertedPdf = options.allowConvertedPdf !== false;
    const viewerUrl = String(options.viewerUrl || desc.viewerUrl || '').trim();
    const now = Date.now();
    const token = String(desc.viewerToken || '').trim();
    const fileId = String(desc.fileId || '').trim();
    const nameFold = fold(desc.name || '');
    const stem = canonicalStem(desc.name || '');
    const ext = desc.ext || extensionOf(desc.name);
    const officeCanBecomePdf = ['doc','docx','xls','xlsx','rtf'].includes(ext);
    let viewerFileToken = '';
    try { viewerFileToken = viewerUrl ? (new URL(viewerUrl, location.href).searchParams.get('file') || '') : ''; } catch (_) {}
    const ranked = [];

    for (const item of capturedFiles) {
      if (!item?.bytes?.length || now - item.ts > recentMs || (notBefore && item.ts < notBefore)) continue;
      const kind = signatureKind(item.bytes);
      const originalCompatible = bytesCompatibleWithExt(item.bytes, ext, item.contentType);
      const convertedPdf = allowConvertedPdf && officeCanBecomePdf && kind === 'pdf';
      if (!originalCompatible && !convertedPdf) continue;

      let decoded = '';
      try { decoded = decodeURIComponent(`${item.url} ${item.frameUrl} ${item.filename}`); }
      catch (_) { decoded = `${item.url} ${item.frameUrl} ${item.filename}`; }
      const f = fold(decoded);
      let score = 0;

      let strongIdentity = false;
      if (viewerUrl) {
        try {
          const itemFrame = item.frameUrl ? new URL(item.frameUrl, location.href) : null;
          const wanted = new URL(viewerUrl, location.href);
          if (itemFrame && itemFrame.href === wanted.href && (wanted.searchParams.get('file') || wanted.search.length > 3)) { score += 40; strongIdentity = true; }
        } catch (_) {}
      }
      if (viewerFileToken && item.frameUrl) {
        try {
          const frameToken = new URL(item.frameUrl, location.href).searchParams.get('file') || '';
          if (frameToken && frameToken === viewerFileToken) { score += 32; strongIdentity = true; }
        } catch (_) {}
      }
      if (item.filename && fold(stripActionWords(item.filename)) === nameFold) { score += 20; strongIdentity = true; }
      else if (nameFold && f.includes(nameFold)) score += 6;
      if (stem && stem.length >= 6 && f.includes(stem)) score += 3;
      if (token && decoded.includes(token)) { score += 18; strongIdentity = true; }
      if (fileId && decoded.includes(fileId)) { score += 14; strongIdentity = true; }
      if (kind === 'pdf' && (ext === 'pdf' || convertedPdf)) score += 3;
      if (originalCompatible) score += 2;
      if (/\/viewfile(?:[?#]|$)/i.test(item.url || '')) score += 2;

      // Không bao giờ nhận bytes chỉ vì cùng stem/tên gần giống: đây là nguồn gây gán nhầm 1 PDF cho nhiều tệp.
      if (strongIdentity && score > 0) ranked.push({ item, score, kind, convertedPdf });
    }

    ranked.sort((a, b) => b.score - a.score || b.item.ts - a.item.ts);
    const best = ranked[0];
    if (!best || best.score < 12) return null;
    return {
      bytes: best.item.bytes,
      url: best.item.url,
      frameUrl: best.item.frameUrl,
      contentType: best.item.contentType,
      disposition: best.item.disposition,
      signature: best.kind,
      convertedPdf: best.convertedPdf,
      source: best.convertedPdf ? 'ioffice-viewer-pdf' : 'captured-original',
      capturedScore: best.score
    };
  }

  let viewerResolverBusy = false;
  async function withViewerResolverLock(signal, task) {
    while (viewerResolverBusy) await sleepAbortable(30, signal);
    assertNotAborted(signal);
    viewerResolverBusy = true;
    try {
      const result = await task();
      // Cho iOffice hoàn tất việc gán src/token cho viewer trước khi tạo viewer kế tiếp.
      await sleepAbortable(180, signal);
      return result;
    } finally {
      viewerResolverBusy = false;
    }
  }

  async function waitForCapturedFile(desc, viewerUrl, options = {}) {
    const signal = options.signal || null;
    const timeoutMs = Math.max(100, Math.min(8000, Number(options.timeoutMs || 1800)));
    const until = performance.now() + timeoutMs;
    do {
      assertNotAborted(signal);
      const found = capturedFileForDescriptor(desc, { viewerUrl, allowConvertedPdf: true, recentMs: 180000, notBefore:options.notBefore || 0 });
      if (found?.bytes?.length) return found;
      await sleepAbortable(70, signal);
    } while (performance.now() < until);
    return capturedFileForDescriptor(desc, { viewerUrl, allowConvertedPdf: true, recentMs: 180000, notBefore:options.notBefore || 0 });
  }

  async function resolveViewerUrlViaPage(desc, signal) {
    const args = Array.isArray(desc?.actionArgs) ? desc.actionArgs.map(x => String(x ?? '')) : [];
    if (!args.length) return '';
    assertNotAborted(signal);
    const requestId = `iof-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 9)}`;
    const result = await new Promise((resolve, reject) => {
      let done = false;
      const finish = (value) => {
        if (done) return;
        done = true;
        clearTimeout(timer);
        signal?.removeEventListener?.('abort', onAbort);
        pendingViewerResolvers.delete(requestId);
        resolve(value);
      };
      const onAbort = () => {
        if (done) return;
        done = true;
        clearTimeout(timer);
        pendingViewerResolvers.delete(requestId);
        reject(abortError());
      };
      const timer = setTimeout(() => finish({ ok:false, url:'', error:'resolve-timeout' }), 1100);
      pendingViewerResolvers.set(requestId, { resolve: finish });
      signal?.addEventListener?.('abort', onAbort, { once:true });
      try {
        window.postMessage({ channel: NETWORK_CHANNEL, type:'resolve-show-file', requestId, args, nodeId:String(desc?.nodeId || '') }, location.origin);
      } catch (_) { finish({ ok:false, url:'', error:'post-message-failed' }); }
    });
    assertNotAborted(signal);
    if (!result?.ok || !result.url) return '';
    try {
      const absolute = new URL(result.url, location.href);
      if (absolute.origin !== location.origin) return '';
      return absolute.href;
    } catch (_) { return ''; }
  }

  async function fetchOriginalFile(desc, options = {}) {
    const signal = options.signal || null;
    assertNotAborted(signal);
    const ext = desc.ext || extensionOf(desc.name);
    const maxFileBytes = maxFileBytesFromOptions(options);
    const capturedFirst = capturedFileForDescriptor(desc, { allowConvertedPdf:false, notBefore:options.notBefore || 0 });
    if (capturedFirst?.bytes?.length) {
      if (capturedFirst.bytes.byteLength > maxFileBytes) return { tooLarge:true, sizeBytes:capturedFirst.bytes.byteLength, url:capturedFirst.url || '', contentType:capturedFirst.contentType || '' };
      return capturedFirst;
    }
    const seen = new Set();
    const queue = urlCandidatesForDescriptor(desc).map(url => ({url, depth:0}));
    const diagnostics = [];
    while (queue.length) {
      assertNotAborted(signal);
      const {url, depth} = queue.shift();
      if (!url || seen.has(url) || seen.size > 28) continue;
      seen.add(url);
      let u;
      try { u = new URL(url, location.href); } catch (_) { continue; }
      if (u.origin !== location.origin) continue;
      // /viewfile chỉ hợp lệ khi chính viewer của iOffice đã tạo đủ query. Không tự gọi endpoint trần/thiếu tham số vì server trả HTTP500.
      if (/\/viewfile$/i.test(u.pathname)) {
        const keys = [...u.searchParams.keys()];
        if (!u.searchParams.has('file') || keys.length < 2) {
          diagnostics.push(`${u.pathname}:skip-incomplete-query`);
          continue;
        }
      }
      try {
        const response = await fetch(u.href, {credentials:'include', cache:'no-store', redirect:'follow', signal, headers:{'Accept':'*/*'}});
        if (!response.ok) { diagnostics.push(`${u.pathname}:HTTP${response.status}`); continue; }
        const contentType = response.headers.get('content-type') || '';
        const disposition = response.headers.get('content-disposition') || '';
        if (/text\/html|application\/xhtml/i.test(contentType)) {
          if (depth >= 1) continue;
          const htmlBytes = await readResponseLimited(response, 2 * 1024 * 1024, signal);
          const html = new TextDecoder('utf-8', {fatal:false}).decode(htmlBytes);
          for (const inner of discoverFileUrlsFromHtml(html, response.url || u.href, desc.name)) {
            if (!seen.has(inner)) queue.push({url:inner, depth:depth+1});
          }
          continue;
        }
        const len = Number(response.headers.get('content-length') || 0);
        if (len > maxFileBytes) return { tooLarge:true, sizeBytes:len, url:response.url || u.href, contentType, disposition };
        const bytes = await readResponseLimited(response, maxFileBytes, signal);
        if (!bytesCompatibleWithExt(bytes, ext, contentType)) {
          diagnostics.push(`${u.pathname}:signature-${signatureKind(bytes)}`);
          if (signatureKind(bytes) === 'html' && depth < 1) {
            const html = new TextDecoder().decode(bytes);
            for (const inner of discoverFileUrlsFromHtml(html, response.url || u.href, desc.name)) queue.push({url:inner, depth:depth+1});
          }
          continue;
        }
        return {bytes, url:response.url || u.href, contentType, disposition, source:'original-file'};
      } catch (error) {
        if (error?.name === 'AbortError') throw error;
        const message = String(error?.message || 'fetch-error');
        if (/vượt giới hạn đọc|lớn hơn\s+\d+\s*MB/i.test(message)) {
          return { tooLarge:true, sizeBytes:maxFileBytes + 1, url:u.href, contentType:'', disposition:'' };
        }
        diagnostics.push(`${u.pathname}:${message}`);
      }
    }
    const capturedLast = capturedFileForDescriptor(desc, { allowConvertedPdf:false, notBefore:options.notBefore || 0 });
    if (capturedLast?.bytes?.length) {
      if (capturedLast.bytes.byteLength > maxFileBytes) return { tooLarge:true, sizeBytes:capturedLast.bytes.byteLength, url:capturedLast.url || '', contentType:capturedLast.contentType || '' };
      return capturedLast;
    }
    return {bytes:null, url:'', contentType:'', source:'none', diagnostics};
  }

  function findEocd(bytes) {
    const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    const min = Math.max(0, bytes.length - 0x10000 - 22);
    for (let i = bytes.length - 22; i >= min; i--) if (view.getUint32(i, true) === 0x06054b50) return i;
    return -1;
  }

  function zipEntries(bytes) {
    const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    const eocd = findEocd(bytes);
    if (eocd < 0) throw new Error('ZIP không có central directory');
    const count = view.getUint16(eocd + 10, true);
    const cdOffset = view.getUint32(eocd + 16, true);
    const decoder = new TextDecoder('utf-8', {fatal:false});
    const entries = new Map(); let pos = cdOffset;
    for (let i=0; i<count && pos+46<=bytes.length; i++) {
      if (view.getUint32(pos,true)!==0x02014b50) break;
      const method=view.getUint16(pos+10,true), compSize=view.getUint32(pos+20,true), uncompSize=view.getUint32(pos+24,true);
      const nameLen=view.getUint16(pos+28,true), extraLen=view.getUint16(pos+30,true), commentLen=view.getUint16(pos+32,true), localOffset=view.getUint32(pos+42,true);
      const name=decoder.decode(bytes.slice(pos+46,pos+46+nameLen));
      entries.set(name,{name,method,compSize,uncompSize,localOffset});
      pos += 46+nameLen+extraLen+commentLen;
    }
    return entries;
  }

  async function unzipEntry(bytes, entry, maxBytes = 6 * 1024 * 1024) {
    if (!entry) return null;
    if (entry.uncompSize > maxBytes) throw new Error(`Mục ZIP ${entry.name} quá lớn`);
    const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    const off = entry.localOffset;
    if (off+30>bytes.length || view.getUint32(off,true)!==0x04034b50) throw new Error('ZIP local header lỗi');
    const nameLen=view.getUint16(off+26,true), extraLen=view.getUint16(off+28,true);
    const start=off+30+nameLen+extraLen, end=start+entry.compSize;
    if (end>bytes.length) throw new Error('ZIP data vượt kích thước');
    const raw=bytes.slice(start,end);
    if (entry.method===0) return raw;
    if (entry.method!==8) throw new Error(`ZIP compression ${entry.method} chưa hỗ trợ`);
    if (typeof DecompressionStream !== 'function') throw new Error('Chrome không hỗ trợ giải nén DOCX/XLSX');
    const ds = new DecompressionStream('deflate-raw');
    const stream = new Blob([raw]).stream().pipeThrough(ds);
    const out = new Uint8Array(await new Response(stream).arrayBuffer());
    if (out.byteLength > maxBytes) throw new Error('Dữ liệu giải nén vượt giới hạn');
    return out;
  }

  async function zipText(bytes, entries, name, maxBytes) {
    const part = await unzipEntry(bytes, entries.get(name), maxBytes);
    return part ? new TextDecoder('utf-8', {fatal:false}).decode(part) : '';
  }

  function xmlDoc(xml) {
    if (!xml) return null;
    const doc = new DOMParser().parseFromString(xml, 'application/xml');
    if (doc.querySelector('parsererror')) return null;
    return doc;
  }

  function docxXmlToText(xml) {
    const doc = xmlDoc(xml); if (!doc) return '';
    const out=[];
    const walk=(node)=>{
      if (node.nodeType!==1) return;
      const local=node.localName;
      if (local==='t') out.push(node.textContent || '');
      else if (local==='tab') out.push('\t');
      else if (local==='br' || local==='cr') out.push('\n');
      else {
        for (const child of node.children || []) walk(child);
        if (local==='p' || local==='tr') out.push('\n');
        else if (local==='tc') out.push('\t');
      }
    };
    walk(doc.documentElement);
    return cleanText(out.join('').replace(/\t+\n/g,'\n').replace(/\n{3,}/g,'\n\n'));
  }

  async function parseDocx(bytes, maxChars = MAX_FILE_CHARS) {
    const entries=zipEntries(bytes);
    if (!entries.has('word/document.xml')) throw new Error('Không thấy word/document.xml');
    const names=['word/document.xml', ...[...entries.keys()].filter(n=>/^word\/(?:header|footer)\d+\.xml$/i.test(n)).slice(0,8)];
    const texts=[];
    for (const name of names) {
      const xml=await zipText(bytes,entries,name,6*1024*1024);
      const text=docxXmlToText(xml); if(text)texts.push(text);
      if (texts.join('\n').length>=maxChars) break;
    }
    return cleanText(texts.join('\n\n')).slice(0,maxChars);
  }

  function colNumber(ref) {
    const m=String(ref||'').match(/^([A-Z]+)/i); if(!m)return 0;
    let n=0; for(const c of m[1].toUpperCase()) n=n*26+(c.charCodeAt(0)-64); return n;
  }

  async function parseXlsx(bytes, maxChars = MAX_FILE_CHARS) {
    const entries=zipEntries(bytes);
    let shared=[];
    if(entries.has('xl/sharedStrings.xml')){
      const doc=xmlDoc(await zipText(bytes,entries,'xl/sharedStrings.xml',8*1024*1024));
      if(doc) shared=[...doc.getElementsByTagNameNS('*','si')].map(si=>[...si.getElementsByTagNameNS('*','t')].map(t=>t.textContent||'').join(''));
    }
    const workbook=xmlDoc(await zipText(bytes,entries,'xl/workbook.xml',3*1024*1024));
    const rels=xmlDoc(await zipText(bytes,entries,'xl/_rels/workbook.xml.rels',3*1024*1024));
    const relMap=new Map();
    if(rels) for(const r of rels.getElementsByTagNameNS('*','Relationship')) relMap.set(r.getAttribute('Id'),r.getAttribute('Target'));
    const sheets=[];
    if(workbook){
      for(const s of workbook.getElementsByTagNameNS('*','sheet')){
        const rid=s.getAttributeNS('http://schemas.openxmlformats.org/officeDocument/2006/relationships','id') || s.getAttribute('r:id') || '';
        let target=relMap.get(rid)||''; if(target) target=target.replace(/^\//,'').replace(/^\.\.\//,'');
        if(target && !target.startsWith('xl/')) target='xl/'+target;
        sheets.push({name:s.getAttribute('name')||'Sheet',target});
      }
    }
    if(!sheets.length) for(const name of [...entries.keys()].filter(n=>/^xl\/worksheets\/sheet\d+\.xml$/i.test(n)).slice(0,20)) sheets.push({name:name.split('/').pop(),target:name});
    const out=[];
    for(const sheet of sheets.slice(0,20)){
      if(!entries.has(sheet.target))continue;
      const doc=xmlDoc(await zipText(bytes,entries,sheet.target,10*1024*1024)); if(!doc)continue;
      out.push(`Sheet: ${sheet.name}`);
      for(const row of doc.getElementsByTagNameNS('*','row')){
        const vals=[]; let lastCol=0;
        for(const c of row.getElementsByTagNameNS('*','c')){
          const col=colNumber(c.getAttribute('r')); while(lastCol && col>lastCol+1 && vals.length<40){vals.push('');lastCol++;}
          const type=c.getAttribute('t')||''; let value='';
          if(type==='inlineStr') value=[...c.getElementsByTagNameNS('*','t')].map(t=>t.textContent||'').join('');
          else {
            const v=c.getElementsByTagNameNS('*','v')[0]?.textContent || '';
            value=type==='s' ? (shared[Number(v)] ?? v) : v;
          }
          vals.push(value); lastCol=col||lastCol+1;
        }
        const line=vals.join('\t').trim(); if(line)out.push(line);
        if(out.join('\n').length>=maxChars)break;
      }
      if(out.join('\n').length>=maxChars)break;
    }
    return cleanText(out.join('\n')).slice(0,maxChars);
  }

  function decodeTextBytes(bytes) {
    let text=new TextDecoder('utf-8',{fatal:false}).decode(bytes);
    const bad=(text.match(/�/g)||[]).length;
    if(bad > Math.max(2,text.length/150)){
      try{text=new TextDecoder('windows-1258',{fatal:false}).decode(bytes);}catch(_){}
    }
    return cleanText(text);
  }

  function parseRtf(text) {
    return cleanText(String(text||'')
      .replace(/\\'([0-9a-fA-F]{2})/g,(_,h)=>String.fromCharCode(parseInt(h,16)))
      .replace(/\\u(-?\d+)\??/g,(_,n)=>String.fromCharCode((Number(n)+65536)%65536))
      .replace(/\\(?:par|line)\b/g,'\n')
      .replace(/\\tab\b/g,'\t')
      .replace(/\\[a-zA-Z]+-?\d* ?/g,'')
      .replace(/[{}]/g,' '));
  }

  async function parseOriginalText(desc, original, options = {}) {
    if(!original?.bytes?.length)return null;
    const ext=String(desc.ext||extensionOf(desc.name)).toLowerCase();
    const maxChars=Math.max(500,Math.min(MAX_FILE_CHARS,Number(options.maxChars||MAX_FILE_CHARS)));
    let text='';
    if(ext==='docx') text=await parseDocx(original.bytes,maxChars);
    else if(ext==='xlsx') text=await parseXlsx(original.bytes,maxChars);
    else if(ext==='txt') text=decodeTextBytes(original.bytes).slice(0,maxChars);
    else if(ext==='rtf') text=parseRtf(decodeTextBytes(original.bytes)).slice(0,maxChars);
    else return null;
    return {text,source:`original-${ext}`,status:text.length>=20?'text':'original-no-text',originalBytes:original.bytes,originalSizeBytes:original.bytes.byteLength,originalUrl:original.url,originalMimeType:original.contentType||mimeForExt(ext)};
  }


  function collectTextLayersFromRoot(root, out, depth = 0) {
    if (!root || depth > 5) return;
    const selectors = [
      '.textLayer', '.text-layer', '[class*="textLayer"]', '[class*="text-layer"]',
      '[data-testid*="text-layer" i]', '[data-test-id*="text-layer" i]',
      '[data-ioffice-ocr-text]'
    ];
    for (const selector of selectors) {
      try {
        for (const el of root.querySelectorAll(selector)) {
          const text = cleanText(el.innerText || el.textContent || '');
          if (text.length >= 20) out.push(text);
        }
      } catch (_) {}
    }
    // PDF/OCR viewer có thể để text layer trong Shadow DOM.
    try {
      for (const el of root.querySelectorAll('*')) {
        if (el.shadowRoot) collectTextLayersFromRoot(el.shadowRoot, out, depth + 1);
      }
    } catch (_) {}
  }

  function cleanViewerBodyText(text) {
    return cleanText(text)
      .replace(/^Bật\/Tắt thanh lề[\s\S]{0,1200}?(?=\b1\b\s|UBND|CỘNG HÒA|SỞ |BỘ |ỦY BAN|HỘI ĐỒNG)/i, '')
      .replace(/^(?:viewfile|tự động chọn kích thước|về xem mặc định|trên\s+\d+)[\s\S]{0,500}?(?=UBND|CỘNG HÒA|SỞ |BỘ |ỦY BAN|HỘI ĐỒNG)/i, '')
      .slice(0, MAX_FILE_CHARS);
  }

  function extractRenderedTextFromDocument(doc, allowBodyFallback = true) {
    if (!doc) return '';
    const layers = [];
    collectTextLayersFromRoot(doc, layers);
    const unique = [...new Set(layers.map(cleanText).filter((x) => x.length >= 20))];
    const layerText = cleanText(unique.join('\n\n'));
    if (layerText.length >= 80) return layerText.slice(0, MAX_FILE_CHARS);

    // Viewer same-origin đôi khi không dùng class textLayer nhưng body vẫn chứa OCR/copy text.
    if (allowBodyFallback) {
      const body = cleanViewerBodyText(doc.body?.innerText || '');
      if (body.length >= 120 && /(?:UBND|CỘNG HÒA|SỞ |BỘ |ỦY BAN|HỘI ĐỒNG|BÁO CÁO|Kính gửi|Số:)/i.test(body)) {
        return body;
      }
    }
    return '';
  }

  function extractRenderedText(frame) {
    try {
      const doc = frame.contentDocument;
      return extractRenderedTextFromDocument(doc);
    } catch (_) {
      return '';
    }
  }

  function readFrameMain(frame, options={}) {
    const signal=options.signal,id=crypto.randomUUID();
    assertNotAborted(signal);
    return new Promise((resolve,reject)=>{
      let settled=false;
      const timeoutMs=Math.max(9000,Number(options.appTimeoutMs)||28000);
      let retryTimer=null;
      const finish=(error,value)=>{
        if(settled)return;settled=true;clearTimeout(timer);clearInterval(retryTimer);
        window.removeEventListener('message',onMessage);signal?.removeEventListener('abort',onAbort);
        error?reject(error):resolve(value);
      };
      const send=type=>{try{frame.contentWindow.postMessage({channel:'ioffice-reader-v2',type,id,maxChars:options.maxChars,maxPages:options.maxPages,captureScanBinary:options.captureScanBinary!==false,tryIofficeOcr:options.tryIofficeOcr!==false,timeoutMs:Math.max(timeoutMs,26000)},location.origin);}catch(_){} };
      const onAbort=()=>{send('cancel');finish(abortError());};
      const onMessage=event=>{
        if(event.source!==frame.contentWindow||event.origin!==location.origin||event.data?.channel!=='ioffice-reader-v2'||event.data?.id!==id)return;
        const r=event.data;finish(null,r.ok?r.data:null);
      };
      const timer=setTimeout(()=>{send('cancel');finish(null,null);},timeoutMs);
      window.addEventListener('message',onMessage);signal?.addEventListener('abort',onAbort,{once:true});
      send('read');
      // viewer-main có thể được inject sau khi iframe load; gửi lại cùng id để không bỏ lỡ lệnh đầu.
      retryTimer=setInterval(()=>{if(!settled)send('read');},700);
    });
  }

  function recentCopiedTextForFrame(frame) {
    const now = Date.now();
    let src = '';
    try { src = String(frame?.src || frame?.contentWindow?.location?.href || ''); } catch (_) {}
    let fileKey = '';
    try { fileKey = new URL(src, location.href).searchParams.get('file') || ''; } catch (_) {}
    for (let i = capturedCopyTexts.length - 1; i >= 0; i--) {
      const item = capturedCopyTexts[i];
      if (now - item.ts > 90000) break;
      if (!item.text || item.text.length < 120) continue;
      if (!src) return item.text;
      if (item.frameUrl === src) return item.text;
      try {
        const k = new URL(item.frameUrl, location.href).searchParams.get('file') || '';
        if (fileKey && k && fileKey === k) return item.text;
      } catch (_) {}
    }
    return '';
  }

  async function extractFromFrame(frame, sourceLabel, options={}) {
    if(/\.docx?$/i.test(options.fileName||'')){const text=extractRenderedText(frame);if(text.length>=120)return{text,source:'word-viewer',status:'text'};}
    const data=await readFrameMain(frame,options);
    assertNotAborted(options.signal);
    if(data?.text?.length>=120)return data;
    if (options.tryIofficeOcr !== false) {
      const copied = recentCopiedTextForFrame(frame);
      if (copied.length >= 120) return { ...data, text: copied, source:'ioffice-copy-captured', status:'ocr-text' };
    }
    if(data?.scanBytes?.length||data?.status==='scan-too-large')return data;
    const text=extractRenderedText(frame);
    return {text,source:sourceLabel,status:text.length>=120?'viewer-ocr-or-text':'scan-no-text',pagesRead:data?.pagesRead||0,totalPages:data?.totalPages||0};
  }

  function currentViewerFrames() {
    const out = [];
    for (const frame of document.querySelectorAll('iframe')) {
      const src = frame.getAttribute('src') || '';
      let readable = false;
      try { readable = Boolean(frame.contentDocument?.body); } catch (_) {}
      if (/viewer|viewfile|pdf|document|file/i.test(src) || readable) out.push(frame);
    }
    return out;
  }

  function descriptorPriority(desc, meta) {
    const subject = meta?.trichYeu || '';
    const symbol = fold(meta?.symbol || meta?.soKyHieu || meta?.soHieu || '');
    const nameFold = fold(desc?.name || '');
    let score = subjectSimilarity(subject, desc?.name || '', '');
    if (symbol && nameFold.includes(symbol)) score += 0.4;
    if (['doc', 'docx'].includes(desc?.ext)) score += 0.08;
    if (desc?.ext === 'pdf') score += 0.05;
    if (looksSupporting(desc?.name || '')) score -= 0.14;
    if (desc?.scopeKind === 'related') score -= 0.05;
    return score;
  }

  function isLikelySignedPdf(desc) {
    return desc?.ext === 'pdf' && /(?:signed|ký|ky|ban\s*ky|da\s*ky)/i.test(fold(desc?.name || ''));
  }

  function buildReadGroups(descriptors, meta) {
    const byStem = new Map();
    for (const desc of descriptors) {
      const key = desc.canonicalStem || `__${desc.scopeKind}|${fold(desc.name)}`;
      if (!byStem.has(key)) byStem.set(key, []);
      byStem.get(key).push(desc);
    }
    return [...byStem.values()]
      .map((items) => ({
        items: items.sort((a, b) => descriptorPriority(b, meta) - descriptorPriority(a, meta)),
        priority: Math.max(...items.map((x) => descriptorPriority(x, meta)))
      }))
      .sort((a, b) => b.priority - a.priority);
  }

  async function runBounded(items, limit, mapper) {
    const results = new Array(items.length);
    let cursor = 0;
    const workers = Array.from({ length: Math.max(1, Math.min(limit, items.length || 1)) }, async (_, workerIndex) => {
      while (true) {
        const index = cursor++;
        if (index >= items.length) break;
        results[index] = await mapper(items[index], index, workerIndex + 1);
      }
    });
    await Promise.all(workers);
    return results;
  }

  async function readDescriptorTimed(desc, readOptions, parentSignal, timeoutMs) {
    const controller = new AbortController();
    let timedOut = false;
    const relayAbort = () => controller.abort();
    if (parentSignal) {
      if (parentSignal.aborted) throw abortError();
      parentSignal.addEventListener('abort', relayAbort, { once: true });
    }
    const timer = setTimeout(() => { timedOut = true; controller.abort(); }, timeoutMs);
    try {
      return await extractDescriptor(desc, { ...readOptions, signal: controller.signal });
    } catch (error) {
      if (parentSignal?.aborted) throw abortError();
      if (timedOut || error?.name === 'AbortError') {
        return { ...desc, text: '', chars: 0, status: 'timeout', source: 'timeout', error: `Timeout ${Math.round(timeoutMs / 1000)}s` };
      }
      return { ...desc, text: '', chars: 0, status: 'reader-error', source: 'none', error: error?.message || String(error) };
    } finally {
      clearTimeout(timer);
      parentSignal?.removeEventListener?.('abort', relayAbort);
    }
  }

  let activeHiddenViewers = 0;
  function adaptiveHiddenViewerConcurrency() {
    const cpu = Math.max(1, Number(navigator.hardwareConcurrency || 4));
    const mem = Number(navigator.deviceMemory || 0);
    if (navigator.connection?.saveData) return 1;
    let n = cpu >= 16 ? 4 : cpu >= 8 ? 3 : cpu >= 6 ? 2 : 1;
    if (mem && mem < 4) n = 1;
    else if (mem && mem < 8) n = Math.min(n, 2);
    return Math.max(1, Math.min(4, n));
  }
  async function withHiddenViewerSlot(signal, task) {
    const maxHidden = adaptiveHiddenViewerConcurrency();
    while (activeHiddenViewers >= maxHidden) await sleepAbortable(35, signal);
    assertNotAborted(signal);
    activeHiddenViewers += 1;
    try { return await task(); }
    finally { activeHiddenViewers = Math.max(0, activeHiddenViewers - 1); }
  }

  async function extractDescriptor(desc, options = {}) {
    const signal = options.signal || null;
    assertNotAborted(signal);
    const partial = Boolean(options.partial);
    const forceFresh = Boolean(options.forceFresh);
    const captureNotBefore = forceFresh ? Date.now() - 25 : Number(options.notBefore || 0);
    const cached = (partial || forceFresh) ? null : await readCache(desc);
    assertNotAborted(signal);
    if (cached?.text) return { ...desc, ...cached, chars: cached.text.length };

    const ext = String(desc.ext || extensionOf(desc.name)).toLowerCase();
    const maxFileBytes = maxFileBytesFromOptions(options);
    const supported = ['pdf','doc','docx','xls','xlsx','rtf','txt'].includes(ext);
    let original = null;
    let originalFailure = '';
    let viewerUrl = String(desc.viewerUrl || '').trim();

    // 1) Luôn hỏi chính iOffice để lấy URL viewer thật. Không tự dựng /viewfile.
    if (Array.isArray(desc.actionArgs) && desc.actionArgs.length) {
      try {
        const actualViewer = await withViewerResolverLock(signal, () => resolveViewerUrlViaPage(desc, signal));
        if (actualViewer) {
          viewerUrl = actualViewer;
          desc = { ...desc, viewerUrl: actualViewer, candidateUrls: [...new Set([actualViewer, ...(desc.candidateUrls || [])])] };
        }
      } catch (error) {
        if (error?.name === 'AbortError') throw error;
        originalFailure = error?.message || String(error);
      }
    }

    // Nếu người dùng vừa mở đúng file, network-tap có thể đã bắt được file gốc hoặc PDF iOffice chuyển đổi.
    const preCaptured = capturedFileForDescriptor(desc, { viewerUrl, allowConvertedPdf:true, recentMs:180000, notBefore:captureNotBefore });
    if (preCaptured?.bytes?.length > maxFileBytes) return tooLargeResult(desc, preCaptured.bytes.byteLength, options, 'captured-size-limit');
    if (preCaptured?.bytes?.length && !preCaptured.convertedPdf && ['docx','xlsx','txt','rtf'].includes(ext)) {
      try {
        const parsed = await parseOriginalText(desc, preCaptured, options);
        if (parsed?.text?.length >= 20) {
          const result = { ...desc, ...parsed, source:`captured-${ext}`, chars:parsed.text.length, words:wordCount(parsed.text) };
          if (!partial) await writeCache(desc, result);
          return result;
        }
      } catch (error) { originalFailure ||= error?.message || String(error); }
    }

    const resolvedViewer = (() => {
      try { return viewerUrl || (makeViewerUrl(desc) ? new URL(makeViewerUrl(desc), location.href).href : ''); }
      catch (_) { return viewerUrl || ''; }
    })();

    const observedOversize = observedOversizeForDescriptor(desc, resolvedViewer, maxFileBytes, captureNotBefore);
    if (observedOversize) return tooLargeResult(desc, observedOversize.sizeBytes, options, 'network-size-limit');

    const frameMatchesDescriptor = (frame) => {
      const src = frame.getAttribute('src') || '';
      const token = String(desc.viewerToken || '').trim();
      const fileId = String(desc.fileId || '').trim();
      let absolute = '', activeToken = '', decoded = '';
      try {
        absolute = new URL(src, location.href).href;
        activeToken = new URL(absolute).searchParams.get('file') || '';
        decoded = decodeURIComponent(absolute);
      } catch (_) {}
      if (resolvedViewer && absolute === resolvedViewer) {
        try { const u = new URL(absolute); if (u.searchParams.get('file') || u.search.length > 3) return true; } catch (_) {}
      }
      if (token && (activeToken === token || decoded.includes(token))) return true;
      if (fileId && decoded && new RegExp(`(?:[?&=/]|^)${fileId.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')}(?:[&#/]|$)`).test(decoded)) return true;
      return false;
    };

    const finishViewerResult = async (data, usedViewerUrl, sourceLabel) => {
      assertNotAborted(signal);
      const text = data?.text || '';
      if (text.length >= 20) {
        const result = { ...desc, ...data, text, chars:text.length, words:wordCount(text), source:data?.source || sourceLabel };
        if (!partial) await writeCache(desc, result);
        return result;
      }
      // v0.15.1: tạm bỏ qua PDF scan. Không OCR và không giữ bytes để upload AI.
      if (ext === 'pdf' && options.tryIofficeOcr === false && options.captureScanBinary === false &&
          /scan-no-text|scan-no-ocr-text|scan-ready-for-ai|scan-too-large/i.test(String(data?.status || ''))) {
        return { ...desc, text:'', chars:0, words:0, status:'pdf-scan-skipped', source:data?.source || sourceLabel, scanSkipped:true };
      }
      if (data?.scanBytes?.length || data?.status === 'scan-too-large') {
        return { ...desc, ...data, text:'', chars:0, words:0, source:data?.source || sourceLabel };
      }

      // iOffice có thể chuyển DOC/DOCX/XLS/XLSX thành PDF trước khi viewer đọc. Bắt chính bytes PDF đó làm fallback cho AI/OCR.
      const converted = await waitForCapturedFile(desc, usedViewerUrl, { signal, timeoutMs:['doc','docx','xls','xlsx'].includes(ext) ? 3500 : 1600, notBefore:captureNotBefore });
      if (converted?.bytes?.length && converted.signature === 'pdf') {
        if (ext === 'pdf' && options.captureScanBinary === false) {
          return { ...desc, text:'', chars:0, words:0, status:'pdf-scan-skipped', source:converted.convertedPdf ? 'ioffice-converted-pdf' : 'captured-pdf', scanSkipped:true, originalUrl:converted.url, viewerUrl:usedViewerUrl };
        }
        const sizeBytes = converted.bytes.byteLength;
        if (sizeBytes <= MAX_SCAN_FILE_BYTES) {
          return { ...desc, text:'', chars:0, words:0, status:'scan-ready-for-ai', source:converted.convertedPdf ? 'ioffice-converted-pdf' : 'captured-pdf', scanBytes:converted.bytes, scanSizeBytes:sizeBytes, originalUrl:converted.url, viewerUrl:usedViewerUrl };
        }
        return { ...desc, text:'', chars:0, words:0, status:'scan-too-large', source:converted.convertedPdf ? 'ioffice-converted-pdf' : 'captured-pdf', scanSizeBytes:sizeBytes, originalUrl:converted.url, viewerUrl:usedViewerUrl };
      }
      return null;
    };

    // 2) Ưu tiên viewer đang mở của đúng tệp.
    const existing = forceFresh ? null : currentViewerFrames().find(frameMatchesDescriptor);
    if (existing) {
      try {
        const data = await extractFromFrame(existing, 'current-viewer', { ...options, signal, fileName:desc.name, tryIofficeOcr:options.tryIofficeOcr!==false, appTimeoutMs:Math.min(68000, Math.max(50000, Number(options.appTimeoutMs || 62000))) });
        const result = await finishViewerResult(data, existing.src || resolvedViewer, 'current-viewer');
        if (result) return result;
      } catch (error) {
        if (error?.name === 'AbortError') throw error;
        originalFailure ||= error?.message || String(error);
      }
    }

    // 3) Mở viewer ẩn đúng URL do iOffice tạo. Đây là đường chính cho PDF và Office cũ do iOffice tự chuyển sang PDF.
    const url = resolvedViewer || makeViewerUrl(desc);
    if (url && supported) {
      const viewerResult = await withHiddenViewerSlot(signal, async () => {
        let frame = null;
        try {
          if (new URL(url, location.href).origin !== location.origin) return null;
          frame = document.createElement('iframe');
          frame.setAttribute('aria-hidden', 'true');
          frame.style.cssText = 'position:fixed;left:-12000px;top:0;width:900px;height:700px;opacity:.01;pointer-events:none;z-index:-1;border:0';
          const loaded = new Promise(resolve => frame.addEventListener('load', resolve, { once:true }));
          frame.src = url;
          document.documentElement.appendChild(frame);
          await Promise.race([loaded, sleepAbortable(6500, signal)]);
          assertNotAborted(signal);

          // network-tap chạy trong chính viewer.jsp và bắt GET /viewfile cùng bytes thật.
          const captured = await waitForCapturedFile(desc, url, { signal, timeoutMs:['doc','docx','xls','xlsx'].includes(ext) ? 4500 : 2200, notBefore:captureNotBefore });
          if (captured?.bytes?.length > maxFileBytes) return tooLargeResult(desc, captured.bytes.byteLength, options, 'viewer-size-limit');
          const lateOversize = observedOversizeForDescriptor(desc, url, maxFileBytes, captureNotBefore);
          if (lateOversize) return tooLargeResult(desc, lateOversize.sizeBytes, options, 'network-size-limit');
          if (captured?.bytes?.length && !captured.convertedPdf && ['docx','xlsx','txt','rtf'].includes(ext)) {
            try {
              const parsed = await parseOriginalText(desc, captured, options);
              if (parsed?.text?.length >= 20) return { ...desc, ...parsed, source:`captured-${ext}`, chars:parsed.text.length, words:wordCount(parsed.text) };
            } catch (error) { originalFailure ||= error?.message || String(error); }
          }

          const data = await extractFromFrame(frame, 'hidden-viewer', { ...options, signal, fileName:desc.name, tryIofficeOcr:options.tryIofficeOcr!==false, appTimeoutMs:Math.min(68000, Math.max(50000, Number(options.appTimeoutMs || 62000))) });
          return await finishViewerResult(data, url, 'hidden-viewer');
        } catch (error) {
          if (error?.name === 'AbortError') throw error;
          originalFailure ||= error?.message || String(error);
          return null;
        } finally {
          try { frame?.remove(); } catch (_) {}
        }
      });
      if (viewerResult) {
        if (!partial && viewerResult.text) await writeCache(desc, viewerResult);
        return viewerResult;
      }
    }

    // 4) Fallback file gốc. Chỉ chạy sau viewer để tận dụng các request thật mà iOffice vừa làm lộ.
    if (['docx','xlsx','txt','rtf','doc','xls','pdf'].includes(ext)) {
      try {
        original = await fetchOriginalFile(desc, { ...options, signal, notBefore:captureNotBefore });
        assertNotAborted(signal);
        if (original?.tooLarge) return tooLargeResult(desc, original.sizeBytes, options, 'original-size-limit');
        if (original?.bytes?.length && ['docx','xlsx','txt','rtf'].includes(ext)) {
          const parsed = await parseOriginalText(desc, original, options);
          if (parsed?.text?.length >= 20) {
            const result = { ...desc, ...parsed, chars:parsed.text.length, words:wordCount(parsed.text) };
            if (!partial) await writeCache(desc, result);
            return result;
          }
        }
      } catch (error) {
        if (error?.name === 'AbortError') throw error;
        originalFailure ||= error?.message || String(error);
      }
    }

    // 5) Nếu đã có PDF (gốc hoặc iOffice chuyển đổi) nhưng không có text, chuyển nguyên PDF cho AI/OCR.
    const capturedPdf = capturedFileForDescriptor(desc, { viewerUrl:url, allowConvertedPdf:true, recentMs:180000, notBefore:captureNotBefore });
    const pdfBytes = capturedPdf?.signature === 'pdf' ? capturedPdf : (original?.bytes?.length && signatureKind(original.bytes)==='pdf' ? original : null);
    if (pdfBytes?.bytes?.length && options.captureScanBinary === false && ext === 'pdf') {
      return { ...desc, text:'', chars:0, words:0, status:'pdf-scan-skipped', source:capturedPdf?.convertedPdf ? 'ioffice-converted-pdf' : 'original-pdf', scanSkipped:true, originalUrl:pdfBytes.url };
    }
    if (pdfBytes?.bytes?.length && options.captureScanBinary !== false) {
      const sizeBytes = pdfBytes.bytes.byteLength;
      if (sizeBytes <= MAX_SCAN_FILE_BYTES) {
        return { ...desc, text:'', chars:0, words:0, status:'scan-ready-for-ai', source:capturedPdf?.convertedPdf ? 'ioffice-converted-pdf' : 'original-pdf', scanBytes:pdfBytes.bytes, scanSizeBytes:sizeBytes, originalUrl:pdfBytes.url };
      }
      return { ...desc, text:'', chars:0, words:0, status:'scan-too-large', source:capturedPdf?.convertedPdf ? 'ioffice-converted-pdf' : 'original-pdf', scanSizeBytes:sizeBytes, originalUrl:pdfBytes.url };
    }

    if (original?.bytes?.length && ['doc','xls'].includes(ext)) {
      return { ...desc, text:'', chars:0, words:0, status:'legacy-binary-unparsed', source:'original-file', originalSizeBytes:original.bytes.byteLength, error:'Đã lấy file gốc Office đời cũ nhưng iOffice viewer không tạo được text/PDF chuyển đổi.' };
    }
    const diagnostics = Array.isArray(original?.diagnostics) ? original.diagnostics.slice(-4).join(' · ') : '';
    return {
      ...desc,
      text:'', chars:0, words:0,
      status: url ? 'viewer-no-text' : 'no-file-source',
      source:'none',
      error: originalFailure || (diagnostics ? `Đã thử viewer thật và nguồn file nhưng chưa lấy được dữ liệu (${diagnostics}).` : 'Không lấy được nội dung từ viewer thật của iOffice hoặc file gốc.')
    };
  }

  function subjectSimilarity(subject, name, text) {
    const subjectTokens = tokens(subject);
    const nameScore = jaccard(subjectTokens, tokens(name));
    const textScore = jaccard(subjectTokens, tokens(String(text || '').slice(0, 6000)));
    return Math.max(0, Math.min(1, nameScore * 0.65 + textScore * 0.35));
  }

  function looksSupporting(name) {
    return /\b(phụ lục|phu luc|danh sách|danh sach|tập\s*\d|tap\s*\d|hướng dẫn|huong dan|quyết định ban hành|quyet dinh ban hanh|tài liệu|tai lieu)\b/i.test(fold(name));
  }

  function chooseRepresentative(group, subject, symbol) {
    const scored = group.map((doc) => {
      const rel = subjectSimilarity(subject, doc.name, doc.text);
      const symbolHit = symbol && fold(`${doc.name} ${doc.text.slice(0, 3000)}`).includes(fold(symbol)) ? 0.12 : 0;
      const extBonus = ['docx', 'doc'].includes(doc.ext) ? 0.06 : doc.ext === 'pdf' ? 0.03 : 0;
      const textBonus = doc.text.length >= 500 ? 0.08 : 0;
      const supportPenalty = looksSupporting(doc.name) ? 0.06 : 0;
      const score = rel + symbolHit + extBonus + textBonus - supportPenalty;
      return { doc, rel, score };
    }).sort((a, b) => b.score - a.score || b.doc.text.length - a.doc.text.length);

    // Nếu DOC/DOCX và PDF gần như trùng nội dung, ưu tiên bản Word làm nguồn text sạch.
    const word = scored.find((x) => ['docx', 'doc'].includes(x.doc.ext) && x.doc.text.length >= 300);
    const pdf = scored.find((x) => x.doc.ext === 'pdf' && x.doc.text.length >= 300);
    if (word && pdf && textSimilarity(word.doc.text, pdf.doc.text) >= 0.84 && pdf.doc.text.length < word.doc.text.length * 1.2) {
      return { ...word, duplicateVerifiedByPdf: true };
    }
    return scored[0] || { doc: group[0], rel: 0, score: 0 };
  }

  function groupDuplicates(docs) {
    const parent = docs.map((_, i) => i);
    const find = (x) => parent[x] === x ? x : (parent[x] = find(parent[x]));
    const join = (a, b) => {
      a = find(a); b = find(b);
      if (a !== b) parent[b] = a;
    };

    for (let i = 0; i < docs.length; i++) {
      for (let j = i + 1; j < docs.length; j++) {
        if (docs[i].forcedDuplicateOf === docs[j].name || docs[j].forcedDuplicateOf === docs[i].name) {
          join(i, j);
          continue;
        }
        const aText = cleanText(docs[i].text || '');
        const bText = cleanText(docs[j].text || '');
        const bothText = aText.length >= 200 && bText.length >= 200;
        if (!bothText) continue;
        const exactSame = aText === bText;
        const shorter = Math.min(aText.length, bText.length);
        const longer = Math.max(aText.length, bText.length);
        const lengthRatio = longer ? shorter / longer : 0;
        const sim = exactSame ? 1 : textSimilarity(aText, bText);
        const nameSim = fileNameSimilarity(docs[i].name, docs[j].name);
        // Văn bản hành chính thường có DOCX chưa ký + PDF đã ký, hoặc nhiều PDF ký số cùng nội dung.
        // - Nội dung gần như tuyệt đối giống nhau: gộp dù tên khác.
        // - Tên cùng họ (bản Word/PDF, _1/_2, signed): cho phép chênh nhẹ do chữ ký/header/footer.
        const sameContent = exactSame
          || (lengthRatio >= 0.90 && sim >= 0.975)
          || (nameSim >= 0.72 && lengthRatio >= 0.80 && sim >= 0.90);
        if (!docs[i].truncated && !docs[j].truncated && sameContent) join(i, j);
      }
    }

    const groups = new Map();
    docs.forEach((doc, i) => {
      const root = find(i);
      if (!groups.has(root)) groups.set(root, []);
      groups.get(root).push(doc);
    });
    return [...groups.values()];
  }

  function chunks(text, size = 1200) {
    const clean = cleanText(text);
    const paras = clean.split(/\n{2,}/).filter(Boolean);
    if (paras.length > 1) return paras;
    const out = [];
    for (let i = 0; i < clean.length; i += size) out.push(clean.slice(i, i + size));
    return out;
  }

  function relevantExcerpt(text, subject, limit) {
    const clean = cleanText(text);
    if (clean.length <= limit) return clean;
    const subjectTokens = tokens(subject);
    const pieces = chunks(clean);
    const ranked = pieces.map((part, idx) => ({
      idx,
      part,
      score: jaccard(subjectTokens, tokens(part)) + (idx === 0 ? 0.22 : idx === 1 ? 0.08 : 0)
    })).sort((a, b) => b.score - a.score || a.idx - b.idx);

    const selected = [];
    let used = 0;
    for (const item of ranked) {
      if (used >= limit) break;
      const take = item.part.slice(0, Math.max(0, limit - used));
      if (take) {
        selected.push({ idx: item.idx, text: take });
        used += take.length + 2;
      }
    }
    return selected.sort((a, b) => a.idx - b.idx).map((x) => x.text).join('\n\n').slice(0, limit);
  }

  function normalizedTextKey(text) {
    const clean = cleanText(text || '');
    if (clean.length < 300) return '';
    return `${clean.length}|${fold(clean.slice(0, 12000))}`;
  }

  function dedupeDocsByIdentity(docs) {
    const map = new Map();
    for (const doc of docs || []) {
      const key = descriptorIdentityKey(doc);
      const prev = map.get(key);
      if (!prev) { map.set(key, doc); continue; }
      const score = (x) => ((x.text?.length || 0) >= MIN_TEXT_CHARS ? 1000000 : 0) + (x.text?.length || 0) + (x.status === 'pdf-scan-skipped' ? 50 : 0);
      if (score(doc) > score(prev)) map.set(key, doc);
    }
    return [...map.values()];
  }

  async function repairViewerCollisions(docs, descriptors, signal, onProgress = () => {}) {
    const current = dedupeDocsByIdentity(docs);
    const groups = new Map();
    for (const doc of current) {
      const key = normalizedTextKey(doc.text);
      if (!key) continue;
      if (!groups.has(key)) groups.set(key, []);
      groups.get(key).push(doc);
    }
    const descMap = new Map((descriptors || []).map(d => [descriptorIdentityKey(d), d]));

    // v0.16.4: nội dung giống nhau không còn mặc định bị coi là lỗi.
    // Chỉ xác minh lại tuần tự khi nhiều descriptor thật sự đang dùng cùng một viewer URL.
    // Sau khi xác minh, nếu nội dung vẫn giống nhau thì coi là bản sao hợp lệ và để prepareBundle gộp token.
    for (const same of groups.values()) {
      if (same.length < 2) continue;
      const sameViewer = same.some((a, i) => same.some((b, j) => i < j && a.viewerUrl && b.viewerUrl && a.viewerUrl === b.viewerUrl));
      if (!sameViewer) continue;

      onProgress({ phase:'collision', message:`Phát hiện ${same.length} tệp đang dùng cùng viewer · xác minh lại tuần tự. Nếu nội dung thật sự trùng sẽ gộp và chỉ gửi AI một bản.` });
      for (let i = 0; i < same.length; i++) {
        assertNotAborted(signal);
        const doc = same[i];
        const desc = descMap.get(descriptorIdentityKey(doc));
        if (!desc) continue;
        try {
          const reread = await readDescriptorTimed(desc, { partial:false, forceFresh:true, maxChars:24000, maxPages:24, tryIofficeOcr:false, captureScanBinary:false, fileName:desc.name }, signal, 18000);
          const idx = current.findIndex(x => descriptorIdentityKey(x) === descriptorIdentityKey(doc));
          if (idx >= 0 && reread) current[idx] = reread;
        } catch (error) {
          if (error?.name === 'AbortError') throw error;
          // Giữ kết quả cũ nếu xác minh lại lỗi tạm thời; không biến file đã đọc được thành "chưa đọc được".
        }
      }
    }
    return current;
  }

  function prepareBundle(meta, docs, expectedAttachmentCount = null, options = {}) {
    docs = dedupeDocsByIdentity(docs);
    const groups = options.readerDeduplicateContent === false ? docs.map((doc) => [doc]) : groupDuplicates(docs);
    const representatives = [];
    const duplicates = [];

    for (const group of groups) {
      const chosen = chooseRepresentative(group, meta.trichYeu || '', meta.symbol || '');
      const rep = chosen.doc;
      const rel = chosen.rel;
      representatives.push({ ...rep, relevance: rel, duplicateVerifiedByPdf: !!chosen.duplicateVerifiedByPdf });
      for (const item of group) {
        if (item === rep) continue;
        duplicates.push({
          name: item.name,
          duplicateOf: rep.name,
          nameSimilarity: Number(fileNameSimilarity(item.name, rep.name).toFixed(3)),
          textSimilarity: item.text && rep.text ? Number(textSimilarity(item.text, rep.text).toFixed(3)) : null,
          status: item.text ? 'duplicate-not-sent' : 'duplicate-skipped'
        });
      }
    }

    representatives.sort((a, b) => {
      const aPrimary = looksSupporting(a.name) ? 0 : 1;
      const bPrimary = looksSupporting(b.name) ? 0 : 1;
      return bPrimary - aPrimary || b.relevance - a.relevance || (b.text?.length || 0) - (a.text?.length || 0);
    });

    const primary = representatives.find((x) => (x.text?.length || 0) >= MIN_TEXT_CHARS) || representatives[0] || null;
    const support = representatives.filter((x) => x !== primary).sort((a, b) => b.relevance - a.relevance);

    // v0.15.1: PDF scan không có text được tạm bỏ qua. Không OCR, không base64 và không upload Gemini.
    const scanAttachments = [];
    const scanBytesUsed = 0;
    const scanNames = new Set();
    const skippedScans = representatives
      .filter((x) => x.status === 'pdf-scan-skipped')
      .map((x) => ({ name:x.name, status:'pdf-scan-skipped', scopeKind:x.scopeKind, ext:x.ext, source:x.source || '' }));
    const skippedLargeFiles = representatives
      .filter((x) => x.status === 'file-too-large-skipped')
      .map((x) => ({ name:x.name, status:'file-too-large-skipped', scopeKind:x.scopeKind, ext:x.ext, source:x.source || '', sizeBytes:Number(x.originalSizeBytes || 0), error:x.error || '' }));

    const unreadable = representatives
      .filter((x) => (!x.text || x.text.length < MIN_TEXT_CHARS) && !scanNames.has(x.name) && x.status !== 'pdf-scan-skipped' && x.status !== 'file-too-large-skipped')
      .map((x) => ({ name: x.name, status: x.status, scopeKind: x.scopeKind, ext:x.ext, sizeBytes: x.originalSizeBytes || x.scanSizeBytes || 0, error:x.error || '' }));

    const primaryText = primary?.text ? relevantExcerpt(primary.text, meta.trichYeu || '', MAX_PRIMARY_CHARS) : '';
    let remaining = Math.max(0, MAX_TOTAL_AI_CHARS - primaryText.length);
    const supportingDocuments = [];
    for (const doc of support) {
      if (remaining < 300 || !doc.text) continue;
      const max = Math.min(MAX_SUPPORT_CHARS, remaining);
      const excerpt = relevantExcerpt(doc.text, meta.trichYeu || '', max);
      if (!excerpt) continue;
      supportingDocuments.push({
        name: doc.name, ext: doc.ext, relevance: Number(doc.relevance.toFixed(3)), source: doc.source,
        charsOriginal: doc.text.length, wordsOriginal: wordCount(doc.text),
        charsSent: excerpt.length, wordsSent: wordCount(excerpt), text: excerpt
      });
      remaining -= excerpt.length;
    }

    const primaryDocument = primary ? {
      name: primary.name, ext: primary.ext, relevance: Number((primary.relevance || 0).toFixed(3)), source: primary.source,
      status: primary.status, charsOriginal: primary.text?.length || 0, wordsOriginal: wordCount(primary.text || ''),
      charsSent: primaryText.length, wordsSent: wordCount(primaryText), pagesRead: primary.pagesRead || 0, totalPages: primary.totalPages || 0,
      truncated: !!primary.truncated || (primary.text?.length || 0) > primaryText.length,
      duplicateVerifiedByPdf: !!primary.duplicateVerifiedByPdf, scanAttachedForAi: scanNames.has(primary.name), text: primaryText
    } : null;

    const combinedText = cleanText([primaryDocument?.text || '', ...supportingDocuments.map((x) => x.text)].filter(Boolean).join('\n\n')).slice(0, MAX_TOTAL_AI_CHARS);
    // Kiểm tra độ đầy đủ theo từng tệp thật đã phát hiện, không theo nhóm nội dung đã gộp.
    // Nhờ vậy 4 tệp thật vẫn được báo 4/4, dù Word + PDF có nội dung trùng và chỉ gửi một bản cho AI.
    const requiredDocs = docs.filter((x) => x.scopeKind !== 'related');
    const expectedRequired = Number(expectedAttachmentCount) > 0 ? Number(expectedAttachmentCount) : requiredDocs.length;
    const missingDescriptors = Math.max(0, expectedRequired - requiredDocs.length);
    const requiredScanSkipped = requiredDocs.filter((x) => x.status === 'pdf-scan-skipped');
    const requiredLargeSkipped = requiredDocs.filter((x) => x.status === 'file-too-large-skipped');
    const requiredUnreadable = requiredDocs.filter((x) => (!x.text || x.text.length < MIN_TEXT_CHARS) && !scanNames.has(x.name) && x.status !== 'pdf-scan-skipped' && x.status !== 'file-too-large-skipped');
    const requiredTextReady = requiredDocs.filter((x) => (x.text?.length || 0) >= MIN_TEXT_CHARS).length;
    const blockedByScanOnly = expectedRequired > 0 && missingDescriptors === 0 && requiredUnreadable.length === 0 && requiredTextReady === 0 && (requiredScanSkipped.length + requiredLargeSkipped.length) > 0;
    const aiReady = expectedRequired === 0 ? true : (!blockedByScanOnly && requiredUnreadable.length === 0 && missingDescriptors === 0 && requiredTextReady > 0);

    const duplicateByName = new Map(duplicates.map((d) => [fold(d.name), d]));
    const fileResults = docs.map((doc) => {
      const textReady = (doc.text?.length || 0) >= MIN_TEXT_CHARS;
      const duplicateInfo = duplicateByName.get(fold(doc.name)) || null;
      const scanReady = scanNames.has(doc.name);
      const scanSkipped = doc.status === 'pdf-scan-skipped';
      const sizeLimitSkipped = doc.status === 'file-too-large-skipped';
      return {
        name:doc.name, ext:doc.ext, scopeKind:doc.scopeKind, role:doc.name===primary?.name?'primary':'support',
        status: duplicateInfo && textReady ? 'duplicate-not-sent' : textReady ? 'text-ready' : scanSkipped ? 'scan-skipped' : sizeLimitSkipped ? 'size-limit-skipped' : scanReady ? 'scan-attached' : (doc.status || 'unreadable'),
        source:doc.source || '', chars:Number(doc.text?.length || 0), words:wordCount(doc.text || ''),
        readyForAi:textReady || scanReady, sentAsScan:scanReady, scanSkipped, sizeLimitSkipped, sizeBytes:Number(doc.originalSizeBytes || 0),
        duplicateOf: duplicateInfo?.duplicateOf || '', duplicateSimilarity: duplicateInfo?.textSimilarity ?? null, error:doc.error || ''
      };
    });

    for (let i = 0; i < missingDescriptors; i++) {
      fileResults.push({
        name: `Tệp chưa nhận diện #${requiredDocs.length + i + 1}`, ext:'', scopeKind:'attachment', role:'unknown',
        status:'descriptor-missing', source:'none', chars:0, words:0, readyForAi:false, sentAsScan:false,
        error:'iOffice báo có tệp nhưng tiện ích chưa lấy được định danh/link của tệp.'
      });
      unreadable.push({ name:`Tệp chưa nhận diện #${requiredDocs.length + i + 1}`, status:'descriptor-missing', scopeKind:'attachment', ext:'', sizeBytes:0, error:'Chưa lấy được định danh/link tệp từ iOffice.' });
    }

    return {
      version: VERSION,
      primaryDocument, supportingDocuments, scanAttachments, skippedScans, skippedLargeFiles, duplicates, unreadable, fileResults,
      stats: {
        filesDetected: expectedRequired,
        relatedFilesDetected: representatives.filter(x=>x.scopeKind==='related').length,
        filesWithText: docs.filter((x) => (x.text?.length || 0) >= MIN_TEXT_CHARS).length,
        filesReadyForAi: requiredTextReady,
        scanSkippedCount: requiredScanSkipped.length,
        oversizedSkippedCount: requiredLargeSkipped.length,
        uniqueGroups: groups.length, duplicatesSkipped: duplicates.length, duplicateCount: duplicates.length,
        scanAttachmentsPrepared: 0, scanBytesPrepared: 0,
        unreadableCount: unreadable.length, requiredUnreadableCount: requiredUnreadable.length + missingDescriptors, missingDescriptorCount: missingDescriptors,
        extractedTextChars: docs.reduce((n,x)=>n+(x.text?.length||0),0),
        extractedWords: docs.reduce((n,x)=>n+wordCount(x.text||''),0),
        aiTextChars: combinedText.length, aiTextWords: wordCount(combinedText)
      },
      aiReady,
      blockedByScanOnly,
      aiBlockedReason: aiReady
        ? ''
        : blockedByScanOnly
          ? (requiredLargeSkipped.length && !requiredScanSkipped.length
              ? (expectedRequired === 1
                  ? `Văn bản chỉ có 1 tệp vượt giới hạn dung lượng nên không còn nội dung để phân tích.`
                  : `Cả ${expectedRequired} tệp đính kèm đều vượt giới hạn dung lượng nên không còn nội dung để phân tích.`)
              : requiredScanSkipped.length && !requiredLargeSkipped.length
                ? (expectedRequired === 1
                    ? 'Văn bản chỉ có 1 PDF scan, chưa thể trích xuất nội dung nên không phân tích được.'
                    : `Cả ${expectedRequired} tệp đính kèm đều là PDF scan, chưa thể trích xuất nội dung nên không phân tích được.`)
                : 'Các tệp đính kèm đều bị bỏ qua (PDF scan hoặc vượt giới hạn dung lượng), nên không còn nội dung để phân tích.')
          : `Chưa đủ dữ liệu: ${requiredUnreadable.length + missingDescriptors}/${expectedRequired} tệp bắt buộc chưa sẵn sàng.`,
      requiresReviewForUnreadable: !aiReady || requiredScanSkipped.length > 0 || requiredLargeSkipped.length > 0 || !!primary?.truncated,
      combinedText
    };
  }



  async function getStableAttachmentDescriptors(options = {}, signal = null, onProgress = () => {}) {
    const includeRelated = options.readerIncludeRelated !== false;
    const deadline = Date.now() + 2200;
    let best = [];
    let lastSig = '';
    let stableRounds = 0;
    let declared = getDeclaredAttachmentCount();
    while (Date.now() < deadline) {
      assertNotAborted(signal);
      const current = getAttachmentDescriptors().filter(d => includeRelated || d.scopeKind !== 'related');
      declared = Math.max(declared, getDeclaredAttachmentCount());
      if (current.length > best.length) best = current;
      else if (current.length === best.length && current.some((d,i)=>d.viewerToken && !best[i]?.viewerToken)) best = current;
      const sig = current.map(d => `${d.scopeKind}|${d.fileId}|${d.viewerToken}|${fold(d.name)}`).sort().join('||');
      stableRounds = sig && sig === lastSig ? stableRounds + 1 : 0;
      lastSig = sig;
      const attachmentCount = current.filter(x => x.scopeKind !== 'related').length;
      if (stableRounds >= 2 && (declared === 0 || attachmentCount >= declared)) return current;
      await sleepAbortable(stableRounds ? 130 : 180, signal);
    }
    const count = best.filter(x => x.scopeKind !== 'related').length;
    if (declared > count) onProgress({ phase:'discover-wait', message:`Danh sách tệp tải chậm: mới nhận diện ${count}/${declared}; tiếp tục đọc các tệp đã có và sẽ kiểm tra lại.` });
    return best;
  }

  function adaptiveReaderConcurrency(groupCount = 1) {
    const hw = Math.max(2, Number(navigator.hardwareConcurrency || 4));
    const mem = Number(navigator.deviceMemory || 4);
    let cpuCap = hw >= 16 ? 6 : hw >= 12 ? 5 : hw >= 8 ? 4 : hw >= 6 ? 3 : 2;
    let memCap = mem >= 8 ? 6 : mem >= 4 ? 4 : mem >= 2 ? 3 : 2;
    try { if (navigator.connection?.saveData) cpuCap = Math.min(cpuCap, 2); } catch (_) {}
    // Đa số tệp iOffice phải đi qua viewer/PDF.js; vượt quá số viewer hữu ích chỉ làm tranh CPU/RAM và tăng timeout.
    const viewerCap = adaptiveHiddenViewerConcurrency();
    const practicalCap = Math.min(6, Math.max(viewerCap, viewerCap + (hw >= 12 && mem >= 8 ? 1 : 0)));
    return Math.max(1, Math.min(practicalCap, cpuCap, memCap, Math.max(1, Number(groupCount) || 1)));
  }


  async function collectAndPrepare(meta, onProgress = () => {}, options = {}) {
    const signal = options.signal || null;
    assertNotAborted(signal);

    const scanEnabled = false; // v0.16.1 FINAL: PDF scan luôn bỏ qua, không OCR/không upload.
    const discovered = dedupeDescriptorList(await getStableAttachmentDescriptors(options, signal, onProgress));
    const declaredAttachmentCount = getDeclaredAttachmentCount();
    let descriptors = constrainDescriptorsToDeclared(discovered, declaredAttachmentCount);
    if (declaredAttachmentCount > 0 && discovered.filter(x=>x.scopeKind!=='related').length > descriptors.filter(x=>x.scopeKind!=='related').length) {
      onProgress({ phase:'dedupe', message:`Loại bản sao giao diện: ${discovered.filter(x=>x.scopeKind!=='related').length} → ${descriptors.filter(x=>x.scopeKind!=='related').length} tệp theo số lượng iOffice công bố.` });
    }
    let attachmentCount = descriptors.filter((x) => x.scopeKind !== 'related').length;
    const expectedAttachmentCount = declaredAttachmentCount > 0 ? declaredAttachmentCount : attachmentCount;
    const relatedCount = descriptors.filter((x) => x.scopeKind === 'related').length;
    onProgress({
      phase: 'discover',
      message: descriptors.length
        ? `Phát hiện ${attachmentCount}/${expectedAttachmentCount} tệp đính kèm${relatedCount ? ` + ${relatedCount} văn bản liên quan` : ''}.`
        : 'Không thấy danh sách tệp hợp lệ; thử lấy text của viewer đang mở.',
      total: descriptors.length,
      files: descriptors.map((x) => ({ name: x.name, scopeKind: x.scopeKind, ext: x.ext }))
    });

    const docs = [];
    const prefilled = new Map();

    if (!descriptors.length) {
      onProgress({phase:'viewer',message:'Không có tệp thuộc văn bản hiện tại; cần kiểm tra kết quả theo trích yếu.'});
    } else {
      const groups = buildReadGroups(descriptors, meta);
      const requestedConcurrency = Number(options.readerConcurrency);
      const autoConcurrency = adaptiveReaderConcurrency(groups.length || 1);
      const concurrency = requestedConcurrency > 0
        ? Math.max(1, Math.min(6, requestedConcurrency, groups.length || 1))
        : autoConcurrency;
      onProgress({
        phase: 'parallel',
        message: `${requestedConcurrency > 0 ? 'Đọc song song' : 'Tự tối ưu theo máy'}: tối đa ${concurrency} luồng · ${groups.length} nhóm tài liệu${requestedConcurrency > 0 ? '' : ` · CPU ${navigator.hardwareConcurrency || '?'} luồng${navigator.deviceMemory ? ` · RAM ~${navigator.deviceMemory} GB` : ''}`}.`,
        total: descriptors.length,
        concurrency
      });

      let startedCount = 0;
      let finishedCount = 0;

      const groupResults = await runBounded(groups, concurrency, async (group, groupIndex, workerId) => {
        assertNotAborted(signal);
        const out = [];
        const items = [...group.items];
        const wordDesc = items.find((x) => ['doc', 'docx'].includes(x.ext));
        const pdfPeers = wordDesc ? items.filter((x) => x.ext === 'pdf' && x.canonicalStem === wordDesc.canonicalStem) : [];

        const readOne = async (desc, forceDeep = false) => {
          assertNotAborted(signal);
          const already = prefilled.get(desc.name);
          if (already) {
            finishedCount += 1;
            return { ...already };
          }

          const ordinal = ++startedCount;
          const priority = descriptorPriority(desc, meta);
          const supporting = looksSupporting(desc.name) || desc.scopeKind === 'related';
          const deep = forceDeep || (!supporting && priority >= 0.12) || groupIndex < 2;
          const readOptions = deep
            ? { maxChars: 24000, maxPages: 24 }
            : { partial: true, maxChars: 5000, maxPages: 4 };
          const configuredTimeoutMs = Math.max(12000, Math.min(45000, Number(options.readerTimeoutMs)||22000));
          const timeoutMs = ['doc','docx'].includes(desc.ext) ? Math.min(configuredTimeoutMs, 18000) : configuredTimeoutMs;
          const startedAt = performance.now();

          onProgress({
            phase: 'read',
            message: `Luồng ${workerId}: đọc ${ordinal}/${descriptors.length} · ${desc.name}`,
            index: ordinal,
            total: descriptors.length,
            name: desc.name,
            worker: workerId
          });

          let item = await readDescriptorTimed(desc, { ...readOptions, tryIofficeOcr:scanEnabled, captureScanBinary:false, fileName: desc.name }, signal, timeoutMs);
          // Tệp iOffice có thể chỉ lộ request/viewer sau nhịp AJAX đầu tiên. Với lỗi tạm thời,
          // chờ ngắn và đọc lại ngay trong cùng lần Phân tích thay vì bắt người dùng bấm lần hai.
          const transient = (item.text?.length || 0) < MIN_TEXT_CHARS && !['scan-ready-for-ai','scan-too-large','legacy-binary-unparsed','pdf-scan-skipped','file-too-large-skipped'].includes(item.status || '');
          if (transient) {
            onProgress({ phase:'retry', message:`Chưa đủ dữ liệu · thử lại ${desc.name} trong cùng phiên`, name:desc.name, worker:workerId });
            await sleepAbortable(450, signal);
            const refreshed = getAttachmentDescriptors().find((d) => fold(d.name) === fold(desc.name) && d.scopeKind === desc.scopeKind) || desc;
            const retry = await readDescriptorTimed(refreshed, { ...readOptions, partial:false, maxChars:Math.max(12000, readOptions.maxChars || 0), maxPages:Math.max(12, readOptions.maxPages || 0), tryIofficeOcr:scanEnabled, captureScanBinary:false, fileName: refreshed.name }, signal, Math.min(30000, Math.max(timeoutMs + 6000, Math.round(timeoutMs * 1.25))));
            const score = (x) => ((x.text?.length || 0) >= MIN_TEXT_CHARS ? 1000000 : 0) + (x.scanSizeBytes || 0) + (x.text?.length || 0);
            if (score(retry) > score(item)) item = retry;
          }
          const tookMs = Math.round(performance.now() - startedAt);
          finishedCount += 1;
          const ok = (item.text?.length || 0) >= MIN_TEXT_CHARS;
          const scanReady = item.status === 'scan-ready-for-ai' && Number(item.scanSizeBytes || 0) > 0;
          const scanSkipped = item.status === 'pdf-scan-skipped';
          const sizeLimitSkipped = item.status === 'file-too-large-skipped';
          const label = ok
            ? 'Đã đọc'
            : sizeLimitSkipped
              ? 'Tệp quá dung lượng · tạm bỏ qua'
            : scanSkipped
              ? 'PDF scan · tạm bỏ qua'
              : scanReady
                ? 'PDF scan · trạng thái cũ'
              : item.status === 'scan-too-large'
                ? 'PDF scan quá lớn để đính kèm tự động'
                : item.status === 'timeout'
                  ? 'Hết thời gian'
                  : 'Chưa lấy được text';
          const detail = sizeLimitSkipped
            ? `Vượt giới hạn ${Math.max(1,Math.min(50,Number(options.readerMaxFileSizeMb||10)))} MB · tạm bỏ qua`
            : scanSkipped
            ? 'không OCR · không gửi file'
            : scanReady
              ? `${(Number(item.scanSizeBytes || 0) / 1024 / 1024).toFixed(1)} MB`
              : `${wordCount(item.text || '').toLocaleString('vi-VN')} từ · ${Number(item.text?.length || 0).toLocaleString('vi-VN')} ký tự`;
          onProgress({
            phase: sizeLimitSkipped ? 'size-limit-skipped' : (scanSkipped ? 'scan-skipped' : (scanReady ? 'scan-ready' : 'file-result')),
            message: `${label}: ${item.name} · ${detail} · ${(tookMs / 1000).toFixed(1)}s`,
            name: item.name,
            chars: item.text?.length || 0,
            source: item.source || '',
            status: item.status || '',
            scanSizeBytes: item.scanSizeBytes || 0,
            worker: workerId,
            tookMs,
            finished: finishedCount
          });
          return item;
        };

        // Cặp Word + PDF cùng stem: đọc Word trước trong nhóm. Các nhóm khác vẫn chạy song song.
        if (wordDesc && pdfPeers.length) {
          const word = await readOne(wordDesc, true);
          out.push(word);

          for (const pdfDesc of pdfPeers) out.push(await readOne(pdfDesc, true));

          for (const desc of items) {
            if (desc === wordDesc || pdfPeers.includes(desc)) continue;
            out.push(await readOne(desc, false));
          }
          return out;
        }

        // Nhóm thường: đọc tuần tự bên trong một worker để không tạo quá nhiều iframe,
        // trong khi các nhóm khác vẫn chạy song song ở worker khác.
        for (const desc of items) out.push(await readOne(desc, false));
        return out;
      });

      for (const groupDocs of groupResults) docs.push(...(groupDocs || []));

      // Readiness barrier lần cuối: iOffice đôi khi render thêm attachment sau khi các viewer đầu đã mở.
      await sleepAbortable(260, signal);
      const freshDescriptors = dedupeDescriptorList(getAttachmentDescriptors()).filter(d => options.readerIncludeRelated !== false || d.scopeKind !== 'related');
      const known = new Set(descriptors.map(descriptorIdentityKey));
      const late = freshDescriptors.filter(d => !known.has(descriptorIdentityKey(d)));
      if (late.length) {
        const merged = constrainDescriptorsToDeclared([...descriptors, ...late], getDeclaredAttachmentCount());
        const accepted = new Set(merged.map(descriptorIdentityKey));
        const lateAccepted = late.filter(d => accepted.has(descriptorIdentityKey(d)));
        descriptors = merged;
        attachmentCount = descriptors.filter(x => x.scopeKind !== 'related').length;
        if (lateAccepted.length) {
          onProgress({ phase:'late-files', message:`Phát hiện thêm ${lateAccepted.length} tệp tải muộn · đọc ngay trong phiên hiện tại.`, total:lateAccepted.length });
          const lateResults = await runBounded(lateAccepted, Math.min(2, lateAccepted.length), async (desc, index) => {
            const baseTimeoutMs = Math.max(16000, Math.min(45000, Number(options.readerTimeoutMs)||22000));
            const timeoutMs = baseTimeoutMs + 6000;
            onProgress({phase:'read', message:`Đọc tệp tải muộn ${index+1}/${lateAccepted.length} · ${desc.name}`, name:desc.name});
            return readDescriptorTimed(desc, { partial:false, maxChars:24000, maxPages:24, tryIofficeOcr:scanEnabled, captureScanBinary:false, fileName:desc.name }, signal, timeoutMs);
          });
          docs.push(...lateResults);
        }
      }
    }

    assertNotAborted(signal);
    const repairedDocs = await repairViewerCollisions(docs, descriptors, signal, onProgress);
    docs.length = 0; docs.push(...repairedDocs);
    const declaredFinal = getDeclaredAttachmentCount();
    const finalExpectedAttachmentCount = declaredFinal > 0 ? declaredFinal : descriptors.filter(x => x.scopeKind !== 'related').length;
    const bundle = prepareBundle(meta, docs, finalExpectedAttachmentCount, options);
    onProgress({
      phase: 'bundle',
      message: `Hoàn tất: ${bundle.stats.filesReadyForAi}/${bundle.stats.filesDetected} tệp đã đọc${bundle.stats.scanSkippedCount ? ` · bỏ qua ${bundle.stats.scanSkippedCount} PDF scan` : ''}${bundle.stats.oversizedSkippedCount ? ` · bỏ qua ${bundle.stats.oversizedSkippedCount} tệp quá dung lượng` : ''}${bundle.stats.duplicatesSkipped ? ` · gộp ${bundle.stats.duplicatesSkipped} tệp trùng` : ''} · lấy ${Number(bundle.stats.extractedWords || 0).toLocaleString('vi-VN')} từ · dự kiến gửi ${Number(bundle.stats.aiTextWords || 0).toLocaleString('vi-VN')} từ.`,
      stats: bundle.stats,
      primaryDocument: bundle.primaryDocument?.name || ''
    });
    return {
      descriptors: descriptors.map(({ viewerToken, candidateUrls, actionArgs, ...safe }) => safe),
      docs: docs.map(({ viewerToken, candidateUrls, actionArgs, scanBytes, originalBytes, ...safe }) => safe),
      bundle,
      combinedText: bundle.combinedText,
      stats: bundle.stats
    };
  }

  globalThis.IOfficeDocumentReader = {
    version: VERSION,
    getAttachmentDescriptors,
    getAttachmentNames,
    getDeclaredAttachmentCount,
    collectAndPrepare,
    fileNameSimilarity,
    textSimilarity,
    adaptiveReaderConcurrency,
    adaptiveHiddenViewerConcurrency
  };
})();
