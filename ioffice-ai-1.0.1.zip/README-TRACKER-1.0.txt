Tracker 1.0.1 tương thích iOffice AI 1.0.1.

- Giữ nguyên dữ liệu và TOKEN của Tracker 1.0.0/7.0.17 khi nâng cấp bằng New version trên cùng deployment.
- Thêm thanh cuộn ngang nổi luôn sẵn khi bảng nhiệm vụ rộng hơn màn hình.
- Rule Pack văn bản đến tiếp tục là 1.0.0.
