(() => {
  'use strict';

  const HOST_ID = 'ealy-ioffice-ai-host';
  const VERSION = globalThis.chrome?.runtime?.getManifest?.().version || '2.2.0';

  const state = {
    runId: 0,
    prepKey: '',
    rules: null,
    root: null,
    refs: {},
    lastSuggestion: null,
    lastContext: null,
    lastSignals: [],
    busy: false,
    updateLocked: false,
    updateDirty: false,
    lastPrep: null,
    documentKey: '',
    analyzedKey: '',
    pickerRole: null,
    analysisStartedAt: 0,
    analysisTimer: null,
    lastAnalysisMeta: null,
    pendingWebJob: null,
    aiEnabled: true,
    analysisMode: 'api',
    fallbackAnalysisMode: 'none',
    progressLog: [],
    activeAbortController: null,
    cancelRequested: false,
    lastWebPhase: '',
    webEventCache: new Map(),
    webWaiters: new Map(),
    appliedKey: '',
    finalizing: false,
    lastAnalysisKind: '',
    inputAudit: null,
    workflowPhase: 'analyze',
    userRole: 'leader',
    documentDirection: 'incoming',
    workflow: 'leader-incoming',
    forceReadAllOnce: false,
    forceTaskSupportOnce: false,
    trackerConfigured: false,
    trackerConnected: null,
    trackerStatusText: 'Đang kiểm tra kết nối Sổ theo dõi…',
    trackerVersion: '',
    trackerTaskCount: 0,
    trackerAttachmentReady: null,
    trackThisDocument: false,
    trackingManualChoice: null,
    manualDeadline: null,
    transferRunning: false,
    leaderWatcherDirectory: [],
    pendingAppliedSuggestion: null,
    pendingTrackerContextSnapshot: null,
    instructionPrefixEnabled: false,
    instructionPrefixText: 'VP đề xuất:',
    leaderDefaultWatcherIds: [],
    leaderDefaultWatcherTargets: [],
    leaderDefaultViewUnitIds: [],
    leaderWatchersLocked: false,
    currentLeaderWatchers: [],
    lastPreparedPayload: null,
    quickApiProvider: '',
    quickApiModel: '',
    widgetPinned: false,
    headerStatusTimer: null,
    autoCompactAnalysis: false,
    lastAiSentText: '',
    lastAiReceivedText: '',
    lastPrivacyStats: null,
    lastPrivacyWarnings: []
  };


  let extensionContextInvalid = false;
  function chromeContextAlive() {
    if (extensionContextInvalid) return false;
    try { return Boolean(globalThis.chrome?.runtime?.id); }
    catch (_) { extensionContextInvalid = true; return false; }
  }
  function contextInvalidError(error) {
    return /Extension context invalidated|context invalidated|Receiving end does not exist/i.test(String(error?.message || error || ''));
  }
  function markExtensionContextInvalid(error = null) {
    if (error && !contextInvalidError(error)) return false;
    // v2.2.0: cập nhật/reload chạy im lặng. Không chèn banner/thông báo lên trang iOffice.
    // Update manager sẽ tự làm mới các tab đã khóa an toàn; nếu context cũ mất thì chỉ dừng thao tác hiện tại.
    extensionContextInvalid = true;
    return true;
  }
  async function safeStorageGet(defaults = {}) {
    if (!chromeContextAlive()) return { ...defaults };
    try { return await chrome.storage.local.get(defaults); }
    catch (error) { if (markExtensionContextInvalid(error)) return { ...defaults }; throw error; }
  }
  async function safeStorageSet(values) {
    if (!chromeContextAlive()) return false;
    try { await chrome.storage.local.set(values); return true; }
    catch (error) { if (markExtensionContextInvalid(error)) return false; throw error; }
  }
  function safeRuntimeSend(message, { quiet = false } = {}) {
    return new Promise((resolve, reject) => {
      if (!chromeContextAlive()) {
        const error = new Error('Extension context invalidated');
        markExtensionContextInvalid(error);
        return quiet ? resolve(null) : reject(error);
      }
      try {
        chrome.runtime.sendMessage(message, (response) => {
          const last = chrome.runtime?.lastError;
          if (last) {
            const error = new Error(last.message || 'Không gửi được yêu cầu tới tiện ích.');
            if (markExtensionContextInvalid(error) && quiet) return resolve(null);
            return quiet ? resolve(null) : reject(error);
          }
          resolve(response);
        });
      } catch (error) {
        if (markExtensionContextInvalid(error) && quiet) return resolve(null);
        quiet ? resolve(null) : reject(error);
      }
    });
  }

  const normalizeText = (value) => (value || '')
    .replace(/\u00a0/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();

  const escapeHtml = (value) => String(value || '')
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;');

  const uniq = (items) => [...new Set((items || []).filter(Boolean))];
  const clamp = (n, min, max) => Math.max(min, Math.min(max, Number(n) || 0));

  const COMMON_METADATA_LABELS = [
    'trích yếu','đơn vị ban hành','cơ quan ban hành','cơ quan gửi','số ký hiệu','số, ký hiệu',
    'số đến','độ khẩn','người soạn thảo','người ký','văn bản giấy','ghi chú','ngày văn bản',
    'hình thức','loại văn bản','lĩnh vực','ngày đến','hạn xử lý'
  ];

  function looksLikeMetadataLabel(value) {
    const text = normalizeText(value).replace(/[:：]+$/, '').toLowerCase();
    if (!text || text.length > 60) return false;
    return COMMON_METADATA_LABELS.some((label) => text === label || text.startsWith(`${label}:`));
  }

  function looksLikeGarbageText(value) {
    const text = normalizeText(value);
    return !text || /:hover\s*\{|text-decoration\s*:|display\s*:|font-size\s*:|\.\w+[^{]{0,50}\{|content\s*:\s*["']?/i.test(text);
  }

  function formatDuration(ms) {
    const value = Math.max(0, Number(ms) || 0);
    if (value < 1000) return `${Math.round(value)} ms`;
    if (value < 10000) return `${(value / 1000).toFixed(1)} s`;
    return `${Math.round(value / 1000)} s`;
  }

  function getTokenUsage(ai) {
    const usage = ai?.usageMetadata || {};
    const firstNumber = (...values) => {
      for (const value of values) {
        const n = Number(value);
        if (Number.isFinite(n) && n >= 0) return n;
      }
      return null;
    };
    const input = firstNumber(usage.promptTokenCount, usage.input_tokens, usage.inputTokens, usage.prompt_tokens);
    const output = firstNumber(usage.candidatesTokenCount, usage.output_tokens, usage.outputTokens, usage.completion_tokens);
    let total = firstNumber(usage.totalTokenCount, usage.total_tokens, usage.totalTokens);
    if (total == null && input != null && output != null) total = input + output;
    if (total != null) return { total: Math.round(total), input, output, estimated: false };
    if (ai?.promptChars) return { total: Math.max(1, Math.round(Number(ai.promptChars) / 4)), input: null, output: null, estimated: true };
    return { total: 0, input: null, output: null, estimated: false };
  }

  function confidenceStyle(pct) {
    if (pct >= 80) return { cls: 'high', color: '#16a34a' };
    if (pct >= 60) return { cls: 'mid', color: '#f59e0b' };
    return { cls: 'low', color: '#ef4444' };
  }

  const SHORT_UNIT_NAMES = {
    U140: 'Văn phòng',
    U141: 'Phòng Kinh tế',
    U142: 'Phòng VH-XH',
    U120: 'TT Phục vụ HCC',
    U183: 'TT Cung ứng DV sự nghiệp công',
    U260: 'HĐND xã',
    U340: 'Công an xã',
    U360: 'Ban CHQS',
    DUUBND: 'Đảng ủy UBND'
  };
  const ROUTING_UNIT_IDS = new Set(['U140','U141','U142','U120','U183','U260','U340','U360','DUUBND']);
  const isPartyUbndName = (value) => { const f=normalizeText(value||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/đ/g,'d').replace(/Đ/g,'D').toLowerCase(); return /\b(?:dang\s+uy|dang\s+bo)\s+(?:uy\s+ban\s+nhan\s+dan|ubnd)\b/i.test(f); };

  function shortUnitName(id, fallback = '') {
    return SHORT_UNIT_NAMES[id] || normalizeText(fallback || id)
      .replace(/\s*-\s*tỉnh\s+Đắk\s+Lắk$/i, '')
      .replace(/^Văn\s+Phòng\s+HĐND\s+và\s+UBND$/i, 'Văn phòng')
      .replace(/^Phòng\s+Văn\s+hóa\s*-\s*Xã\s+hội$/i, 'Phòng VH-XH')
      .replace(/^Trung\s+tâm\s+Phục\s+vụ\s+hành\s+chính\s+công$/i, 'TT Phục vụ HCC')
      .replace(/^Trung\s+tâm\s+Cung\s+ứng\s+dịch\s+vụ\s+sự\s+nghiệp\s+công\s+xã\s+Ea\s+Ly$/i, 'TT Cung ứng DV sự nghiệp công')
      .replace(/^CÔNG\s+AN\s+XÃ\s+EA\s+LY$/i, 'Công an xã')
      .replace(/^BAN\s+CHỈ\s+HUY\s+QUÂN\s+SỰ\s+XÃ\s+EA\s+LY$/i, 'Ban CHQS')
      .replace(/^Trạm\s+Y\s+tế\s+xã\s+Ea\s+Ly$/i, 'Trạm Y tế');
  }

  function cleanTrichYeu(value) {
    let text = normalizeText(value);
    if (!text || looksLikeGarbageText(text) || looksLikeMetadataLabel(text)) return '';
    text = text.replace(/^\[[^\]]+\]\s*/, '');
    text = text.split(/(?:Nén\s+và\s+tải\s+tất\s+cả|FILE\s+ĐÍNH\s+KÈM|TỆP\s+ĐÍNH\s+KÈM|Tệp\s+đính\s+kèm|File\s+đính\s+kèm)/i)[0];
    // Nếu tên file bị dính vào trích yếu, cắt trước phần mở rộng đầu tiên.
    const fileAt = text.search(/\s+[^|]{2,}\.(?:pdf|docx?|xlsx?|xls|pptx?|zip|rar)(?:\s*\||\s|$)/i);
    if (fileAt > 12) text = text.slice(0, fileAt);
    return normalizeText(text).replace(/[|·\-]+\s*$/, '').trim();
  }

  function displayTrichYeu(value, maxWords = 32) {
    const text = cleanTrichYeu(value);
    const words = text.split(/\s+/).filter(Boolean);
    if (words.length <= maxWords) return text;
    return `${words.slice(0, maxWords).join(' ')}…`;
  }

  function isElementVisible(el) {
    if (!el) return false;
    const style = getComputedStyle(el);
    const rect = el.getBoundingClientRect();
    return style.display !== 'none' && style.visibility !== 'hidden' && rect.width > 0 && rect.height > 0;
  }

  async function loadRules() {
    try {
      const response = await safeRuntimeSend({ type: 'GET_ROUTING_RULES' });
      if (!response?.ok) throw new Error(response?.error || 'Không đọc được routing-rules.json');
      state.rules = response.rules;
    } catch (error) {
      console.error('[iOffice AI] Không tải được routing-rules.json qua service worker', error);
      state.rules = { policy: {}, legalBasis: [], units: [] };
    }
  }

  function rulesUnitMap() {
    return new Map((state.rules?.units || []).map((u) => [u.id, u]));
  }

  function getNearbyName(input) {
    if (!input) return '';
    const candidates = [
      input.closest('tr'),
      input.closest('li'),
      input.closest('.row'),
      input.parentElement,
      input.parentElement?.parentElement,
      input.parentElement?.parentElement?.parentElement
    ].filter(Boolean);

    for (const container of candidates) {
      const labels = [...container.querySelectorAll('label')]
        .map((x) => normalizeText(x.innerText))
        .filter(Boolean)
        .filter((x) => !/^(P\.ban|C\.Nhân|Gửi SMS|Kết thúc văn bản|Chỉ hiển thị)/i.test(x));
      if (labels.length) {
        const exact = labels.find((x) => !x.includes('(')) || labels[0];
        if (exact) return exact;
      }
      const text = normalizeText(container.innerText);
      if (text && text.length <= 180 && !/^(P\.ban|C\.Nhân|Gửi SMS)$/i.test(text)) return text;
    }
    return input.value || input.id || 'Không rõ';
  }

  function scanRecipients() {
    const mainControls = [...document.querySelectorAll(
      'input[name="rdo_chuyentiep"], input.chk_chuyentiep_multixlc, input[name="chk_chuyen_lienthong_noibo_chutri"]'
    )];
    const coordinationControls = [...document.querySelectorAll(
      'input[name="chk_chuyentiep"], input.chk_chuyentiep_class, input[name="chk_chuyen_lienthong_noibo"]'
    )];
    const viewControls = [...document.querySelectorAll(
      'input[name="chk_chuyentiep_ph"], input.chk_chuyentiep_ph_class, input[name="chk_chuyen_lienthong_noibo_xem"]'
    )];

    const ruleMap = rulesUnitMap();
    const toEntity = (el) => {
      const code = unitCodeFromControl(el);
      return {
        id: el.id || '',
        value: code || el.value || '',
        name: ruleMap.get(code)?.name || getNearbyName(el),
        visible: controlVisible(el),
        checked: !!el.checked,
        element: el
      };
    };

    const dedupeUnits = (items) => {
      const map = new Map();
      for (const item of items.map(toEntity)) {
        if (!/^U\d+$/i.test(item.value)) continue;
        const current = map.get(item.value);
        if (!current || (!current.visible && item.visible)) map.set(item.value, item);
      }
      return [...map.values()];
    };

    const mainUnits = dedupeUnits(mainControls);
    const coordinationUnits = dedupeUnits(coordinationControls);
    const viewUnits = dedupeUnits(viewControls);
    const all = new Map();
    for (const item of [...mainUnits, ...coordinationUnits, ...viewUnits]) {
      if (!all.has(item.value)) all.set(item.value, item);
    }

    return { mainUnits, coordinationUnits, viewUnits, units: [...all.values()] };
  }

  function canonicalRoutingUnitId(unit) {
    const value = normalizeText(unit?.value || unit?.id || '').toUpperCase();
    if (ROUTING_UNIT_IDS.has(value) && value !== 'DUUBND') return value;
    if (isPartyUbndName(unit?.name || '')) return 'DUUBND';
    return '';
  }

  function getAvailableUnits() {
    const scanned = scanRecipients().units;
    const map = new Map();
    for (const unit of state.rules?.units || []) {
      if (!ROUTING_UNIT_IDS.has(unit.id)) continue;
      map.set(unit.id, { value: unit.id, name: unit.name, rule: unit });
    }
    // Chỉ nhận đúng danh mục 9 đầu mối. Trạm/Trường và mọi đơn vị khác không xuất hiện ở UI phân luồng.
    for (const unit of scanned) {
      const canonical = canonicalRoutingUnitId(unit);
      if (!canonical) continue;
      const existing = map.get(canonical);
      map.set(canonical, { value: canonical, name: existing?.name || unit.name, rule: existing?.rule || null, actualValue: unit.value });
    }
    return [...map.values()];
  }

  function resolveIofficeUnitCode(code) {
    const logical = normalizeText(code || '').toUpperCase();
    if (logical !== 'DUUBND') return logical;
    const hit = scanRecipients().units.find((u) => isPartyUbndName(u.name || ''));
    return normalizeText(hit?.value || '');
  }

  function extractAttachmentNames() {
    try {
      const smart = globalThis.IOfficeDocumentReader?.getAttachmentNames?.();
      if (Array.isArray(smart) && smart.length) return smart;
    } catch (_) {}
    const names = [];
    for (const el of document.querySelectorAll('#div_file_list > [id^="file_"]')) {
      let text = normalizeText(el.innerText || '');
      text = text.replace(/^(?:Xoá|Xóa)\s+Tải file\s+Xem\s+/i, '');
      text = text.replace(/^(?:Tải file\s+Xem\s+)/i, '');
      if (text && !names.includes(text)) names.push(text);
    }
    return names;
  }

  function labelMatches(text, wanted) {
    const key = normalizeText(text).replace(/\(\*\)/g, '').replace(/[:：]+$/, '').toLowerCase();
    return !!key && wanted.some((x) => key === x || key.startsWith(`${x}:`) || key.startsWith(`${x} `));
  }

  function readControlOrText(el) {
    if (!el) return '';
    const control = el.matches?.('input,textarea,select') ? el : el.querySelector?.('input,textarea,select');
    const value = normalizeText(control?.value || el.innerText || el.textContent || '');
    return value;
  }

  function findValueByLabels(labels) {
    const wanted = labels.map((x) => normalizeText(x).toLowerCase());
    const roots = [
      document.querySelector('#divThongTinVanBan'),
      document.querySelector('#rightContentDLK'),
      document.querySelector('#div_doc_detail'),
      document.querySelector('#div_thongtin_chitiet')
    ].filter(el=>el && isElementVisible(el));
    if(!roots.length)roots.push(document.body);

    // 1) Bảng kiểu iOffice: một hàng có nhiều cặp nhãn/giá trị (td1->td2, td3->td4...).
    for (const root of roots) {
      for (const row of root.querySelectorAll('tr')) {
        if (!isElementVisible(row)) continue;
        const cells = [...row.querySelectorAll(':scope > th, :scope > td')];
        for (let i = 0; i < cells.length; i++) {
          if (!labelMatches(cells[i].innerText, wanted)) continue;
          const candidate = readControlOrText(cells[i + 1]);
          if (candidate && !labelMatches(candidate, wanted) && !looksLikeMetadataLabel(candidate) && !looksLikeGarbageText(candidate)) return candidate;
        }
      }
    }

    // 2) Các form div/label thông thường.
    for (const root of roots) {
      const rows = [...root.querySelectorAll('.info-row, .form-group, .row')];
      for (const row of rows) {
        if (!isElementVisible(row)) continue;
        const keyNodes = [...row.querySelectorAll('.info-row-key, .control-label, label, th')];
        const keyEl = keyNodes.find((el) => labelMatches(el.innerText, wanted));
        if (!keyEl) continue;
        const candidates = [
          row.querySelector('.info-row-value'),
          keyEl.nextElementSibling,
          ...[...row.children].filter((x) => x !== keyEl)
        ].filter(Boolean);
        for (const node of candidates) {
          const value = readControlOrText(node);
          if (value && !labelMatches(value, wanted) && !looksLikeMetadataLabel(value) && !looksLikeGarbageText(value)) return value;
        }
      }
    }

    // 3) Fallback: tìm đúng ô có chữ nhãn rồi lấy sibling bên cạnh.
    const selectors = 'label,th,td,span,.info-row-key,.control-label,div';
    for (const root of roots) {
      for (const el of root.querySelectorAll(selectors)) {
        if (el.childElementCount > 2)continue;
        const text = normalizeText(el.textContent || '');
        if(text.length>80 || !isElementVisible(el))continue;
        if (text.length > 80 || !labelMatches(text, wanted)) continue;
        const candidates = [el.nextElementSibling, el.parentElement?.nextElementSibling];
        if (el.parentElement) {
          const siblings = [...el.parentElement.children];
          const idx = siblings.indexOf(el);
          if (idx >= 0) candidates.push(siblings[idx + 1]);
        }
        for (const node of candidates.filter(Boolean)) {
          const value = readControlOrText(node);
          if (value && !labelMatches(value, wanted) && !looksLikeMetadataLabel(value) && !looksLikeGarbageText(value) && value.length < 500) return value;
        }
      }
    }
    return '';
  }

  function extractHeading() {
    const root = document.querySelector('#div_thongtin_chitiet');
    const rootText = normalizeText(root?.innerText || '');

    // Ưu tiên đúng dòng tiêu đề văn bản đang hiển thị; tránh bắt nhầm CSS kiểu [selector]:hover {...}.
    const visibleCandidates = root
      ? [...root.querySelectorAll('div,span,p,b,strong,h1,h2,h3,h4')]
          .filter(isElementVisible)
          .map((el) => normalizeText(el.innerText || el.textContent || ''))
          .filter((text) => text.length >= 20 && text.length <= 650 && /^\[[^\]]+\]\s*/.test(text))
          .sort((a, b) => a.length - b.length)
      : [];

    const candidates = [...visibleCandidates, rootText];
    for (const text of candidates) {
      const matches = [...String(text).matchAll(/\[([^\]]{5,240})\]\s*([^\[]+?)(?=Nén\s+và\s+tải\s+tất\s+cả|FILE\s+ĐÍNH\s+KÈM|TỆP\s+ĐÍNH\s+KÈM|Đơn vị ban hành|Số đến|Độ khẩn|$)/ig)];
      for (const match of matches) {
        const bracket = normalizeText(match[1]);
        const summary = cleanTrichYeu(match[2]);
        if (!summary || looksLikeGarbageText(summary)) continue;
        // Header iOffice thật thường có loại VB/số/ngày; loại CSS selector giả sẽ không thỏa điều kiện này.
        if (!/(?:công\s*văn|thông\s*báo|quyết\s*định|kế\s*hoạch|báo\s*cáo|tờ\s*trình|giấy\s*mời|nghị\s*quyết|chỉ\s*thị|số\s*[:\d])/i.test(bracket)) continue;
        return { bracket, summary };
      }
    }
    return { bracket: '', summary: '' };
  }


  function detectDocumentDirection() {
    const title = normalizeText(document.title || '').toLowerCase();
    // Tên màn hình iOffice là tín hiệu nhẹ và ổn định nhất.
    if (/văn bản đến|văn bản vào sổ|van ban den|vao so/.test(title)) return 'incoming';
    if (/văn bản đi|van ban di/.test(title)) return 'outgoing';
    // DOM VB đi mới: title nằm ngay trong <prefix>_grid.
    if ([...document.querySelectorAll('[id$="_vbtitle"]')].some(isElementVisible)) return 'outgoing';
    const incomingDom = Boolean(document.querySelector('#txt_so_den,#txt_ngay_den,#modal_xuly_vanbanscan,[name="rd_unit_noibo_emp"],[name="rd_unit_emp"],#btn_xuly'));
    if (incomingDom) return 'incoming';
    const outgoingDom = Boolean(document.querySelector('[id$="_InfoTable"],[id$="_FileList"],#btn_vdi_savedoc,#vanbandi_lienthong_modal'));
    return outgoingDom ? 'outgoing' : 'incoming';
  }

  function currentWorkflow() {
    if (state.userRole === 'tracker') { state.workflow = 'tracker'; return 'tracker'; }
    const direction = detectDocumentDirection();
    state.documentDirection = direction;
    state.workflow = `leader-${direction}`;
    return state.workflow;
  }

  function workflowLabel(workflow = currentWorkflow()) {
    if (workflow === 'leader-incoming') return 'VĂN BẢN ĐẾN';
    if (workflow === 'leader-outgoing') return 'VĂN BẢN ĐI';
    return 'SỔ THEO DÕI';
  }

  function isoToVi(value) {
    const m = String(value || '').match(/^(\d{4})-(\d{2})-(\d{2})$/);
    return m ? `${m[3]}/${m[2]}/${m[1]}` : String(value || '');
  }

  function parseIsoLocal(value) {
    const m = String(value || '').match(/^(\d{4})-(\d{2})-(\d{2})$/);
    if (!m) return null;
    const d = new Date(Number(m[1]), Number(m[2])-1, Number(m[3]));
    return Number.isNaN(d.getTime()) ? null : d;
  }

  function daysUntil(value) {
    const d = parseIsoLocal(value);
    if (!d) return null;
    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    return Math.round((d - today) / 86400000);
  }


  function primaryDeadline(suggestion = state.lastSuggestion) {
    const tasks = Array.isArray(suggestion?.tasks) ? suggestion.tasks : [];
    return tasks.find(t => /^\d{4}-\d{2}-\d{2}$/.test(String(t?.deadline || ''))) || null;
  }

  function extractDocumentContext() {
    const direction = detectDocumentDirection();
    const attachments = [];
    const descriptors = [];
    const previewText = '';

    if (direction === 'outgoing') {
      const visibleOne = (selector) => [...document.querySelectorAll(selector)].find(isElementVisible) || document.querySelector(selector);
      const titleEl = visibleOne('[id$="_vbtitle"]');
      const info = visibleOne('[id$="_InfoTable"]');
      const readInfo = (label) => {
        if (!info) return '';
        const wanted = normalizeText(label).toLowerCase();
        for (const row of info.querySelectorAll('[class*="inforow"],div,tr')) {
          const lbl = normalizeText(row.querySelector?.('.lbl')?.textContent || '').toLowerCase();
          if (lbl !== wanted) continue;
          return normalizeText(row.querySelector?.('.val')?.textContent || '');
        }
        return '';
      };
      const trichYeu = cleanTrichYeu(titleEl?.textContent || '');
      const symbol = readInfo('Số ký hiệu');
      const docType = readInfo('Hình thức');
      const urgency = readInfo('Độ khẩn') || 'Thường';
      const author = readInfo('Người soạn thảo');
      const documentType = readInfo('Loại văn bản');
      const summaryBtn = visibleOne('button.summary-btn[onclick*="dlkXemVbDi_showTongHop_"]');
      const onclick = String(summaryBtn?.getAttribute?.('onclick') || '');
      const resultId = onclick.match(/dlkXemVbDi_showTongHop_(\d+)/i)?.[1] || '';
      const root = titleEl?.closest?.('[id$="_grid"]') || info?.closest?.('[id$="_grid"]') || visibleOne('[id$="_grid"]');
      const visibleOutgoing = [...document.querySelectorAll('[id$="_vbtitle"],[id$="_InfoTable"],[id$="_FileList"]')].some(isElementVisible);
      return {
        documentId: normalizeText(resultId),
        detected: Boolean(visibleOutgoing),
        trichYeu: trichYeu || 'Chưa nhận diện được trích yếu',
        sender: '',
        author,
        symbol,
        documentDate: '',
        docType: normalizeText(docType || documentType),
        urgency,
        attachmentNames: attachments,
        attachmentRevision: descriptors.map(d=>[d.fileId,d.viewerToken,d.date,d.scopeKind].join(':')).join('|'),
        previewText,
        previewChars: 0,
        direction
      };
    }

    const heading = extractHeading();
    const titleText = cleanTrichYeu(heading.summary || findValueByLabels(['Trích yếu']));
    const sender = findValueByLabels(['Đơn vị ban hành', 'Cơ quan ban hành', 'Cơ quan gửi']);
    const urgency = findValueByLabels(['Độ khẩn']);
    const docTypeRaw = document.querySelector('#dcmTypeCode')?.value || findValueByLabels(['Hình thức']);
    let symbol = findValueByLabels(['Số ký hiệu', 'Số, ký hiệu']);
    if (!symbol && heading.bracket) {
      const m = heading.bracket.match(/(?:số\s*)?([^\s]+\/[A-ZĐ0-9-]+)/i);
      if (m) symbol = m[1];
    }
    let documentDate = findValueByLabels(['Ngày văn bản']);
    if (!documentDate && heading.bracket) {
      const m = heading.bracket.match(/ngày\s+(\d{1,2}\/\d{1,2}\/\d{4})/i);
      if (m) documentDate = m[1];
    }
    const fallbackText = normalizeText(document.querySelector('#div_thongtin_chitiet')?.innerText || '');
    const fallbackTitle = titleText || (() => {
      const vv = fallbackText.match(/(?:V\/v|Về việc)\s+(.{10,320}?)(?=FILE ĐÍNH KÈM|Đơn vị ban hành|$)/i);
      return vv ? cleanTrichYeu(vv[0]) : '';
    })();
    const documentId = document.querySelector('#idVB')?.value || document.querySelector('#hide_docid')?.value || '';
    return {
      documentId: normalizeText(documentId),
      detected: [...document.querySelectorAll('#btn_xuly,#div_thongtin_chitiet,#modal_detail_doc_popup')].some(isElementVisible),
      trichYeu: fallbackTitle || 'Chưa nhận diện được trích yếu',
      sender: sender || 'Chưa nhận diện được đơn vị ban hành',
      author: '',
      symbol,
      documentDate,
      docType: normalizeText(docTypeRaw),
      urgency: urgency || 'Thường',
      attachmentNames: attachments,
      attachmentRevision: descriptors.map(d=>[d.fileId,d.viewerToken,d.date,d.scopeKind].join(':')).join('|'),
      previewText,
      previewChars: previewText.length,
      direction
    };
  }

  function getDocumentKey(ctx) {
    if (!ctx?.detected) return '';
    // ID văn bản là khóa ổn định. Không đưa trạng thái tệp/viewer vào khóa vì chúng tải bất đồng bộ và từng làm cùng một văn bản bị nhận nhầm là văn bản mới.
    if (ctx.documentId) return `id:${ctx.documentId}`;
    return [ctx.symbol, ctx.documentDate, ctx.sender, ctx.trichYeu, ...(ctx.attachmentNames || []).slice(0, 3)]
      .map((x) => normalizeText(x).toLowerCase())
      .filter(Boolean)
      .join('|');
  }

  function resetProgressLog() {
    state.progressLog = [];
    state.lastWebPhase = '';
    if (state.refs.progressDetails) state.refs.progressDetails.open = false;
    if (state.refs.aiInfoDetails) state.refs.aiInfoDetails.open = false;
    renderProgressLog();
  }

  function progressElapsed() {
    return state.analysisStartedAt ? Math.max(0, performance.now() - state.analysisStartedAt) : 0;
  }

  function addProgress(message, kind = 'info', key = '') {
    const text = normalizeText(message);
    if (!text) return;
    const last = state.progressLog[state.progressLog.length - 1];
    if (key && last?.key === key && last?.message === text) return;
    if (!key && last?.message === text) return;
    state.progressLog.push({
      atMs: progressElapsed(),
      message: text,
      kind,
      key: key || ''
    });
    if (state.progressLog.length > 80) state.progressLog = state.progressLog.slice(-80);
    renderProgressLog();
  }

  function renderProgressLog() {
    if (!state.refs.source) return;
    const items = state.progressLog || [];
    if (!items.length) {
      state.refs.source.innerHTML = '<div class="progress-empty">Chưa chạy phân tích.</div>';
    } else {
      state.refs.source.innerHTML = items.map((item) => {
        const icon = item.kind === 'success' ? '✓' : item.kind === 'warn' ? '⚠' : item.kind === 'error' ? '✕' : '•';
        return `<div class="progress-row ${escapeHtml(item.kind)}"><span class="progress-time">${escapeHtml(formatDuration(item.atMs))}</span><span class="progress-icon">${icon}</span><span class="progress-text">${escapeHtml(item.message)}</span></div>`;
      }).join('');
    }
    if (state.refs.progressSummary) {
      const label=state.refs.progressSummary.querySelector?.('.progress-summary-label'); if(label) label.textContent=`Tiến trình xử lý${items.length ? ` (${items.length})` : ''}`;
    }
  }

  async function copyTextToClipboard(text,label){
    const value=String(text||'');
    if(!value){setMessage(`Chưa có ${label}. Hãy phân tích AI trước.`,'info');return;}
    try{await navigator.clipboard.writeText(value);setMessage(`✓ Đã copy ${label}.`,'success');}
    catch(_){const ta=document.createElement('textarea');ta.value=value;ta.style.position='fixed';ta.style.opacity='0';document.body.appendChild(ta);ta.select();document.execCommand('copy');ta.remove();setMessage(`✓ Đã copy ${label}.`,'success');}
  }
  function captureAiDebug(result){
    state.lastAiSentText=String(result?._debug?.sent||'');
    state.lastAiReceivedText=String(result?._debug?.received||'');
    state.lastPrivacyStats=result?._debug?.privacyStats||state.lastPrivacyStats||null;
  }
  function privacyStatsText(stats){
    const s=stats||{},parts=[];
    if(Number(s.persons))parts.push(`${s.persons} tên người`);
    if(Number(s.addresses))parts.push(`${s.addresses} địa chỉ`);
    if(Number(s.ids))parts.push(`${s.ids} số định danh`);
    if(Number(s.phones))parts.push(`${s.phones} SĐT`);
    if(Number(s.emails))parts.push(`${s.emails} email`);
    if(Number(s.dob))parts.push(`${s.dob} ngày sinh`);
    if(Number(s.bankAccounts))parts.push(`${s.bankAccounts} tài khoản/thẻ`);
    if(Number(s.credentials))parts.push(`${s.credentials} thông tin đăng nhập`);
    if(Number(s.sensitive))parts.push(`${s.sensitive} thuộc tính nhạy cảm`);
    if(Number(s.parcel))parts.push(`${s.parcel} thông tin thửa/tài sản`);
    if(Number(s.coordinates))parts.push(`${s.coordinates} tọa độ`);
    if(Number(s.fileNames))parts.push(`${s.fileNames} tên tệp`);
    return parts.join(' · ');
  }
  function privacyRiskText(risk){
    const flags=Array.isArray(risk?.flags)?risk.flags:[];
    const labels={medical:'sức khỏe/bệnh án',children:'trẻ em', 'poverty-social':'an sinh/hộ nghèo','complaint-denunciation':'khiếu nại/tố cáo','law-enforcement':'thực thi pháp luật',banking:'tài chính/ngân hàng',biometric:'sinh trắc học','private-family':'đời tư/gia đình','online-behavior':'hành vi trực tuyến',credentials:'thông tin đăng nhập','state-secret':'dấu mức độ bí mật'};
    return flags.map(x=>labels[x]||x).filter(Boolean).join(' · ');
  }

  function handleReaderProgress(progress) {
    const message = progress?.message || 'Đang đọc tài liệu…',phase=String(progress?.phase||'reader');
    setMessage(message, 'info');
    const successPhases=new Set(['bundle','dedupe','scan-ready','primary-select']);
    const warnPhases=new Set(['timeout','scan-skipped','size-limit-skipped','appendix-required','primary-fallback','primary-late-fallback','discover-wait','collision']);
    const kind = successPhases.has(phase) ? 'success'
      : warnPhases.has(phase) || (phase==='file-result' && Number(progress?.chars||0)<120) ? 'warn'
      : 'info';
    addProgress(message, kind, `${phase}:${progress?.name || progress?.index || ''}`);
  }

  async function stopCurrentAnalysis() {
    if(!state.busy)return;
    state.cancelRequested=true;state.activeAbortController?.abort();
    runtimeMessagePromise({type:'AI_CANCEL'}).catch(()=>{});
    if(state.pendingWebJob)runtimeMessagePromise({type:'WEB_AUTOMATION_CANCEL',jobId:state.pendingWebJob}).catch(()=>{});
    setMessage('Đang dừng tác vụ…','info');
  }

  function updateHeaderAction() {
    const btn = state.refs.headerActionBtn;
    if (!btn) return;
    const workflow = currentWorkflow();
    const trackerMode = workflow === 'tracker';
    btn.classList.toggle('hidden', trackerMode);
    if (trackerMode) return;
    const outgoing = workflow === 'leader-outgoing';
    const detected = Boolean(state.lastContext?.detected);
    const done = Boolean(state.lastSuggestion && state.analyzedKey === state.documentKey);
    btn.disabled = Boolean(state.busy || state.updateLocked || state.transferRunning);
    const elapsedSec=state.busy&&state.analysisStartedAt?Math.max(0,Math.floor((performance.now()-state.analysisStartedAt)/1000)):0;
    btn.textContent = state.busy
      ? (outgoing ? `⏳ Kiểm tra · ${elapsedSec}s` : `⏳ Phân tích · ${elapsedSec}s`)
      : outgoing
        ? (done ? '↻ Kiểm tra lại' : '🔎 Kiểm tra văn bản')
        : (done ? '↻ Phân tích lại' : '✨ Phân tích AI');
    btn.title = detected
      ? (outgoing ? 'Kiểm tra văn bản đi · ưu tiên bản Word trong FILE TRÌNH KÝ' : 'Phân tích văn bản hiện tại')
      : 'Mở một văn bản trên iOffice để sử dụng';
    state.refs.headerStopBtn?.classList.toggle('hidden', !state.busy);
  }

  function updatePrimaryAction() {
    const btn = state.refs.suggestBtn;
    if (!btn) return;
    const workflow = currentWorkflow();
    const phase = state.workflowPhase || 'analyze';
    const incoming = workflow === 'leader-incoming';
    const outgoing = workflow === 'leader-outgoing';

    if (state.refs.modeSelect) state.refs.modeSelect.disabled = Boolean(state.busy);
    if (state.refs.aiAnalyzeBtn) {
      state.refs.aiAnalyzeBtn.disabled = Boolean(state.busy) || !state.lastContext?.detected;
      state.refs.aiAnalyzeBtn.textContent = state.busy ? '⏳ Đang phân tích…'
        : (state.lastSuggestion && state.analyzedKey === state.documentKey ? '↻ Phân tích lại' : '✨ Phân tích AI');
    }
    updateHeaderAction();

    if (outgoing) {
      state.refs.applyOnlyBtn?.classList.add('hidden');
      btn.classList.add('hidden');
      return;
    }

    btn.classList.remove('hidden');
    const canApplyOnly = incoming && phase !== 'transfer' && phase !== 'transferred' && !state.busy;
    state.refs.applyOnlyBtn?.classList.toggle('hidden', !canApplyOnly);
    if (state.refs.applyOnlyBtn) state.refs.applyOnlyBtn.disabled = Boolean(state.busy) || !state.lastContext?.detected;
    btn.disabled = Boolean(state.busy) || !state.lastContext?.detected || phase === 'transferred';

    if (state.busy) {
      btn.textContent = '⏳ Đang xử lý…';
      btn.className = 'primary-btn busy';
    } else if (phase === 'transfer') {
      btn.textContent = 'Chuyển';
      btn.className = 'primary-btn transfer-state';
    } else if (phase === 'transferred') {
      btn.textContent = 'Đã chuyển';
      btn.className = 'primary-btn transfer-state';
    } else {
      btn.textContent = 'Áp dụng & Chuyển';
      btn.className = 'primary-btn apply-state';
    }
    updateAiToggleUi({quiet:true});
  }

  async function handlePrimaryAction() {
    if (state.busy || state.updateLocked || state.transferRunning) return;
    const phase = state.workflowPhase || 'analyze';
    const workflow = currentWorkflow();
    if (workflow === 'tracker') return;
    if (workflow === 'leader-outgoing') return runSelectedAnalysis();
    if (phase === 'transfer') return finalizeCurrentTransfer();
    if (phase === 'transferred') return;
    return applyCurrentSuggestion(true);
  }

  function clearAnalysisVisuals() {
    state.runId++;
    if(state.busy)runtimeMessagePromise({type:'AI_CANCEL'}).catch(()=>{});
    if(state.pendingWebJob) runtimeMessagePromise({type:'WEB_AUTOMATION_CANCEL',jobId:state.pendingWebJob}).catch(()=>{});
    state.busy=false;
    state.prepKey='';
    state.lastSuggestion = null;
    state.lastPrep = null;
    state.lastPreparedPayload = null;
    state.trackerAttachmentReady = null;
    state.lastSignals = [];
    state.analyzedKey = '';
        state.pendingWebJob = null;
    state.cancelRequested = false;
    state.appliedKey = '';
    state.finalizing = false;
    state.lastAnalysisKind = '';
    state.inputAudit = null;
    state.lastAnalysisMeta = null;
    state.pendingAppliedSuggestion = null;
    state.pendingTrackerContextSnapshot = null;
    state.workflowPhase = 'analyze';
    try { state.activeAbortController?.abort(); } catch (_) {}
    state.activeAbortController = null;
    resetProgressLog();
    renderInputAudit(null);
    hideFallbackActions();
    state.refs.manualPastePanel?.classList.add('hidden');
    if (!state.refs.suggestBtn) return;
    updatePrimaryAction();
    if (state.refs.ruleBtn) state.refs.ruleBtn.classList.add('hidden');
    state.refs.reanalyzeBtn?.classList.add('hidden');
    state.refs.analysisPanel?.classList.add('hidden');
    state.refs.instruction.value = '';
    autoSizeInstruction();
    state.refs.confidenceValue.textContent = '—';
    state.refs.confidenceValue.className = 'confidence-value';
    state.refs.confidenceFill.style.width = '0%';
    state.refs.confidenceFill.style.background = '#cbd5e1';
    state.refs.mainRoleSection?.style.removeProperty('--confidence-color');
    clearAnalysisTimer();
    if (state.refs.analysisMeta) { state.refs.analysisMeta.textContent = ''; state.refs.analysisMeta.title = ''; }
    state.refs.review.textContent = 'Chưa phân tích';
    state.refs.review.className = 'review warn';
    state.refs.reason.textContent = '';
    if (state.refs.analysisRouting) state.refs.analysisRouting.textContent = '';
    if (state.refs.signalList) state.refs.signalList.innerHTML = '';
    if (state.refs.deadlineCard) { state.refs.deadlineCard.innerHTML = ''; if (currentWorkflow()==='leader-incoming') renderDeadlineCard(manualSuggestionFromUi()); else state.refs.deadlineCard.classList.add('hidden'); }
    if (state.refs.modeResult) { state.refs.modeResult.innerHTML = ''; state.refs.modeResult.classList.add('hidden'); }
    renderProgressLog();
    refreshUnitOptions(true);
    renderRoleChips();
    updateTrackerInlineOwner();
    setBusy(false);
  }

  function markAnalyzed() {
    state.analyzedKey = state.documentKey;
    const workflow = currentWorkflow();
    state.workflowPhase = ['leader-outgoing'].includes(workflow) ? 'reviewed' : 'apply';
    updatePrimaryAction();
    if (state.refs.ruleBtn) state.refs.ruleBtn.classList.add('hidden');
    if (state.refs.analysisTitle) state.refs.analysisTitle.textContent = state.lastAnalysisKind === 'rules' ? 'Phân tích · Local nhanh' : `Phân tích · ${state.analysisMode === 'rules' ? 'Local nhanh' : state.analysisMode === 'gemini-web' ? 'Gemini Web' : state.analysisMode === 'chatgpt-web' ? 'ChatGPT Web' : 'API'}`;
    state.refs.reanalyzeBtn?.classList.add('hidden');
    state.refs.analysisPanel?.classList.toggle('hidden', state.aiEnabled === false || workflow === 'leader-outgoing');
    updateAiToggleUi({quiet:true});
  }

  function cleanAnalysisReason(value) {
    let text = normalizeText(value || '');
    if (!text) return '';
    // Phần phân tích chỉ giữ lý do nghiệp vụ. Metadata đã hiển thị ở đầu widget nên không lặp lại.
    text = text
      .replace(/(?:^|[.;\n]\s*)(?:Số\s*\/?\s*ký\s*hiệu|Số\s*văn\s*bản|Nơi\s*nhận|Đơn\s*vị\s*ban\s*hành|Cơ\s*quan\s*ban\s*hành|Cơ\s*quan\s*gửi|Trích\s*yếu|Xử\s*lý\s*chính|Phối\s*hợp|Xem\s*để\s*biết)\s*:\s*[^.;\n]*/gi, ' ')
      .replace(/\s{2,}/g, ' ')
      .replace(/^[\s.;,:-]+|[\s.;,:-]+$/g, '')
      .trim();
    return text;
  }

  function cleanDocumentSummary(value, ctx = {}) {
    let text = normalizeText(value || '');
    if (!text) text = normalizeText(ctx?.trichYeu || '');
    if (!text) return '';
    text = text
      .replace(/\((?:U\d+|DUUBND)\)/gi, '')
      .replace(/\b(?:U\d+|DUUBND)\b/gi, '')
      .replace(/\s{2,}/g, ' ')
      .trim();
    const sentences = text.split(/(?<=[.!?;])\s+/).map(x=>x.trim()).filter(Boolean);
    const kept = sentences.filter(x => !/(?:không có|chưa có|không phát hiện)[^.!?;]{0,80}(?:mốc|thời hạn|deadline)|(?:thuộc|về)\s+lĩnh vực[^.!?;]{0,100}(?:phân công|xử lý chính)|(?:nên|đề xuất)\s+phân công|xử lý chính\s*(?:là|:)|phối hợp\s*(?:là|:)/i.test(x));
    text = (kept.length ? kept : sentences).join(' ').replace(/\s{2,}/g,' ').trim();
    if (!text) text = normalizeText(ctx?.trichYeu || '');
    return text.slice(0,1600);
  }

  function summaryHtml(value) {
    // Tóm tắt cần đọc như một đoạn văn hoàn chỉnh; không tự bôi đậm từ khóa gây rối mắt.
    return escapeHtml(normalizeText(value || ''));
  }

  function foldBusinessText(value) {
    return String(value || '').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/đ/g,'d').replace(/Đ/g,'D').toLowerCase().replace(/\s+/g,' ').trim();
  }

  function optionalResponseGuard(ctx = {}) {
    const text = foldBusinessText(ctx?.documentBundle?.combinedText || ctx?.previewText || '');
    if (!text || !/(?:ubnd|uy ban nhan dan)\s+(?:cac\s+)?xa(?:,?\s*phuong)?/.test(text)) return false;
    return /khong\s+nhan\s+duoc[^.\n]{0,260}(?:phan hoi|phuc dap|tra loi)[^.\n]{0,280}(?:xem nhu|duoc xem la)[^.\n]{0,220}(?:khong co thong tin|khong phan hoi|chua duoc)/.test(text)
      || /(?:truong hop|neu)[^.\n]{0,180}khong\s+co[^.\n]{0,180}(?:khong can|khong phai)[^.\n]{0,120}(?:phan hoi|tra loi|gui|bao cao)/.test(text)
      || /neu\s+co[^.\n]{0,180}(?:thong tin|so lieu)[^.\n]{0,180}(?:cung cap|phan hoi|tra loi)/.test(text);
  }

  function sanitizeSuggestion(raw, ctx) {
    const allowedIds=[...new Set([...getAvailableUnits().map(x=>x.value),...((state.activeRulePack?.units||[]).map(x=>x.id))])];
    const validated=globalThis.IOfficeResultValidator.validate(raw,{
      workflow:currentWorkflow(),allowedUnitIds:allowedIds,context:ctx||{}
    });
    let mainUnit=validated.mainUnit;
    let coordinationUnits=[...(validated.coordinationUnits||[])];
    // iOffice cần một đầu mối nhận; việc nâng PH đầu tiên thành XLC chỉ là routing UI,
    // tuyệt đối không biến thành actionRequired hay nhiệm vụ Tracker.
    if(currentWorkflow()==='leader-incoming'&&!mainUnit&&coordinationUnits.length){
      mainUnit=coordinationUnits.shift();
      validated.requiresReview=true;
      validated.signals=uniq([...(validated.signals||[]),'AI chưa chọn XLC; tạm dùng đơn vị phối hợp đầu tiên làm đầu mối iOffice.']).slice(0,12);
    }
    let actionRequired=validated.actionRequired===true;
    let taskScope=validated.taskScope;
    let trackRecommended=validated.trackRecommended===true;
    let trackingReason=normalizeText(validated.trackingReason||'');
    let safeTasks=[...(validated.tasks||[])];
    let guardedOptional=false;
    if(currentWorkflow()==='leader-incoming'&&optionalResponseGuard(ctx)&&taskScope==='direct'){
      guardedOptional=true;actionRequired=false;taskScope='coordination';trackRecommended=false;
      trackingReason='Yêu cầu phản hồi có điều kiện; không phản hồi được văn bản quy ước là không có thông tin nên không tự tạo nhiệm vụ theo dõi.';
    }
    // Không dùng task/hạn để tự bật Tracker khi phạm vi không trực tiếp. Giữ allTasks để không mất dữ liệu AI phục vụ chẩn đoán.
    const allTasks=safeTasks.map(x=>({...x}));
    if(currentWorkflow()==='leader-incoming'&&taskScope!=='direct'){
      safeTasks=[];trackRecommended=false;actionRequired=false;
    }
    const instruction=guardedOptional
      ? `Giao ${unitDisplayNameById(mainUnit||'')||'đơn vị chuyên môn'} rà soát; chỉ tham mưu phản hồi khi có thông tin liên quan theo đề nghị của văn bản.`
      : conciseInstruction(validated.instruction,mainUnit,safeTasks,taskScope);
    return {
      ...validated,
      actionRequired,mainUnit,coordinationUnits,viewUnits:[],instruction,tasks:safeTasks,allTasks,
      taskScope,trackRecommended,trackingReason,
      documentSummary:cleanDocumentSummary(validated.documentSummary||validated.reason,ctx),
      reason:cleanAnalysisReason(validated.reason),
      requiresReview:validated.requiresReview||!!ctx?.documentBundle?.requiresReviewForUnreadable||!!ctx?.documentBundle?.appendixRequiredMissing||(currentWorkflow()==='leader-incoming'&&!mainUnit)
    };
  }

  function buildAiPayload(ctx, signals, rulePack = null) {
    const availableIds = new Set(getAvailableUnits().map((x) => x.value));
    const activePack = globalThis.IOfficeRulePack?.resolvePack(rulePack);
    const packUnits = new Map((activePack?.units || []).map(u => [u.id, u]));
    const units = (state.rules?.units || [])
      .filter((u) => ROUTING_UNIT_IDS.has(u.id) && (availableIds.has(u.id) || u.id === 'DUUBND' || availableIds.size === 0))
      .map((u) => {
        const rp = packUnits.get(u.id) || {};
        return {
          id: u.id,
          name: rp.name || u.name,
          kind: u.kind,
          preferredMain: !!u.preferredMain,
          operationalOnly: !!u.operationalOnly
        };
      });

    const workflow = currentWorkflow();
    const selected = globalThis.IOfficeRulePack?.buildSelectedAiInput(ctx, activePack) || { context: {
      trichYeu: ctx.trichYeu, sender: ctx.sender, symbol: ctx.symbol, documentDate: ctx.documentDate,
      docType: ctx.docType, urgency: ctx.urgency, attachmentNames: ctx.attachmentNames,
      previewText: ctx.documentBundle ? '' : ctx.previewText, documentBundle: ctx.documentBundle || null,
      direction: ctx.direction || state.documentDirection
    }};
    return {
      workflow,
      documentKeyHint:getDocumentKey(ctx),
      analysisProviderId: normalizeAnalysisMode(state.analysisMode) === 'api' ? normalizeText(state.quickApiProvider || '') : '',
      analysisModel: normalizeAnalysisMode(state.analysisMode) === 'api' ? normalizeText(state.quickApiModel || '') : '',
      direction: state.documentDirection,
      readerMode: state.forceReadAllOnce ? 'all' : undefined,
      context: selected.context,
      rulePackVersion: workflow === 'leader-incoming' ? (selected.rulePackVersion || activePack?.version || '') : '',
      inputPolicyVersion: selected.inputPolicyVersion || null,
      routingPolicy: state.rules?.policy || {},
      legalBasis: state.rules?.legalBasis || [],
      availableUnits: units,
      heuristicSignals: []
    };
  }

  function callAi(payload) {
    return safeRuntimeSend({ type:'AI_ANALYZE', payload }).then((response) => {
      if (!response?.ok) throw new Error(response?.error || 'Không gọi được AI Gateway');
      return response.data;
    });
  }

  function nativeSetValue(el, value) {
    const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const descriptor = Object.getOwnPropertyDescriptor(proto, 'value');
    if (descriptor?.set) descriptor.set.call(el, value); else el.value = value;
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    el.dispatchEvent(new Event('blur', { bubbles: true }));
  }

  function findCommentField() {
    const selectors = [
      '#txtCommentChuyenTiep',
      '#txtCommentChuyenTiepDSNhan',
      'textarea[id*="CommentChuyenTiep"]',
      'textarea[id*="commentChuyen"]',
      'textarea[placeholder*="nội dung" i]'
    ];
    for (const selector of selectors) {
      const all = [...document.querySelectorAll(selector)];
      const visible = all.find(isElementVisible);
      if (visible) return visible;
      if (all[0]) return all[0];
    }
    return null;
  }


  const sleepUi = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
  const actionText = (el) => normalizeText(el?.value || el?.innerText || el?.textContent || el?.getAttribute?.('aria-label') || el?.getAttribute?.('title') || '');
  const actionEnabled = (el) => !!el && !el.disabled && el.getAttribute?.('aria-disabled') !== 'true';

  function findActionElement(exactPattern, preferredSelectors = [], scope = document) {
    const candidates = [];
    for (const selector of preferredSelectors) {
      try { candidates.push(...scope.querySelectorAll(selector)); } catch (_) {}
    }
    try { candidates.push(...scope.querySelectorAll('button,a,input[type="button"],input[type="submit"],[role="button"]')); } catch (_) {}
    const seen = new Set();
    return candidates.find((el) => {
      if (!el || seen.has(el)) return false;
      seen.add(el);
      return isElementVisible(el) && actionEnabled(el) && exactPattern.test(actionText(el));
    }) || null;
  }

  function findOpenTransferButton() {
    // iOffice có nhiều nút cùng tên. Ưu tiên nút Chuyển xử lý đã được
    // chẩn đoán là mở bảng người nhận (chuyenTiepVanBanV2), sau đó mới
    // fallback sang nút editDoc/Xử lý ở các giao diện cũ.
    const preferred = [
      '#div_btn_chuyentiep_detail > button',
      '#div_btn_chuyentiep_detail button.btn-success',
      '#div_btn_xuly_detail > button',
      '#div_btn_xuly_detail button.btn-success'
    ];
    for (const selector of preferred) {
      const el = document.querySelector(selector);
      if (el && isElementVisible(el) && actionEnabled(el) && /^Chuyển\s*xử\s*lý$/i.test(actionText(el))) return el;
    }
    const transfer = findActionElement(/^Chuyển\s*xử\s*lý$/i, preferred);
    if (transfer) return transfer;
    const legacy = document.querySelector('#btn_xuly');
    if (legacy && isElementVisible(legacy) && actionEnabled(legacy)) return legacy;
    return findActionElement(/^Xử\s*lý$/i, ['#btn_xuly','[id*="xuly" i]']);
  }

  function processingFormReady(mainCode = '') {
    const comment = findCommentField();
    const main = mainCode ? findMainUnitControl(mainCode) : null;
    return !!(comment && controlVisible(comment) && (!mainCode || (main && controlVisible(main) && !main.disabled)));
  }

  async function waitForProcessingForm(mainCode, timeoutMs = 6500) {
    const started = performance.now();
    while (performance.now() - started < timeoutMs) {
      if (processingFormReady(mainCode)) return true;
      await sleepUi(90);
    }
    return processingFormReady(mainCode);
  }

  async function ensureProcessingForm(suggestion) {
    if (processingFormReadyForSuggestion(suggestion)) return true;
    const button = findOpenTransferButton();
    if (!button) return false;
    button.click();
    // Modal xuất hiện trước bảng người nhận. Chờ đúng toàn bộ control mà đề xuất cần.
    return await waitForSuggestionControls(suggestion, 15000);
  }

  function findTransferSubmitButton() {
    // Nút gửi thật trong cửa sổ “THÔNG TIN VĂN BẢN PHÁT HÀNH”.
    // Không được nhầm với nút “Chuyển xử lý” trên thanh công cụ.
    const exact = document.querySelector('#btndetail_action_send');
    if (exact && isElementVisible(exact) && actionEnabled(exact) && /^Chuyển$/i.test(actionText(exact))) return exact;

    const comment = findCommentField();
    const local = comment?.closest?.('[role="dialog"],.modal,.modal-dialog,.ui-dialog,.bootbox,.popup,.dialog') || null;
    const pattern = /^(?:Chuyển|Gửi)$/i;
    const preferred = ['#btndetail_action_send','button[id*="action_send" i]','input[id*="action_send" i]'];
    const localHit = local ? findActionElement(pattern, preferred, local) : null;
    if (localHit) return localHit;

    const hit = findActionElement(pattern, preferred, document);
    if (hit) return hit;

    // Fallback có kiểm soát cho một số phiên bản iOffice cũ.
    const candidates = [...document.querySelectorAll('button,a,input[type="button"],input[type="submit"]')];
    return candidates.find((el) => {
      if (!isElementVisible(el) || !actionEnabled(el)) return false;
      if (!/^(?:Chuyển|Gửi)$/i.test(actionText(el))) return false;
      const onclick = el.getAttribute?.('onclick') || '';
      return !/chuyenTiepVanBanV2|editDoc/i.test(onclick);
    }) || null;
  }

  function nativeSetChecked(el, checked) {
    if (!el) return false;
    const wanted = Boolean(checked);
    try {
      if (Boolean(el.checked) !== wanted) {
        // iOffice gắn khá nhiều handler trực tiếp lên checkbox. Click trước để
        // nghiệp vụ gốc chạy; nếu handler không đổi trạng thái thì mới ép property.
        try { el.click(); } catch (_) {}
      }
      if (Boolean(el.checked) !== wanted) {
        const proto = HTMLInputElement.prototype;
        const descriptor = Object.getOwnPropertyDescriptor(proto, 'checked');
        if (descriptor?.set) descriptor.set.call(el, wanted); else el.checked = wanted;
        el.dispatchEvent(new Event('input', { bubbles: true }));
        el.dispatchEvent(new Event('change', { bubbles: true }));
      }
      return Boolean(el.checked) === wanted;
    } catch (_) { return false; }
  }

  const controlVisible = el => !!el && (isElementVisible(el) || isElementVisible(el.closest?.('label') || el.parentElement));
  const chooseControl = selector => {const all=[...document.querySelectorAll(selector)];return all.find(controlVisible)||all[0]||null;};

  function unitCodeFromControl(el) {
    if (!el) return '';
    const candidates = [el.id, el.value, el.getAttribute?.('data-unit-id'), el.getAttribute?.('data-id'), el.name];
    for (const raw of candidates) {
      const m = String(raw || '').match(/(?:^|[^A-Z0-9])(U\d+)(?:$|[^A-Z0-9])/i) || String(raw || '').match(/(U\d+)/i);
      if (m) return m[1].toUpperCase();
    }
    return '';
  }

  // Với ĐƠN VỊ, iOffice Ea Ly có hai vùng nhận:
  // (1) “Đơn vị/cá nhân nhận trực tiếp” -> gửi trực tiếp cho lãnh đạo/cá nhân của phòng;
  // (2) “Đơn vị liên thông nội bộ” -> chuyển vào đầu mối/văn thư đơn vị.
  // Tiện ích phải ƯU TIÊN tuyệt đối vùng (2) cho XLC/PH/Xem theo đơn vị.
  // Chỉ fallback về vùng trực tiếp khi iOffice không có đơn vị đó trong bảng liên thông (ví dụ đơn vị hiện hành).
  function choosePreferredControl(preferredSelector, fallbackSelector='') {
    const preferred=[...document.querySelectorAll(preferredSelector)];
    const preferredVisible=preferred.find(controlVisible);
    if(preferredVisible) return preferredVisible;
    if(preferred[0]) return preferred[0];
    return fallbackSelector ? chooseControl(fallbackSelector) : null;
  }

  function findMainUnitControl(code) {
    const resolved=resolveIofficeUnitCode(code); if(!resolved)return null;
    const c=CSS.escape(resolved);
    return choosePreferredControl(
      `#chk_chuyen_lienthong_noibo_chutri${c},input[name="chk_chuyen_lienthong_noibo_chutri"][value="${c}"]`,
      `#rd_unit_emp_${c},#rdunitemp${c},input[name="rd_unit_emp"][value="${c}"],input[name="rd_unit_noibo_emp"][value="${c}"],input[name="rdo_chuyentiep"][value="${c}"]`
    );
  }
  function findCoordinationUnitControl(code) {
    const resolved=resolveIofficeUnitCode(code); if(!resolved)return null;
    const c=CSS.escape(resolved);
    return choosePreferredControl(
      `#chk_chuyen_lienthong_noibo${c},input[name="chk_chuyen_lienthong_noibo"][value="${c}"]`,
      `#chk_canhan_xuly_${c},#chkcanhanxuly${c},input[name="chk_unit_emp_xuly"][value="${c}"],input[name="chk_unit_noibo_xuly"][value="${c}"],input[name="chk_chuyentiep"][value="${c}"]`
    );
  }
  function findViewUnitControl(code) {
    const resolved=resolveIofficeUnitCode(code); if(!resolved)return null;
    const c=CSS.escape(resolved);
    return choosePreferredControl(
      `#chk_chuyen_lienthong_noibo_xem${c},input[name="chk_chuyen_lienthong_noibo_xem"][value="${c}"]`,
      `#chk_unit_emp_xem_${c},#chkunitempxem${c},input[name="chk_unit_emp_xem"][value="${c}"],input[name="chk_unit_noibo_xem"][value="${c}"],input[name="chk_chuyentiep_ph"][value="${c}"]`
    );
  }

  function allRoutingControls() {
    return [...document.querySelectorAll([
      'input[name="rd_unit_emp"]','input[name="rd_unit_noibo_emp"]','input[name="chk_unit_emp_xuly"]','input[name="chk_unit_noibo_xuly"]','input[name="chk_unit_emp_xem"]','input[name="chk_unit_noibo_xem"]',
      'input[name="rdo_chuyentiep"]','input[name="chk_chuyentiep"]','input[name="chk_chuyentiep_ph"]',
      'input[name="chk_chuyen_lienthong_noibo_chutri"]','input[name="chk_chuyen_lienthong_noibo"]','input[name="chk_chuyen_lienthong_noibo_xem"]',
      'input[id^="rd_unit_emp_U"]','input[id^="chk_canhan_xuly_U"]','input[id^="chk_unit_emp_xem_U"]',
      'input[id^="rdunitempU"]','input[id^="chkcanhanxulyU"]','input[id^="chkunitempxemU"]'
    ].join(','))];
  }

  function clearUnitSelections() {
    for (const el of allRoutingControls()) {
      if (!unitCodeFromControl(el) || !controlVisible(el)) continue;
      if (el.checked) nativeSetChecked(el, false);
    }
  }

  function requestedControlsForSuggestion(suggestion) {
    const items = [];
    if (suggestion?.mainUnit) items.push({ role:'XLC', code:suggestion.mainUnit, el:findMainUnitControl(suggestion.mainUnit) });
    for (const code of suggestion?.coordinationUnits || []) {
      if (code && code !== suggestion.mainUnit) items.push({ role:'PH', code, el:findCoordinationUnitControl(code) });
    }
    return items;
  }

  function processingFormReadyForSuggestion(suggestion) {
    const comment = findCommentField();
    const controls = requestedControlsForSuggestion(suggestion);
    const needsComment = Boolean(normalizeText(suggestion?.instruction || ''));
    return Boolean((!needsComment || (comment && controlVisible(comment))) && controls.length && controls.every(x => x.el && !x.el.disabled && controlVisible(x.el)));
  }

  async function waitForSuggestionControls(suggestion, timeoutMs = 15000) {
    const started = performance.now();
    while (performance.now() - started < timeoutMs) {
      if (processingFormReadyForSuggestion(suggestion)) return true;
      await sleepUi(100);
    }
    return processingFormReadyForSuggestion(suggestion);
  }

  function findDeadlineField() {
    const selectors = ['#txtHanXuLyChuyenTiep','input[id*="HanXuLyChuyenTiep" i]','input[name*="HanXuLy" i]'];
    for (const selector of selectors) {
      const all=[...document.querySelectorAll(selector)];
      const visible=all.find(isElementVisible);
      if (visible) return visible;
      if (all[0]) return all[0];
    }
    return null;
  }

  function directPersonProcessingControls(){
    return [...document.querySelectorAll('input[name="chk_chuyentiep"],input.chk_chuyentiep_class,input[id^="chk_canhan_xuly_"],input[id^="chkcanhanxuly"]')].filter(el=>!unitCodeFromControl(el));
  }
  async function applyAdditionalRecipient(suggestion){
    const roleKey=normalizeText(suggestion?.additionalRecipientKey||'');
    if(!roleKey)return {applied:false,count:0,reason:'none'};
    const confidence=Number(suggestion?.recipientConfidence||0);
    if(confidence<.85)return {applied:false,count:0,reason:'low-confidence'};
    const res=await safeRuntimeSend({type:'RECIPIENT_BINDINGS_GET',roleKey});
    const bindings=res?.ok&&Array.isArray(res.data)?res.data:[];
    if(!bindings.length)return {applied:false,count:0,reason:'unbound'};
    const wanted=new Map(bindings.filter(x=>x?.personKey).map(x=>[String(x.personKey),x]));
    const matched=new Set();
    const started=performance.now();
    while(performance.now()-started<2200&&matched.size<wanted.size){
      for(const el of directPersonProcessingControls()){
        const key=recipientKey(el);if(!wanted.has(String(key))||matched.has(String(key)))continue;
        if(nativeSetChecked(el,true)&&el.checked)matched.add(String(key));
      }
      if(matched.size>=wanted.size)break;
      await sleepUi(120);
    }
    return {applied:matched.size>0,count:matched.size,total:wanted.size,missing:[...wanted.keys()].filter(k=>!matched.has(k)),reason:matched.size?'ok':'not-found',roleKey};
  }

  function applySuggestion(suggestion) {
    const report = { main: false, coordination: [], view: [], comment: false, deadline: false, warnings: [] };
    const requested = requestedControlsForSuggestion(suggestion);
    const missing = requested.filter(x => !x.el || x.el.disabled || !controlVisible(x.el));
    const needsComment = Boolean(normalizeText(suggestion?.instruction || ''));
    if (missing.length || (needsComment && !findCommentField())) {
      report.warnings.push(`Danh sách đơn vị chưa sẵn sàng${missing.length ? `: ${missing.map(x=>`${x.role} ${x.code}`).join(', ')}` : ''}.`);
      return report;
    }

    clearUnitSelections();
    // Các lựa chọn vừa được áp dụng lên iOffice nhưng chưa Chuyển được xem là dữ liệu chưa lưu.
    state.updateDirty = true;

    if (suggestion?.mainUnit) {
      const main = findMainUnitControl(suggestion.mainUnit);
      report.main = nativeSetChecked(main, true);
      if (!report.main) report.warnings.push(`Không chọn được Xử lý chính ${suggestion.mainUnit}.`);
    } else {
      report.main = true; // Văn bản chỉ để biết có thể không có XLC.
    }

    for (const code of suggestion.coordinationUnits || []) {
      if (code === suggestion.mainUnit) continue;
      const el = findCoordinationUnitControl(code);
      const ok = nativeSetChecked(el, true);
      report.coordination.push({ code, ok });
      if (!ok) report.warnings.push(`Không chọn được Phối hợp ${code}.`);
    }

    const comment = findCommentField();
    if (comment && needsComment) {
      nativeSetValue(comment, suggestion.instruction || '');
      report.comment = String(comment.value || '').trim() === String(suggestion.instruction || '').trim();
      if (!report.comment) report.warnings.push('Không điền được Ý kiến chỉ đạo.');
    } else report.comment = !needsComment;

    const deadline = primaryDeadline(suggestion);
    if (deadline?.deadline) {
      const field = findDeadlineField();
      if (field) {
        nativeSetValue(field, isoToVi(deadline.deadline));
        report.deadline = normalizeText(field.value).includes(isoToVi(deadline.deadline));
        if (!report.deadline) report.warnings.push('Không điền được Hạn xử lý trên iOffice.');
      } else {
        // Không chặn chuyển nếu giao diện iOffice hiện tại không có trường hạn; Sổ vẫn ghi hạn từ văn bản.
        report.warnings.push('Không tìm thấy ô Hạn xử lý trên iOffice; chưa tự điền hạn vào iOffice.');
      }
    } else report.deadline = true;

    const verify = requestedControlsForSuggestion(suggestion);
    for (const item of verify) {
      if (!item.el?.checked) report.warnings.push(`${item.role} ${item.code} chưa được đánh dấu trên iOffice.`);
    }
    return report;
  }

  function getSelectedCodes(container) {
    return [...container.querySelectorAll('input[type="checkbox"]:checked')].map((x) => x.value);
  }

  function syncExclusiveRoles() {
    const main = state.refs.mainSelect?.value;
    const coord = new Set(getSelectedCodes(state.refs.coordBox));
    for (const box of state.refs.coordBox.querySelectorAll('input')) {
      if (box.value === main) box.checked = false;
    }
    for (const box of state.refs.viewBox.querySelectorAll('input')) {
      if (box.value === main || coord.has(box.value)) box.checked = false;
    }
  }

  function refreshUnitOptions(reset = false) {
    const units = getAvailableUnits().filter((u) => u.value !== 'U100');
    const select = state.refs.mainSelect;
    if (!select) return;
    const oldMain = reset ? '' : select.value;
    const oldCoord = reset ? new Set() : new Set(getSelectedCodes(state.refs.coordBox));
    const oldView = reset ? new Set() : new Set(getSelectedCodes(state.refs.viewBox));

    select.innerHTML = `<option value="">— Chọn đơn vị xử lý chính —</option>` + units.map((u) => `<option value="${escapeHtml(u.value)}" title="${escapeHtml(u.name)}">${escapeHtml(shortUnitName(u.value, u.name))}</option>`).join('');
    if (units.some((u) => u.value === oldMain)) select.value = oldMain;

    const buildChecks = (container, selected) => {
      container.innerHTML = '';
      for (const unit of units) {
        const box = document.createElement('input');
        box.type = 'checkbox';
        box.value = unit.value;
        box.dataset.name = unit.name;
        box.checked = selected.has(unit.value);
        box.addEventListener('change', () => { syncExclusiveRoles(); renderRoleChips(); });
        container.appendChild(box);
      }
    };
    buildChecks(state.refs.coordBox, oldCoord);
    state.refs.viewBox.innerHTML='';
    syncExclusiveRoles();
    renderRoleChips();
  }

  function unitNameById(id) {
    const unit = getAvailableUnits().find((x) => x.value === id);
    return unit?.name || rulesUnitMap().get(id)?.name || id;
  }

  function unitDisplayNameById(id) {
    return shortUnitName(id, unitNameById(id));
  }

  function renderRoleChips() {
    if (!state.refs.coordChips || !state.refs.viewChips) return;
    const render = (role, target, codes) => {
      target.innerHTML = '';
      if (!codes.length) { target.innerHTML = '<span class="role-empty">Chưa chọn</span>'; return; }
      for (const code of codes) {
        const chip = document.createElement('button');
        chip.type='button'; chip.className='role-chip'; chip.title=`Bấm để bỏ chọn: ${unitNameById(code)}`; chip.textContent=unitDisplayNameById(code);
        chip.addEventListener('click',()=>{
          const box=(role==='coord'?state.refs.coordBox:state.refs.viewBox).querySelector(`input[value="${CSS.escape(code)}"]`);
          if(box)box.checked=false;
          syncExclusiveRoles(); renderRoleChips();
          if(role==='view' && state.leaderWatchersLocked) void persistLeaderWatcherLock();
        });
        target.appendChild(chip);
      }
    };
    render('coord',state.refs.coordChips,getSelectedCodes(state.refs.coordBox));
    state.refs.viewChips.innerHTML='';
  }

  function renderPickerList() {
    const role = state.pickerRole;
    if (!role || !state.refs.pickerList) return;
    const query = normalizeText(state.refs.pickerSearch.value).toLowerCase();
    state.refs.pickerList.innerHTML = '';
    if(role==='watchers'){
      const selected=new Map(activeLeaderWatcherTargets().map(x=>[(x.key||x.name),x]));
      const people=(state.leaderWatcherDirectory||[]).filter(x=>!query || `${x.name||''} ${x.parentName||''} ${x.parentUnit||''}`.toLowerCase().includes(query));
      let lastGroup='';
      for(const person of people){
        const group=normalizeText(person.parentName||person.parentUnit||'Khác');
        if(group!==lastGroup){const h=document.createElement('div');h.className='picker-group';h.textContent=group;state.refs.pickerList.appendChild(h);lastGroup=group;}
        const id=person.key||person.name;
        const row=document.createElement('label');row.className='picker-row';
        row.innerHTML=`<input type="checkbox" ${selected.has(id)?'checked':''}><span><b>${escapeHtml(person.name||person.key)}</b></span>`;
        row.querySelector('input').addEventListener('change',(e)=>{
          const map=new Map(activeLeaderWatcherTargets().map(x=>[(x.key||x.name),x]));
          if(e.target.checked) map.set(id,{key:normalizeText(person.key||''),name:normalizeText(person.name||''),parentUnit:normalizeText(person.parentUnit||''),parentName:normalizeText(person.parentName||'')}); else map.delete(id);
          state.currentLeaderWatchers=[...map.values()];
          if(state.leaderWatchersLocked) void persistLeaderWatcherLock();
          renderLeaderWatcherChips();
        });
        state.refs.pickerList.appendChild(row);
      }
      if(!people.length) state.refs.pickerList.innerHTML='<div class="picker-empty">Chưa có danh bạ cá nhân. Hãy mở một lần màn Chuyển xử lý để iOffice nạp danh bạ.</div>';
      return;
    }
    const main = state.refs.mainSelect.value;
    const coord = new Set(getSelectedCodes(state.refs.coordBox));
    const store = role === 'coord' ? state.refs.coordBox : state.refs.viewBox;
    const units = getAvailableUnits().filter((u) => u.value !== 'U100' && (!query || `${u.name} ${u.value}`.toLowerCase().includes(query)));
    for (const unit of units) {
      const row = document.createElement('label');
      row.className = 'picker-row';
      const disabled = unit.value === main || (role === 'view' && coord.has(unit.value));
      const checked = !!store.querySelector(`input[value="${CSS.escape(unit.value)}"]`)?.checked;
      row.innerHTML = `<input type="checkbox" ${checked ? 'checked' : ''} ${disabled ? 'disabled' : ''}><span><b title="${escapeHtml(unit.name)}">${escapeHtml(shortUnitName(unit.value, unit.name))}</b></span>`;
      const box = row.querySelector('input');
      box.addEventListener('change', () => {
        const target = store.querySelector(`input[value="${CSS.escape(unit.value)}"]`);
        if (target) target.checked = box.checked;
        syncExclusiveRoles();
        renderRoleChips();
        if (role === 'view' && state.leaderWatchersLocked) void persistLeaderWatcherLock();
      });
      state.refs.pickerList.appendChild(row);
    }
  }

  async function openRolePicker(role) {
    state.pickerRole = role;
    if(role==='watchers'){
      state.refs.pickerTitle.textContent='Chọn cá nhân Xem để biết';
      state.refs.pickerSearch.placeholder='Tìm tên người hoặc đơn vị…';
      await loadLeaderWatcherDirectory();
    }else{
      state.refs.pickerTitle.textContent = role === 'coord' ? 'Chọn đơn vị phối hợp xử lý' : 'Chọn đơn vị xem để biết';
      state.refs.pickerSearch.placeholder='Tìm tên đơn vị hoặc mã…';
    }
    state.refs.pickerSearch.value = '';
    state.refs.picker.classList.remove('hidden');
    renderPickerList();
    setTimeout(() => state.refs.pickerSearch.focus(), 0);
  }

  function closeRolePicker() {
    state.pickerRole = null;
    state.refs.picker.classList.add('hidden');
  }


  function clearAnalysisTimer() {
    if (state.analysisTimer) clearInterval(state.analysisTimer);
    state.analysisTimer = null;
  }

  function beginAnalysisTimer() {
    clearAnalysisTimer();
    state.analysisStartedAt = performance.now();
    state.lastAnalysisMeta = null;
    if (state.refs.analysisPanel) state.refs.analysisPanel.classList.remove('hidden');
    if (state.refs.analysisMeta) state.refs.analysisMeta.textContent = 'Đang xử lý · 0.0 s';
    renderAiInfoSummary();
    state.analysisTimer = setInterval(() => {
      if (!state.analysisStartedAt) return;
      if (state.refs.analysisMeta) state.refs.analysisMeta.textContent = `Đang xử lý · ${formatDuration(performance.now() - state.analysisStartedAt)}`;
      updateHeaderAction();
      renderAiInfoSummary();
    }, 500);
  }

  function finishAnalysisMeta(ai, timing = {}, fallbackLabel = '') {
    clearAnalysisTimer();
    const totalMs = Number(timing.totalMs ?? (state.analysisStartedAt ? performance.now() - state.analysisStartedAt : 0));
    const aiMs = Number(timing.aiMs || 0);
    const prepMs = Number(timing.prepMs || 0);
    const usage = getTokenUsage(ai);
    const provider = fallbackLabel || ai?.providerLabel || ai?.provider || 'AI';
    const model = fallbackLabel ? '' : (ai?.model || 'model');
    const isRules = ['local-rules','local-fast'].includes(ai?.provider) || /quy tắc|local nhanh/i.test(provider);
    const tokenText = usage.estimated ? `~${usage.total.toLocaleString('vi-VN')} token` : `${usage.total.toLocaleString('vi-VN')} token`;
    const pieces = [provider];
    if (model) pieces.push(model);
    if (!isRules) pieces.push(tokenText);
    pieces.push(formatDuration(totalMs));
    const titleParts = [];
    if (usage.input != null) titleParts.push(`Input: ${Number(usage.input).toLocaleString('vi-VN')} token`);
    if (usage.output != null) titleParts.push(`Output: ${Number(usage.output).toLocaleString('vi-VN')} token`);
    if (prepMs) titleParts.push(`Đọc tài liệu: ${formatDuration(prepMs)}`);
    if (aiMs) titleParts.push(`AI: ${formatDuration(aiMs)}`);
    state.lastAnalysisMeta = { provider, model, usage, totalMs, aiMs, prepMs };
    if (state.refs.analysisMeta) {
      state.refs.analysisMeta.textContent = pieces.join(' · ');
      state.refs.analysisMeta.title = titleParts.join(' · ');
    }
    renderAiInfoSummary();
  }


  function stripInstructionPrefix(value) {
    let text = normalizeText(value || '');
    const prefixes = [state.instructionPrefixText,'VP đề xuất:','Văn phòng đề xuất:','Đề xuất:','Tham mưu:','Ý kiến đề xuất:'].map(normalizeText).filter(Boolean);
    for (const prefix of prefixes) {
      const escaped = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      text = text.replace(new RegExp(`^${escaped}\\s*`, 'i'), '');
    }
    return normalizeText(text);
  }

  function applyInstructionPrefix(value) {
    const text = stripInstructionPrefix(value);
    if (!text) return '';
    if (state.userRole !== 'leader' || !state.instructionPrefixEnabled) return text;
    const prefix = normalizeText(state.instructionPrefixText || '');
    return prefix ? `${prefix} ${text}` : text;
  }

  function autoSizeInstruction() {
    const el = state.refs?.instruction;
    if (!el) return;
    try {
      el.style.height = 'auto';
      const next = Math.max(96, Math.ceil(el.scrollHeight + 2));
      el.style.height = `${next}px`;
      el.style.overflowY = 'hidden';
    } catch (_) {}
  }



  function setWorkflowUi() {
    const workflow = currentWorkflow();
    const trackerMode = workflow === 'tracker';
    if (state.refs.workflowBadge) state.refs.workflowBadge.textContent = workflowLabel(workflow);
    if (state.refs.modeToggleBtn) {
      state.refs.modeToggleBtn.textContent = '📒';
      state.refs.modeToggleBtn.setAttribute('aria-pressed', String(trackerMode));
      state.refs.modeToggleBtn.classList.toggle('active', trackerMode);
      state.refs.modeToggleBtn.title = trackerMode ? 'Đóng Sổ theo dõi · quay lại phân tích văn bản' : 'Mở Sổ theo dõi';
      state.refs.modeToggleBtn.setAttribute('aria-label', trackerMode ? 'Đóng Sổ theo dõi' : 'Mở Sổ theo dõi');
    }
    state.refs.documentMode?.classList.toggle('hidden', trackerMode);
    state.refs.trackerBoard?.classList.toggle('hidden', !trackerMode);
    if (trackerMode) {
      globalThis.IOfficeTrackerBoard?.clearMatch?.();
      globalThis.IOfficeTrackerBoard?.activate?.();
      return;
    }
    globalThis.IOfficeTrackerBoard?.deactivate?.();
    const incoming = workflow === 'leader-incoming';
    if (incoming) globalThis.IOfficeTrackerBoard?.clearMatch?.();
    state.refs.mainRoleSection?.classList.toggle('hidden', !incoming);
    state.refs.coordSection?.classList.toggle('hidden', !incoming);
    state.refs.viewSection?.classList.toggle('hidden', !incoming);
    state.refs.instructionSection?.classList.toggle('hidden', !incoming);
    state.refs.inputAudit?.classList.remove('hidden');
    state.refs.progressDetails?.classList.remove('hidden');
    if (state.refs.instructionLabel) state.refs.instructionLabel.textContent = 'Ý kiến chỉ đạo';
    if (incoming) renderDeadlineCard(state.lastSuggestion || manualSuggestionFromUi());
    updateAiToggleUi({quiet:true});
    updatePrimaryAction();
    updateHeaderAction();
  }

  function formatTrackerStatusTime(ts = Date.now()) {
    const d=new Date(ts);
    const z=n=>String(n).padStart(2,'0');
    return `${z(d.getHours())}:${z(d.getMinutes())} ${z(d.getDate())}/${z(d.getMonth()+1)}/${d.getFullYear()}`;
  }

  async function refreshTrackerConnectionStatus() {
    if (!state.trackerConfigured) {
      state.trackerConnected=false;
      state.trackerVersion='';
      state.trackerTaskCount=0;
      state.trackerStatusText='Chưa cấu hình kết nối Sổ theo dõi';
      renderDeadlineCard(state.lastSuggestion || manualSuggestionFromUi());
      if (currentWorkflow()==='tracker') globalThis.IOfficeTrackerBoard?.render?.();
      return;
    }
    state.trackerStatusText='Đang kiểm tra kết nối Sổ theo dõi…';
    renderDeadlineCard(state.lastSuggestion || manualSuggestionFromUi());
    try {
      const res=await safeRuntimeSend({type:'TRACKER_TEST'}, {quiet:true});
      if(res?.ok){
        state.trackerConnected=true;
        const ver=normalizeText(res.data?.version || '');
        state.trackerVersion=ver.replace(/^v/i,'');
        state.trackerTaskCount=Math.max(0,Number(res.data?.taskCount||0));
        state.trackerStatusText=`Đã kết nối Sổ theo dõi${state.trackerVersion ? ' Tracker '+state.trackerVersion : ''} · ${state.trackerTaskCount} nhiệm vụ đang mở · Đồng bộ ${formatTrackerStatusTime()}`.replace(/\s+/g,' ').trim();
      } else {
        state.trackerConnected=false;
        state.trackerVersion='';
        state.trackerTaskCount=0;
        state.trackerStatusText=`Sổ theo dõi chưa kết nối${res?.error ? ` · ${normalizeText(res.error)}` : ''}`;
      }
    } catch(e) {
      state.trackerConnected=false;
      state.trackerVersion='';
      state.trackerTaskCount=0;
      state.trackerStatusText=`Sổ theo dõi chưa kết nối · ${normalizeText(e?.message || e)}`;
    }
    renderDeadlineCard(state.lastSuggestion || manualSuggestionFromUi());
    if (currentWorkflow()==='tracker') globalThis.IOfficeTrackerBoard?.render?.();
  }

  function renderDeadlineCard(s = null) {
    const box = state.refs.deadlineCard;
    if (!box) return;
    if (currentWorkflow() !== 'leader-incoming') { box.classList.add('hidden'); box.innerHTML=''; return; }

    const aiTasks = Array.isArray(s?.tasks) ? s.tasks.filter(Boolean) : [];
    const base = aiTasks.find(t=>textDateToIso(t.deadline||'')) || aiTasks[0] || {};
    const oldDeadline = textDateToIso(box.querySelector('.track-deadline')?.value || '');
    const deadline = state.manualDeadline !== null ? state.manualDeadline : (oldDeadline || textDateToIso(base.deadline || ''));
    const left = deadline ? daysUntil(deadline) : null;
    const badge = left==null?'':left<0?`Quá hạn ${Math.abs(left)} ngày`:left===0?'Hôm nay':left<=3?`Còn ${left} ngày`:'';
    const canTrack=Boolean(deadline);
    const autoTrack=Boolean(canTrack && s?.actionRequired===true && s?.taskScope==='direct' && s?.trackRecommended===true);
    if (state.trackingManualChoice === null) state.trackThisDocument = autoTrack;
    if(!canTrack) state.trackThisDocument=false;
    const tracking=Boolean(state.trackThisDocument && canTrack);
    const statusClass=state.trackerConnected===true?'ok':state.trackerConnected===false?'err':'checking';
    const statusText=normalizeText(state.trackerStatusText || 'Đang kiểm tra kết nối Sổ theo dõi…');

    box.innerHTML = `<div class="tracker-connection ${statusClass}"><span class="tracker-dot">●</span><span>${escapeHtml(statusText)}</span></div>
      <div class="tracker-inline-row">
        <button type="button" class="tracker-toggle ${tracking?'on':'off'}" ${canTrack?'':'disabled'} title="${canTrack?'Bật/tắt việc tạo nhiệm vụ trong Sổ theo dõi':'Chọn Hạn xử lý trước khi thêm vào Sổ theo dõi'}">${tracking?'✓ Thêm vào Sổ theo dõi':'＋ Thêm vào Sổ theo dõi'}</button>
        <label class="tracker-inline-deadline">Hạn xử lý <input class="track-deadline" type="date" value="${escapeHtml(deadline)}" aria-label="Hạn xử lý"></label>
        <span class="tracker-inline-owner" id="trackerInlineOwner">XLC: ${escapeHtml(unitDisplayNameById(state.refs.mainSelect?.value || s?.mainUnit || '') || 'chọn ở mục 1')}</span>
        ${badge?`<span class="tracker-inline-badge">${escapeHtml(badge)}</span>`:''}
      </div>
      <div class="tracker-inline-note ${tracking?'on':'off'}">${tracking ? 'Đã bật theo dõi · Sẽ gửi sau khi Chuyển văn bản.' : 'Chưa bật theo dõi'}</div>`;
    box.classList.remove('hidden');

    const dateInput = box.querySelector('.track-deadline');
    dateInput?.addEventListener('change', () => {
      state.trackingManualChoice=null;
      state.manualDeadline=textDateToIso(dateInput.value || '');
      if(!textDateToIso(dateInput.value || '')) { state.trackThisDocument=false; state.trackingManualChoice=false; }
      renderDeadlineCard(state.lastSuggestion || manualSuggestionFromUi());
    });
    box.querySelector('.tracker-toggle')?.addEventListener('click', () => {
      const d=textDateToIso(box.querySelector('.track-deadline')?.value || '');
      if(!d) return setMessage('Chọn Hạn xử lý trước khi thêm vào Sổ theo dõi.','info');
      if(!state.trackerConfigured || state.trackerConnected===false) {
        return setMessage('Sổ theo dõi chưa kết nối. Mở Cài đặt để kiểm tra URL/TOKEN.','error');
      }
      state.trackThisDocument=!state.trackThisDocument;
      state.trackingManualChoice=state.trackThisDocument;
      renderDeadlineCard(state.lastSuggestion || manualSuggestionFromUi());
      setMessage(state.trackThisDocument?'Đã bật: văn bản này sẽ được thêm vào Sổ theo dõi khi Chuyển.':'Đã tắt: văn bản này không ghi vào Sổ theo dõi.','info');
    });
  }

  function updateTrackerInlineOwner() {
    const el = state.refs.deadlineCard?.querySelector('#trackerInlineOwner');
    if (!el) return;
    const id = state.refs.mainSelect?.value || state.lastSuggestion?.mainUnit || '';
    el.textContent = `XLC: ${unitDisplayNameById(id) || 'chọn ở mục 1'}`;
  }

  function trackerSelectionEnabled() {
    return Boolean(currentWorkflow()==='leader-incoming' && state.trackThisDocument);
  }

  function trackingItemsFromUi(suggestion) {
    if(!trackerSelectionEnabled()) return [];
    const box=state.refs.deadlineCard;
    const deadline=textDateToIso(box?.querySelector('.track-deadline')?.value||'');
    const base=(suggestion.tasks||[]).find(t=>t.deadline===deadline)||(suggestion.tasks||[])[0]||{};
    const task=normalizeText(state.refs.instruction?.value || suggestion.instruction || '');
    const responsibleUnit=normalizeText(state.refs.mainSelect?.value || suggestion.mainUnit || '');
    return [{
      task, deadline,
      deadlineText:base.deadlineText||'', deadlineEvidence:base.deadlineEvidence||'', deadlineSource:deadline ? (base.deadlineSource||'manual') : 'none',
      responsibleUnit, scope:base.scope||suggestion.taskScope||'direct', trackRecommended:true,
      manualOverride: task!==normalizeText(base.task||'') || deadline!==(base.deadline||'') || responsibleUnit!==(base.responsibleUnit||suggestion.mainUnit||'')
    }];
  }

  function validateTrackingSelection(suggestion) {
    if(!trackerSelectionEnabled()) return {ok:true,items:[]};
    if(!state.trackerConfigured) return {ok:false,error:'Sổ theo dõi chưa sẵn sàng.'};
    if(state.trackerConnected===false) return {ok:false,error:'Sổ theo dõi chưa kết nối. Kiểm tra cấu hình trước khi chuyển.'};
    const items=trackingItemsFromUi(suggestion), t=items[0]||{};
    const missing=[];
    if(!normalizeText(t.task)) missing.push('Ý kiến chỉ đạo');
    if(!normalizeText(t.responsibleUnit)) missing.push('Xử lý chính');
    if(!/^\d{4}-\d{2}-\d{2}$/.test(String(t.deadline||''))) missing.push('Hạn xử lý');
    if(missing.length) return {ok:false,error:`Cần bổ sung trước khi ghi Sổ: ${missing.join(', ')}.`};
    return {ok:true,items};
  }

  function textDateToIso(value) {
    const s=normalizeText(value||'');
    let m=s.match(/^(\d{4})-(\d{2})-(\d{2})$/); if(m)return s;
    m=s.match(/^(\d{1,2})[\/\-.](\d{1,2})[\/\-.](\d{4})$/); if(m)return `${m[3]}-${String(m[2]).padStart(2,'0')}-${String(m[1]).padStart(2,'0')}`;
    return '';
  }

  function outgoingReviewScore(s){
    let score=100;for(const x of (s?.reviewIssues||[])){const sev=String(x?.severity||'low').toLowerCase();score-=sev==='high'?24:sev==='medium'?10:4;}
    if(s?.requiresReview && !(s?.reviewIssues||[]).some(x=>String(x?.severity||'').toLowerCase()==='high'))score-=6;
    return Math.max(0,Math.min(100,Math.round(score)));
  }
  function outgoingReviewDecision(score){
    if(score>=90)return {text:'Có thể trình duyệt',cls:'good'};
    if(score>=75)return {text:'Nên rà soát trước khi duyệt',cls:'warn'};
    return {text:'Nên sửa trước khi duyệt',cls:'bad'};
  }
  function renderModeResult(s) {
    const box = state.refs.modeResult;if (!box) return;
    if (currentWorkflow() === 'leader-outgoing') {
      const score=outgoingReviewScore(s),decision=outgoingReviewDecision(score);
      const issues=(s.reviewIssues||[]).map((x,i)=>`<div class="review-issue ${escapeHtml(x.severity)}"><div class="review-issue-head"><b>Lỗi ${i+1} · ${escapeHtml(x.category||'Kiểm tra')}</b><span>${escapeHtml(String(x.severity||'low').toUpperCase())}</span></div><div>${escapeHtml(x.detail)}</div>${x.evidence?`<small>Đoạn cần xem: ${escapeHtml(x.evidence)}</small>`:''}</div>`).join('');
      box.innerHTML=`<div class="review-title-row"><div class="mode-result-title">🔎 Kiểm tra văn bản</div><div class="review-score ${decision.cls}"><b>${score}</b><span>/100</span></div></div><div class="review-decision ${decision.cls}">${escapeHtml(decision.text)}</div><div class="review-score-note">Điểm dựa trên lỗi câu chữ, lặp, tính nhất quán và trình bày cơ bản trong phần tài liệu đã đọc.</div>${s.reviewSummary?`<div class="review-summary">${escapeHtml(s.reviewSummary)}</div>`:''}${issues||'<div class="mode-empty review-ok-empty">✓ Không phát hiện lỗi cơ bản đáng chú ý trong phần đọc được.</div>'}`;
      box.classList.remove('hidden');return;
    }
    box.classList.add('hidden');box.innerHTML='';
  }

  function populateSuggestion(s) {
    setWorkflowUi();
    refreshUnitOptions();
    state.refs.mainSelect.value = '';
    if (s.mainUnit && [...state.refs.mainSelect.options].some((o) => o.value === s.mainUnit)) state.refs.mainSelect.value = s.mainUnit;
    for (const box of state.refs.coordBox.querySelectorAll('input')) box.checked = (s.coordinationUnits || []).includes(box.value);
    for (const box of state.refs.viewBox.querySelectorAll('input')) box.checked = (s.viewUnits || []).includes(box.value);
    state.refs.instruction.value = currentWorkflow() === 'leader-incoming' ? applyInstructionPrefix(s.instruction || '') : (s.instruction || '');
    autoSizeInstruction();
    syncExclusiveRoles();
    renderRoleChips();

    const pct = Math.round((s.confidence || 0) * 100);
    const conf = confidenceStyle(pct);
    state.refs.confidenceValue.textContent = `${pct}%`;
    state.refs.confidenceValue.className = `confidence-value ${conf.cls}`;
    state.refs.confidenceFill.style.width = `${pct}%`;
    state.refs.confidenceFill.style.background = conf.color;
    state.refs.mainRoleSection?.style.setProperty('--confidence-color', conf.color);

    if (['leader-incoming'].includes(currentWorkflow()) && !s.actionRequired) {
      state.refs.review.textContent = '✓ Chỉ để biết';
      state.refs.review.className = 'review ok';
    } else {
      state.refs.review.textContent = s.requiresReview ? '⚠ Cần kiểm tra kỹ' : '✓ Có thể xem xét áp dụng';
      state.refs.review.className = `review ${s.requiresReview ? 'warn' : 'ok'}`;
    }
    const docSummary=cleanDocumentSummary(s.documentSummary||s.reason,state.lastContext||{});
    state.refs.reason.textContent=normalizeText(docSummary||s.reviewSummary||'');
    // A new analysis replaces the previous suggested deadline, never a stale document's deadline.
    const dueInput=state.refs.deadlineCard?.querySelector('.track-deadline');
    if(dueInput) dueInput.value='';
    state.trackingManualChoice=null;
    state.manualDeadline=null;
    renderDeadlineCard(s);
    renderModeResult(s);
    if (currentWorkflow() === 'leader-outgoing') setTimeout(()=>void globalThis.IOfficeTrackerBoard?.matchCurrentOutgoing?.(), 0);

    if (state.refs.analysisRouting) {
      const parts = [];
      if (s.mainUnit) parts.push(`Xử lý chính: ${unitDisplayNameById(s.mainUnit)}`);
      if (s.coordinationUnits?.length) parts.push(`Phối hợp: ${s.coordinationUnits.map(unitDisplayNameById).join(', ')}`);
      state.refs.analysisRouting.textContent = parts.join(' · ');
    }
    if (state.refs.signalList) {
      state.refs.signalList.innerHTML = '';
      state.refs.signalList.classList.add('hidden');
    }
    // Sau khi phân tích file chính, nếu kết quả có khả năng phát sinh nhiệm vụ/hạn
    // và còn tệp chưa đọc, đề xuất đọc thêm để xác minh thay vì tự đọc tràn lan từ đầu.
    if (currentWorkflow()==='leader-incoming' && state.refs.readAllBtn) {
      const b=state.lastPrep?.bundle || {};
      const otherCount=Array.isArray(b.otherFiles)?b.otherFiles.length:0;
      const hasDue=(s.tasks||[]).some(t=>t?.deadline||t?.deadlineText) || Boolean(s.deadline);
      const likely=!!(hasDue || b.likelyTaskDeadline || b.additionalReadSuggested || (s.taskScope==='ambiguous' && b.appendixReferenced));
      if (otherCount>0 && likely && b.readMode==='primary') {
        state.refs.readAllBtn.classList.remove('hidden');
        state.refs.readAllBtn.classList.add('recommended');
        state.refs.readAllBtn.textContent=`Đọc thêm tất cả (${otherCount})`;
        state.refs.readAllBtn.title='Có khả năng phát sinh nhiệm vụ/hạn. Đọc toàn bộ tệp còn lại rồi phân tích lại để xác minh phạm vi, sản phẩm và thời hạn.';
      }
    }
  }

  function analysisModeLabel(mode = state.analysisMode) {
    mode = normalizeAnalysisMode(mode);
    return mode === 'rules' ? 'Local nhanh'
      : mode === 'gemini-web' ? 'Gemini Web'
      : mode === 'chatgpt-web' ? 'ChatGPT Web'
      : 'API';
  }

  function renderAiInfoSummary() {
    const summaryEl=state.refs.aiInfoSummary||state.refs.inputAuditText;
    if(!summaryEl)return;
    const audit=state.inputAudit,meta=state.lastAnalysisMeta;
    const incoming=currentWorkflow()==='leader-incoming';
    const ruleVersion=incoming?(state.activeRulePack?.version||''):'';
    let model='';
    if(meta?.model) model=meta.model;
    else if(normalizeAnalysisMode(state.analysisMode)==='api') model=normalizeText(state.quickApiModel||'gemini-3.5-flash-lite');
    else if(normalizeAnalysisMode(state.analysisMode)==='gemini-web') model='Gemini Web';
    else if(normalizeAnalysisMode(state.analysisMode)==='chatgpt-web') model='ChatGPT Web';
    else model='Local Rule';
    const parts=[`Model: ${model||'AI'}`];
    if(ruleVersion)parts.push(`Rule: ${ruleVersion}`);
    if(audit&&(audit.sentWords||audit.extractedWords))parts.push(`${Number(audit.sentWords||audit.extractedWords).toLocaleString('vi-VN')} từ`);
    if(meta){
      const usage=meta.usage||{};
      if(Number(usage.total||0))parts.push(`${usage.estimated?'~':''}${Number(usage.total).toLocaleString('vi-VN')} token`);
      if(Number(meta.totalMs||0))parts.push(formatDuration(meta.totalMs));
    }
    summaryEl.textContent=parts.join(' · ');
    if(state.refs.aiInfoDetails){
      const cls=audit?(audit.complete&&!audit.skippedScans&&!audit.oversizedSkipped?'ok':'warn'):'pending';
      state.refs.aiInfoDetails.className=`ai-info ${cls}`;
    }
  }

  function renderInputAudit(bundle = null) {
    const box = state.refs.inputAudit;
    const textEl = state.refs.inputAuditText;
    const filesEl = state.refs.inputAuditFiles;
    if (!box || !textEl || !filesEl) return;
    if (!bundle?.stats) {
      box.className = 'ai-info pending';
      filesEl.innerHTML = '';
      if (state.refs.inputAuditDetail) state.refs.inputAuditDetail.textContent = 'Bấm “Phân tích AI” để đọc tài liệu.';
      state.inputAudit = null;
      state.refs.readAllBtn?.classList.add('hidden');
      state.refs.readAllBtn?.classList.remove('recommended');
      renderAiInfoSummary();
      return;
    }
    const st = bundle.stats;
    const detected = Number(st.filesDetected || 0);
    const discovered = Number(st.filesDiscovered || detected);
    const ready = Number(st.filesReadyForAi || 0);
    const readMode = String(bundle.readMode || st.readMode || 'all');
    const extractedWords = Number(st.extractedWords || 0);
    const sentWords = Number(st.aiTextWords || 0);
    const scans = Number(st.scanAttachmentsPrepared || 0);
    const skippedScans = Number(st.scanSkippedCount || 0);
    const oversizedSkipped = Number(st.oversizedSkippedCount || 0);
    const duplicatesSkipped = Number(st.duplicatesSkipped || st.duplicateCount || 0);
    const complete = bundle.aiReady !== false;
    box.className = `ai-info ${complete && !skippedScans && !oversizedSkipped ? 'ok' : 'warn'}`;
    const isRules = normalizeAnalysisMode(state.analysisMode) === 'rules';
    const sourceLabel = (source, ext='') => {
      source=String(source||'');
      if(source.startsWith('original-')) return `file gốc ${source.slice(9).toUpperCase()}`;
      if(source==='captured-original'||source==='original-file') return 'file gốc từ request iOffice';
      if(source.startsWith('captured-') && source!=='captured-pdf') return `file gốc ${source.slice(9).toUpperCase()}`;
      if(source==='ioffice-converted-pdf') return 'PDF do iOffice chuyển đổi';
      if(source==='captured-pdf') return 'PDF bắt từ viewer iOffice';
      if(source==='pdf-main-world') return /docx?/i.test(ext) ? 'Word qua viewer iOffice' : 'PDF.js toàn văn';
      if(source==='word-viewer'||source==='word-viewer-dom') return 'viewer Word';
      if(source==='viewer-text-layer') return 'text layer PDF 1 trang';
      if(source==='word-viewer-dom-fallback') return 'Word qua viewer iOffice · text tạm';
      if(source.startsWith('direct-')) return `file gốc ${source.slice(7).toUpperCase()}`;
      if(source==='ioffice-copy-captured') return 'text Copy/OCR iOffice';
      if(source==='ioffice-ocr-textlayer'||source==='ioffice-ocr-pdfjs'||source==='ioffice-ocr-partial') return 'OCR iOffice';
      if(source==='current-viewer'||source==='hidden-viewer'||source==='viewer-ocr-or-text') return 'viewer iOffice';
      return source ? source : '';
    };
    const statusText = (item) => item.status === 'duplicate-not-sent' ? `Trùng nội dung với ${item.duplicateOf ? '“'+item.duplicateOf+'”' : 'tệp khác'} · đã gộp, không gửi lặp`
      : item.status === 'text-ready' ? `Đã đọc · ${Number(item.words||0).toLocaleString('vi-VN')} từ${sourceLabel(item.source,item.ext) ? ` · ${sourceLabel(item.source,item.ext)}` : ''}`
      : item.status === 'scan-skipped' ? 'AI chưa đọc được tệp · PDF không có lớp chữ/text layer'
      : item.status === 'size-limit-skipped' ? `Tệp quá dung lượng · tạm bỏ qua${item.sizeBytes ? ` · ${(Number(item.sizeBytes)/1024/1024).toFixed(1)} MB` : ''}`
      : item.status === 'unsupported-file' ? 'Tệp nén/định dạng không đọc tự động · không ảnh hưởng nếu chính văn đã đọc đủ'
      : item.status === 'scan-attached' ? 'AI chưa đọc được tệp · PDF không có lớp chữ/text layer'
      : `Chưa đọc được${item.error ? ` · ${item.error}` : ''}`;
    filesEl.innerHTML = (bundle.fileResults || []).map((item) => {
      const skipped = item.status === 'scan-skipped';
      const cls = item.readyForAi ? 'ok' : 'bad';
      const icon = item.readyForAi ? '✓' : '⚠';
      return `<div class="input-file ${cls}"><span>${icon}</span><b>${escapeHtml(item.name)}</b><small>${escapeHtml(statusText(item))}</small></div>`;
    }).join('');
    state.inputAudit = { detected, discovered, ready, extractedWords, sentWords, scans, skippedScans, oversizedSkipped, duplicatesSkipped, complete, readMode };
    const signingReview = bundle.sourceSection === 'FILE_TRINH_KY';
    if (state.refs.inputAuditDetail) {
      if (signingReview) {
        const name = bundle.signingFileName || bundle.primaryDocument?.name || bundle.fileResults?.[0]?.name || 'chưa nhận diện';
        state.refs.inputAuditDetail.textContent = detected
          ? `${ready ? 'Đã đọc' : 'Đã nhận diện nhưng chưa đọc được'} FILE TRÌNH KÝ: ${name} · ${extractedWords.toLocaleString('vi-VN')} từ`
          : 'Chưa nhận diện được FILE TRÌNH KÝ của văn bản hiện tại.';
      } else {
        state.refs.inputAuditDetail.textContent = detected
          ? `${ready}/${readMode === 'primary' ? Math.max(1, detected) : detected} tệp đã đọc${readMode === 'primary' && discovered > detected ? ` · ưu tiên file chính · ${discovered - detected} tệp khác chưa đọc` : ''}${skippedScans ? ` · bỏ qua ${skippedScans} PDF scan` : ''}${oversizedSkipped ? ` · bỏ qua ${oversizedSkipped} tệp quá dung lượng` : ''}${duplicatesSkipped ? ` · gộp ${duplicatesSkipped} tệp trùng` : ''} · lấy ${extractedWords.toLocaleString('vi-VN')} từ văn bản · ${isRules ? 'dùng Local nhanh' : 'gửi AI'} ${sentWords.toLocaleString('vi-VN')} từ`
          : `Không có tệp đính kèm · ${sentWords.toLocaleString('vi-VN')} từ nội dung sẵn có`;
      }
    }
    if (state.refs.readAllBtn) {
      const otherCount = Array.isArray(bundle.otherFiles) ? bundle.otherFiles.length : Math.max(0, discovered - ready);
      const canReadMore = !signingReview && readMode === 'primary' && otherCount > 0;
      state.refs.readAllBtn.classList.toggle('hidden', !canReadMore);
      const recommended = canReadMore && bundle.additionalReadSuggested === true;
      state.refs.readAllBtn.classList.toggle('recommended', recommended);
      state.refs.readAllBtn.textContent = recommended
        ? `Đọc thêm tất cả (${otherCount})`
        : `Đọc tất cả (${Math.max(discovered, ready + otherCount)} tệp)`;
      state.refs.readAllBtn.title = recommended
        ? 'Văn bản có dấu hiệu nhiệm vụ/hạn; đọc các tệp còn lại để AI xác minh đầy đủ hơn.'
        : 'Đọc toàn bộ tệp đính kèm trong lần phân tích tiếp theo.';
    }
    renderAiInfoSummary();
  }

  function renderSourceContext(ctx, signals, prep = state.lastPrep) {
    if (prep?.bundle) renderInputAudit(prep.bundle);
    if (prep?.stats) {
      addProgress(
        `Tổng hợp tài liệu: ${prep.stats.filesReadyForAi}/${prep.stats.filesDetected} tệp đã đọc${Number(prep.stats.scanSkippedCount||0) ? ` · bỏ qua ${Number(prep.stats.scanSkippedCount||0)} PDF scan` : ''}${Number(prep.stats.oversizedSkippedCount||0) ? ` · bỏ qua ${Number(prep.stats.oversizedSkippedCount||0)} tệp quá dung lượng` : ''}${Number(prep.stats.duplicatesSkipped||0) ? ` · gộp ${Number(prep.stats.duplicatesSkipped||0)} tệp trùng` : ''} · lấy ${Number(prep.stats.extractedWords || 0).toLocaleString('vi-VN')} từ · ${normalizeAnalysisMode(state.analysisMode)==='rules'?'Local nhanh':'dự kiến gửi AI'} ${Number(prep.stats.aiTextWords || 0).toLocaleString('vi-VN')} từ.`,
        prep.bundle?.aiReady === false ? 'warn' : 'success',
        'reader-summary'
      );
    }
    renderProgressLog();
  }

  function setMessage(text, kind = 'info') {
    const message = normalizeText(text || '');
    if (state.refs.message) {
      state.refs.message.textContent = message;
      state.refs.message.className = `message ${kind}`;
    }
    const headerStatus = state.refs.headerStatus;
    if (headerStatus) {
      clearTimeout(state.headerStatusTimer);
      const collapsed = Boolean(state.refs.card?.classList.contains('collapsed'));
      const important = state.busy || collapsed || ['success','warn','error'].includes(kind);
      headerStatus.textContent = message;
      headerStatus.className = `header-status ${kind}${important && message ? '' : ' hidden'}`;
      headerStatus.title = message;
      if (!state.busy && message && (kind === 'success' || (kind === 'info' && collapsed))) {
        state.headerStatusTimer = setTimeout(() => {
          if (!state.busy && state.refs.headerStatus) state.refs.headerStatus.classList.add('hidden');
        }, kind === 'info' ? 4200 : 6500);
      }
    }
  }

  function setBusy(busy) {
    state.busy = busy;
    if (state.refs.ruleBtn) state.refs.ruleBtn.disabled = true;
    for(const el of state.root.querySelectorAll('.ai-mode-btn,#reanalyzeBtn')) el.disabled=busy;
    state.refs.stopBtn?.classList.toggle('hidden', !busy);
    state.refs.headerStopBtn?.classList.toggle('hidden', !busy);
    if (!busy && state.lastSuggestion && state.analyzedKey === state.documentKey && state.workflowPhase === 'analyze') {
      state.workflowPhase = 'apply';
    }
    updatePrimaryAction();
    if (!busy && state.refs.headerStatus?.classList.contains('success')) {
      clearTimeout(state.headerStatusTimer);
      state.headerStatusTimer = setTimeout(() => { if (!state.busy) state.refs.headerStatus?.classList.add('hidden'); }, 6500);
    }
  }




  function compactTaskPhrase(value, unit = '') {
    let text = normalizeText(value || '').replace(/\s+/g, ' ');
    const exactUnit = normalizeText(unit || '');
    if (exactUnit) {
      const escaped = exactUnit.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      text = text.replace(new RegExp(`^Giao\\s+${escaped}\\s+(?:chủ\\s+trì\\s+)?`, 'i'), '');
    }
    return text.replace(/^[\s:;,.–—-]+|[\s:;,.–—-]+$/g, '');
  }

  function conciseInstruction(value, mainUnit, tasks = [], taskScope = '') {
    const raw = normalizeText(value || '');
    const unit = unitDisplayNameById(mainUnit || '') || 'đơn vị chuyên môn';
    const scope = String(taskScope || '');
    if (scope === 'coordination' && !tasks.length) return `Giao ${unit} tiếp nhận, theo dõi và phối hợp theo yêu cầu.`;
    if ((scope === 'information' || scope === 'other-locality') && !tasks.length) return `Giao ${unit} tiếp nhận, nghiên cứu để biết.`;

    const directTasks = (tasks || []).filter(t => t && (t.scope === 'direct' || (!t.scope && t.task)));
    if (directTasks.length) {
      const prepared = directTasks.map(task => ({
        action: compactTaskPhrase(task.task || '', unit),
        deadline: /^\d{4}-\d{2}-\d{2}$/.test(String(task.deadline || '')) ? isoToVi(task.deadline) : ''
      })).filter(x => x.action);
      const sharedDeadline = prepared.length > 1 && prepared.every(x => x.deadline && x.deadline === prepared[0].deadline) ? prepared[0].deadline : '';
      const parts = [];
      for (const item of prepared) {
        let action = item.action;
        const folded = normalizeText(action).toLowerCase();
        if (!sharedDeadline && item.deadline && !folded.includes(item.deadline.toLowerCase()) && !/hoàn thành|trước ngày|hạn/.test(folded)) action += ` (hoàn thành trước ${item.deadline})`;
        if (!parts.some(x => x.toLowerCase() === action.toLowerCase())) parts.push(action);
      }
      if (parts.length) {
        const body = parts.map((x, i) => i === 0 ? `${x.charAt(0).toLowerCase()}${x.slice(1)}` : x).join('; ');
        const due = sharedDeadline ? `; hoàn thành trước ${sharedDeadline}` : '';
        return `Giao ${unit} ${body}${due}.`.replace(/\.\s*\./g, '.');
      }
    }

    // Không cắt chuỗi bằng số ký tự. Nếu AI đã viết một ý kiến đầy đủ thì giữ đủ ý, chỉ chuẩn hóa khoảng trắng.
    if (raw) return raw;
    return `Giao ${unit} tiếp nhận, xử lý theo chức năng.`;
  }

  function manualSuggestionFromUi() {
    const mainUnit = normalizeText(state.refs.mainSelect?.value || '') || null;
    const coordinationUnits = state.refs.coordBox ? getSelectedCodes(state.refs.coordBox).filter(x => x !== mainUnit) : [];
    const coordSet = new Set(coordinationUnits);
    const viewUnits = [];
    const instruction = normalizeText(state.refs.instruction?.value || '');
    const deadline = textDateToIso(state.refs.deadlineCard?.querySelector('.track-deadline')?.value || '');
    const tasks = instruction || deadline || mainUnit ? [{
      index: 1,
      task: stripInstructionPrefix(instruction),
      deadline: deadline || null,
      deadlineText: deadline ? isoToVi(deadline) : '',
      deadlineEvidence: '',
      deadlineSource: deadline ? 'manual' : 'none',
      responsibleUnit: mainUnit,
      scope: 'direct',
      trackRecommended: true
    }] : [];
    return {
      workflow: 'leader-incoming',
      actionRequired: true,
      mainUnit,
      coordinationUnits,
      viewUnits,
      instruction,
      tasks,
      recipientNames: [],
      reviewSummary: '',
      reviewIssues: [],
      taskScope: 'direct',
      trackRecommended: true,
      trackingReason: 'Người dùng phân công thủ công.',
      reason: 'Phân công thủ công.',
      confidence: 1,
      requiresReview: false,
      signals: [],
      source: 'manual'
    };
  }

  function updateAiToggleUi({ quiet = false } = {}) {
    const incoming = currentWorkflow() === 'leader-incoming';
    state.aiEnabled = true;
    state.refs.aiTools?.classList.remove('hidden');
    if (state.refs.aiAnalyzeBtn) {
      state.refs.aiAnalyzeBtn.classList.remove('hidden');
      state.refs.aiAnalyzeBtn.disabled = state.busy || !state.lastContext?.detected;
      state.refs.aiAnalyzeBtn.textContent = state.lastSuggestion && state.analyzedKey === state.documentKey ? '↻ Phân tích lại' : '✨ Phân tích AI';
    }
    if (incoming) {
      state.refs.inputAudit?.classList.remove('hidden');
      state.refs.progressDetails?.classList.remove('hidden');
      if (state.lastSuggestion && state.analyzedKey === state.documentKey) state.refs.analysisPanel?.classList.remove('hidden');
      const meter = state.refs.mainRoleSection?.querySelector('.confidence-meter');
      meter?.classList.toggle('hidden', !state.lastSuggestion);
    }
  }

  async function setAiEnabled(enabled, persist = true) {
    if (state.busy || state.updateLocked || state.transferRunning) return;
    state.aiEnabled = true;
    if (persist) await safeStorageSet({ aiAnalysisEnabled: true });
    updateAiToggleUi();
    updatePrimaryAction();
  }

  function normalizeAnalysisMode(value) {
    return ['gemini-web', 'chatgpt-web', 'api'].includes(value) ? value : 'api';
  }

  function updateAnalysisModeUi() {
    const mode = normalizeAnalysisMode(state.analysisMode);
    state.analysisMode = mode;
    if (state.refs.modeSelect) state.refs.modeSelect.value = mode;
    state.refs.quickApiRow?.classList.add('hidden');
    renderInputAudit(state.lastPrep?.bundle || null);
    renderAiInfoSummary();
    updateAiToggleUi({quiet:true});
    updatePrimaryAction();
  }

  function setAnalysisMode(mode, persist = true) {
    if(state.busy || state.updateLocked || state.transferRunning)return;
    mode = normalizeAnalysisMode(mode);
    if (state.analysisMode === mode) { updateAnalysisModeUi(); return; }
    state.analysisMode = mode;
    // Luôn nhớ đúng lựa chọn cuối cùng của người dùng cho văn bản tiếp theo.
    if (persist) void safeStorageSet({ analysisMode: mode });
    updateAnalysisModeUi();
    // Giữ nguyên kết quả cũ để người dùng còn đối chiếu; chỉ thay khi bấm Phân tích lại.
    const picked = mode === 'rules' ? 'Local nhanh'
      : mode === 'gemini-web' ? 'Gemini Web'
      : mode === 'chatgpt-web' ? 'ChatGPT Web'
      : 'API';
    setMessage(state.lastSuggestion ? `Đã chọn ${picked} · bấm “Phân tích AI” để chạy lại bằng lựa chọn mới.` : `Đã chọn ${picked}.`, 'info');
  }

  function hideFallbackActions(){}
  function showFallbackActions(){}
  async function runFallbackMode(mode){
    if(state.busy)return; hideFallbackActions(); setAnalysisMode(mode,true); await runSelectedAnalysis();
  }


  async function getCurrentPromptText(){
    let payload=state.lastPreparedPayload;
    if(!payload){
      const prepared=await prepareWebPayload({aiRequireCompleteFiles:false});
      payload=prepared.payload; state.lastPreparedPayload=payload;
    }
    const r=await safeRuntimeSend({type:'AI_BUILD_PROMPT',payload});
    if(!r?.ok||!r.prompt)throw new Error(r?.error||'Không tạo được prompt.');
    return r.prompt;
  }
  async function copyTextSafe(text){
    try{await navigator.clipboard.writeText(text);return true;}catch(_){
      const ta=document.createElement('textarea');ta.value=text;ta.style.position='fixed';ta.style.opacity='0';document.body.appendChild(ta);ta.select();let ok=false;try{ok=document.execCommand('copy');}catch(_){}ta.remove();return ok;
    }
  }
  async function copyPromptForManual(){
    if(state.busy)return;
    try{setMessage('Đang tạo prompt để copy…','info');const prompt=await getCurrentPromptText();const ok=await copyTextSafe(prompt);if(!ok)throw new Error('Trình duyệt không cho phép sao chép.');setMessage('✓ Đã copy prompt. Dán vào Gemini/ChatGPT, sau đó dùng “Dán kết quả”.','success');showFallbackActions();}
    catch(e){setMessage(e.message,'error');}
  }
  function parseManualJson(text){
    let raw=String(text||'').trim().replace(/^```(?:json)?\s*/i,'').replace(/\s*```$/,'').trim();
    const first=raw.indexOf('{'),last=raw.lastIndexOf('}'); if(first>=0&&last>first)raw=raw.slice(first,last+1);
    return JSON.parse(raw);
  }
  function openManualPaste(){
    state.refs.manualPastePanel?.classList.remove('hidden'); if(state.refs.manualPasteText){state.refs.manualPasteText.value='';state.refs.manualPasteText.focus();}
  }
  function closeManualPaste(){state.refs.manualPastePanel?.classList.add('hidden');}
  function applyManualPastedResult(){
    try{
      const raw=parseManualJson(state.refs.manualPasteText?.value||'');
      const ctx=state.lastContext||extractDocumentContext();
      const suggestion=sanitizeSuggestion(raw,ctx); state.lastSuggestion=suggestion; state.lastAnalysisKind='manual';
      populateSuggestion(suggestion); markAnalyzed(); closeManualPaste(); hideFallbackActions();
      finishAnalysisMeta({...raw,provider:'manual-paste',providerLabel:'Dán thủ công',model:''},{totalMs:0},'Dán thủ công');
      setMessage('✓ Đã nhận kết quả dán thủ công. Kiểm tra lại trước khi áp dụng.','success');
    }catch(e){setMessage(`Kết quả dán chưa đúng JSON yêu cầu: ${e.message}`,'error');}
  }

  async function runSelectedAnalysis({ compact = true } = {}) {
    if (state.busy || state.updateLocked || state.transferRunning) return;
    updateDetection();
    if (!state.lastContext?.detected) return setMessage('Hãy mở một văn bản trên iOffice.', 'error');
    const mode = normalizeAnalysisMode(state.analysisMode);
    if (compact) {
      state.autoCompactAnalysis = true;
      setWidgetCollapsed(true, false);
    }
    try {
      if (mode === 'rules') return await runRuleAnalysis();
      return await runAnalysis(mode);
    } finally {
      if (compact && state.autoCompactAnalysis) {
        state.autoCompactAnalysis = false;
        setWidgetCollapsed(false, false);
      }
    }
  }


  async function prepareWebPayload(overrides = null) {
    const ctx = extractDocumentContext();
    if (!ctx.detected) throw new Error('Chưa nhận diện được văn bản đang mở.');
    const signal = state.activeAbortController?.signal || null;
    let prep = state.lastPrep;
    const storedOptions = await safeStorageGet({readerMode:'primary',readerConcurrency:0,readerIncludeRelated:false,readerDeduplicateContent:true,readerScanEnabled:true,readerTimeoutMs:7000,readerMaxFileSizeMb:10,aiRequireCompleteFiles:false,aiRulePack:null});
    const outgoingReview = currentWorkflow() === 'leader-outgoing';
    const activeRulePack = globalThis.IOfficeRulePack?.resolvePack(storedOptions.aiRulePack);
    state.activeRulePack = activeRulePack;
    let cpuLogical=0;
    try{const cpuRes=await safeRuntimeSend({type:'SYSTEM_CPU_INFO'});cpuLogical=Math.max(0,Number(cpuRes?.data?.numOfProcessors||0));}catch(_){cpuLogical=0;}
    const options = {
      ...storedOptions,
      ...(overrides || {}),
      readerMode: outgoingReview ? 'primary' : (state.forceReadAllOnce ? 'all' : (overrides?.readerMode || storedOptions.readerMode || 'primary')),
      readerIncludeRelated: outgoingReview ? false : ((overrides && Object.prototype.hasOwnProperty.call(overrides,'readerIncludeRelated')) ? overrides.readerIncludeRelated : storedOptions.readerIncludeRelated),
      readTaskAppendices: outgoingReview ? false : (state.forceTaskSupportOnce ? true : ((overrides && Object.prototype.hasOwnProperty.call(overrides,'readTaskAppendices')) ? overrides.readTaskAppendices : (activeRulePack?.inputPolicy?.additionalReadPolicy?.autoReadStrongAppendix===false ? false : undefined))),
      maxAdditionalTaskFiles: Number(activeRulePack?.inputPolicy?.additionalReadPolicy?.maxAdditionalFiles || 6),
      signingFileOnly: outgoingReview,
      readerScanEnabled: false, // Stable 1.1: không OCR/không phân tích PDF scan
      readerPolicy: outgoingReview ? null : (activeRulePack?.inputPolicy?.additionalReadPolicy||null),
      readerCpuLogical:cpuLogical
    };
    const prepKey=getDocumentKey(ctx)+'|'+JSON.stringify(options);
    if (!prep || state.prepKey !== prepKey) {
      if (globalThis.IOfficeDocumentReader?.collectAndPrepare) {
        setMessage(outgoingReview ? 'Đang đọc FILE TRÌNH KÝ để kiểm tra văn bản…' : 'Đang đọc đúng các tệp của văn bản…', 'info');
        addProgress(outgoingReview ? 'Bắt đầu đọc FILE TRÌNH KÝ của văn bản đi.' : 'Bắt đầu đọc FILE ĐÍNH KÈM / Văn bản liên quan.', 'info', 'reader-start');
        prep = await globalThis.IOfficeDocumentReader.collectAndPrepare(ctx, handleReaderProgress, { signal, ...options });
        if(signal?.aborted)throw new DOMException('Đã dừng phân tích.','AbortError');
        state.lastPrep = prep;state.prepKey=prepKey;state.forceReadAllOnce=false;state.forceTaskSupportOnce=false;
        if (prep?.combinedText) { ctx.previewText = prep.combinedText; ctx.previewChars = prep.combinedText.length; }
        ctx.documentBundle = prep?.bundle || null;
      }
    } else if (prep) {
      addProgress('Dùng lại kết quả đọc tài liệu đã có của văn bản này.', 'success', 'reader-cache');
      ctx.previewText = prep.combinedText || ''; ctx.previewChars = ctx.previewText.length; ctx.documentBundle = prep?.bundle || null;
    }
    if (!ctx.documentBundle) {
      ctx.documentBundle = {
        version: 'metadata-only',
        primaryDocument: null,
        supportingDocuments: [],
        duplicates: [],
        unreadable: (ctx.attachmentNames || []).map((name) => ({ name, status: 'reader-no-text' })),
        fileResults: (ctx.attachmentNames || []).map((name) => ({name,status:ctx.previewText?'metadata-only':'reader-no-text',readyForAi:false,words:0,error:'Không lấy được nội dung tệp.'})),
        stats: {
          filesDetected: (ctx.attachmentNames || []).length,
          filesWithText: 0, filesReadyForAi: 0,
          uniqueGroups: (ctx.attachmentNames || []).length,
          duplicatesSkipped: 0,
          unreadableCount: (ctx.attachmentNames || []).length,
          requiredUnreadableCount: (ctx.attachmentNames || []).length,
          extractedWords: 0, aiTextWords: 0, aiTextChars: (ctx.previewText || '').length
        },
        aiReady: (ctx.attachmentNames || []).length === 0,
        aiBlockedReason: (ctx.attachmentNames || []).length ? 'Không lấy được nội dung tệp đính kèm.' : '',
        requiresReviewForUnreadable: !!(ctx.attachmentNames || []).length,
        combinedText: ctx.previewText || ''
      };
    }
    const signals = [];
    state.lastContext = ctx; state.lastSignals = signals;
    renderSourceContext(ctx, signals, prep);
    return { ctx, signals, payload: buildAiPayload(ctx, signals, activeRulePack), settings: options };
  }

  function runtimeMessagePromise(message) {
    return safeRuntimeSend(message).then((response) => {
      if (!response?.ok) throw new Error(response?.error || 'Extension không trả kết quả.');
      return response.data ?? response;
    });
  }

  function handleWebJobEvent(message) {
    if (!message?.jobId || message.jobId !== state.pendingWebJob) return;
    state.webEventCache.set(message.jobId, message);
    const phase = message.phase || message.status || 'waiting';
    const providerLabel = message.provider === 'chatgpt' ? 'ChatGPT' : 'Gemini';
    const phaseMessage = message.phaseMessage || `${providerLabel} đang xử lý`;
    if (message.kind === 'progress') {
      setMessage(`${phaseMessage} · ${formatDuration(message.elapsedMs || 0)}`, 'info');
      if (phase !== state.lastWebPhase) {
        state.lastWebPhase = phase;
        addProgress(phaseMessage, 'info', `${message.provider || 'web'}:${phase}`);
      }
    }
    const waiter = state.webWaiters.get(message.jobId);
    if (waiter) waiter(message);
  }

  async function waitWebBackgroundJob(jobId, provider, timeoutMs=340000, signal) {
    const label = provider === 'chatgpt' ? 'ChatGPT' : 'Gemini';
    return new Promise((resolve,reject)=>{
      let done=false,polling=false;
      const finish=(error,value)=>{if(done)return;done=true;clearTimeout(timer);clearInterval(poll);state.webWaiters.delete(jobId);signal?.removeEventListener('abort',abort);error?reject(error):resolve(value);};
      const abort=()=>finish(new Error('Đã dừng phân tích.'));
      const receive=event=>{
        if(event.status==='done')finish(null,event);
        else if(event.status==='error')finish(new Error(event.error||event.phaseMessage||`${label} không hoàn tất.`));
        else if(event.status==='cancelled')abort();
      };
      const recover=async()=>{if(done||polling)return;polling=true;try{receive(await runtimeMessagePromise({type:'WEB_AUTOMATION_STATUS',jobId}));}catch(e){finish(e);}finally{polling=false;}};
      state.webWaiters.set(jobId,receive);
      const timer=setTimeout(()=>finish(new Error(`Hết thời gian chờ ${label}.`)),timeoutMs);
      // Chỉ ping trạng thái 6 giây/lần để đánh thức MV3 khi push bị mất; không quét DOM Web AI.
      const poll=setInterval(recover,6000);
      signal?.addEventListener('abort',abort,{once:true});
      if(signal?.aborted)return abort();
      const cached=state.webEventCache.get(jobId);if(cached)receive(cached);
      if(!done)void recover();
    });
  }

  function waitWithSignal(promise,signal) {
    return new Promise((resolve,reject)=>{
      const abort=()=>reject(new DOMException('Đã dừng phân tích.','AbortError'));
      if(signal.aborted){abort();Promise.resolve(promise).catch(()=>{});return;}
      signal.addEventListener('abort',abort,{once:true});
      Promise.resolve(promise).then(resolve,reject).finally(()=>signal.removeEventListener('abort',abort));
    });
  }
  async function rerunLastAnalysis() {
    if (state.lastAnalysisKind !== 'rules') return runSelectedAnalysis();
    if (state.busy || state.updateLocked || state.transferRunning) return;
    updateDetection();
    if (!state.lastContext?.detected) return setMessage('Hãy mở một văn bản trên iOffice.', 'error');
    state.autoCompactAnalysis = true;
    setWidgetCollapsed(true, false);
    try { return await runRuleAnalysis(); }
    finally { state.autoCompactAnalysis = false; setWidgetCollapsed(false, false); }
  }

  async function runRuleAnalysis() {
    if (state.busy || state.updateLocked || state.transferRunning) return;
    updateDetection();
    if (!['leader-incoming','leader-outgoing'].includes(currentWorkflow())) return setMessage('Local nhanh chỉ dùng cho chế độ Lãnh đạo.', 'error');
    if (!state.lastContext?.detected) return setMessage('Hãy mở một văn bản trên iOffice.','error');
    const run=++state.runId,key=state.documentKey,startedAt=performance.now();
    const controller=new AbortController(),signal=controller.signal;
    state.activeAbortController=controller; state.cancelRequested=false; state.lastSuggestion=null; state.analyzedKey=''; state.appliedKey=''; state.workflowPhase='analyze';
    state.lastAnalysisKind='rules';
    const assertCurrent=()=>{if(signal.aborted||run!==state.runId||key!==getDocumentKey(extractDocumentContext()))throw new DOMException('Đã dừng phân tích.','AbortError');};
    let prepMs=0;
    resetProgressLog(); beginAnalysisTimer(); setBusy(true);
    try {
      addProgress('Đang đọc tài liệu trước khi chạy bộ quy tắc.','info','start');
      const t=performance.now();
      const prepared=await waitWithSignal(prepareWebPayload({ readerScanEnabled:false, aiRequireCompleteFiles:false }),signal); prepMs=performance.now()-t; assertCurrent();
      state.lastPreparedPayload=prepared.payload;
      if (!globalThis.IOfficeRuleEngine?.analyze) throw new Error('Không tải được bộ máy phân tích quy tắc.');
      const ruleStart=performance.now();
      const raw=globalThis.IOfficeRuleEngine.analyze({...prepared.ctx,workflow:currentWorkflow()},state.rules,getAvailableUnits());
      assertCurrent();
      const suggestion=sanitizeSuggestion(raw,prepared.ctx);
      // Không phân tích khi chưa đọc được chính văn. Tránh sinh kết quả từ riêng metadata/trích yếu.
      const ruleBundle = prepared.ctx.documentBundle || {};
      const rulePrimary = ruleBundle.primaryDocument || null;
      const rulePrimaryReadable = !!rulePrimary && Number(rulePrimary.wordsSent || rulePrimary.wordsOriginal || 0) > 0 && !['pdf-scan-skipped','primary-unverified','timeout','viewer-no-text','no-file-source'].includes(String(rulePrimary.status || ''));
      if (!rulePrimaryReadable && Number(ruleBundle.stats?.filesDetected || 0) > 0) {
        const fileName = rulePrimary?.name || ruleBundle.skippedScans?.[0]?.name || ruleBundle.unreadable?.[0]?.name || 'tệp chính';
        throw new Error(`AI chưa đọc được tệp chính “${fileName}”. Tiện ích chưa phân tích để tránh kết quả sai; hãy thử lại hoặc mở bản Word/PDF có lớp chữ.`);
      }
      const ruleScanOnly = Number(ruleBundle?.stats?.scanSkippedCount || 0) > 0;
      const ruleDataIncomplete = ruleBundle?.aiReady === false || ruleScanOnly;
      if (ruleDataIncomplete) {
        suggestion.requiresReview = true;
        suggestion.confidence = Math.min(suggestion.confidence, 0.69);
        const warning = ruleScanOnly
          ? 'Có PDF scan đã bị bỏ qua; bộ quy tắc chỉ phân tích các tệp có text, kết quả cần kiểm tra kỹ.'
          : 'Dữ liệu tệp chưa đầy đủ; kết quả quy tắc chỉ là gợi ý.';
        suggestion.signals = uniq([...(suggestion.signals||[]), warning]).slice(0,8);
      }
      state.lastSuggestion=suggestion; populateSuggestion(suggestion); markAnalyzed();
      finishAnalysisMeta(raw,{totalMs:performance.now()-startedAt,prepMs,aiMs:performance.now()-ruleStart},'Local nhanh');
      addProgress('Local nhanh đã đọc text, xác định chủ thể/nhiệm vụ/hạn/lĩnh vực bằng quy tắc cục bộ; không gửi dữ liệu ra ngoài.','success','done');
      setMessage(ruleDataIncomplete ? 'Local nhanh đã xử lý phần text đọc được; cần kiểm tra lại dữ liệu thiếu.' : (currentWorkflow()==='leader-outgoing'?'✓ Đã kiểm tra văn bản đi.':'✓ Local nhanh đã phân tích xong.'),'success');
      state.refs.progressDetails.open=false;
    } catch(e) {
      if (run===state.runId) {
        const cancelled=signal.aborted||e.name==='AbortError'||/Đã dừng/.test(e.message);
        addProgress(cancelled?'Đã dừng xử lý.':`Local nhanh thất bại: ${e.message}`,cancelled?'warn':'error','error');if(!cancelled&&state.refs.progressDetails)state.refs.progressDetails.open=true;
        setMessage(cancelled?'Đã dừng. Anh có thể phân tích lại.':e.message,cancelled?'info':'error');
        if(!cancelled)showFallbackActions();
        finishAnalysisMeta({provider:'local-fast'},{totalMs:performance.now()-startedAt,prepMs},cancelled?'Đã dừng':'Local nhanh');
      }
    } finally {
      if(run===state.runId){state.activeAbortController=null;clearAnalysisTimer();setBusy(false);}
    }
  }

  async function runAnalysis(mode) {
    if(state.busy || state.updateLocked || state.transferRunning)return;
    updateDetection();
    if(!state.lastContext?.detected)return setMessage('Hãy mở một văn bản trên iOffice.','error');
    const run=++state.runId,key=state.documentKey,startedAt=performance.now();
    const controller=new AbortController(),signal=controller.signal;
    state.activeAbortController=controller;state.cancelRequested=false;state.lastSuggestion=null;state.analyzedKey='';state.appliedKey='';state.workflowPhase='analyze';
    state.lastAnalysisKind='ai';state.lastAiSentText='';state.lastAiReceivedText='';state.lastPrivacyStats=null;state.lastPrivacyWarnings=[];
    const webProvider=mode==='gemini-web'?'gemini':mode==='chatgpt-web'?'chatgpt':null;
    state.pendingWebJob=webProvider?`${webProvider==='chatgpt'?'cweb':'gweb'}_${crypto.randomUUID()}`:null;
    let jobId=state.pendingWebJob;
    const assertCurrent=()=>{if(signal.aborted||run!==state.runId||key!==getDocumentKey(extractDocumentContext()))throw new DOMException('Đã dừng phân tích.','AbortError');};
    let prepMs=0,analysisStage='khởi tạo';
    hideFallbackActions();resetProgressLog();beginAnalysisTimer();setBusy(true);
    try {
      analysisStage='đọc tài liệu';addProgress('Bắt đầu phân tích · nhận diện văn bản và chuẩn bị tệp nguồn.','info','start');
      const warm=webProvider?runtimeMessagePromise({type:'WEB_AUTOMATION_PREWARM',provider:webProvider}).catch(e=>({error:e.message})):Promise.resolve();
      const t=performance.now(),prepared=await waitWithSignal(prepareWebPayload(),signal);prepMs=performance.now()-t;assertCurrent();
      state.lastPreparedPayload=prepared.payload;
      {const st=prepared.ctx?.documentBundle?.stats||{},primary=prepared.ctx?.documentBundle?.primaryDocument;addProgress(`Đã chuẩn bị tài liệu · ${Number(st.filesReadyForAi||0)}/${Number(st.filesDetected||0)} tệp sẵn sàng · ${Number(st.aiTextWords||st.extractedWords||0).toLocaleString('vi-VN')} từ${primary?.name?` · file chính: ${primary.name}`:''} · ${formatDuration(prepMs)}.`,'success','reader-summary');}
      analysisStage='kiểm tra dữ liệu riêng tư';
      const privacyPreview=await waitWithSignal(safeRuntimeSend({type:'AI_PRIVACY_PREVIEW',payload:prepared.payload}),signal);assertCurrent();
      if(!privacyPreview?.ok){
        addProgress(`⚠ Privacy Shield không kiểm tra được đầy đủ: ${privacyPreview?.error||'không rõ lỗi'} · vẫn tiếp tục theo chế độ cảnh báo.`,'warn','privacy-preview-error');
      }
      state.lastPrivacyStats=privacyPreview?.data?.stats||null;
      state.lastPrivacyWarnings=Array.isArray(privacyPreview?.data?.warnings)?privacyPreview.data.warnings:[];
      const privacyText=privacyStatsText(state.lastPrivacyStats);
      if(privacyText)addProgress(`🛡 Privacy Shield 2.1: đã khử nhận dạng ${privacyText}. Kết quả kiểm tra được ghi để người dùng đối chiếu trước/sau khi phân tích.`,'success','privacy-shield');
      const risk=privacyPreview?.data?.risk||null,riskText=privacyRiskText(risk);
      if(risk?.level&&risk.level!=='normal')addProgress(`⚠ Cảnh báo riêng tư ${String(risk.level).toUpperCase()}${riskText?`: ${riskText}`:''}. Tiện ích vẫn cho phép gửi; hãy mở Tiến trình xử lý để kiểm tra.`,'warn','privacy-risk');
      for(let i=0;i<state.lastPrivacyWarnings.length;i++)addProgress(`⚠ ${state.lastPrivacyWarnings[i]}`,'warn',`privacy-warning-${i}`);
      const audit=privacyPreview?.data?.audit;if(audit?.ok===false)addProgress(`⚠ Kiểm tra prompt cuối còn ${Number(audit.findings?.length||0)} loại dấu hiệu chưa chắc đã khử hết. Vẫn gửi theo chế độ cảnh báo.`,'warn','privacy-audit');
      if(Number(privacyPreview?.data?.scanAttachmentCount||0)>0)addProgress(`⚠ Có ${Number(privacyPreview.data.scanAttachmentCount)} tệp scan/ảnh; bộ lọc text không thể che nội dung nằm trong ảnh. Tiện ích vẫn cho phép gửi.`,'warn','privacy-scan');
      if(Number(privacyPreview?.data?.recipientCandidateCount||0)>0)addProgress(`Có ${Number(privacyPreview.data.recipientCandidateCount)} luật người nhận ẩn danh sẵn sàng; AI chỉ nhận mã vai trò, không nhận tên người.`,'info','recipient-rules');
      const bundle=prepared.ctx.documentBundle || {};
      // Stable 1.3: chỉ gọi AI khi đã lấy được text của chính văn. PDF scan, timeout, viewer lỗi
      // hay tệp đọc được nhưng không xác minh đúng văn bản đều dùng chung cảnh báo "AI chưa đọc được tệp".
      const primary = bundle.primaryDocument || null;
      const primaryReadable = !!primary && Number(primary.wordsSent || primary.wordsOriginal || 0) > 0 && !['pdf-scan-skipped','primary-unverified','timeout','viewer-no-text','no-file-source'].includes(String(primary.status || ''));
      if (!primaryReadable && Number(bundle.stats?.filesDetected || 0) > 0) {
        const unreadName = primary?.name || bundle.skippedScans?.[0]?.name || bundle.unreadable?.[0]?.name || 'tệp chính';
        const scanConfirmed = primary?.scanConfirmed === true || bundle.skippedScans?.some?.(x=>x?.name===unreadName && x?.scanConfirmed===true);
        const detail = scanConfirmed
          ? 'PDF.js đã kiểm tra trang và xác nhận không có lớp chữ.'
          : 'Viewer/tệp chưa đọc được; chưa đủ căn cứ kết luận là PDF scan.';
        addProgress(`⚠ AI chưa đọc được tệp chính: ${unreadName}. ${detail} Không gửi AI để tránh phân tích sai.`, 'warn', 'primary-unreadable');
        throw new Error(scanConfirmed
          ? `AI chưa đọc được tệp chính “${unreadName}” vì đây là PDF scan không có lớp chữ. Nếu có bản Word cùng văn bản, hãy thử lại sau khi iOffice tải xong.`
          : `AI chưa đọc được tệp chính “${unreadName}”. Tiện ích chưa kết luận đây là PDF scan; hãy thử lại khi viewer iOffice tải xong.`);
      }
      if (bundle.aiReady === false) {
        const st=bundle.stats || {};
        addProgress(`⚠ Dữ liệu chưa đầy đủ (${Number(st.filesReadyForAi||0)}/${Number(st.filesDetected||0)} tệp sẵn sàng); vẫn gửi phần văn bản đã đọc được và đánh dấu cần kiểm tra.`, 'warn', 'partial-input');
      }
      const warmed=await waitWithSignal(warm,signal);assertCurrent();if(warmed?.error)throw new Error(warmed.error);
      let result,status;
      const aiStart=performance.now();analysisStage='gửi AI';
      const aiWords=Number(bundle.stats?.aiTextWords||bundle.stats?.extractedWords||0);addProgress(`Dữ liệu đã sẵn sàng · ${aiWords.toLocaleString('vi-VN')} từ · bắt đầu gửi ${webProvider?(webProvider==='gemini'?'Gemini Web':'ChatGPT Web'):'AI qua API'}.`,'info','ai-send-start');
      if(webProvider) {
        const start=await waitWithSignal(runtimeMessagePromise({type:'WEB_AUTOMATION_START',provider:webProvider,jobId,payload:prepared.payload}),signal);assertCurrent();
        if(start.jobId && start.jobId!==jobId){jobId=start.jobId;state.pendingWebJob=jobId;}
        addProgress(start.message||`Đã gửi dữ liệu sang ${webProvider==='gemini'?'Gemini Web':'ChatGPT Web'} · đang chờ phản hồi.`,'success','sent');
        status=await waitWebBackgroundJob(jobId,webProvider,340000,signal);assertCurrent();result=status.result;
      }else if(mode==='api') {
        addProgress('Đã gửi yêu cầu tới chuỗi API · đang chờ AI phản hồi.','success','sent');
        result=await waitWithSignal(callAi(prepared.payload),signal);assertCurrent();
      }
      if(!result)throw new Error('AI hoàn tất nhưng không có kết quả.');
      analysisStage='kiểm tra kết quả AI';addProgress(`Đã nhận phản hồi AI${result?.provider?` · ${result.provider}`:''} · đang kiểm tra cấu trúc và chuẩn hóa đề xuất.`,'success','ai-received');
      captureAiDebug(result);
      const suggestion=sanitizeSuggestion(result,prepared.ctx);state.lastSuggestion=suggestion;
      populateSuggestion(suggestion);markAnalyzed();finishAnalysisMeta(result,{totalMs:performance.now()-startedAt,prepMs,aiMs:performance.now()-aiStart});
      addProgress(`Hoàn tất · đã đưa đề xuất vào biểu mẫu · AI ${formatDuration(performance.now()-aiStart)} · tổng ${formatDuration(performance.now()-startedAt)}.`,'success','done');
      setMessage(currentWorkflow()==='leader-outgoing'?'✓ Kiểm tra văn bản hoàn tất.':'✓ Phân tích xong. Kiểm tra đề xuất trước khi chuyển.','success');
      state.refs.progressDetails.open=false;
      if(jobId)await runtimeMessagePromise({type:'WEB_AUTOMATION_CONSUME',jobId}).catch(()=>{});
    }catch(e){
      if(jobId)await runtimeMessagePromise({type:'WEB_AUTOMATION_CANCEL',jobId}).catch(()=>{});
      if(run===state.runId){
        const cancelled=signal.aborted||e.name==='AbortError'||/Đã dừng/.test(e.message);
        addProgress(cancelled?'Đã dừng xử lý.':`Thất bại ở bước ${analysisStage}: ${e.message}`,cancelled?'warn':'error','error');if(!cancelled&&state.refs.progressDetails)state.refs.progressDetails.open=true;
        setMessage(cancelled?'Đã dừng. Anh có thể phân tích lại.':e.message,cancelled?'info':'error');
        if(!cancelled)showFallbackActions();
        finishAnalysisMeta(null,{totalMs:performance.now()-startedAt,prepMs},cancelled?'Đã dừng':'Chưa hoàn tất');
      }
    }finally{
      if(jobId){state.webEventCache.delete(jobId);state.webWaiters.delete(jobId);}
      if(run===state.runId){state.pendingWebJob=null;state.activeAbortController=null;clearAnalysisTimer();setBusy(false);}
    }
  }


  function updateDetection() {
    const ctx = extractDocumentContext();
    const nextKey = getDocumentKey(ctx);
    const changed = !!state.documentKey && state.documentKey !== nextKey;
    if (!state.busy || changed) state.lastContext = ctx;
    if (changed) {
      state.documentKey = nextKey;
      state.updateDirty = false;
      state.trackThisDocument = false;
      state.trackingManualChoice = null;
      state.manualDeadline = null;
      clearAnalysisVisuals();
      resetLeaderWatchersForDocument();
      setMessage(ctx.direction === 'incoming' ? 'Sẵn sàng. Có thể phân tích AI hoặc phân luồng thủ công.' : 'Sẵn sàng kiểm tra văn bản đi.', 'info');
    } else if (!state.documentKey && nextKey) {
      state.documentKey = nextKey;
      state.trackThisDocument = false;
      state.trackingManualChoice = null;
      state.manualDeadline = null;
      resetLeaderWatchersForDocument();
    }
    if (!state.refs.docTitle) return;
    state.refs.docTitle.textContent = ctx.detected ? cleanTrichYeu(ctx.trichYeu) : 'Chưa mở văn bản';
    state.refs.docTitle.title = ctx.detected ? cleanTrichYeu(ctx.trichYeu) : '';
    if (ctx.direction === 'outgoing') {
      state.refs.sender.textContent = ctx.detected ? (ctx.author ? `Người soạn thảo: ${ctx.author}` : 'Người soạn thảo: —') : '—';
      if (state.refs.docMeta) state.refs.docMeta.textContent = ctx.detected ? [ctx.docType,ctx.urgency].filter(Boolean).join(' · ') : '';
    } else {
      state.refs.sender.textContent = ctx.detected ? ctx.sender : '—';
      if (state.refs.docMeta) state.refs.docMeta.textContent = ctx.detected ? [ctx.symbol,ctx.documentDate].filter(Boolean).join(' · ') : '';
    }
    setWorkflowUi();
    updatePrimaryAction();
    if (ctx.detected && ctx.direction === 'outgoing' && state.userRole === 'leader') {
      const matchKey = nextKey;
      setTimeout(() => {
        if (state.documentKey === matchKey && currentWorkflow() === 'leader-outgoing') {
          void globalThis.IOfficeTrackerBoard?.matchCurrentOutgoing?.({ auto:true });
        }
      }, changed ? 80 : 140);
    } else if (ctx.direction !== 'outgoing') {
      globalThis.IOfficeTrackerBoard?.clearMatch?.();
    }
    if (!ctx.detected && state.userRole !== 'tracker' && !state.busy) setWidgetCollapsed(true, false);
    if (state.refs.ruleBtn) state.refs.ruleBtn.disabled = !ctx.detected || state.busy;
    updateHeaderAction();
  }

  function refreshHeaderInteractionTitle() {
    const header = state.root?.getElementById?.('dragHeader');
    if (!header) return;
    const collapsed = state.refs.card?.classList.contains('collapsed');
    const moveHint = state.widgetPinned ? 'đã ghim vị trí' : 'kéo để di chuyển';
    header.title = `${collapsed ? 'Bấm để mở' : 'Bấm để thu gọn'} iOffice AI · ${moveHint}`;
    header.classList.toggle('pinned', state.widgetPinned);
  }

  function setWidgetPinned(pinned, persist = true) {
    state.widgetPinned = Boolean(pinned);
    if (state.refs.pinBtn) {
      state.refs.pinBtn.textContent = state.widgetPinned ? '🔒' : '📌';
      state.refs.pinBtn.title = state.widgetPinned ? 'Đã ghim vị trí · bấm để cho phép kéo' : 'Ghim vị trí tiện ích';
      state.refs.pinBtn.setAttribute('aria-pressed', String(state.widgetPinned));
    }
    refreshHeaderInteractionTitle();
    if (persist) void safeStorageSet({ widgetPinned: state.widgetPinned });
  }

  function setWidgetCollapsed(collapsed, persist = true) {
    const value = Boolean(collapsed);
    if (!state.refs.card || !state.refs.body) return;
    state.refs.card.classList.toggle('collapsed', value);
    state.refs.body.classList.toggle('hidden', value);
    const header = state.root?.getElementById?.('dragHeader');
    if (header) header.setAttribute('aria-expanded', value ? 'false' : 'true');
    refreshHeaderInteractionTitle();
    if (persist) void safeStorageSet({ widgetCollapsed: value });
  }

  function enableDragging(host, header, onTap = null) {
    let pointerDown = false, dragging = false, startX = 0, startY = 0, startLeft = 0, startTop = 0;
    const MOVE_THRESHOLD = 5;
    header.addEventListener('pointerdown', (e) => {
      if (e.target.closest('button,a,input,select,textarea,.outgoing-match-popover')) return;
      const rect = host.getBoundingClientRect();
      pointerDown = true;
      dragging = false;
      startX = e.clientX; startY = e.clientY; startLeft = rect.left; startTop = rect.top;
      header.setPointerCapture?.(e.pointerId);
      e.preventDefault();
    });
    header.addEventListener('pointermove', (e) => {
      if (!pointerDown || state.widgetPinned) return;
      const dx = e.clientX - startX, dy = e.clientY - startY;
      if (!dragging && Math.hypot(dx, dy) < MOVE_THRESHOLD) return;
      if (!dragging) {
        dragging = true;
        const rect = host.getBoundingClientRect();
        host.style.right = 'auto'; host.style.bottom = 'auto';
        host.style.left = `${rect.left}px`; host.style.top = `${rect.top}px`;
        startLeft = rect.left; startTop = rect.top;
      }
      const card = host.getBoundingClientRect();
      const left = Math.max(0, Math.min(window.innerWidth - card.width, startLeft + dx));
      const top = Math.max(0, Math.min(window.innerHeight - 36, startTop + dy));
      host.style.left = `${left}px`; host.style.top = `${top}px`;
    });
    const finishPointer = (e, cancelled = false) => {
      if (!pointerDown) return;
      pointerDown = false;
      try { header.releasePointerCapture?.(e.pointerId); } catch (_) {}
      if (dragging) {
        dragging = false;
        void safeStorageSet({ widgetPosition: { left: parseInt(host.style.left, 10) || 0, top: parseInt(host.style.top, 10) || 0 } });
      } else if (!cancelled && typeof onTap === 'function') {
        onTap();
      }
    };
    header.addEventListener('pointerup', (e) => finishPointer(e, false));
    header.addEventListener('pointercancel', (e) => finishPointer(e, true));
    safeStorageGet({ widgetPosition: null }).then(({ widgetPosition }) => {
      if (!widgetPosition) return;
      host.style.right = 'auto'; host.style.bottom = 'auto';
      host.style.left = `${Math.max(0, Math.min(window.innerWidth - 330, widgetPosition.left || 0))}px`;
      host.style.top = `${Math.max(0, Math.min(window.innerHeight - 36, widgetPosition.top || 0))}px`;
    }).catch(() => {});
  }


  function foldRecipientText(value) {
    return normalizeText(value).toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/đ/g,'d').replace(/[^a-z0-9]+/g,' ').trim();
  }

  function recipientKey(el){
    return normalizeText(el?.value || el?.dataset?.id || el?.id || '');
  }

  function recipientTextForControl(el) {
    if (!el) return '';
    const row = el.closest?.('tr') || el.closest?.('[class*="treegrid-"]') || el.closest?.('li,.row,.form-group,label') || el.parentElement;
    return normalizeText(row?.innerText || el.getAttribute?.('title') || el.value || el.id || '');
  }

  function selectRecipientKeys(keys, selectors, includeHidden=false){
    const all=[...document.querySelectorAll(selectors)];
    const controls=includeHidden?all:all.filter(controlVisible);
    const matched=[],unmatched=[];
    for(const key of keys||[]){
      const el=controls.find(x=>recipientKey(x)===key);
      if(el&&nativeSetChecked(el,true))matched.push({target:key,text:recipientTextForControl(el),value:recipientKey(el),score:1}); else unmatched.push(key);
    }
    return {matched,unmatched,totalControls:controls.length};
  }


  function normalizedWatcherTargets(list) {
    return (Array.isArray(list)?list:[]).map(x=>({
      key:normalizeText(x?.key||''), name:normalizeText(x?.name||''),
      parentUnit:normalizeText(x?.parentUnit||''), parentName:normalizeText(x?.parentName||'')
    })).filter(x=>x.key||x.name);
  }

  function activeLeaderWatcherTargets() {
    return normalizedWatcherTargets(state.currentLeaderWatchers);
  }

  function resetLeaderWatchersForDocument() {
    state.currentLeaderWatchers = state.leaderWatchersLocked ? normalizedWatcherTargets(state.leaderDefaultWatcherTargets) : [];
    renderLeaderWatcherChips();
  }

  function renderLeaderWatcherChips() {
    const box=state.refs.viewPersonChips, lock=state.refs.viewWatcherLock;
    if(!box) return;
    const items=activeLeaderWatcherTargets();
    box.innerHTML='';
    for(const x of items){
      const chip=document.createElement('button');
      chip.type='button'; chip.className='role-chip person-chip';
      chip.textContent=x.name||x.key; chip.title=`Bấm để bỏ người theo dõi${x.parentName?` · ${x.parentName}`:''}`;
      chip.addEventListener('click',()=>{
        state.currentLeaderWatchers=activeLeaderWatcherTargets().filter(y=>(y.key||y.name)!==(x.key||x.name));
        if(state.leaderWatchersLocked) persistLeaderWatcherLock();
        renderLeaderWatcherChips();
      });
      box.appendChild(chip);
    }
    if(!items.length) box.innerHTML='<span class="role-empty">Chưa chọn cá nhân</span>';
    if(lock){
      lock.textContent=state.leaderWatchersLocked?'🔒':'🔓';
      lock.title=state.leaderWatchersLocked?'Đang khóa danh sách cá nhân xem để biết cho các văn bản sau':'Khóa danh sách cá nhân hiện tại làm mặc định';
      lock.classList.toggle('locked',state.leaderWatchersLocked);
    }
  }

  async function persistLeaderWatcherLock() {
    const targets = activeLeaderWatcherTargets();
    const units = [];
    state.leaderDefaultWatcherTargets = targets;
    state.leaderDefaultWatcherIds = targets.map(x=>x.key).filter(Boolean);
    state.leaderDefaultViewUnitIds = [];
    await safeStorageSet({
      leaderWatchersLocked:state.leaderWatchersLocked,
      leaderDefaultWatcherTargets:targets,
      leaderDefaultWatcherIds:state.leaderDefaultWatcherIds,
      leaderDefaultViewUnitIds:state.leaderDefaultViewUnitIds
    });
  }

  async function toggleLeaderWatcherLock() {
    const people = activeLeaderWatcherTargets();
    const units = [];
    if (!state.leaderWatchersLocked && !people.length) {
      setMessage('Hãy chọn ít nhất 1 cá nhân Xem để biết trước khi khóa.', 'error');
      return;
    }
    state.leaderWatchersLocked = !state.leaderWatchersLocked;
    if (state.leaderWatchersLocked) {
      await persistLeaderWatcherLock();
      setMessage(`🔒 Đã khóa mặc định ${people.length} cá nhân Xem để biết.`, 'success');
    } else {
      await safeStorageSet({leaderWatchersLocked:false});
      setMessage('🔓 Đã bỏ khóa mặc định. Lựa chọn của văn bản hiện tại vẫn được giữ.', 'info');
    }
    renderLeaderWatcherChips();
  }

  function leaderWatcherControls() {
    // DOM Lãnh đạo dùng chkunitempxem<email|Uxxx> + cxl_vbden_checkbox_click_xem(this,1).
    // Dùng đúng selector Xem để biết của màn Lãnh đạo (chkunitempxem...).
    return [...document.querySelectorAll('input[id^="chkunitempxem"],input.chk_chuyentiep_ph_class[name="chk_chuyentiep_ph"]')].filter((el) => {
      const id=String(el.id||'');
      const onchange=String(el.getAttribute?.('onchange')||'');
      return id.startsWith('chkunitempxem') || /cxl_vbden_checkbox_click_xem/i.test(onchange);
    });
  }

  function leaderWatcherMetaForControl(el) {
    if(!el) return {key:'',name:'',type:'unknown',parentUnit:'',parentName:''};
    const key=recipientKey(el);
    const row=el.closest?.('tr') || el.closest?.('[class*="treegrid-"]') || el.parentElement;
    const cls=normalizeText(row?.className||'');
    const parentUnit=normalizeText(cls.match(/(?:^|\s)treegrid-parent-([^\s]+)/i)?.[1]||'');
    const type=/^U\d+$/i.test(key)?'unit':'person';
    let name=normalizeText(row?.innerText||el.getAttribute?.('title')||key);
    if(name.includes('|')) name=normalizeText(name.split('|')[0]);
    let parentName='';
    if(parentUnit){
      const parent=leaderWatcherControls().find(x=>recipientKey(x)===parentUnit);
      const prow=parent?.closest?.('tr') || parent?.closest?.('[class*="treegrid-"]') || parent?.parentElement;
      parentName=normalizeText(prow?.innerText||'');
    }
    return {key,name,type,parentUnit,parentName};
  }

  async function captureLeaderWatcherDirectory() {
    const map=new Map();
    for(const el of leaderWatcherControls()){
      const meta=leaderWatcherMetaForControl(el);
      if(meta.type!=='person' || !meta.key || !meta.name) continue;
      if(!map.has(meta.key)) map.set(meta.key,meta);
    }
    const list=[...map.values()].sort((a,b)=>{
      const ga=normalizeText(a.parentName||a.parentUnit||''), gb=normalizeText(b.parentName||b.parentUnit||'');
      return ga.localeCompare(gb,'vi') || a.name.localeCompare(b.name,'vi');
    });
    if(list.length) await safeStorageSet({leaderWatcherDirectory:list,leaderWatcherDirectoryUpdatedAt:Date.now()});
    return list;
  }

  async function loadLeaderWatcherDirectory() {
    const cfg=await safeStorageGet({leaderWatcherDirectory:[]});
    const cached=Array.isArray(cfg.leaderWatcherDirectory)?cfg.leaderWatcherDirectory:[];
    // Cây nhận của Lãnh đạo có thể đã được iOffice nạp nhưng đang thu gọn; đọc cả control ẩn.
    const liveControls=leaderWatcherControls();
    const live=liveControls.length ? await captureLeaderWatcherDirectory().catch(()=>[]) : [];
    state.leaderWatcherDirectory=(live.length?live:cached).filter(x=>x?.type==='person' && (x.key||x.name));
    return state.leaderWatcherDirectory;
  }

  function applyLeaderDefaultWatchers() {
    const targets = activeLeaderWatcherTargets();
    const matched=[],unmatched=[]; let totalControls=0;


    if (!targets.length) return {matched,unmatched,totalControls};
    const controls=leaderWatcherControls().filter(el=>!/^U\d+$/i.test(recipientKey(el)));
    totalControls=controls.length; const used=new Set();
    for(const target of targets){
      let best=null,bestScore=0;const wantedKey=normalizeText(target.key||'');
      if(wantedKey){best=controls.find(el=>!used.has(el)&&recipientKey(el)===wantedKey)||null;if(best)bestScore=1;}
      if(!best&&target.name){for(const el of controls){if(used.has(el))continue;const meta=leaderWatcherMetaForControl(el);let score=recipientMatchScore(target.name,meta.name||recipientTextForControl(el));if(target.parentUnit&&meta.parentUnit===target.parentUnit)score=Math.min(1,score+.06);if(target.parentName&&meta.parentName&&recipientMatchScore(target.parentName,meta.parentName)>.85)score=Math.min(1,score+.04);if(score>bestScore){bestScore=score;best=el;}}}
      if(best&&bestScore>=.72&&nativeSetChecked(best,true)&&best.checked){used.add(best);const meta=leaderWatcherMetaForControl(best);matched.push({target:target.name||target.key,text:meta.name||recipientTextForControl(best),value:recipientKey(best),score:bestScore});}else unmatched.push(target.name||target.key);
    }
    if(controls.length)void captureLeaderWatcherDirectory().catch(()=>{});
    return {matched,unmatched,totalControls};
  }

  function recipientMatchScore(target, candidate) {
    const a=foldRecipientText(target), b=foldRecipientText(candidate);
    if (!a || !b) return 0;
    if (a === b) return 1;
    if (b.includes(a) || a.includes(b)) return .92;
    const stop=new Set(['tinh','dak','lak','xa','phuong','ubnd','uy','ban','nhan','dan','va','cua','the','so','phong']);
    const A=a.split(' ').filter(x=>x.length>1 && !stop.has(x));
    const B=new Set(b.split(' ').filter(x=>x.length>1 && !stop.has(x)));
    if (!A.length) return 0;
    const hit=A.filter(x=>B.has(x)).length;
    return hit/A.length;
  }

  function matchAndSelectRecipients(names, selectors, includeHidden=false) {
    const all=[...document.querySelectorAll(selectors)];
    const controls=includeHidden?all:all.filter(controlVisible);
    const matched=[], unmatched=[];
    for (const target of names || []) {
      let best=null, score=0;
      for (const el of controls) {
        const text=recipientTextForControl(el);
        const s=recipientMatchScore(target,text);
        if (s>score) {score=s;best={el,text};}
      }
      if (best && score>=.72) {
        const ok=nativeSetChecked(best.el,true);
        if (ok) matched.push({target,text:best.text,value:best.el.value,score}); else unmatched.push(target);
      } else unmatched.push(target);
    }
    return {matched,unmatched,totalControls:controls.length};
  }

  async function waitForVisibleSelector(selector, timeoutMs=6000) {
    const started=performance.now();
    while(performance.now()-started<timeoutMs){
      const el=[...document.querySelectorAll(selector)].find(controlVisible);
      if(el)return el;
      await sleepUi(100);
    }
    return [...document.querySelectorAll(selector)].find(controlVisible)||null;
  }

  function dateToIsoToday() {
    const d=new Date();
    const z=n=>String(n).padStart(2,'0');
    return `${d.getFullYear()}-${z(d.getMonth()+1)}-${z(d.getDate())}`;
  }

  function firstControlValue(selectors) {
    for (const selector of selectors || []) {
      const el=document.querySelector(selector);
      const value=normalizeText(el?.value || el?.textContent || '');
      if(value)return value;
    }
    return '';
  }

  function validTrackerMeta(value) {
    const text=normalizeText(value || '');
    if(!text)return '';
    if(/^Chưa nhận diện/i.test(text))return '';
    return text;
  }

  function snapshotTrackerContext(ctx = {}) {
    // Giữ metadata của văn bản TRƯỚC khi mở/đóng modal Chuyển xử lý.
    // iOffice thay đổi DOM khi chuyển nên đọc lại sau khi bấm Chuyển có thể mất trích yếu/số ký hiệu.
    const current=ctx && typeof ctx==='object' ? ctx : {};
    const trichYeu=validTrackerMeta(current.trichYeu)
      || validTrackerMeta(firstControlValue(['#txt_trich_yeu','textarea[name="trichYeu"]']))
      || validTrackerMeta(cleanTrichYeu(findValueByLabels(['Trích yếu'])));
    const sender=validTrackerMeta(current.sender)
      || validTrackerMeta(firstControlValue(['#txt_coquan']))
      || validTrackerMeta(findValueByLabels(['Đơn vị ban hành','Cơ quan ban hành','Cơ quan gửi']));
    const symbol=validTrackerMeta(current.symbol)
      || validTrackerMeta(findValueByLabels(['Số ký hiệu','Số, ký hiệu']));
    const documentDate=validTrackerMeta(current.documentDate)
      || validTrackerMeta(firstControlValue(['#txt_ngay_vanban']))
      || validTrackerMeta(findValueByLabels(['Ngày văn bản']));
    const arrivalDate=validTrackerMeta(current.arrivalDate)
      || validTrackerMeta(firstControlValue(['#txt_ngay_den']))
      || validTrackerMeta(findValueByLabels(['Ngày đến']));
    const documentId=validTrackerMeta(current.documentId)
      || validTrackerMeta(firstControlValue(['#idVB','#hide_docid']));
    return {
      ...current,
      documentId,
      trichYeu,
      sender,
      symbol,
      documentDate,
      arrivalDate,
      sourceUrl: current.sourceUrl || location.href
    };
  }

  function taskSyncKey(ctx, task, index) {
    // Khóa cục bộ để tránh gửi lại cùng nhiệm vụ; API Tracker chỉ tạo mới, không upsert.
    const base=normalizeText(ctx?.documentId || ctx?.symbol || getDocumentKey(ctx) || 'ioffice').replace(/\s+/g,'_').slice(0,160);
    return `${base}#${index+1}`;
  }

  function buildTrackerTaskData(suggestion, ctx, task, index, attachment=null) {
    const snap=snapshotTrackerContext(ctx);
    const main=task.responsibleUnit || suggestion.mainUnit || '';
    const data={
      syncKey:taskSyncKey(snap,task,index), sourceNo:snap.symbol||'', sourceDate:snap.documentDate||'',
      sourceSubject:snap.trichYeu||'', taskText:task.task||'', deadline:task.deadline||'', mainUnitId:main,
      note:''
    };
    if(attachment?.base64 && attachment?.name) data.attachment=attachment;
    return data;
  }

  async function resolveTrackerOfficialAttachment(ctx) {
    const reader=globalThis.IOfficeDocumentReader;
    if(!reader?.getOfficialPrimaryAttachment) return null;
    const snap=snapshotTrackerContext(ctx);
    const key=getDocumentKey(snap);
    if(state.trackerAttachmentReady?.key===key) return state.trackerAttachmentReady.attachment || null;
    const analysisPrimaryName=normalizeText(state.lastPrep?.bundle?.primaryDocument?.name || '');
    addProgress('Đang lấy PDF chính thức để giao kèm nhiệm vụ…','info','tracker-attachment');
    try{
      const file=await reader.getOfficialPrimaryAttachment(snap,analysisPrimaryName,{maxMb:20});
      if(!file?.ok){
        addProgress(file?.message || 'Chưa xác định được PDF chính thức để giao kèm; nhiệm vụ vẫn được tạo.','warn','tracker-attachment-missing');
        state.trackerAttachmentReady={key,attachment:null,reason:file?.reason||''};
        return null;
      }
      const attachment={name:file.name,mimeType:file.mimeType||'application/pdf',size:Number(file.size||0),base64:file.base64};
      state.trackerAttachmentReady={key,attachment};
      const mb=(attachment.size/1024/1024).toFixed(1);
      addProgress(`✓ Tệp giao kèm: ${attachment.name} · ${mb} MB${file.reusedCaptured?' · dùng lại dữ liệu đã tải':''}`,'success','tracker-attachment-ready');
      return attachment;
    }catch(e){
      addProgress(`Không lấy được PDF chính thức để giao kèm: ${normalizeText(e?.message||e)}. Nhiệm vụ vẫn được tạo.`,'warn','tracker-attachment-error');
      state.trackerAttachmentReady={key,attachment:null,reason:'error'};
      return null;
    }
  }

  async function prepareTrackerDelivery(suggestion, ctx) {
    const tasks=trackingItemsFromUi(suggestion);
    if(!tasks.length) return [];
    const attachment=await resolveTrackerOfficialAttachment(ctx);
    const ids=[];
    for(let i=0;i<tasks.length;i++) {
      const r=await safeRuntimeSend({type:'TRACKER_DELIVERY_PREPARE',data:buildTrackerTaskData(suggestion,ctx,tasks[i],i,attachment)});
      if(!r?.ok) throw new Error(r?.error||'Chưa lưu được nhiệm vụ gửi ngầm. Chưa chuyển văn bản.');
      ids.push(r.id);
    }
    return ids;
  }

  async function clickLeaderTransferAndWait() {
    const button=findTransferSubmitButton();
    if(!button) return {ok:false,error:'Không tìm thấy nút “Chuyển” trong cửa sổ Chuyển xử lý.'};
    const dialog=button.closest?.('[role="dialog"],.modal,.modal-dialog,.ui-dialog,.bootbox,.popup,.dialog');
    button.click();
    const started=performance.now();
    while(performance.now()-started<5000){
      await sleepUi(120);
      const buttonGone=!document.contains(button) || !isElementVisible(button);
      const dialogGone=dialog ? (!document.contains(dialog) || !isElementVisible(dialog)) : false;
      if(buttonGone || dialogGone) return {ok:true};
    }
    return {ok:false,error:'iOffice chưa xác nhận đã chuyển; chưa ghi Sổ để tránh tạo nhiệm vụ sai.'};
  }

  function collectIncomingSuggestionForApply() {
    const suggestion = {
      ...state.lastSuggestion,
      mainUnit: state.refs.mainSelect.value || null,
      coordinationUnits: getSelectedCodes(state.refs.coordBox),
      viewUnits: [],
      instruction: applyInstructionPrefix(state.refs.instruction.value)
    };
    syncExclusiveRoles();
    suggestion.coordinationUnits=getSelectedCodes(state.refs.coordBox).filter(x=>x!==suggestion.mainUnit);
    suggestion.viewUnits=[];

    // Hạn người dùng chọn trên widget cũng là Hạn xử lý của iOffice, kể cả khi không ghi Sổ.
    const uiDeadline=textDateToIso(state.refs.deadlineCard?.querySelector('.track-deadline')?.value || '');
    if(uiDeadline){
      const tasks=Array.isArray(suggestion.tasks)?suggestion.tasks.map(x=>({...x})):[];
      if(tasks.length) tasks[0]={...tasks[0],deadline:uiDeadline,deadlineSource:(tasks[0].deadline===uiDeadline?(tasks[0].deadlineSource||'ai'):'manual')};
      else tasks.push({task:normalizeText(state.refs.instruction?.value || suggestion.instruction || ''),deadline:uiDeadline,deadlineSource:'manual',responsibleUnit:suggestion.mainUnit||'',scope:suggestion.taskScope||'direct'});
      suggestion.tasks=tasks;
    }

    const trackedNow=trackingItemsFromUi(suggestion);
    if(!suggestion.mainUnit&&trackedNow.length===1&&trackedNow[0].responsibleUnit){suggestion.mainUnit=trackedNow[0].responsibleUnit;if(state.refs.mainSelect)state.refs.mainSelect.value=suggestion.mainUnit;syncExclusiveRoles();renderRoleChips();}
    if(!suggestion.mainUnit&&suggestion.coordinationUnits.length){suggestion.mainUnit=suggestion.coordinationUnits.shift();if(state.refs.mainSelect)state.refs.mainSelect.value=suggestion.mainUnit;syncExclusiveRoles();renderRoleChips();}
    if(!suggestion.mainUnit)throw new Error('Mỗi văn bản phải có 1 đơn vị Xử lý chính để iOffice chuyển đến đầu mối tiếp nhận.');
    if(trackedNow.some(t=>t.responsibleUnit&&t.responsibleUnit!==suggestion.mainUnit))throw new Error('XLC ghi Sổ phải trùng Xử lý chính của văn bản.');
    return suggestion;
  }

  async function completeTransferAfterClick(suggestion, trackerContextSnapshot, deliveryIds=[]) {
    state.updateDirty=false;
    state.appliedKey=''; state.workflowPhase='transferred';
    state.pendingAppliedSuggestion=null; state.pendingTrackerContextSnapshot=null;
    for(const id of deliveryIds) {
      const r=await safeRuntimeSend({type:'TRACKER_DELIVERY_COMMIT',data:{id}});
      if(!r?.ok) {setMessage('Đã chuyển văn bản. Mở Lịch sử gửi Sổ để xác nhận tiếp tục gửi nhiệm vụ đã lưu.','info');setWidgetCollapsed(true,false);return;}
    }
    setMessage(deliveryIds.length ? '✓ Đã chuyển văn bản · Nhiệm vụ đã lưu vào hàng đợi gửi ngầm. Xem Lịch sử gửi Sổ để biết kết quả.' : '✓ Đã chuyển văn bản.', 'success');
    setWidgetCollapsed(true, false);
  }

  async function applyCurrentSuggestion(transferNow=true) {
    if (state.busy || state.updateLocked || state.transferRunning) return;
    const workflow=currentWorkflow();
    if (workflow !== 'leader-incoming') return setMessage('Văn bản đi chỉ dùng Kiểm tra văn bản và đối chiếu Sổ.', 'info');
    const currentKey=getDocumentKey(extractDocumentContext());
    const hasCurrentAi = Boolean(state.lastSuggestion && state.analyzedKey === currentKey);
    const baseSuggestion = hasCurrentAi ? state.lastSuggestion : manualSuggestionFromUi();
    if (!hasCurrentAi && state.lastSuggestion && state.analyzedKey && state.analyzedKey !== currentKey) state.lastSuggestion = null;
    let suggestion;try{
      const old = state.lastSuggestion;
      state.lastSuggestion = baseSuggestion;
      suggestion=collectIncomingSuggestionForApply();
      state.lastSuggestion = old;
    }catch(e){return setMessage(e.message,'error');}
    const trackingCheck=validateTrackingSelection(suggestion);
    if(!trackingCheck.ok)return setMessage(trackingCheck.error,'error');
    const trackerContextSnapshot=snapshotTrackerContext(state.lastContext||extractDocumentContext());
    state.transferRunning=true;
    state.workflowPhase='apply';
    if(state.refs.suggestBtn){state.refs.suggestBtn.disabled=true;state.refs.suggestBtn.textContent=transferNow?'⏳ Đang áp dụng & chuyển…':'⏳ Đang áp dụng…';state.refs.suggestBtn.className='primary-btn apply-state';}
    if(state.refs.applyOnlyBtn)state.refs.applyOnlyBtn.disabled=true;
    try{
      const opened=await ensureProcessingForm(suggestion);if(!opened){setMessage('Không mở được cửa sổ Chuyển xử lý hoặc danh sách đơn vị chưa tải xong.','error');return;}
      await sleepUi(100);
      let report=applySuggestion(suggestion);
      const wr=applyLeaderDefaultWatchers();
      if(wr.matched.length)addProgress(`Đã chọn ${wr.matched.length} cá nhân Xem để biết mặc định.`,'success','default-watchers');
      const extraRecipient=await applyAdditionalRecipient(suggestion);
      if(extraRecipient.applied){addProgress(`Đã chọn thêm ${extraRecipient.count}/${extraRecipient.total||extraRecipient.count} cá nhân nhận trực tiếp theo lĩnh vực đã phân công; XLC phòng vẫn được giữ nguyên.`,'success','recipient-extra');if(extraRecipient.missing?.length)addProgress(`Có ${extraRecipient.missing.length} người đã phân công chưa xuất hiện trong cây nhận hiện tại.`,'warn','recipient-extra-missing');}
      else if(suggestion.additionalRecipientKey && extraRecipient.reason!=='none')addProgress(`Không gửi thêm cá nhân: ${extraRecipient.reason==='unbound'?'lĩnh vực chưa gắn người cục bộ':extraRecipient.reason==='not-found'?'người đã gắn chưa xuất hiện trong cây nhận hiện tại':extraRecipient.reason==='low-confidence'?'độ tin cậy chưa đủ':'không chọn được'}. XLC phòng vẫn được giữ nguyên.`,'warn','recipient-extra');
      if(wr.unmatched.length)addProgress(`Có ${wr.unmatched.length} cá nhân mặc định chưa khớp cây nhận hiện tại.`,'warn','watchers-unmatched');
      const nonBlock=report.warnings.filter(x=>/Không tìm thấy ô Hạn xử lý/.test(x));
      let block=report.warnings.filter(x=>!/Không tìm thấy ô Hạn xử lý/.test(x));
      if(block.length){await sleepUi(300);if(await waitForSuggestionControls(suggestion,2200))report=applySuggestion(suggestion);block=report.warnings.filter(x=>!/Không tìm thấy ô Hạn xử lý/.test(x));}
      if(block.length){setMessage(block.join(' '),'error');return;}if(nonBlock.length)addProgress(nonBlock.join(' '),'warn','deadline-field');
      if(!transferNow){state.pendingAppliedSuggestion={...suggestion};state.pendingTrackerContextSnapshot={...trackerContextSnapshot};state.workflowPhase='transfer';setMessage('✓ Đã áp dụng lên iOffice. Kiểm tra lại rồi bấm Chuyển.','success');return;}
      if(getDocumentKey(extractDocumentContext())!==currentKey)throw new Error('Văn bản đã thay đổi. Hãy kiểm tra lại văn bản trước khi chuyển.');
      const deliveryIds=await prepareTrackerDelivery(suggestion,trackerContextSnapshot);
      const moved=await clickLeaderTransferAndWait();if(!moved.ok){
        for(const id of deliveryIds) await safeRuntimeSend({type:'TRACKER_DELIVERY_CANCEL',data:{id}}).catch?.(()=>{});
        state.workflowPhase='apply';setMessage(moved.error,'error');return;
      }
      await completeTransferAfterClick(suggestion,trackerContextSnapshot,deliveryIds);
    }catch(e){setMessage(e.message||String(e),'error');}finally{state.transferRunning=false;if(state.refs.applyOnlyBtn)state.refs.applyOnlyBtn.disabled=false;updatePrimaryAction();}
  }

  async function finalizeCurrentTransfer() {
    if(state.busy || state.updateLocked || state.transferRunning)return;
    const currentKey=getDocumentKey(extractDocumentContext());
    const suggestion=state.pendingAppliedSuggestion;
    const snap=state.pendingTrackerContextSnapshot;
    if(!suggestion || !snap) return applyCurrentSuggestion(true);
    if(getDocumentKey(snap)!==currentKey){setMessage('Văn bản đã thay đổi. Áp dụng lại trên văn bản hiện tại.','error');return;}
    const trackingCheck=validateTrackingSelection(suggestion);
    if(!trackingCheck.ok){setMessage(trackingCheck.error,'error');return;}
    if(state.refs.suggestBtn){state.refs.suggestBtn.disabled=true;state.refs.suggestBtn.textContent='⏳ Đang chuyển…';}
    state.transferRunning=true;
    try{
      const deliveryIds=await prepareTrackerDelivery(suggestion,snap);
      const moved=await clickLeaderTransferAndWait();
      if(!moved.ok){setMessage(moved.error,'error');return;}
      await completeTransferAfterClick(suggestion,snap,deliveryIds);
    } catch(e) {setMessage(e.message||String(e),'error');} finally { state.transferRunning=false;updatePrimaryAction(); }
  }

  async function switchAssistantMode(next) {
    next = next === 'tracker' ? 'tracker' : 'leader';
    if (state.busy || state.updateLocked || state.transferRunning || next === state.userRole) return;
    // Stable 1.1: Sổ theo dõi chỉ là một bảng xem nhanh trong tiện ích, không phải chế độ
    // được ghi nhớ. Mỗi lần tải iOffice luôn trở về phân tích văn bản.
    state.userRole = next;
    setWorkflowUi();
    if (next === 'tracker') {
      void refreshTrackerConnectionStatus();
      return;
    }
    updateDetection();
  }

  function createWidget() {
    if (document.getElementById(HOST_ID)) return;
    const host = document.createElement('div');
    host.id = HOST_ID;
    host.style.cssText = 'position:fixed;right:18px;bottom:18px;z-index:2147483647;visibility:hidden';
    document.documentElement.appendChild(host);
    const shadow = host.attachShadow({ mode: 'open' });
    state.root = shadow;

    shadow.innerHTML = `
      <style>
        :host{all:initial}*{box-sizing:border-box}.hidden{display:none!important}.card{width:430px;height:690px;min-width:360px;min-height:360px;max-width:min(760px,calc(100vw - 20px));max-height:calc(100vh - 20px);overflow:hidden;resize:both;display:flex;flex-direction:column;border-radius:15px;background:#fff;border:1px solid rgba(0,0,0,.12);box-shadow:0 18px 60px rgba(0,0,0,.28);font-family:Arial,Helvetica,sans-serif;color:#172033}.card.collapsed{height:auto!important;min-height:0;resize:none;overflow:visible}.card.collapsed .body{display:none!important}
        .header{display:flex;align-items:center;justify-content:space-between;gap:7px;padding:8px 9px;background:linear-gradient(135deg,#0759c8,#1188d8);color:#fff;user-select:none;cursor:grab;touch-action:none;position:relative;flex-wrap:wrap}.header:active{cursor:grabbing}.header.pinned,.header.pinned:active{cursor:default}.title{display:flex;align-items:center;gap:5px;min-width:0;font-size:12.5px;font-weight:700;line-height:1.2;flex:1 1 auto;overflow:hidden}.version{font-size:8.5px;opacity:.72;font-weight:600}.workflow-badge{font-size:8.5px;font-weight:900;letter-spacing:.04em;padding:3px 6px;border-radius:999px;background:rgba(255,255,255,.2);white-space:nowrap}.head-actions{display:flex;align-items:center;gap:4px;flex:0 0 auto}.header-main-action{height:30px;border:1px solid rgba(255,255,255,.56);border-radius:9px;background:#fff;color:#0759a8;padding:0 9px;font-size:9.5px;font-weight:900;cursor:pointer;white-space:nowrap;max-width:132px;overflow:hidden;text-overflow:ellipsis}.header-main-action:hover{background:#f3f8ff}.header-main-action:disabled{opacity:.62;cursor:not-allowed}.header-status{flex:1 0 100%;min-width:0;margin-top:1px;padding:5px 8px;border-radius:8px;border:1px solid #bfdbfe;background:#eff6ff;color:#1d4f91;box-shadow:0 4px 14px #0002;font-size:9.5px;font-weight:800;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;pointer-events:none}.header-status.success{border-color:#bbf7d0;background:#f0fdf4;color:#166534}.header-status.warn{border-color:#fde68a;background:#fffbeb;color:#92400e}.header-status.error{border-color:#fecaca;background:#fff1f2;color:#b42318}.header-stop{width:30px;height:30px;border:1px solid #fecaca;border-radius:9px;background:#dc2626;color:#fff;font-size:12px;font-weight:900;cursor:pointer;box-shadow:0 3px 10px rgba(185,28,28,.28)}.header-stop:hover{background:#b91c1c}.card.collapsed .workflow-badge{display:none!important}.card.collapsed .outgoing-match-chip{max-width:92px}.body-analyze-btn{display:none!important}.mode-toggle{width:30px;height:30px;border:1px solid rgba(255,255,255,.38);border-radius:9px;background:rgba(255,255,255,.14);color:#fff;padding:0;font-size:14px;font-weight:850;cursor:pointer;white-space:nowrap;display:inline-flex;align-items:center;justify-content:center}.mode-toggle:hover{background:rgba(255,255,255,.24)}.mode-toggle.active{background:#fff;color:#0a6c8a;border-color:#fff;box-shadow:0 2px 8px rgba(0,0,0,.12)}.icon-btn{width:30px;height:30px;border:0;border-radius:9px;color:#fff;background:rgba(255,255,255,.17);cursor:pointer}.icon-btn:hover{background:rgba(255,255,255,.26)}
        .body{padding:11px;overflow:auto;flex:1;min-height:0;max-height:none}.body.hidden{display:none}.meta{padding:9px 10px;background:#f7f9fc;border:1px solid #e4e9f1;border-radius:10px}.doc{font-size:12px;line-height:1.42;color:#1d2939;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;max-height:35px}.doc b{font-weight:800;color:#334155}.sender-line{font-size:10px;color:#64748b;margin-top:5px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.sender-sep{margin:0 4px;color:#cbd5e1}
        .ai-control{display:flex;align-items:center;gap:5px;margin-top:8px;padding:7px 8px;border:1px solid #dce6ef;border-radius:11px;background:#f8fbfd}.ai-info-wrap{display:flex;align-items:stretch;gap:6px;margin-top:8px}.ai-info-wrap>.ai-info{margin-top:0!important;flex:1 1 auto;min-width:0}.ai-info-wrap>.read-all-btn{width:auto!important;flex:0 0 auto;align-self:stretch;min-height:34px;margin:0!important;padding:0 9px;border:1px solid #8fc0e9;border-radius:10px;background:#f5fbff;color:#145d9a;font-size:9.5px;font-weight:900;cursor:pointer;white-space:nowrap;max-width:165px;overflow:hidden;text-overflow:ellipsis}.ai-info-wrap>.read-all-btn:hover{background:#eaf6ff}.ai-info-wrap>.read-all-btn.recommended{background:#fff7df;border-color:#f0c34e;color:#8b5a00}.ai-info-body{padding-top:2px}.ai-toggle{display:flex;align-items:center;gap:5px;font-size:10px;font-weight:850;color:#24506f;white-space:nowrap;cursor:pointer}.ai-toggle input{width:16px;height:16px;accent-color:#0f766e}.ai-tools{display:flex;align-items:center;gap:5px;flex:0 0 92px;min-width:0}.ai-analyze-btn{border:1px solid #7eb6e8;border-radius:9px;background:#eef7ff;color:#145d9a;font-size:10.5px;font-weight:850;padding:0 10px;min-height:34px;cursor:pointer;white-space:nowrap}.ai-analyze-btn:hover{background:#e3f1ff}.ai-analyze-btn:disabled{opacity:.55;cursor:not-allowed}.hero-actions{display:flex;flex-wrap:nowrap;gap:5px;margin-top:0;flex:1 1 auto;min-width:0}.hero-actions .primary-btn{width:auto;flex:1 1 auto;min-width:0;min-height:36px;padding:8px 9px;font-size:10.5px;white-space:nowrap}.apply-only-btn{border:1px solid #16834d;border-radius:9px;background:#fff;color:#16834d;font-size:10px;font-weight:900;padding:0 8px;cursor:pointer;white-space:nowrap;min-height:36px;flex:0 0 auto}.apply-only-btn:hover{background:#f0fdf4}.apply-only-btn:disabled{opacity:.55;cursor:not-allowed}.primary-btn{width:100%;border:0;border-radius:10px;padding:11px 12px;background:#0866cf;color:#fff;font-weight:700;cursor:pointer;box-shadow:0 4px 12px rgba(8,102,207,.2)}.primary-btn:hover{filter:brightness(.97)}.primary-btn:disabled{opacity:.52;cursor:not-allowed}.primary-btn.analyzed{background:#138a4b;box-shadow:0 4px 12px rgba(19,138,75,.18)}.primary-btn.busy{background:#64748b}.primary-btn.apply-state{background:#16834d;box-shadow:0 4px 12px rgba(22,131,77,.2)}.primary-btn.transfer-state{background:#0f766e;box-shadow:0 4px 12px rgba(15,118,110,.2)}.rule-btn{width:100%;border:1px solid #c9d8e5;border-radius:10px;padding:10px 9px;background:#fff;color:#34546d;font-weight:750;font-size:11px;cursor:pointer}.rule-btn:hover{background:#f5f9fc}.rule-btn:disabled{opacity:.5;cursor:not-allowed}.apply-btn{border:0;border-radius:10px;background:#16834d;color:#fff;font-size:11px;font-weight:800;padding:0 12px;cursor:pointer;white-space:nowrap}.apply-btn:hover{filter:brightness(.97)}.apply-btn:disabled{opacity:.55;cursor:not-allowed}.reanalyze{width:40px;border:1px solid #cfd7e4;border-radius:10px;background:#fff;color:#435167;font-size:16px;cursor:pointer}.stop-btn{width:52px;border:1px solid #fecaca;border-radius:10px;background:#fff1f2;color:#b42318;font-size:10px;font-weight:800;cursor:pointer}.stop-btn:hover{background:#ffe4e6}.finalize-btn{border:0;border-radius:10px;background:#0f766e;color:#fff;font-size:11px;font-weight:800;padding:0 12px;cursor:pointer;white-space:nowrap}.finalize-btn:hover{filter:brightness(.96)}.finalize-btn:disabled{opacity:.55;cursor:not-allowed}
        details{margin-top:8px;border:1px solid #e4e9f1;border-radius:9px;background:#fafbfd}summary{cursor:pointer;padding:7px 9px;font-size:10.5px;font-weight:700;color:#667085}.source{padding:0 9px 8px;font-size:9.5px;line-height:1.45;color:#667085;max-height:145px;overflow:auto}.signal-score{margin-top:4px;color:#255a98}
        .section{margin-top:10px}.section-head{display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:5px}.label{font-size:11px;font-weight:700;color:#475467}.hint{font-size:9px;color:#98a2b3}select,textarea{width:100%;border:1px solid #d0d7e2;border-radius:9px;padding:8px;font:12px Arial,sans-serif;background:#fff;color:#172033;outline:none}select:focus,textarea:focus{border-color:#7ab8f3;box-shadow:0 0 0 3px rgba(8,102,207,.08)}textarea{min-height:76px;resize:vertical;line-height:1.45}.instruction-section .label{font-size:12.5px;font-weight:800;color:#1f3f66}.instruction-section textarea{min-height:96px;font-size:13px;line-height:1.58;padding:10px 11px;resize:none;overflow:hidden;background:#fffefb;border-color:#c9d6e3}.instruction-section .deadline-card{margin-top:7px}.tracker-connection{display:flex;align-items:center;gap:5px;margin:0 0 5px 2px;font-size:11px;color:#64748b}.tracker-connection.ok{color:#166534}.tracker-connection.err{color:#b42318}.tracker-connection.checking{color:#64748b}.tracker-dot{font-size:8px}.tracker-inline-row{display:flex;align-items:center;gap:7px;flex-wrap:wrap;padding:7px 8px;border:1px solid #d6e6df;border-radius:9px;background:#f7fbf8}.tracker-toggle{display:inline-flex;align-items:center;justify-content:center;gap:5px;border-radius:999px;padding:6px 9px;font-size:13px;font-weight:900;white-space:nowrap;cursor:pointer}.tracker-toggle.off{color:#b42318;background:#fff1f0;border:2px solid #f04438}.tracker-toggle.on{color:#fff;background:#16834d;border:1px solid #16834d}.tracker-toggle:disabled{opacity:.5;cursor:not-allowed;background:#f1f5f9;color:#64748b;border-color:#cbd5e1}.tracker-inline-deadline{display:inline-flex;align-items:center;gap:7px;font-size:14px;font-weight:800;color:#17365d}.tracker-inline-deadline input{width:155px;height:36px;border:1px solid #cdd8e3;border-radius:7px;padding:6px 8px;font-size:14px;background:#fff}.tracker-inline-owner{font-size:12px;font-weight:800;color:#31516f;background:#eef5fb;border-radius:999px;padding:4px 7px}.tracker-inline-badge{font-size:12px;font-weight:850;color:#b45309;background:#fff7ed;border-radius:999px;padding:4px 7px}.tracker-inline-note{margin-top:6px;padding:6px 8px;border-radius:8px;font-size:12px;font-weight:850;line-height:1.35}.tracker-inline-note.on{color:#166534;background:#ecfdf3;border:1px solid #bbf7d0}.tracker-inline-note.off{color:#92400e;background:#fffbeb;border:1px solid #fde68a}
        .main-role-section{--confidence-color:#0866cf;padding:10px;border:1px solid color-mix(in srgb,var(--confidence-color) 42%,#d8e5f4);border-left:5px solid var(--confidence-color);border-radius:11px;background:linear-gradient(135deg,color-mix(in srgb,var(--confidence-color) 8%,#fff),#f8fbff);box-shadow:0 3px 12px color-mix(in srgb,var(--confidence-color) 10%,transparent)}.main-role-section .label{font-size:12px;color:#174f8e}.main-role-section select{font-weight:700;border-color:#86bff6;background:#fff}.confidence-meter{display:flex;align-items:center;gap:6px;min-width:104px}.confidence-track{position:relative;width:66px;height:8px;border-radius:999px;background:#e2e8f0;overflow:hidden}.confidence-fill{width:0;height:100%;border-radius:inherit;background:#cbd5e1;transition:width .25s ease,background .25s ease}.confidence-value{min-width:30px;text-align:right;font-size:10px;font-weight:800;color:#64748b}.confidence-value.high{color:#15803d}.confidence-value.mid{color:#a16207}.confidence-value.low{color:#b91c1c}.role-box{display:flex;align-items:center;gap:6px;flex-wrap:wrap;min-height:38px;padding:6px;border:1px solid #dce3ec;border-radius:9px;background:#fbfcfe}.selected-chips{display:flex;gap:5px;flex-wrap:wrap;flex:1;min-width:0}.role-empty{font-size:10px;color:#98a2b3;padding:3px}.role-chip{display:inline-flex;align-items:center;max-width:100%;background:#eaf3ff;color:#245d9d;border:1px solid #d6e8ff;border-radius:999px;padding:5px 9px;font-size:9.8px;font-weight:600;cursor:pointer;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.role-chip:hover{background:#dcecff;border-color:#bdd8fa}.add-role{border:1px dashed #a9bdd6;border-radius:8px;background:#fff;color:#2563a7;padding:6px 9px;font-size:10px;font-weight:700;cursor:pointer;white-space:nowrap}.watcher-role-box{margin-top:5px;background:#fff}.person-chip{background:#eefaf4;color:#166534;border-color:#cce9d8}.watch-lock{border:1px solid #d7e2ec;background:#fff;border-radius:8px;min-width:32px;height:28px;cursor:pointer;font-size:14px}.watch-lock.locked{background:#eaf7ef;border-color:#9fd0ae}.picker-group{position:sticky;top:0;background:#eef5fb;color:#245d9d;font-size:9px;font-weight:900;padding:5px 7px;margin:3px 0}.picker-empty{padding:10px;color:#64748b;font-size:10px;line-height:1.4}.hidden-store{display:none}
        .analysis{margin-top:9px;border:1px solid #b9d9fb;border-radius:11px;background:linear-gradient(180deg,#f2f8ff,#fbfdff);padding:10px}.analysis.hidden{display:none}.analysis-meta{font-size:9.6px;font-weight:700;color:#64748b;background:#eaf2fb;border-radius:7px;padding:5px 7px;margin-bottom:7px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.analysis-title{display:none}.analysis-routing{display:none}.summary-label{display:block;font-weight:900;color:#1f3f66;margin-bottom:5px;letter-spacing:.02em}.reason strong{font-weight:850;color:#203f63}.review{font-size:11.5px;font-weight:700;margin-top:4px}.review.ok{color:#176b3d}.review.warn{color:#a36a00}.reason{margin-top:6px;font-size:12.4px;color:#4b5d73;line-height:1.52}.chips{display:flex;flex-wrap:wrap;gap:4px;margin-top:7px}.chips.hidden{display:none}.chip{background:#eaf2ff;color:#285e9d;padding:3px 6px;border-radius:10px;font-size:9.2px}.muted{color:#8b94a4;font-size:9px}
        .ai-mode-wrap{margin:7px 0 2px}.ai-mode-switch{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:4px;padding:4px;border:1px solid #d8e2ef;background:#f3f6fa;border-radius:10px}.ai-mode-btn{border:0;background:transparent;color:#617087;border-radius:7px;padding:7px 5px;font-size:9.7px;font-weight:800;cursor:pointer;transition:.16s ease}.ai-mode-btn:hover{background:#e8f1fb;color:#245d9d}.ai-mode-btn.active{background:#0b72d7;color:#fff;box-shadow:0 2px 7px rgba(11,114,215,.22)}.ai-mode-hint{margin-top:4px;text-align:right;font-size:8.5px;color:#8a96a8}.message{margin-top:7px;padding:8px 9px;border-radius:9px;font-size:10.6px;font-weight:700;line-height:1.42;border:1px solid transparent}.message.info{border-color:#d5e7fb}.message.success{border-color:#ccebd9}.message.error{border-color:#f3caca}.message.info{background:#eef5ff;color:#255a98}.message.success{background:#eaf8f0;color:#16663a}.message.error{background:#fff0f0;color:#a23535}.safety{margin-top:7px;font-size:8.8px;color:#8b5b12;background:#fff7e8;padding:6px 7px;border-radius:7px}
        .fallback-actions{display:flex;gap:5px;flex-wrap:wrap;margin-top:6px}.fallback-actions button{border:1px solid #cbd5e1;background:#fff;border-radius:8px;padding:6px 8px;font-size:9.5px;font-weight:800;color:#334155;cursor:pointer}.fallback-actions button:hover{background:#f1f5f9}.input-audit{margin-top:7px;border:1px solid #dde5ed;border-radius:10px;padding:8px 9px;background:#fbfcfe}.input-audit.pending{color:#667085}.input-audit.ok{background:#effaf4;border-color:#cce9d8}.input-audit.warn{background:#fff8e8;border-color:#f0d59a}.input-audit-head{font-size:10.5px;font-weight:800;line-height:1.4}.input-audit-files{display:grid;gap:4px;margin-top:6px;max-height:105px;overflow:auto}.input-file{display:grid;grid-template-columns:14px minmax(0,1fr);column-gap:5px;align-items:start;font-size:9.5px;padding:4px 5px;border-radius:6px;background:#fff8}.input-file span{grid-row:1/3}.input-file b{font-weight:700;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.input-file small{grid-column:2;color:#667085;font-size:8.7px;line-height:1.35}.input-file.ok span{color:#15803d}.input-file.bad span{color:#b7791f}
        .workflow-strip{display:flex;align-items:center;gap:7px;margin:8px 0 2px}.workflow-role{width:118px;min-height:32px;padding:5px 26px 5px 8px;border-radius:9px;font-size:10.5px;font-weight:800;background:#fff}.workflow-badge{flex:1;min-width:0;padding:7px 9px;border:1px solid #cfe0dc;border-radius:9px;background:#eef8f5;color:#17675f;font-size:10.5px;font-weight:800;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.read-all-btn{width:100%;margin-top:6px;border:1px solid #b9d4e8;border-radius:8px;background:#f7fbff;color:#245d8f;padding:6px 8px;font-size:10px;font-weight:800;cursor:pointer}.mode-result{margin-top:9px;border:1px solid #d9e2ec;border-radius:10px;background:#fbfcfe;padding:11px 12px;font-size:13px}.mode-result-title{font-size:15px;font-weight:900;color:#334155}.review-title-row{display:flex;align-items:center;justify-content:space-between;gap:10px;margin-bottom:6px}.review-score{display:flex;align-items:baseline;gap:2px;padding:5px 8px;border-radius:10px;background:#eef2f7}.review-score b{font-size:19px;line-height:1}.review-score span{font-size:9px;font-weight:800}.review-score.good{background:#eaf8ef;color:#166534}.review-score.warn{background:#fff7e7;color:#9a670d}.review-score.bad{background:#fff0f0;color:#b42318}.review-decision{display:inline-flex;padding:4px 8px;border-radius:999px;font-size:10px;font-weight:900;margin-bottom:6px}.review-decision.good{background:#eaf8ef;color:#166534}.review-decision.warn{background:#fff7e7;color:#9a670d}.review-decision.bad{background:#fff0f0;color:#b42318}.review-score-note{font-size:9.5px;line-height:1.4;color:#748293;margin-bottom:7px}.review-summary{font-size:14px;line-height:1.58;color:#334155}.review-issue{font-size:13.5px;line-height:1.5}.review-issue-head{display:flex;align-items:center;justify-content:space-between;gap:8px}.review-issue-head span{font-size:8px;font-weight:900;color:#7b8794}.review-ok-empty{padding:9px;border-radius:8px;background:#eef9f1;color:#166534;font-weight:800}.review-issue{display:flex;flex-direction:column;gap:2px;margin-top:6px;padding:6px 7px;border-radius:7px;background:#fff}.review-issue.high{border-left:4px solid #dc2626}.review-issue.medium{border-left:4px solid #f59e0b}.review-issue.low{border-left:4px solid #60a5fa}.review-issue small{color:#64748b}.recipient-list{display:grid;gap:3px;color:#334155;line-height:1.4}.mode-empty{color:#64748b}.info-only{padding:8px 9px;border-radius:8px;background:#eef7ff;color:#285e9d;line-height:1.5}.toast-inline{font-weight:800}
                .picker{position:absolute;inset:0;display:flex;align-items:flex-end;justify-content:center;background:rgba(15,23,42,.26);z-index:10;border-radius:15px;overflow:hidden}.picker.hidden{display:none}.picker-panel{width:100%;max-height:72%;display:flex;flex-direction:column;background:#fff;border-radius:14px 14px 0 0;box-shadow:0 -14px 38px rgba(0,0,0,.16);padding:10px}.picker-head{display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:7px}.picker-head b{font-size:12px}.picker-close{border:0;background:#f1f4f8;border-radius:8px;width:30px;height:30px;cursor:pointer}.picker-search{width:100%;border:1px solid #d0d7e2;border-radius:8px;padding:8px;font-size:11px;margin-bottom:6px}.picker-list{overflow:auto}.picker-row{display:grid;grid-template-columns:20px 1fr;gap:7px;align-items:center;padding:7px 4px;border-bottom:1px solid #f0f2f5;cursor:pointer}.picker-row b{display:block;font-size:10.5px;font-weight:600}.picker-row small{display:block;font-size:8.5px;color:#98a2b3;margin-top:2px}
        .card{font-family:system-ui,-apple-system,"Segoe UI",sans-serif;width:400px;height:690px;border-radius:16px;box-shadow:0 14px 48px #163c3433;border-color:#d4e3df}.header{background:#087d77;padding:8px 10px;min-height:42px}.title{font-size:13px;line-height:1.2}.version{font-size:9px}.body{padding:10px}.doc{font-size:13px;line-height:1.45;max-height:39px}.meta-label{font-size:9px}.sender-line{font-size:11px}.label,.main-role-section .label{font-size:12px}.primary-btn{background:#087d77;font-size:13px;min-height:40px}.message{font-size:11px;font-weight:500}.analysis-meta{font-size:10.5px;white-space:normal;line-height:1.5}.reason{font-size:14px;line-height:1.58}.role-chip{font-size:11px;min-height:30px}.role-empty,.add-role{font-size:11px}.add-role{min-height:32px}.ai-mode-btn{font-size:10.5px;min-height:32px}.ai-mode-hint{font-size:9.5px}.stop-btn{font-size:11px;min-width:52px;height:40px}select,textarea{font:12.5px/1.45 system-ui,sans-serif;min-height:38px}.source{font-size:10.5px;max-height:165px}.progress-row{display:grid;grid-template-columns:42px 12px 1fr;gap:5px;padding:4px 0;border-bottom:1px solid #e5ecec}.progress-time{font-variant-numeric:tabular-nums;color:#708087}.progress-row.warn{color:#9b670c}.progress-row.error{color:#aa3535}.progress-row.success{color:#25714a}summary{font-size:11.5px;padding:8px 9px}.safety{font-size:9.5px;line-height:1.45}.picker-row{padding:10px 5px}.picker-row b{font-size:12px}.picker-row small{font-size:10.5px}.picker-search{font-size:12px}.picker-head b{font-size:13px}.hero-actions{position:sticky;top:-10px;background:#fff;padding:6px 0;z-index:2;display:flex;flex-wrap:nowrap;gap:6px}.hero-actions .primary-btn{width:auto;flex:1 1 auto;min-width:0;min-height:36px;padding:8px 9px;font-size:10.5px;white-space:nowrap}.apply-only-btn{border:1px solid #16834d;border-radius:9px;background:#fff;color:#16834d;font-size:10px;font-weight:900;padding:0 8px;cursor:pointer;white-space:nowrap;min-height:36px;flex:0 0 auto}.apply-only-btn:hover{background:#f0fdf4}.apply-only-btn:disabled{opacity:.55;cursor:not-allowed}.reanalyze{width:auto;min-width:92px;height:40px;padding:0 10px;font-size:10.5px;font-weight:900;white-space:nowrap}.icon-btn{min-width:34px;min-height:34px;width:34px;height:34px;flex:0 0 34px}.hint{font-size:9.5px}button:focus-visible,select:focus-visible,textarea:focus-visible,input:focus-visible{outline:3px solid #75c8bc;outline-offset:2px}@media(prefers-reduced-motion:reduce){*{transition:none!important}}
        /* v0.16.2: giao diện gọn theo luồng Phân tích → Áp dụng → Chuyển */
        .hero-actions{align-items:stretch}.primary-btn{background:#1976d2!important;box-shadow:0 4px 12px rgba(25,118,210,.20)!important}.primary-btn.apply-state{background:#d97706!important;box-shadow:0 4px 12px rgba(217,119,6,.20)!important}.primary-btn.transfer-state{background:#15803d!important;box-shadow:0 4px 12px rgba(21,128,61,.20)!important}.primary-btn.busy{background:#64748b!important;box-shadow:none!important}.mode-select{width:92px;min-width:92px;max-width:92px;height:40px;min-height:40px;padding:0 26px 0 9px;border:1px solid #cbd5e1;border-radius:10px;background:#f8fafc;color:#334155;font-size:10.5px;font-weight:750;cursor:pointer;box-shadow:none}.quick-api-row{display:grid;grid-template-columns:minmax(130px,.8fr) minmax(130px,1fr);gap:6px;align-items:center;margin-top:6px}.quick-api-row select,.quick-api-row input{min-height:34px;height:34px;border:1px solid #cbd5e1;border-radius:9px;background:#fff;color:#334155;padding:0 8px;font-size:10.5px;min-width:0}.analysis-choice-note{display:none}.fallback-actions{display:flex;gap:5px;flex-wrap:wrap;margin-top:6px}.fallback-actions button{border:1px solid #cbd5e1;border-radius:8px;background:#fff;color:#334155;padding:6px 8px;font-size:9.5px;font-weight:800;cursor:pointer}.manual-paste{margin-top:7px;padding:8px;border:1px solid #cbd5e1;border-radius:10px;background:#fff}.manual-paste-head{display:flex;justify-content:space-between;align-items:center;font-size:10.5px;color:#334155}.manual-paste-head button{border:0;background:transparent;font-size:18px;cursor:pointer}.manual-paste textarea{width:100%;min-height:120px;margin-top:6px;border:1px solid #d5dee8;border-radius:8px;padding:7px;font:10px/1.4 ui-monospace,SFMono-Regular,Consolas,monospace}.manual-paste-actions{display:flex;justify-content:flex-end;margin-top:6px}.manual-paste-actions button{border:0;border-radius:8px;background:#0f766e;color:#fff;padding:7px 10px;font-size:9.5px;font-weight:850;cursor:pointer}.mode-select:hover{border-color:#94a3b8;background:#fff}.mode-select:disabled{opacity:.65;cursor:not-allowed}.ai-info{margin-top:7px;border:1px solid #d7e2ec;border-radius:10px;background:#f8fbfd;overflow:hidden}.ai-info.pending{border-color:#d7e2ec}.ai-info.ok{border-color:#c9e5d5;background:#f5fbf7}.ai-info.warn{border-color:#f0d59a;background:#fffaf0}.ai-info-summary{display:flex;align-items:center;justify-content:space-between;gap:8px;padding:8px 9px;list-style:none;font-size:10.5px;font-weight:800;color:#475569}.ai-info-summary::-webkit-details-marker{display:none}.ai-info-title{min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.ai-info-chevron{flex:0 0 auto;color:#64748b;font-size:12px;transition:transform .16s ease}.ai-info[open] .ai-info-chevron{transform:rotate(180deg)}.ai-info-body{padding:0 8px 8px}.ai-info-stats{font-size:10px;font-weight:700;line-height:1.45;color:#475569;padding:6px 7px;margin-bottom:5px;background:rgba(255,255,255,.68);border-radius:7px}.ai-info .analysis-meta{margin:0 0 6px;padding:5px 7px;font-size:9.5px;line-height:1.4;background:#edf3f8;color:#64748b;border-radius:7px}.ai-info .input-audit-files{margin-top:0;max-height:145px}.analysis{padding:10px 11px}.review{font-size:12px}.reason{font-size:14px;line-height:1.62;color:#425466}.summary-label{font-size:14px;color:#1f3f66}.chips{display:none!important}.progress-details{margin-top:12px;margin-bottom:2px;background:#fafbfd}.progress-details summary{color:#64748b}.message{padding:7px 9px}.section{margin-top:9px}
        /* v0.30 · giao diện dùng chung: rõ vai trò, ít nhiễu, ưu tiên thao tác chính */
        .card{width:438px;height:720px;min-width:370px;background:#f7f9fc;border:1px solid #d8e2ec;border-radius:18px;box-shadow:0 20px 60px rgba(15,42,68,.24),0 2px 8px rgba(15,42,68,.08)}
        .header{min-height:48px;padding:8px 10px 8px 12px;background:linear-gradient(135deg,#0b5cab 0%,#087d77 100%);border-bottom:1px solid rgba(255,255,255,.18)}
        .title{display:flex;align-items:center;gap:6px;min-width:0;font-size:14px;font-weight:900;letter-spacing:-.15px}.version{display:inline-flex;align-items:center;justify-content:center;padding:3px 8px;border-radius:999px;background:#fff;color:#0b5cab;border:1px solid rgba(255,255,255,.9);box-shadow:0 2px 8px rgba(0,0,0,.14);font-size:10.5px;font-weight:950;line-height:1.2}.workflow-badge{max-width:124px;overflow:hidden;text-overflow:ellipsis}
        .header-role{width:98px!important;border-radius:9px!important}.body{padding:11px 12px 13px;background:linear-gradient(180deg,#f8fbfd,#f7f9fc);scrollbar-width:thin;scrollbar-color:#cbd5e1 transparent}
        .meta{background:#fff;border-color:#dce5ed;border-radius:12px;box-shadow:0 2px 8px rgba(15,42,68,.045)}.doc{font-weight:650;color:#1f3348}.sender-line{color:#65778a}
        .hero-actions{top:-11px;margin:8px -2px 0;padding:7px 2px 6px;background:rgba(247,249,252,.94);backdrop-filter:blur(8px);z-index:4}.primary-btn,.apply-only-btn,.mode-select,.stop-btn,.reanalyze{border-radius:11px;min-height:42px}.primary-btn{font-weight:850;letter-spacing:.05px}.mode-select{width:92px;min-width:92px;max-width:92px;background:#fff}
        
        .main-role-section{border-radius:12px}.role-box,select,textarea{border-radius:10px}.analysis,.ai-info,.progress-details,.mode-result{border-radius:12px}.analysis{background:#fff;border-color:#dbe7f2;box-shadow:0 3px 12px rgba(32,79,120,.045)}
        .message{position:sticky;bottom:-2px;z-index:5;margin:9px -1px 0;padding:8px 10px;border-radius:10px;box-shadow:0 5px 16px rgba(15,42,68,.08);backdrop-filter:blur(7px)}.message.info{background:rgba(238,245,255,.96)}.message.success{background:rgba(234,248,240,.97)}.message.error{background:rgba(255,240,240,.97)}
        details>summary{border-radius:10px}.fallback-actions button{min-height:32px}.picker{border-radius:18px}.picker-panel{border-radius:16px 16px 0 0}.tiny-btn{min-height:30px}
        @media(max-width:520px){.card{width:min(438px,calc(100vw - 12px));height:min(720px,calc(100vh - 12px));min-width:330px}.mode-select{width:122px;min-width:122px;max-width:122px}.workflow-badge{display:none}}
        /* v0.65 · API-first compact action row */
        .ai-control>.hero-actions{position:static!important;top:auto!important;margin:0!important;padding:0!important;background:transparent!important;backdrop-filter:none!important;z-index:auto!important;display:flex!important;flex:1 1 auto!important;gap:5px!important;min-width:0!important}
        .ai-control>.hero-actions .apply-only-btn{min-height:36px!important;height:36px!important;padding:0 7px!important;font-size:9.7px!important}
        .ai-control>.hero-actions .primary-btn{min-height:36px!important;height:36px!important;padding:0 8px!important;font-size:10px!important}
        .ai-control .mode-select{width:92px!important;min-width:92px!important;max-width:92px!important;height:36px!important;min-height:36px!important;padding-left:7px!important;padding-right:22px!important}
        .ai-control .stop-btn,.ai-control .reanalyze{display:none!important}
      .progress-details>summary{display:flex;align-items:center;gap:7px;cursor:pointer}.progress-summary-label{flex:1;min-width:0}.progress-copy-actions{display:inline-flex;gap:4px;margin-left:auto}.progress-copy-actions button{border:1px solid #c9d8e8;background:#fff;color:#285d8e;border-radius:6px;padding:3px 6px;font-size:8.8px;font-weight:800;cursor:pointer}.progress-copy-actions button:hover{background:#eef6ff}.progress-details>summary::marker{color:#64748b}
        /* v2.2.2 · thanh tiêu đề theo thiết kế blue-teal premium */
        .card{border-radius:20px;border-color:#d7e5ea;box-shadow:0 22px 60px rgba(21,63,91,.23),0 3px 10px rgba(21,63,91,.08)}
        .header{min-height:58px;padding:10px 12px 10px 14px;gap:8px;background:radial-gradient(130px 52px at 52% 118%,rgba(255,255,255,.12),transparent 72%),radial-gradient(220px 86px at 92% -20%,rgba(72,255,226,.18),transparent 70%),linear-gradient(118deg,#075ed2 0%,#067eb6 45%,#08a98f 100%);border-bottom:1px solid rgba(255,255,255,.24);border-radius:19px 19px 0 0;box-shadow:inset 0 1px 0 rgba(255,255,255,.32);overflow:visible}
        .title{flex:1 1 150px;gap:7px;overflow:visible!important;font-size:13.5px!important;font-weight:900!important;letter-spacing:-.12px;white-space:nowrap;text-shadow:0 1px 2px rgba(0,38,82,.18)}
        .header .version{display:inline-flex!important;align-items:center;justify-content:center;min-height:25px;padding:3px 9px!important;border:1px solid rgba(255,255,255,.9)!important;border-radius:999px;background:linear-gradient(180deg,#eef8ff,#d7edff)!important;color:#0759b7!important;box-shadow:0 3px 10px rgba(1,55,116,.16),inset 0 1px 0 #fff;font-size:10px!important;font-weight:950!important;text-shadow:none;opacity:1!important}
        .workflow-badge{display:inline-flex;align-items:center;min-height:30px;max-width:128px;margin-left:2px;padding:5px 10px;border:1px solid rgba(218,255,249,.82);border-radius:10px;background:linear-gradient(180deg,rgba(239,255,252,.98),rgba(219,249,244,.96));color:#126b67;box-shadow:0 3px 10px rgba(1,72,86,.10);font-size:9px;font-weight:950;letter-spacing:.035em;text-shadow:none}
        .head-actions{gap:6px}
        .header-main-action{height:36px;max-width:126px;padding:0 13px;border:1px solid rgba(255,255,255,.92);border-radius:12px;background:linear-gradient(180deg,#fff,#f4fbff);color:#0864bd;box-shadow:0 5px 14px rgba(0,60,112,.18),inset 0 1px 0 #fff;font-size:10.5px;font-weight:950;transition:transform .14s ease,box-shadow .14s ease,background .14s ease}
        .header-main-action:hover{background:#fff;transform:translateY(-1px);box-shadow:0 7px 17px rgba(0,60,112,.23)}
        .mode-toggle,.icon-btn,.header-stop{width:36px;height:36px;min-width:36px;min-height:36px;flex:0 0 36px;border-radius:12px;border:1px solid rgba(255,255,255,.28);background:linear-gradient(180deg,rgba(255,255,255,.17),rgba(255,255,255,.10));box-shadow:inset 0 1px 0 rgba(255,255,255,.18),0 3px 9px rgba(0,63,92,.12);font-size:15px;transition:transform .14s ease,background .14s ease,border-color .14s ease}
        .mode-toggle:hover,.icon-btn:hover{background:rgba(255,255,255,.23);border-color:rgba(255,255,255,.45);transform:translateY(-1px)}
        .mode-toggle.active{background:#fff;color:#0a7775;border-color:#fff;box-shadow:0 4px 12px rgba(0,70,92,.18)}
        .header-stop{background:linear-gradient(180deg,#e84b4b,#c92828);border-color:#ffb8b8;color:#fff}
        .header-status{margin-top:0;border-radius:10px;box-shadow:0 5px 16px rgba(4,55,91,.14)}
        .card.collapsed{background:transparent!important;border:0!important;box-shadow:none!important;overflow:visible!important}
        .card.collapsed .header{min-height:58px;border:1px solid rgba(255,255,255,.82);border-radius:20px;box-shadow:0 13px 32px rgba(5,66,108,.25),0 2px 8px rgba(5,66,108,.13),inset 0 1px 0 rgba(255,255,255,.38)}
        .card.collapsed .workflow-badge{display:none!important}
        .analysis .reason{display:block;margin-top:8px;padding:10px 11px;border:1px solid #e2eaf1;border-radius:10px;background:#fbfdff;color:#334155;font-size:13.5px;font-weight:400!important;line-height:1.62;white-space:pre-wrap}
        .analysis .summary-label{display:block;margin:0 0 6px;color:#31516f;font-size:10px;font-weight:900;letter-spacing:.065em;text-transform:uppercase}
        .analysis .summary-label+span{font-weight:400!important}
        @media(max-width:520px){.header{padding-left:11px;padding-right:10px}.title{font-size:13px!important;gap:5px}.header .version{padding:3px 7px!important}.head-actions{gap:4px}.header-main-action{padding:0 10px;max-width:112px}.mode-toggle,.icon-btn,.header-stop{width:34px;height:34px;min-width:34px;min-height:34px;flex-basis:34px}}
      </style>
      <div class="card">
        <div class="header" id="dragHeader" role="button" tabindex="0" aria-expanded="true" title="Bấm để thu gọn Trợ lý phân luồng văn bản · kéo để di chuyển">
          <div class="title">✨ iOffice AI - Ea Ly <span class="version">v${VERSION}</span><span class="workflow-badge" id="workflowBadge">VĂN BẢN ĐẾN</span><button class="outgoing-match-chip hidden" id="outgoingMatchChip" type="button" title="Đối chiếu Sổ theo dõi"></button></div>
          <div class="head-actions"><button class="header-main-action" id="headerActionBtn" type="button">✨ Phân tích AI</button><button class="header-stop hidden" id="headerStopBtn" type="button" title="Dừng xử lý">■</button><button class="mode-toggle" id="modeToggleBtn" type="button" title="Mở Sổ theo dõi" aria-label="Mở Sổ theo dõi" aria-pressed="false">📒</button><button class="icon-btn" id="pinBtn" title="Ghim vị trí tiện ích" aria-label="Ghim vị trí" aria-pressed="false">📌</button><button class="icon-btn" id="settings" title="Cài đặt" aria-label="Cài đặt">⚙</button></div>
          <div class="header-status hidden" id="headerStatus" role="status" aria-live="polite"></div>
          <div class="outgoing-match-popover hidden" id="outgoingMatchPopover"></div>
        </div>
        <div class="body" id="body">
          <div id="documentMode">
          <div class="meta">
            <div class="doc"><b>Trích yếu:</b> <span id="docTitle">Chưa mở văn bản</span></div>
            <div class="sender-line"><span id="sender">—</span><span class="sender-sep">·</span><span id="docMeta"></span></div>
          </div>
          <div class="message info" id="message" role="status" aria-live="polite">Sẵn sàng. Có thể phân tích AI hoặc phân luồng thủ công.</div>
          <div class="ai-info-wrap"><details class="ai-info pending" id="inputAudit"><summary class="ai-info-summary"><span class="ai-info-title" id="inputAuditText">Model: gemini-3.5-flash-lite · Rule: —</span><span class="ai-info-chevron">⌄</span></summary><div class="ai-info-body"><div class="ai-info-stats" id="inputAuditDetail">Bấm mở để xem chi tiết tài liệu AI sử dụng.</div><div class="input-audit-files" id="inputAuditFiles"></div></div></details><button class="read-all-btn hidden" id="readAllBtn" type="button">Đọc thêm</button></div>
          <div class="ai-control"><div class="ai-tools" id="aiTools"><select class="mode-select" id="modeSelect" aria-label="Cách phân tích" title="Chọn cách phân tích"><option value="api">API</option><option value="gemini-web">Gemini Web</option><option value="chatgpt-web">ChatGPT Web</option></select><button class="ai-analyze-btn body-analyze-btn" id="aiAnalyzeBtn" type="button">✨ Phân tích AI</button><button class="stop-btn hidden" id="stopBtn" title="Dừng tiến trình hiện tại">Dừng</button><button class="reanalyze hidden" id="reanalyzeBtn" title="Phân tích lại bằng nhà cung cấp đang chọn">↻</button></div><div class="hero-actions"><button class="apply-only-btn" id="applyOnlyBtn">Áp dụng</button><button class="primary-btn apply-state" id="suggestBtn">Áp dụng &amp; Chuyển</button></div></div><div class="quick-api-row hidden" id="quickApiRow"></div><div class="manual-paste hidden" id="manualPastePanel"></div>
          <div class="analysis hidden" id="analysisPanel">
            <div class="review warn" id="review">Chưa phân tích</div><div class="reason"><b class="summary-label">TÓM TẮT VĂN BẢN</b><span id="reason"></span></div><div class="chips hidden" id="signalList"></div>
          </div>
          <div class="mode-result hidden" id="modeResult"></div>
          <div class="section main-role-section" id="mainRoleSection"><div class="section-head"><span class="label">1. Xử lý chính</span><div class="confidence-meter" title="Độ tin cậy của đề xuất xử lý chính"><div class="confidence-track"><div class="confidence-fill" id="confidenceFill"></div></div><span class="confidence-value" id="confidenceValue">—</span></div></div><select id="mainSelect" aria-label="Đơn vị xử lý chính"></select></div>
          <div class="section" id="coordSection"><div class="section-head"><span class="label">2. Phối hợp</span><span class="hint">nhiều đơn vị</span></div><div class="role-box"><div class="selected-chips" id="coordChips"></div><button class="add-role" id="addCoord">＋ Thêm</button></div><div class="hidden-store" id="coordBox"></div></div>
          <div class="section" id="viewSection"><div class="section-head"><span class="label">3. Xem để biết cá nhân</span></div><div class="role-box watcher-role-box"><div class="selected-chips" id="viewPersonChips"></div><button class="add-role" id="addViewPerson">＋ Người</button><button class="watch-lock" id="viewWatcherLock" type="button" title="Khóa danh sách cá nhân đang chọn làm mặc định">🔓</button></div><div class="hidden-store" id="viewBox"></div><div class="hidden-store" id="viewChips"></div><button class="hidden-store" id="addView" type="button"></button></div>
          <div class="section instruction-section" id="instructionSection"><div class="section-head"><span class="label" id="instructionLabel">Dự thảo ý kiến chỉ đạo</span></div><textarea id="instruction" aria-label="Dự thảo ý kiến chỉ đạo" placeholder="Ví dụ: Giao Phòng Kinh tế rà soát, tổng hợp và báo cáo; hoàn thành trước 05/10/2026."></textarea><div class="deadline-card hidden" id="deadlineCard"></div></div>
          <details class="progress-details" id="progressDetails"><summary id="progressSummary"><span class="progress-summary-label">Tiến trình xử lý</span><span class="progress-copy-actions"><button type="button" id="copyAiSent" title="Copy đúng dữ liệu/prompt đã gửi AI">Copy gửi AI</button><button type="button" id="copyAiReceived" title="Copy dữ liệu thô nhận từ AI">Copy nhận AI</button></span></summary><div class="source" id="source"><div class="progress-empty">Chưa chạy phân tích.</div></div></details>
          <div class="tracker-match hidden" id="trackerMatch"></div>
          </div>
          <div class="tracker-board hidden" id="trackerBoard"></div>
        </div>
        <div class="picker hidden" id="picker"><div class="picker-panel"><div class="picker-head"><b id="pickerTitle">Chọn đơn vị</b><button class="picker-close" id="pickerClose">×</button></div><input class="picker-search" id="pickerSearch" placeholder="Tìm tên đơn vị hoặc mã…"><div class="picker-list" id="pickerList"></div></div></div>
      </div>`;

    state.refs = {
      card: shadow.querySelector('.card'), body: shadow.getElementById('body'), documentMode: shadow.getElementById('documentMode'), trackerBoard: shadow.getElementById('trackerBoard'), trackerMatch: shadow.getElementById('trackerMatch'), outgoingMatchChip: shadow.getElementById('outgoingMatchChip'), outgoingMatchPopover: shadow.getElementById('outgoingMatchPopover'), docTitle: shadow.getElementById('docTitle'), sender: shadow.getElementById('sender'), docMeta: shadow.getElementById('docMeta'), modeToggleBtn: shadow.getElementById('modeToggleBtn'), workflowBadge: shadow.getElementById('workflowBadge'), headerActionBtn: shadow.getElementById('headerActionBtn'), headerStopBtn: shadow.getElementById('headerStopBtn'), headerStatus: shadow.getElementById('headerStatus'), pinBtn: shadow.getElementById('pinBtn'),
      suggestBtn: shadow.getElementById('suggestBtn'), applyOnlyBtn: shadow.getElementById('applyOnlyBtn'), aiToggle: shadow.getElementById('aiToggle'), aiTools: shadow.getElementById('aiTools'), aiAnalyzeBtn: shadow.getElementById('aiAnalyzeBtn'), ruleBtn: shadow.getElementById('ruleBtn'), stopBtn: shadow.getElementById('stopBtn'), reanalyzeBtn: shadow.getElementById('reanalyzeBtn'), quickApiRow: shadow.getElementById('quickApiRow'), quickApiProvider: shadow.getElementById('quickApiProvider'), quickApiModel: shadow.getElementById('quickApiModel'), copyPromptBtn: shadow.getElementById('copyPromptBtn'), pasteResultBtn: shadow.getElementById('pasteResultBtn'), manualPastePanel: shadow.getElementById('manualPastePanel'), manualPasteText: shadow.getElementById('manualPasteText'), manualPasteApply: shadow.getElementById('manualPasteApply'), manualPasteClose: shadow.getElementById('manualPasteClose'), source: shadow.getElementById('source'),
      progressDetails: shadow.getElementById('progressDetails'), progressSummary: shadow.getElementById('progressSummary'), copyAiSent: shadow.getElementById('copyAiSent'), copyAiReceived: shadow.getElementById('copyAiReceived'),
      mainSelect: shadow.getElementById('mainSelect'), coordBox: shadow.getElementById('coordBox'), viewBox: shadow.getElementById('viewBox'),
      coordChips: shadow.getElementById('coordChips'), viewChips: shadow.getElementById('viewChips'), viewPersonChips: shadow.getElementById('viewPersonChips'), viewWatcherLock: shadow.getElementById('viewWatcherLock'), instruction: shadow.getElementById('instruction'),
      analysisPanel: shadow.getElementById('analysisPanel'), analysisMeta: shadow.getElementById('analysisMeta'), analysisTitle: shadow.getElementById('analysisTitle'), analysisRouting: shadow.getElementById('analysisRouting'), review: shadow.getElementById('review'),
      confidenceValue: shadow.getElementById('confidenceValue'), confidenceFill: shadow.getElementById('confidenceFill'), mainRoleSection: shadow.getElementById('mainRoleSection'), coordSection: shadow.getElementById('coordSection'), viewSection: shadow.getElementById('viewSection'), instructionSection: shadow.getElementById('instructionSection'), instructionLabel: shadow.getElementById('instructionLabel'), deadlineCard: shadow.getElementById('deadlineCard'), modeResult: shadow.getElementById('modeResult'),
      reason: shadow.getElementById('reason'), signalList: shadow.getElementById('signalList'), message: shadow.getElementById('message'),
      picker: shadow.getElementById('picker'), pickerTitle: shadow.getElementById('pickerTitle'), pickerSearch: shadow.getElementById('pickerSearch'), pickerList: shadow.getElementById('pickerList'),
      modeSelect: shadow.getElementById('modeSelect'), fallbackActions: shadow.getElementById('fallbackActions'),
      inputAudit: shadow.getElementById('inputAudit'), aiInfoDetails: shadow.getElementById('inputAudit'), aiInfoSummary: shadow.getElementById('inputAuditText'), inputAuditText: shadow.getElementById('inputAuditText'), inputAuditDetail: shadow.getElementById('inputAuditDetail'), inputAuditFiles: shadow.getElementById('inputAuditFiles'), readAllBtn: shadow.getElementById('readAllBtn')
    };

    globalThis.IOfficeTrackerBoard?.init?.({
      root:shadow,
      container:state.refs.trackerBoard,
      matchContainer:state.refs.trackerMatch,
      headerChip:state.refs.outgoingMatchChip,
      headerPopover:state.refs.outgoingMatchPopover,
      getRole:()=>state.userRole,
      getContext:()=>state.lastContext || extractDocumentContext(),
      getTrackerConfigured:()=>state.trackerConfigured === true,
      getTrackerStatus:()=>({connected:state.trackerConnected,version:state.trackerVersion,text:state.trackerStatusText,taskCount:state.trackerTaskCount}),
      getPreparedText:()=>state.lastPrep?.combinedText || '',
      getUnits:()=>((state.rules?.units || []).filter(u=>u.id!=='U100').map(u=>({value:u.id,name:shortUnitName(u.id,u.name)}))),
      notify:(text,kind='info')=>setMessage(text,kind),
      openTracker:()=>void switchAssistantMode('tracker')
    });

    renderInputAudit(null);
    shadow.getElementById('settings').addEventListener('click', () => { void safeRuntimeSend({ type: 'OPEN_OPTIONS' }, { quiet:true }); });
    shadow.getElementById('suggestBtn').addEventListener('click', () => void handlePrimaryAction());
    state.refs.applyOnlyBtn?.addEventListener('click', () => void applyCurrentSuggestion(false));
    state.refs.aiAnalyzeBtn?.addEventListener('click', () => void runSelectedAnalysis());
    state.refs.headerActionBtn?.addEventListener('click', (e) => { e.stopPropagation(); void runSelectedAnalysis(); });
    state.refs.headerStopBtn?.addEventListener('click', (e) => { e.stopPropagation(); void stopCurrentAnalysis(); });
    state.refs.pinBtn?.addEventListener('click', (e) => { e.stopPropagation(); setWidgetPinned(!state.widgetPinned, true); });
    state.refs.ruleBtn?.addEventListener('click', () => void runSelectedAnalysis());
    state.refs.reanalyzeBtn.addEventListener('click', rerunLastAnalysis);
    state.refs.stopBtn?.addEventListener('click', stopCurrentAnalysis);
    state.refs.modeSelect?.addEventListener('change', (e) => setAnalysisMode(e.target.value, true));
    state.refs.quickApiProvider?.addEventListener('change', async (e) => {
      state.quickApiProvider = normalizeText(e.target.value);
      const cfg = await safeStorageGet({providerConfigs:{},providerOrder:[]});
      state.quickApiModel = normalizeText(cfg.providerConfigs?.[state.quickApiProvider]?.model || '');
      if(state.refs.quickApiModel) state.refs.quickApiModel.value = state.quickApiModel;
      const order=[state.quickApiProvider,...(Array.isArray(cfg.providerOrder)?cfg.providerOrder:[]).filter(x=>x!==state.quickApiProvider)];
      await safeStorageSet({providerOrder:order});
    });
    state.refs.quickApiModel?.addEventListener('change', async (e) => {
      state.quickApiModel = normalizeText(e.target.value);
      if(!state.quickApiProvider) return;
      const cfg=await safeStorageGet({providerConfigs:{}});
      const providerConfigs={...(cfg.providerConfigs||{})};
      providerConfigs[state.quickApiProvider]={...(providerConfigs[state.quickApiProvider]||{}),model:state.quickApiModel};
      await safeStorageSet({providerConfigs});
    });
    state.refs.copyPromptBtn?.addEventListener('click',()=>void copyPromptForManual());
    state.refs.pasteResultBtn?.addEventListener('click',openManualPaste);
    state.refs.manualPasteClose?.addEventListener('click',closeManualPaste);
    state.refs.manualPasteApply?.addEventListener('click',applyManualPastedResult);
    state.refs.modeToggleBtn?.addEventListener('click',()=>void switchAssistantMode(state.userRole==='tracker'?'leader':'tracker'));
    state.refs.readAllBtn?.addEventListener('click', async () => {
      if (state.busy || currentWorkflow()==='tracker') return;
      const recommended=state.refs.readAllBtn?.classList.contains('recommended');
      state.forceTaskSupportOnce = false;
      state.forceReadAllOnce = true;
      state.lastPrep = null; state.prepKey = ''; state.workflowPhase = 'analyze'; state.lastSuggestion = null; state.analyzedKey = ''; state.trackerAttachmentReady = null;
      setMessage(recommended
        ? 'Đang đọc toàn bộ tệp còn lại để xác minh nhiệm vụ/hạn…'
        : 'Đang đọc toàn bộ tệp cho lần phân tích này…', 'info');
      await runSelectedAnalysis();
    });
    shadow.getElementById('addCoord').addEventListener('click', () => void openRolePicker('coord'));
    shadow.getElementById('addView').addEventListener('click', () => void openRolePicker('view'));
    shadow.getElementById('addViewPerson')?.addEventListener('click', () => void openRolePicker('watchers'));
    state.refs.viewWatcherLock?.addEventListener('click', () => void toggleLeaderWatcherLock());
    shadow.addEventListener('keydown',e=>{if(e.key==='Escape')closeRolePicker();});
    shadow.getElementById('pickerClose').addEventListener('click', closeRolePicker);
    state.refs.picker.addEventListener('click', (e) => { if (e.target === state.refs.picker) closeRolePicker(); });
    state.refs.pickerSearch.addEventListener('input', renderPickerList);
    state.refs.mainSelect.addEventListener('change', () => { syncExclusiveRoles(); renderRoleChips(); updateTrackerInlineOwner(); });
    state.refs.instruction?.addEventListener('input', autoSizeInstruction);
    requestAnimationFrame(autoSizeInstruction);

    state.refs.copyAiSent?.addEventListener('click',e=>{e.preventDefault();e.stopPropagation();void copyTextToClipboard(state.lastAiSentText,'dữ liệu gửi AI');});
    state.refs.copyAiReceived?.addEventListener('click',e=>{e.preventDefault();e.stopPropagation();void copyTextToClipboard(state.lastAiReceivedText,'dữ liệu nhận AI');});

    const header = shadow.getElementById('dragHeader');
    const toggleFromHeader = () => { if (state.busy) return; setWidgetCollapsed(!state.refs.card.classList.contains('collapsed'), true); };
    enableDragging(host, header, toggleFromHeader);
    header.addEventListener('keydown', (e) => {
      if ((e.key === 'Enter' || e.key === ' ') && !e.target.closest('button')) {
        e.preventDefault();
        toggleFromHeader();
      }
    });
    safeStorageGet({ widgetSize: null, widgetCollapsed: false, widgetPinned: false }).then(({ widgetSize, widgetCollapsed, widgetPinned }) => {
      setWidgetPinned(widgetPinned === true, false);
      if (widgetSize && state.refs.card) {
        const w = clamp(widgetSize.width, 330, Math.min(760, window.innerWidth - 20));
        const h = clamp(widgetSize.height, 360, window.innerHeight - 20);
        state.refs.card.style.width = `${w}px`;
        state.refs.card.style.height = `${h}px`;
      }
      setWidgetCollapsed(widgetCollapsed === true, false);
      host.style.visibility = 'visible';
    }).catch(() => { setWidgetPinned(false, false); setWidgetCollapsed(false, false); host.style.visibility = 'visible'; });
    if (window.ResizeObserver && state.refs.card) {
      let sizeTimer = null;
      const ro = new ResizeObserver(() => {
        if (state.refs.card.classList.contains('collapsed')) return;
        clearTimeout(sizeTimer);
        sizeTimer = setTimeout(() => {
          if (!chromeContextAlive()) { try { ro.disconnect(); } catch (_) {} return; }
          if (!state.refs.card?.isConnected) return;
          const rect = state.refs.card.getBoundingClientRect();
          void safeStorageSet({ widgetSize: { width: Math.round(rect.width), height: Math.round(rect.height) } });
        }, 250);
      });
      ro.observe(state.refs.card);
    }
    safeStorageGet({ aiAnalysisEnabled:true, analysisMode: 'api', fallbackAnalysisMode:'none', userRole: 'leader', trackerApiUrl:'', trackerToken:'', instructionPrefixEnabled:false, instructionPrefixText:'VP đề xuất:', leaderDefaultWatcherIds:[], leaderDefaultWatcherTargets:[], leaderDefaultViewUnitIds:[], leaderWatchersLocked:null, providerOrder:['gemini-openai'], providerConfigs:{}, aiRulePack:null }).then((cfg) => {
      state.aiEnabled = true;
      state.analysisMode = normalizeAnalysisMode(cfg.analysisMode);
      state.activeRulePack = globalThis.IOfficeRulePack?.resolvePack(cfg.aiRulePack);
      state.fallbackAnalysisMode = 'none';
      state.userRole = 'leader';
      state.instructionPrefixEnabled = cfg.instructionPrefixEnabled === true;
      state.instructionPrefixText = typeof cfg.instructionPrefixText === 'string' ? cfg.instructionPrefixText : 'VP đề xuất:';
      state.leaderDefaultWatcherIds = Array.isArray(cfg.leaderDefaultWatcherIds) ? cfg.leaderDefaultWatcherIds.map(normalizeText).filter(Boolean) : [];
      state.leaderDefaultWatcherTargets = Array.isArray(cfg.leaderDefaultWatcherTargets) ? cfg.leaderDefaultWatcherTargets : [];
      state.leaderDefaultViewUnitIds = Array.isArray(cfg.leaderDefaultViewUnitIds) ? cfg.leaderDefaultViewUnitIds.map(normalizeText).filter(Boolean) : [];
      state.leaderWatchersLocked = cfg.leaderWatchersLocked === true || (cfg.leaderWatchersLocked == null && state.leaderDefaultWatcherTargets.length > 0);
      state.currentLeaderWatchers = state.leaderWatchersLocked ? normalizedWatcherTargets(state.leaderDefaultWatcherTargets) : [];
      renderLeaderWatcherChips();
      state.quickApiProvider = (Array.isArray(cfg.providerOrder) && cfg.providerOrder.find(x=>x && x!=='none')) || 'gemini-openai';
      state.quickApiModel = normalizeText(cfg.providerConfigs?.[state.quickApiProvider]?.model || '');
      if(state.refs.quickApiProvider) state.refs.quickApiProvider.value = state.quickApiProvider;
      if(state.refs.quickApiModel) state.refs.quickApiModel.value = state.quickApiModel;
      state.trackerConfigured = Boolean(normalizeText(cfg.trackerApiUrl) && normalizeText(cfg.trackerToken));
      void refreshTrackerConnectionStatus();
      updateAnalysisModeUi(); updateAiToggleUi({quiet:true}); setWorkflowUi(); updateDetection();
    }).catch(() => { updateAnalysisModeUi(); setWorkflowUi(); updateDetection(); });
    refreshUnitOptions(true);
    updateDetection();
  }

  async function init() {
    const { iofficeAssistantEnabled = true } = await safeStorageGet({ iofficeAssistantEnabled: true });
    if (iofficeAssistantEnabled === false) return;
    await loadRules();
    if (chromeContextAlive()) {
      try { chrome.runtime.onMessage.addListener((message) => {
        if (message?.type === 'IOFFICE_WEB_AI_JOB_EVENT') {
          handleWebJobEvent(message);
          return false;
        }
      }); } catch (error) { markExtensionContextInvalid(error); }
    }
    createWidget();
    if (chromeContextAlive()) {
      try { chrome.storage.onChanged.addListener((changes, areaName) => {
        if (areaName === 'local' && changes.analysisMode?.newValue) setAnalysisMode(changes.analysisMode.newValue, false);
        if (areaName === 'local' && changes.aiRulePack) { state.activeRulePack=globalThis.IOfficeRulePack?.resolvePack(changes.aiRulePack.newValue); renderAiInfoSummary(); }
        if (areaName === 'local' && changes.instructionPrefixEnabled) {
          state.instructionPrefixEnabled = changes.instructionPrefixEnabled.newValue === true;
          if (currentWorkflow() === 'leader-incoming' && state.refs.instruction) { state.refs.instruction.value = applyInstructionPrefix(state.refs.instruction.value); autoSizeInstruction(); }
        }
        if (areaName === 'local' && changes.instructionPrefixText) {
          state.instructionPrefixText = typeof changes.instructionPrefixText.newValue === 'string' ? changes.instructionPrefixText.newValue : 'VP đề xuất:';
          if (currentWorkflow() === 'leader-incoming' && state.refs.instruction) { state.refs.instruction.value = applyInstructionPrefix(state.refs.instruction.value); autoSizeInstruction(); }
        }
        if (areaName === 'local' && changes.leaderDefaultWatcherIds) { state.leaderDefaultWatcherIds = Array.isArray(changes.leaderDefaultWatcherIds.newValue) ? changes.leaderDefaultWatcherIds.newValue.map(normalizeText).filter(Boolean) : []; }
        if (areaName === 'local' && changes.leaderDefaultViewUnitIds) { state.leaderDefaultViewUnitIds = Array.isArray(changes.leaderDefaultViewUnitIds.newValue) ? changes.leaderDefaultViewUnitIds.newValue.map(normalizeText).filter(Boolean) : []; }
        if (areaName === 'local' && changes.leaderDefaultWatcherTargets) { state.leaderDefaultWatcherTargets = Array.isArray(changes.leaderDefaultWatcherTargets.newValue) ? changes.leaderDefaultWatcherTargets.newValue : []; if(state.leaderWatchersLocked){state.currentLeaderWatchers=normalizedWatcherTargets(state.leaderDefaultWatcherTargets);renderLeaderWatcherChips();} }
        if (areaName === 'local' && changes.leaderWatchersLocked) { state.leaderWatchersLocked = changes.leaderWatchersLocked.newValue === true; resetLeaderWatchersForDocument(); }
        if (areaName === 'local' && (changes.trackerApiUrl || changes.trackerToken)) { safeStorageGet({trackerApiUrl:'',trackerToken:''}).then(x=>{state.trackerConfigured=Boolean(normalizeText(x.trackerApiUrl)&&normalizeText(x.trackerToken));void refreshTrackerConnectionStatus();renderDeadlineCard(state.lastSuggestion || manualSuggestionFromUi());if(currentWorkflow()==='leader-outgoing') void globalThis.IOfficeTrackerBoard?.matchCurrentOutgoing?.({force:true,auto:true});}); }
        if (areaName === 'local' && changes.routingRulesCustom) {
          loadRules().then(() => { refreshUnitOptions(true); renderRoleChips(); }).catch(() => {});
        }
      }); } catch (error) { markExtensionContextInvalid(error); }
    }
    // v0.19: chỉ quét lại khi dấu hiệu văn bản thật sự thay đổi. Không poll 2,5 giây,
    // không chạy 3 lần sau mỗi click và bỏ qua mọi mutation do chính widget tạo ra.
    let detectionTimer = null;
    let lastQuickKey = '';
    const quickValue = (selectors) => {
      for (const sel of selectors) {
        const el = document.querySelector(sel);
        const value = normalizeText(el?.value || el?.textContent || '');
        if (value) return value.slice(0, 220);
      }
      return '';
    };
    const quickKey = () => [
      location.pathname, location.hash, document.title,
      quickValue(['#idVB','#hide_docid','#txt_idedit']),
      quickValue(['[id$="_vbtitle"]','#txt_trich_yeu','#TRICH_YEU']) || normalizeText(extractHeading().summary).slice(0,220)
    ].join('|');
    const scheduleDetection = (delay = 150, force = false) => {
      clearTimeout(detectionTimer);
      detectionTimer = setTimeout(() => {
        if (document.hidden || state.busy || state.userRole === 'tracker') return;
        const key = quickKey();
        if (!force && key === lastQuickKey) return;
        lastQuickKey = key;
        updateDetection();
      }, delay);
    };
    const ownHost = () => document.getElementById(HOST_ID);
    // v0.41: không dùng MutationObserver toàn trang. iOffice có DOM rất lớn và nút Xử lý
    // tạo nhiều mutation; chỉ cập nhật nhẹ sau thao tác người dùng / đổi URL. Khi bấm Phân tích
    // hoặc Kiểm tra văn bản, runAnalysis() luôn gọi updateDetection() lần cuối nên không dùng dữ liệu cũ.
    document.addEventListener('visibilitychange',()=>{ if(!document.hidden) scheduleDetection(120, true); });
    window.addEventListener('hashchange',()=>scheduleDetection(120, true));
    window.addEventListener('popstate',()=>scheduleDetection(120, true));
    let switchProbeTimers=[];
    const probeAfterNavigation=()=>{
      for(const t of switchProbeTimers) clearTimeout(t);
      switchProbeTimers=[120,520,1250].map(delay=>setTimeout(()=>{
        if(document.hidden || state.userRole==='tracker') return;
        const key=quickKey();
        if(key!==lastQuickKey){lastQuickKey=key;updateDetection();}
      },delay));
    };
    document.addEventListener('click',(ev)=>{
      const host = ownHost();
      const target = ev.target instanceof Element ? ev.target : null;
      if (!target || (host && (target === host || host.contains(target)))) return;
      probeAfterNavigation();
    },true);
  }

  // Theo dõi thay đổi do người dùng nhập trực tiếp trên iOffice.
  // Tự cập nhật sẽ không làm mới trang khi còn dữ liệu chưa gửi.
  const markUpdateDirty = (event) => {
    if (!event?.isTrusted) return;
    const target = event.target instanceof Element ? event.target : null;
    const host = ownHost();
    if (target && host && (target === host || host.contains(target))) return;
    state.updateDirty = true;
  };
  document.addEventListener('input', markUpdateDirty, true);
  document.addEventListener('change', markUpdateDirty, true);

  init();

  chrome.runtime.onMessage.addListener((m, sender, reply) => {
    if(m?.type==='IOFFICE_UPDATE_LOCK') {
      if(state.busy || state.finalizing || state.transferRunning || state.pendingWebJob) { reply({ok:false,reason:'busy'}); return; }
      if(!m.forceDirty && (state.updateDirty || state.pendingAppliedSuggestion)) { reply({ok:false,reason:'dirty'}); return; }
      state.updateLocked=true;
      reply({ok:true});
    }
    if(m?.type==='IOFFICE_UPDATE_UNLOCK') { state.updateLocked=false; reply({ok:true}); }
  });
})();
