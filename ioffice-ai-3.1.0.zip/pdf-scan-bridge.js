/* iOffice AI 3.1.0 · single MAIN-world bridge for PDF scan detection + native iOffice OCR. */
(() => {
  'use strict';
  if (window !== window.top) return;

  const CHANNEL = 'ioffice-scan-bridge-v1';
  const DEFAULT_MAX_BYTES = 10 * 1024 * 1024;
  const jobs = new Map();
  const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
  const clean = (s) => String(s || '').replace(/\u00a0/g, ' ').replace(/[\t\r ]+/g, ' ').replace(/\n{3,}/g, '\n\n').trim();
  const fold = (s) => String(s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim();

  function normToken(value) {
    return String(value || '').trim().replace(/\s+/g, '');
  }

  function tokenVariants(value) {
    const out = new Set();
    const raw = normToken(value);
    if (!raw) return out;
    const add = (v) => {
      const t = normToken(v);
      if (!t) return;
      out.add(t);
      out.add(t.replace(/~+$/g, '=').replace(/=+$/g, ''));
    };
    add(raw);
    try { add(decodeURIComponent(raw)); } catch (_) {}
    try { add(btoa(unescape(encodeURIComponent(raw)))); } catch (_) {}
    try {
      const p = raw.replace(/~/g, '=').replace(/-/g, '+').replace(/_/g, '/');
      const pad = p.length % 4 ? '='.repeat(4 - (p.length % 4)) : '';
      add(decodeURIComponent(escape(atob(p + pad))));
    } catch (_) {}
    return out;
  }

  function tokensEquivalent(a, b) {
    const A = tokenVariants(a), B = tokenVariants(b);
    if (!A.size || !B.size) return false;
    for (const x of A) if (B.has(x)) return true;
    return false;
  }

  function frameUrls(frame) {
    const values = [
      frame?.getAttribute?.('src') || '',
      frame?.getAttribute?.('data-dlk-viewer-src') || '',
      frame?.dataset?.dlkViewerSrc || ''
    ].filter(Boolean);
    const out = [];
    for (const v of values) {
      try {
        const href = new URL(v, location.href).href;
        if (!out.includes(href)) out.push(href);
      } catch (_) {}
    }
    return out;
  }

  function frameViewerTokens(frame) {
    const out = [];
    for (const href of frameUrls(frame)) {
      try {
        const u = new URL(href);
        const t = u.searchParams.get('file') || '';
        if (t && !out.includes(t)) out.push(t);
      } catch (_) {}
    }
    return out;
  }

  function isPdfViewerFrame(frame) {
    try {
      const mode = String(frame?.dataset?.dlkMode || frame?.getAttribute?.('data-dlk-mode') || '').toLowerCase();
      if (mode === 'raw') return false;
      const urls = frameUrls(frame);
      if (urls.some((href) => /\/web\/viewer\.jsp(?:[?#]|$)/i.test(href))) return true;
      if (mode === 'viewer') return true;
      return !!frame?.contentWindow?.PDFViewerApplication;
    } catch (_) { return false; }
  }

  function visibleRank(frame) {
    try {
      const r = frame.getBoundingClientRect();
      const st = getComputedStyle(frame);
      const opacity = Number.parseFloat(st.opacity || '1');
      const visible = r.width > 300 && r.height > 300 && st.display !== 'none' && st.visibility !== 'hidden' && opacity > 0.1 && r.right > 0 && r.bottom > 0;
      if (visible) return 1000000 + Math.min(900000, Math.round(r.width * r.height));
      if (r.width > 20 && r.height > 20) return Math.round(r.width * r.height);
    } catch (_) {}
    return 0;
  }

  function requestHasIdentity(req = {}) {
    return Boolean(String(req.viewerToken||'').trim() || String(req.viewerUrl||'').trim() || String(req.fileId||'').trim() || String(req.fileName||'').trim());
  }

  function strongFrameMatch(frame, req = {}) {
    const expectedToken = String(req.viewerToken || '').trim();
    if (expectedToken && frameViewerTokens(frame).some((t)=>tokensEquivalent(t, expectedToken))) return true;
    if (req.viewerUrl) {
      try {
        const target = new URL(req.viewerUrl, location.href).href;
        if (frameUrls(frame).includes(target)) return true;
      } catch (_) {}
    }
    const params = window.VBParams || {};
    const isVisible = visibleRank(frame) >= 1000000;
    if (isVisible && req.fileId && String(params.file_id || '') === String(req.fileId)) return true;
    if (isVisible && req.fileName && fold(params.file_name || '') === fold(req.fileName || '')) return true;
    return false;
  }

  function scoreFrame(frame, req = {}) {
    let score = visibleRank(frame);
    const expectedToken = String(req.viewerToken || '');
    const expectedFileId = String(req.fileId || '');
    const expectedName = fold(req.fileName || '');
    const params = window.VBParams || {};

    try {
      if (frame.contentWindow?.PDFViewerApplication?.pdfDocument) score += 250000;
    } catch (_) {}

    if (expectedToken) {
      const tokens = frameViewerTokens(frame);
      if (tokens.some((t) => tokensEquivalent(t, expectedToken))) score += 4000000;
    }

    if (expectedFileId && String(params.file_id || '') === expectedFileId) score += 2200000;
    if (expectedName && fold(params.file_name || '') === expectedName) score += 1600000;

    if (req.viewerUrl) {
      try {
        const target = new URL(req.viewerUrl, location.href).href;
        if (frameUrls(frame).includes(target)) score += 3200000;
      } catch (_) {}
    }
    return score;
  }

  function candidateFrames() {
    return [...document.querySelectorAll('iframe')].filter(isPdfViewerFrame);
  }

  async function findViewer(req, check) {
    const until = Date.now() + Math.max(1600, Math.min(12000, Number(req.findTimeoutMs) || 6500));
    const requireStrong = requestHasIdentity(req);
    let best = null, bestScore = -1;
    while (Date.now() < until) {
      check();
      best = null; bestScore = -1;
      for (const frame of candidateFrames()) {
        if (requireStrong && !strongFrameMatch(frame, req)) continue;
        const s = scoreFrame(frame, req);
        if (s > bestScore) { best = frame; bestScore = s; }
      }
      if (best) {
        try {
          if (best.contentWindow?.PDFViewerApplication?.pdfDocument) return best;
        } catch (_) {}
      }
      await sleep(100);
    }
    return best;
  }

  async function waitPdf(frame, check, timeoutMs = 12000) {
    const until = Date.now() + Math.max(1200, Math.min(30000, Number(timeoutMs) || 12000));
    while (Date.now() < until) {
      check();
      try {
        const app = frame?.contentWindow?.PDFViewerApplication;
        if (app?.pdfDocument) return { app, pdf: app.pdfDocument, win: frame.contentWindow };
      } catch (_) {}
      await sleep(90);
    }
    return null;
  }

  function resourcePdfSize(frame) {
    try {
      const cw = frame?.contentWindow;
      const viewerToken = frameViewerTokens(frame)[0] || '';
      const entries = cw?.performance?.getEntriesByType?.('resource') || [];
      for (let i = entries.length - 1; i >= 0; i--) {
        const e = entries[i];
        const name = String(e?.name || '');
        if (!/\/viewfile(?:[?#]|$)/i.test(name)) continue;
        if (viewerToken) {
          try {
            const token = new URL(name).searchParams.get('file') || '';
            if (token && !tokensEquivalent(token, viewerToken)) continue;
          } catch (_) {}
        }
        const size = Math.max(Number(e?.decodedBodySize || 0), Number(e?.encodedBodySize || 0), Number(e?.transferSize || 0));
        if (size > 0) return size;
      }
    } catch (_) {}
    return 0;
  }

  async function pdfProxySize(pdf, frame, check) {
    let size = resourcePdfSize(frame);
    if (size > 0) return size;
    try {
      const candidates = [
        pdf?._transport?._params?.length,
        pdf?._transport?._fullReader?.contentLength,
        pdf?._transport?._networkStream?._fullRequestReader?.contentLength,
        pdf?.loadingTask?._transport?._params?.length
      ].map(Number).filter((n)=>Number.isFinite(n) && n>0);
      if (candidates.length) return Math.max(...candidates);
    } catch (_) {}
    try {
      if (typeof pdf?.getDownloadInfo === 'function') {
        const info = await Promise.race([
          pdf.getDownloadInfo(),
          sleep(260).then(()=>null)
        ]);
        check();
        const n = Number(info?.length || 0);
        if (n > 0) return n;
      }
    } catch (_) {}
    return 0;
  }

  function meaningfulChars(text) {
    try { return (String(text || '').match(/[\p{L}\p{N}]/gu) || []).length; }
    catch (_) { return (String(text || '').match(/[A-Za-z0-9À-ỹ]/g) || []).length; }
  }

  async function pageHasRasterImage(win, page) {
    try {
      const ops = win?.pdfjsLib?.OPS || win?.pdfjsViewer?.OPS || null;
      if (!ops || !page?.getOperatorList) return null;
      const ids = new Set([
        ops.paintImageXObject,
        ops.paintJpegXObject,
        ops.paintInlineImageXObject,
        ops.paintImageMaskXObject,
        ops.paintSolidColorImageMask
      ].filter((x) => Number.isFinite(x)));
      if (!ids.size) return null;
      const list = await page.getOperatorList();
      return (list?.fnArray || []).some((fn) => ids.has(fn));
    } catch (_) { return null; }
  }

  async function inspectPdfFrame(frame, req, check, progress) {
    const ready = await waitPdf(frame, check, req.pdfTimeoutMs || 12000);
    if (!ready) return { status:'unavailable', reason:'PDF.js chưa sẵn sàng.' };
    const { pdf, win } = ready;
    const totalPages = Number(pdf.numPages || 0);
    const maxPages = Math.max(1, Math.min(80, Number(req.maxPages) || 80, totalPages || 1));
    const maxChars = Math.max(500, Math.min(80000, Number(req.maxChars) || 40000));
    const sizeBytes = await pdfProxySize(pdf, frame, check);
    const maxBytes = Math.max(1, Number(req.maxFileBytes) || DEFAULT_MAX_BYTES);
    if (sizeBytes > maxBytes) {
      return { status:'too-large', totalPages, pagesRead:0, sizeBytes, text:'', scanPages:[], textPages:[], blankPages:[], unknownPages:[] };
    }

    const pages = [];
    const scanPages = [], textPages = [], blankPages = [], unknownPages = [];
    let chars = 0;
    const hw = Math.max(2, Number(navigator.hardwareConcurrency || 4));
    const concurrency = hw >= 12 ? 4 : hw >= 6 ? 3 : 2;

    for (let start = 1; start <= maxPages; start += concurrency) {
      check();
      const nums = [];
      for (let n = start; n < Math.min(start + concurrency, maxPages + 1); n++) nums.push(n);
      const batch = await Promise.all(nums.map(async (n) => {
        check();
        const page = await pdf.getPage(n);
        check();
        const tc = await page.getTextContent();
        check();
        const text = clean((tc.items || []).map((x) => x.str || '').join(' '));
        const items = Number(tc.items?.length || 0);
        const meaningful = meaningfulChars(text);
        const textLike = text.length >= 40 || meaningful >= 24 || items >= 8;
        const hasRaster = textLike ? null : await pageHasRasterImage(win, page);
        let kind = 'text';
        if (!textLike) {
          if (hasRaster === false && text.length === 0 && items === 0) kind = 'blank';
          else if (hasRaster === true) kind = 'scan';
          else if (text.length <= 24 && meaningful <= 16 && items <= 4) kind = 'scan';
          else kind = 'unknown';
        }
        return { page:n, text, chars:text.length, items, meaningful, hasRaster, kind };
      }));
      for (const item of batch) {
        pages.push(item);
        if (item.kind === 'text') textPages.push(item.page);
        else if (item.kind === 'scan') scanPages.push(item.page);
        else if (item.kind === 'blank') blankPages.push(item.page);
        else unknownPages.push(item.page);
        chars += item.text.length;
        progress?.({ phase:'inspect-page', page:item.page, totalPages, kind:item.kind, chars:item.text.length });
      }
    }

    // Trang text rất ngắn/không chắc chắn được coi là scan cần đọc khi file còn thiếu nội dung;
    // trang trống thực sự (không text + không raster image) không ép nhận dạng.
    for (const n of unknownPages) if (!scanPages.includes(n)) scanPages.push(n);
    scanPages.sort((a,b)=>a-b);

    const textParts = pages.filter((p) => p.text).map((p) => `[Trang ${p.page}] ${p.text}`);
    const text = clean(textParts.join('\n\n')).slice(0, maxChars);
    let status = 'text';
    if (scanPages.length && textPages.length) status = 'mixed';
    else if (scanPages.length && !textPages.length) status = 'scan';

    return {
      status,
      text,
      pages,
      pagesRead:pages.length,
      totalPages,
      scanPages,
      textPages,
      blankPages,
      unknownPages,
      sizeBytes,
      truncated:pages.length < totalPages || textParts.join('\n\n').length > maxChars,
      viewerToken:frameViewerTokens(frame)[0] || ''
    };
  }

  function lexical(win, expression) {
    try { return win.eval(expression); } catch (_) { return null; }
  }

  function ocrEntries(win) {
    const result = lexical(win, 'typeof ocrResults !== "undefined" ? ocrResults : null');
    const out = [];
    try {
      if (result && typeof result.forEach === 'function') result.forEach((value, key) => out.push([Number(key), value]));
      else if (result && typeof result === 'object') for (const [key, value] of Object.entries(result)) out.push([Number(key), value]);
    } catch (_) {}
    return out.filter(([page]) => Number.isFinite(page)).sort((a,b)=>a[0]-b[0]);
  }

  function ocrValue(win, pageNumber) {
    const hit = ocrEntries(win).find(([page]) => Number(page) === Number(pageNumber));
    return hit ? hit[1] : null;
  }

  function snapshotProperty(obj, key) {
    return { had:Object.prototype.hasOwnProperty.call(obj || {}, key), value:obj?.[key] };
  }

  function restoreProperty(obj, key, snap) {
    if (!obj || !snap) return;
    try {
      if (snap.had) obj[key] = snap.value;
      else delete obj[key];
    } catch (_) {}
  }

  async function runNativeScanRead(frame, req, check, progress) {
    const before = await inspectPdfFrame(frame, req, check, progress);
    if (before.status === 'unavailable' || before.status === 'too-large' || before.status === 'text') return before;

    const scanPages = [...new Set((Array.isArray(req.scanPages) && req.scanPages.length ? req.scanPages : before.scanPages).map(Number).filter((n)=>n>=1 && n<=before.totalPages))].sort((a,b)=>a-b);
    if (!scanPages.length) return { ...before, status:'text' };

    const params = window.VBParams = window.VBParams || {};
    const old = {
      vbtc:snapshotProperty(params,'vbtc'),
      vbtcFlag:snapshotProperty(params,'config_display_lay_vbtc'),
      vblqFlag:snapshotProperty(params,'config_display_lay_vblq'),
      fileId:snapshotProperty(params,'file_id'),
      fileName:snapshotProperty(params,'file_name'),
      globalFlag:snapshotProperty(window,'config_display_lay_vbtc')
    };

    let currentFrame = frame;
    let ready = await waitPdf(currentFrame, check, 6000);
    const originalPage = Number(ready?.app?.pdfViewer?.currentPageNumber || 1);
    const started = Date.now();
    const overallMs = Math.max(30000, Math.min(180000, Number(req.timeoutMs) || 180000));
    const maxChars = Math.max(500, Math.min(80000, Number(req.maxChars) || 40000));

    try {
      params.vbtc = true;
      params.config_display_lay_vbtc = '1';
      params.config_display_lay_vblq = '0';
      if (req.fileId) params.file_id = String(req.fileId);
      if (req.fileName) params.file_name = String(req.fileName);
      try { window.config_display_lay_vbtc = '1'; } catch (_) {}

      progress?.({ phase:'scan-start', page:0, totalPages:before.totalPages, scanPages:[...scanPages] });

      // Reload đúng viewer đã xác định; đây là cơ chế đã kiểm chứng trực tiếp trên iOffice.
      try { currentFrame.contentWindow.location.reload(); }
      catch (_) { currentFrame.src = currentFrame.src; }

      ready = await waitPdf(currentFrame, check, Math.min(30000, overallMs));
      if (!ready) throw new Error('Viewer PDF.js không tải lại sau khi bật đọc tệp scan.');
      let { app, pdf, win } = ready;

      // ocr.js đọc cờ khi khởi tạo. Không chạy tiếp nếu viewer mới chưa nhận cờ = 1.
      let ts = null;
      while (Date.now() - started < Math.min(30000, overallMs)) {
        check();
        ts = lexical(win, 'typeof ts_vbtc !== "undefined" ? ts_vbtc : null');
        if (String(ts) === '1') break;
        await sleep(120);
      }
      if (String(ts) !== '1') throw new Error('iOffice chưa bật chế độ đọc tệp scan trong viewer.');

      // Chờ ocr.js tạo Map kết quả.
      while (Date.now() - started < overallMs) {
        check();
        const result = lexical(win, 'typeof ocrResults !== "undefined" ? ocrResults : null');
        if (result) break;
        await sleep(120);
      }

      const ocrTexts = new Map();
      const failedPages = [];
      for (let i = 0; i < scanPages.length; i++) {
        const pageNumber = scanPages[i];
        check();
        progress?.({ phase:'scan-page-start', page:pageNumber, index:i+1, count:scanPages.length, totalPages:before.totalPages });
        try {
          if (app?.pdfViewer) {
            if (Number(app.pdfViewer.currentPageNumber || 0) !== pageNumber) app.pdfViewer.currentPageNumber = pageNumber;
            try { app.pdfViewer.scrollPageIntoView?.({ pageNumber }); } catch (_) {}
          }
        } catch (_) {}

        const pageStarted = Date.now();
        let value = null;
        while (Date.now() - started < overallMs && Date.now() - pageStarted < 45000) {
          check();
          value = ocrValue(win, pageNumber);
          if (value && value !== 'processing' && typeof value?.data?.text === 'string') break;
          await sleep(180);
        }
        const text = clean(value?.data?.text || '');
        if (text) {
          ocrTexts.set(pageNumber, text);
          progress?.({ phase:'scan-page-done', page:pageNumber, index:i+1, count:scanPages.length, totalPages:before.totalPages, chars:text.length });
        } else {
          failedPages.push(pageNumber);
          progress?.({ phase:'scan-page-error', page:pageNumber, index:i+1, count:scanPages.length, totalPages:before.totalPages, error:'iOffice không trả nội dung nhận dạng.' });
        }
      }

      // Ghép text PDF.js + text nhận dạng đúng thứ tự trang. Chỉ các trang scan mới dùng kết quả iOffice.
      const merged = [];
      const pageLimit = Math.max(1, Math.min(80, Number(req.maxPages) || 80, Number(pdf.numPages || before.totalPages || 1)));
      for (let n = 1; n <= pageLimit; n++) {
        check();
        let text = ocrTexts.get(n) || '';
        if (!text) {
          const page = await pdf.getPage(n);
          const tc = await page.getTextContent();
          text = clean((tc.items || []).map((x) => x.str || '').join(' '));
        }
        if (text) merged.push(`[Trang ${n}] ${text}`);
      }

      const full = clean(merged.join('\n\n'));
      const partial = failedPages.length > 0 || scanPages.some((p) => !ocrTexts.has(p));
      return {
        status: full.length >= 40 ? (partial ? 'partial' : 'ok') : 'failed',
        source:'ioffice-native-scan',
        text:full.slice(0, maxChars),
        totalPages:Number(pdf.numPages || before.totalPages || 0),
        pagesRead:pageLimit,
        scanPages,
        pagesSucceeded:scanPages.filter((p)=>ocrTexts.has(p)).length,
        failedPages,
        ocrPartial:partial,
        sizeBytes:before.sizeBytes || resourcePdfSize(currentFrame),
        truncated:pageLimit < Number(pdf.numPages || 0) || full.length > maxChars
      };
    } finally {
      try {
        const cw = currentFrame?.contentWindow;
        const app = cw?.PDFViewerApplication;
        if (app?.pdfViewer && originalPage >= 1 && originalPage <= Number(app.pdfDocument?.numPages || originalPage)) {
          app.pdfViewer.currentPageNumber = originalPage;
        }
      } catch (_) {}
      restoreProperty(params,'vbtc',old.vbtc);
      restoreProperty(params,'config_display_lay_vbtc',old.vbtcFlag);
      restoreProperty(params,'config_display_lay_vblq',old.vblqFlag);
      restoreProperty(params,'file_id',old.fileId);
      restoreProperty(params,'file_name',old.fileName);
      restoreProperty(window,'config_display_lay_vbtc',old.globalFlag);
    }
  }

  function reply(id, ok, data, error='') {
    window.postMessage({ channel:CHANNEL, direction:'response', id, ok, data:data || null, error:String(error || '') }, location.origin);
  }

  function emitProgress(id, progress) {
    window.postMessage({ channel:CHANNEL, direction:'progress', id, progress:progress || {} }, location.origin);
  }

  window.addEventListener('message', async (event) => {
    if (event.source !== window || event.origin !== location.origin) return;
    const m = event.data;
    if (m?.channel !== CHANNEL || m?.direction !== 'request' || typeof m.id !== 'string') return;
    if (m.type === 'cancel') { jobs.get(m.id)?.abort(); return; }
    if (!['inspect','read-scan'].includes(m.type) || jobs.has(m.id)) return;

    const controller = new AbortController();
    jobs.set(m.id, controller);
    const deadline = Date.now() + Math.max(3000, Math.min(185000, Number(m.timeoutMs) || (m.type === 'read-scan' ? 180000 : 12000)));
    const check = () => {
      if (controller.signal.aborted) throw new Error('Đã dừng đọc tệp scan.');
      if (Date.now() > deadline) throw new Error('Hết thời gian đọc tệp scan.');
    };

    try {
      const frame = await findViewer(m, check);
      if (!frame) return reply(m.id, false, null, 'Không tìm thấy PDF viewer phù hợp của iOffice.');
      const progress = (p) => emitProgress(m.id, p);
      const result = m.type === 'inspect'
        ? await inspectPdfFrame(frame, m, check, progress)
        : await runNativeScanRead(frame, m, check, progress);
      reply(m.id, true, result);
    } catch (error) {
      reply(m.id, false, null, error?.message || String(error));
    } finally {
      jobs.delete(m.id);
    }
  });
})();
