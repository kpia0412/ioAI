/* Runs only inside same-origin iOffice viewer frames, in the page's MAIN world. */
(() => {
  'use strict';
  if (window === window.top || !/\/web\/viewer\.jsp$/.test(location.pathname)) return;

  const jobs = new Map();
  const clean = (s) => String(s || '').replace(/\u00a0/g, ' ').replace(/\s+/g, ' ').trim();
  const fold = (s) => clean(s).normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/đ/g, 'd').replace(/Đ/g, 'D').toLowerCase();
  const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

  function visible(el) {
    try {
      if (!(el instanceof Element)) return false;
      const st = getComputedStyle(el);
      const r = el.getBoundingClientRect();
      return st.display !== 'none' && st.visibility !== 'hidden' && Number(st.opacity || 1) > 0 && r.width > 1 && r.height > 1;
    } catch (_) { return false; }
  }

  let lastCopiedText = '';

  function rememberCopiedText(value) {
    const t = clean(value);
    if (t.length >= 40 && t.length > lastCopiedText.length) lastCopiedText = t.slice(0, 40000);
  }

  // Không dùng Selection.addRange() nữa. iOffice/PDF.js thường render lại page node,
  // khiến Range vừa tạo đã thuộc một document/root khác và Chrome báo
  // "addRange(): The given range isn't in document." Range.toString() đọc được
  // text node mà không làm thay đổi selection thật của người dùng.
  function selectableText(el) {
    try {
      if (!el || !el.ownerDocument) return '';
      const doc = el.ownerDocument;
      if (el.nodeType !== 1 && el.nodeType !== 11) return '';
      const range = doc.createRange();
      range.selectNodeContents(el);
      return clean(range.toString());
    } catch (_) {
      try { return clean(el?.textContent || ''); } catch (_) { return ''; }
    }
  }

  // Bắt text nếu chính iOffice dùng thao tác copy/clipboard sau OCR.
  try {
    document.addEventListener('copy', () => {
      try { rememberCopiedText(document.getSelection?.()?.toString?.() || window.getSelection?.()?.toString?.() || ''); } catch (_) {}
    }, true);

    const originalExec = document.execCommand?.bind(document);
    if (originalExec) {
      document.execCommand = function(command, ...args) {
        if (String(command || '').toLowerCase() === 'copy') {
          try { rememberCopiedText(document.getSelection?.()?.toString?.() || window.getSelection?.()?.toString?.() || ''); } catch (_) {}
        }
        return originalExec(command, ...args);
      };
    }

    const cb = navigator.clipboard;
    if (cb && typeof cb.writeText === 'function') {
      const originalWriteText = cb.writeText.bind(cb);
      try {
        cb.writeText = function(value) {
          rememberCopiedText(value);
          return originalWriteText(value);
        };
      } catch (_) {}
    }
  } catch (_) {}

  function textFromAttributes(root, push) {
    try {
      const nodes = root.querySelectorAll?.(
        '[data-text],[data-ocr-text],[data-ioffice-ocr-text],[aria-label],[data-content],[data-value],[alt]'
      ) || [];
      for (const el of nodes) {
        if (el.closest?.('button,[role="button"],[role="toolbar"],#toolbarContainer,#secondaryToolbar,.toolbar')) continue;
        for (const name of ['data-text','data-ocr-text','data-ioffice-ocr-text','data-content','data-value','aria-label','alt']) {
          const v = el.getAttribute?.(name);
          if (v && clean(v).length >= 8) push(v);
        }
      }
    } catch (_) {}
  }

  function textFromPageRoot(root, maxChars = 32000, seenRoots = new Set()) {
    if (!root || seenRoots.has(root)) return '';
    seenRoots.add(root);

    const parts = [];
    const push = (value) => {
      const t = clean(value);
      if (t.length >= 12) parts.push(t);
    };

    if (lastCopiedText) push(lastCopiedText);

    const selectors = [
      '.textLayer', '.text-layer', '[class*="textLayer"]', '[class*="text-layer"]',
      '[data-ioffice-ocr-text]', '[data-ocr-text]', '[data-text]',
      '[class*="ocr" i] [class*="text" i]', '[class*="copy" i] [class*="text" i]',
      'textarea', '[contenteditable="true"]', 'svg text'
    ];
    for (const selector of selectors) {
      try {
        for (const el of root.querySelectorAll?.(selector) || []) {
          if (el.closest?.('button,[role="button"],[role="toolbar"],#toolbarContainer,#secondaryToolbar,.toolbar')) continue;
          push(['TEXTAREA','INPUT'].includes(el.tagName) ? el.value : (el.innerText || el.textContent || ''));
        }
      } catch (_) {}
    }
    textFromAttributes(root, push);

    let pageRoots = [];
    try {
      pageRoots = [...(root.querySelectorAll?.(
        '.page,[data-page-number],#viewer,.pdfViewer,#viewerContainer,[role="document"],[class*="pageContainer" i]'
      ) || [])];
    } catch (_) {}
    if (!pageRoots.length && root.body) pageRoots = [root.body];

    for (const page of pageRoots.slice(0, 120)) {
      try {
        push(selectableText(page));
        push(page.innerText || page.textContent || '');

        const pageDoc = page.ownerDocument || document;
        const pageWin = pageDoc.defaultView || window;
        const NF = pageWin.NodeFilter || NodeFilter;
        const walker = pageDoc.createTreeWalker(page, NF.SHOW_TEXT, {
          acceptNode(node) {
            const parent = node.parentElement;
            if (!parent) return NF.FILTER_REJECT;
            if (parent.closest('button,[role="button"],[role="toolbar"],#toolbarContainer,#secondaryToolbar,.toolbar,input,select,option,script,style,noscript')) return NF.FILTER_REJECT;
            const v = clean(node.nodeValue || '');
            return v.length >= 2 ? NF.FILTER_ACCEPT : NF.FILTER_REJECT;
          }
        });
        const textNodes = [];
        let node, charCount = 0;
        while ((node = walker.nextNode()) && charCount < maxChars) {
          const v = node.nodeValue || '';
          textNodes.push(v);
          charCount += v.length + 1;
        }
        push(textNodes.join(' '));
        textFromAttributes(page, push);
      } catch (_) {}
    }

    try {
      const views = window.PDFViewerApplication?.pdfViewer?._pages || [];
      for (const view of Array.isArray(views) ? views : []) {
        const candidates = [
          view?.textLayer?.div,
          view?.textLayer?.textLayerDiv,
          view?.textLayer?.container,
          view?.div,
          view?.canvas?.parentElement
        ];
        for (const el of candidates) {
          if (!el) continue;
          push(selectableText(el));
          push(el.innerText || el.textContent || '');
          textFromAttributes(el, push);
        }
      }
    } catch (_) {}

    try {
      for (const el of root.querySelectorAll?.('*') || []) {
        if (el.shadowRoot) push(textFromPageRoot(el.shadowRoot, maxChars, seenRoots));
        if (el.tagName === 'IFRAME') {
          try {
            const childDoc = el.contentDocument;
            if (childDoc) push(textFromPageRoot(childDoc, maxChars, seenRoots));
          } catch (_) {}
        }
      }
    } catch (_) {}

    const unique = [...new Set(parts.map(clean).filter(Boolean))];
    unique.sort((a, b) => b.length - a.length);
    const best = unique[0] || '';
    if (best.length >= 120) return best.slice(0, maxChars);
    return clean(unique.join('\n\n')).slice(0, maxChars);
  }

  function textFromDom(maxChars = 32000) {
    return textFromPageRoot(document, maxChars);
  }

  async function readPdfText(pdf, { maxPages, maxChars, check }) {
    const totalPages = pdf.numPages;
    const limitPages = Math.min(totalPages, Math.max(1, Math.min(80, maxPages || 20)));
    const charLimit = Math.min(40000, Math.max(500, maxChars || 24000));
    const hw = Math.max(2, Number(navigator.hardwareConcurrency || 4));
    const pageConcurrency = hw >= 12 ? 4 : hw >= 6 ? 3 : 2;
    const pages = [];
    let chars = 0, pagesRead = 0, empty = 0;

    for (let start = 1; start <= limitPages; start += pageConcurrency) {
      check();
      const nums = [];
      for (let n = start; n < Math.min(start + pageConcurrency, limitPages + 1); n++) nums.push(n);
      const batch = await Promise.all(nums.map(async (n) => {
        check();
        const page = await pdf.getPage(n);
        check();
        const content = await page.getTextContent();
        check();
        return clean((content.items || []).map((x) => x.str || '').join(' '));
      }));
      for (const t of batch) {
        pages.push(t); chars += t.length; pagesRead += 1; empty = t ? 0 : empty + 1;
      }
      if (chars >= charLimit || (!chars && empty >= 4)) break;
    }
    return {
      text: clean(pages.join('\n\n')).slice(0, charLimit),
      pagesRead,
      totalPages,
      truncated: pagesRead < totalPages || chars > charLimit
    };
  }

  function controlLabel(el) {
    if (!el) return '';
    return clean([
      el.innerText, el.textContent, el.getAttribute?.('title'), el.getAttribute?.('aria-label'),
      el.getAttribute?.('data-l10n-id'), el.id, el.className
    ].filter(Boolean).join(' '));
  }

  function ocrScore(el) {
    const raw = controlLabel(el);
    const s = fold(raw);
    if (!s) return -999;
    let score = 0;
    // Đúng nhãn người dùng đã thấy trên viewer iOffice.
    if (/chuyen.{0,20}van ban.{0,25}sang.{0,15}dang.{0,15}copy/.test(s)) score += 260;
    if (/xem.{0,20}dang.{0,15}copy.{0,15}duoc/.test(s)) score += 250;
    if (/xem.{0,20}dang.{0,15}copy/.test(s)) score += 220;
    if (/copy.{0,15}duoc/.test(s)) score += 160;
    if (/\bocr\b/.test(s)) score += 120;
    if (/nhan dang/.test(s)) score += 110;
    if (/chuyen.{0,20}van ban.{0,30}(copy|sao chep)/.test(s)) score += 190;
    if (/chuyen.{0,20}van ban/.test(s)) score += 100;
    if (/van ban.{0,20}(copy|sao chep)/.test(s)) score += 95;
    if (/(copy|sao chep).{0,20}van ban/.test(s)) score += 90;
    if (/dang copy/.test(s)) score += 95;
    if (/extract.{0,10}text|recognize.{0,10}text/.test(s)) score += 85;
    if (/\btext\b/.test(s) && /(convert|copy|recogn|ocr|extract)/.test(s)) score += 70;
    // Loại copy link/url và các nút sao chép không liên quan văn bản PDF.
    if (/copy.{0,10}(link|url)|sao chep.{0,10}(lien ket|duong dan)|copy page/.test(s)) score -= 220;
    if (/download|tai xuong|print|in van ban|zoom|rotate|xoay/.test(s)) score -= 70;
    if (/btncopyai|dlk-copy-btn/.test(s) && !/van ban|dang copy|ocr|nhan dang/.test(s)) score -= 140;
    if (visible(el)) score += 15;
    const role = String(el.getAttribute?.('role') || '').toLowerCase();
    const onclick = String(el.getAttribute?.('onclick') || '');
    if (/button|menuitem/.test(role) || ['BUTTON','A'].includes(el.tagName) || onclick || /pointer/.test(getComputedStyle(el)?.cursor || '')) score += 8;
    return score;
  }

  function collectControlCandidates(root, out, seen = new Set()) {
    if (!root || seen.has(root)) return;
    seen.add(root);
    const selectors = 'button,a,[role="button"],[role="menuitem"],[title],[aria-label],[data-l10n-id],[onclick],input[type="button"],input[type="submit"],span,i,div';
    try {
      for (const el of root.querySelectorAll?.(selectors) || []) {
        // div/span đại trà chỉ xét khi có dấu hiệu click/nhãn copy/OCR để tránh quét hàng nghìn node vô ích.
        if (['DIV','SPAN','I'].includes(el.tagName)) {
          const label = fold(controlLabel(el));
          const clickish = el.hasAttribute?.('onclick') || /pointer/.test(getComputedStyle(el)?.cursor || '') || /copy|ocr|nhan dang|dang copy|chuyen van ban/.test(label);
          if (!clickish) continue;
        }
        out.push(el);
        if (el.shadowRoot) collectControlCandidates(el.shadowRoot, out, seen);
      }
    } catch (_) {}
    try {
      for (const frame of root.querySelectorAll?.('iframe') || []) {
        const child = frame.contentDocument;
        if (child) collectControlCandidates(child, out, seen);
      }
    } catch (_) {}
  }

  function bestOcrControl(exclude = new Set()) {
    const list = [];
    const elements = [];
    collectControlCandidates(document, elements);
    for (const el of elements) {
      if (exclude.has(el)) continue;
      const score = ocrScore(el);
      if (score >= 70) list.push({ el, score, label: controlLabel(el) });
    }
    list.sort((a, b) => b.score - a.score);
    return list[0] || null;
  }

  function openLikelyToolbars() {
    const ids = ['secondaryToolbarToggle', 'editorModeButtons', 'toolsButton', 'moreButton'];
    for (const id of ids) {
      try {
        const el = document.getElementById(id);
        if (el && visible(el) && el.getAttribute('aria-expanded') !== 'true') el.click();
      } catch (_) {}
    }
    // Một số bản viewer dùng nút ba chấm/More thay ID cố định.
    try {
      const candidates = [...document.querySelectorAll('button,[role="button"]')]
        .filter(visible)
        .filter((el) => /^(more|them|tuy chon|cong cu|tools?|⋮|…)$/.test(fold(controlLabel(el))));
      for (const el of candidates.slice(0, 2)) { try { el.click(); } catch (_) {} }
    } catch (_) {}
  }

  async function waitForOcrText(pdf, opts) {
    const { check, maxPages, maxChars, timeoutMs = 20000 } = opts;
    const deadline = Date.now() + Math.max(5000, Math.min(60000, timeoutMs));
    const clicked = new Set();
    let actionLabel = '';
    let lastText = '';

    // Text layer có thể đã được iOffice OCR sẵn trước khi extension hỏi.
    const already = textFromDom(maxChars);
    if (already.length >= 120) return { text: already, source: 'ioffice-ocr-textlayer', actionLabel: 'OCR/text layer đã sẵn sàng' };
    if (lastCopiedText.length >= 120) return { text: lastCopiedText.slice(0, maxChars), source: 'ioffice-copy-captured', actionLabel: 'Đã bắt text từ thao tác copy của iOffice' };

    openLikelyToolbars();
    await sleep(180);

    while (Date.now() < deadline) {
      check();

      // Sau khi bấm OCR, PDF.js có thể nhận textContent mới.
      try {
        const reread = await readPdfText(pdf, { maxPages, maxChars, check });
        if ((reread.text || '').length >= 120) return { ...reread, source: 'ioffice-ocr-pdfjs', actionLabel };
      } catch (_) {}

      if (lastCopiedText.length >= 120) return { text: lastCopiedText.slice(0, maxChars), source: 'ioffice-copy-captured', actionLabel };
      const domText = textFromDom(maxChars);
      if (domText.length >= 120) return { text: domText, source: 'ioffice-ocr-textlayer', actionLabel };
      if (domText.length > lastText.length) lastText = domText;

      let candidate = bestOcrControl(clicked);
      if (!candidate) {
        openLikelyToolbars();
        await sleep(250);
        candidate = bestOcrControl(clicked);
      }

      if (candidate) {
        clicked.add(candidate.el);
        actionLabel ||= candidate.label;
        try {
          candidate.el.scrollIntoView?.({ block: 'nearest' });
          candidate.el.click();
        } catch (_) {}
        // Nút đầu tiên đôi khi chỉ mở menu/modal; cho DOM thời gian sinh nút xác nhận tiếp theo.
        await sleep(700);
      } else {
        await sleep(700);
      }
    }

    return { text: lastText, source: lastText.length >= 40 ? 'ioffice-ocr-partial' : 'scan-no-ocr-text', actionLabel };
  }

  window.addEventListener('message', async (event) => {
    if (event.source !== parent || event.origin !== location.origin) return;
    const m = event.data;
    if (m?.channel !== 'ioffice-reader-v2' || typeof m.id !== 'string') return;
    if (m.type === 'cancel') { jobs.get(m.id)?.abort(); return; }
    if (m.type !== 'read' || jobs.has(m.id)) return;

    const controller = new AbortController();
    jobs.set(m.id, controller);
    // Stable 1.3.2: timeout của viewer phải khớp với timeout parent. Bản 1.3.1 ép tối thiểu 12s
    // trong khi parent thường chỉ chờ 6-7s, nên parent hủy job trước khi PDF.js đọc xong.
    // OCR nếu được bật sẽ tự truyền timeout dài hơn; đọc text thường dùng đúng ngân sách caller.
    const overallMs = Math.min(70000, Math.max(2200, Number(m.timeoutMs) || 6000));
    const until = Date.now() + overallMs;
    const check = () => {
      if (controller.signal.aborted) throw new Error('Đã dừng đọc viewer.');
      if (Date.now() > until) throw new Error('Hết thời gian đọc/OCR viewer.');
    };

    let output;
    try {
      let app;
      while (!(app = window.PDFViewerApplication)?.pdfDocument) { check(); await sleep(80); }
      const pdf = app.pdfDocument;
      const maxPages = Math.min(80, Math.max(1, Number(m.maxPages) || 20));
      const maxChars = Math.min(40000, Math.max(500, Number(m.maxChars) || 24000));

      const initial = await readPdfText(pdf, { maxPages, maxChars, check });
      output = { ...initial, source: 'pdf-main-world', status: initial.text.length >= 120 ? 'text' : 'scan-no-text' };

      // Scan PDF: ưu tiên OCR/copy text của chính viewer iOffice trước khi lấy file để upload AI.
      if (initial.text.length < 120 && m.tryIofficeOcr !== false) {
        const left = Math.max(3500, until - Date.now() - 1200);
        const ocr = await waitForOcrText(pdf, { check, maxPages, maxChars, timeoutMs: Math.min(58000, left) });
        check();
        if ((ocr.text || '').length >= 120) {
          output = {
            ...output,
            ...ocr,
            text: clean(ocr.text).slice(0, maxChars),
            status: 'ocr-text',
            pagesRead: ocr.pagesRead || output.pagesRead || 0,
            totalPages: ocr.totalPages || output.totalPages || pdf.numPages,
            ocrAction: ocr.actionLabel || ''
          };
        } else {
          output.ocrAttempted = true;
          output.ocrAction = ocr.actionLabel || '';
          output.ocrPartialChars = (ocr.text || '').length;
        }
      }

      if ((output.text || '').length < 120 && m.captureScanBinary) {
        const bytes = await pdf.getData();
        check();
        output.scanSizeBytes = bytes.byteLength;
        if (bytes.byteLength <= 8 * 1024 * 1024) {
          output.scanBytes = bytes;
          output.status = 'scan-ready-for-ai';
        } else {
          output.status = 'scan-too-large';
        }
      }

      check();
      parent.postMessage({ channel: 'ioffice-reader-v2', id: m.id, ok: true, data: output }, event.origin);
    } catch (e) {
      if (!controller.signal.aborted) parent.postMessage({ channel: 'ioffice-reader-v2', id: m.id, ok: false, error: e.message }, event.origin);
    } finally {
      jobs.delete(m.id);
    }
  });
})();
