(() => {
  'use strict';

  const VERSION = '0.18.3';
  const ACTION_CHANNEL = 'ioffice-tracker-action-v1';
  const WIDGET_HOST_ID = 'ealy-ioffice-ai-host';
  const CARD_ID = 'trackerWatch';

  const state = {
    enabled: false,
    userRole: 'leader',
    busy: false,
    scanTimer: null,
    lastMatchKey: '',
    currentMatch: null,
    currentRelatedDocs: [],
    currentContext: null,
    pendingAction: null,
    actionResponses: new Map(),
    lastRender: ''
  };

  const norm = (v) => String(v ?? '').replace(/\u00a0/g, ' ').replace(/\s+/g, ' ').trim();
  const esc = (v) => String(v ?? '')
    .replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;')
    .replaceAll('"','&quot;').replaceAll("'",'&#039;');

  function visible(el) {
    if (!el) return false;
    try {
      const s = getComputedStyle(el), r = el.getBoundingClientRect();
      return s.display !== 'none' && s.visibility !== 'hidden' && r.width > 0 && r.height > 0;
    } catch (_) { return false; }
  }

  function firstValue(selectors) {
    for (const sel of selectors) {
      for (const el of document.querySelectorAll(sel)) {
        const v = norm(el.value || el.textContent || '');
        if (v) return v;
      }
    }
    return '';
  }

  function detectOutgoing() {
    const title = norm(document.title).toLowerCase();

    // Quan trọng: màn hình Lãnh đạo xem VB đi có thể chỉ hiển thị chi tiết,
    // còn các control vbdi/ký/ban hành vẫn nằm ẩn trong DOM. Không được yêu cầu
    // control phải visible, nếu không Tracker sẽ bỏ qua đúng màn hình cần đối chiếu.
    const outgoingDom = Boolean(document.querySelector(
      '#TRICH_YEU,#txt_idedit,#btn_vdi_savedoc,#btn_ky_vbTrinhKy,' +
      '#btn_action_publish,#btnBanhanh,[name="vbdi_chk_donvi_truc"],[name="vbdi_rd_unit_noibo_emp"]'
    ));

    // Đồng bộ trực tiếp với nhãn workflow mà content.js đã xác định.
    const workflowText = norm(
      document.getElementById(WIDGET_HOST_ID)?.shadowRoot?.getElementById('workflowBadge')?.textContent || ''
    ).toLowerCase();

    const workflowOutgoing = /văn bản đi|van ban di/.test(workflowText);
    const titleOutgoing = /văn bản đi|van ban di/.test(title);

    // Nếu đã có Văn bản liên quan và workflow xác định là VB đi thì phải quét ngay,
    // kể cả khi người dùng mới chỉ mở màn hình xem, chưa bấm Xử lý/Ký.
    const hasRelated = !!document.querySelector('#thongtinvb div.download');

    return outgoingDom || workflowOutgoing || titleOutgoing || (hasRelated && workflowOutgoing);
  }

  function readRelatedDocuments() {
    const root = document.querySelector('#thongtinvb');
    if (!root) return [];
    const out = [];
    for (const el of root.querySelectorAll('div.download')) {
      const rawText = norm(el.textContent || '');
      if (!/Trích\s*yếu\s*:/i.test(rawText) || !/Số\s*ký\s*hiệu\s*:/i.test(rawText)) continue;
      const cleaned = rawText.replace(/^\d+\.\s*/, '');
      const subjectMatch = cleaned.match(/Trích\s*yếu\s*:\s*(.*?)\s*Số\s*ký\s*hiệu\s*:/i);
      const symbolMatch = cleaned.match(/Số\s*ký\s*hiệu\s*:\s*([^\s|,;()]+)/i);
      const onclick = el.getAttribute('onclick') || '';
      const idm = onclick.match(/get_detail_doc_popup_v1\(['"]?([^'")]+)['"]?\)/i);
      const symbol = norm(symbolMatch?.[1] || '').replace(/[;,]+$/, '');
      const subject = norm(subjectMatch?.[1] || '');
      if (!symbol && !idm?.[1]) continue;
      out.push({
        relatedIofficeId: norm(idm?.[1] || ''),
        symbol,
        subject,
        rawText
      });
    }
    const seen = new Set();
    return out.filter(x => {
      const k = `${x.relatedIofficeId}|${x.symbol}|${x.subject}`.toLowerCase();
      if (seen.has(k)) return false;
      seen.add(k); return true;
    });
  }

  function signedFileName() {
    const values = [...document.querySelectorAll('input[id^="txt_file_name_"]')]
      .map(x => norm(x.value)).filter(Boolean);
    return values.find(x => /\.signed(?:\.signed)*\.pdf$/i.test(x))
      || values.find(x => /signed/i.test(x) && /\.pdf$/i.test(x))
      || values.find(x => /\.pdf$/i.test(x)) || '';
  }

  function signatureFingerprint() {
    const parts = [];
    for (const el of document.querySelectorAll('input[id^="txt_file_signature_"]')) {
      const v = norm(el.value);
      if (v) parts.push(`${el.id}:${v}`);
    }
    for (const el of document.querySelectorAll('input[id^="txt_file_name_"]')) {
      const v = norm(el.value);
      if (v && /signed|\.pdf$/i.test(v)) parts.push(`${el.id}:${v}`);
    }
    return parts.sort().join('|');
  }

  function readOutgoingContext() {
    const resultIofficeId = firstValue(['#txt_idedit', '#idVB', '#hide_docid']);
    const resultSymbol = firstValue(['#hide_sokyhieu', 'input[id^="vbdi_sokyhieu_"]']);
    const resultSubject = firstValue(['#TRICH_YEU', 'textarea[id*="TRICH_YEU" i]', 'textarea[name*="trich" i]']);
    const resultDate = firstValue(['#NGAY_VAN_BAN', '#ngay_tao_doc', 'input.ngayBanHanh']);
    return {
      resultIofficeId,
      resultSymbol,
      resultSubject,
      resultDate,
      resultUrl: location.href,
      signedFileName: signedFileName()
    };
  }

  function outgoingKey(ctx = readOutgoingContext()) {
    return norm(ctx.resultIofficeId || [ctx.resultSymbol, ctx.resultDate, ctx.resultSubject].join('|')).toLowerCase();
  }

  function statusLabel(s) {
    return ({
      PROCESSING:'Đang xử lý',
      WAITING_PUBLISH:'Đã xử lý - chờ ban hành',
      COMPLETED:'Đã hoàn thành',
      STOPPED:'Dừng theo dõi'
    })[norm(s)] || norm(s) || 'Đang xử lý';
  }

  function deadlineLabel(v) {
    const m = norm(v).match(/^(\d{4})-(\d{2})-(\d{2})$/);
    return m ? `${m[3]}/${m[2]}/${m[1]}` : norm(v);
  }

  function ensureCard() {
    const host = document.getElementById(WIDGET_HOST_ID);
    const root = host?.shadowRoot;
    if (!root) return null;
    let card = root.getElementById(CARD_ID);
    if (card) return card;
    card = document.createElement('div');
    card.id = CARD_ID;
    card.className = 'tracker-watch hidden';
    const body = root.getElementById('body');
    const message = root.getElementById('message');
    if (!body) return null;
    if (message?.nextSibling) body.insertBefore(card, message.nextSibling);
    else body.appendChild(card);
    const style = document.createElement('style');
    style.textContent = `
      .tracker-watch{margin:8px 0;padding:9px 10px;border:1px solid #b8d8c5;border-left:5px solid #15803d;border-radius:10px;background:#f2faf4;color:#244c34;font-size:10.5px;line-height:1.45}
      .tracker-watch.hidden{display:none!important}.tracker-watch.wait{border-color:#f0cf84;border-left-color:#d97706;background:#fff9eb;color:#7a4c00}.tracker-watch.err{border-color:#fecaca;border-left-color:#dc2626;background:#fff5f5;color:#8b1e1e}
      .tracker-watch .tw-head{font-size:11px;font-weight:900}.tracker-watch .tw-row{margin-top:3px}.tracker-watch .tw-symbol{font-weight:900;color:#14532d}.tracker-watch .tw-status{font-weight:900}.tracker-watch .tw-small{font-size:9.5px;color:#64748b}.tracker-watch button{margin-top:6px;border:0;border-radius:7px;padding:6px 8px;font-size:9.5px;font-weight:800;cursor:pointer;background:#0f766e;color:#fff}.tracker-watch button.secondary{background:#64748b}`;
    root.appendChild(style);
    return card;
  }

  function render(html, cls = '') {
    const card = ensureCard();
    if (!card) return;
    const signature = `${cls}|${html}`;
    if (signature === state.lastRender) return;
    state.lastRender = signature;
    card.className = `tracker-watch ${cls}`.trim();
    card.innerHTML = html;
  }

  function hideCard() {
    const card = ensureCard();
    if (!card) return;
    state.lastRender = '';
    card.className = 'tracker-watch hidden';
    card.innerHTML = '';
  }

  function renderMatch() {
    const m = state.currentMatch;
    if (!m?.matched || !m.task) return hideCard();
    const t = m.task;
    const role = state.userRole === 'clerk' ? 'Văn thư' : 'Lãnh đạo';
    const status = statusLabel(t.businessStatus);
    const actionHint = t.businessStatus === 'WAITING_PUBLISH'
      ? (state.userRole === 'clerk' ? 'Văn bản đã được lãnh đạo xử lý. Chờ Ban hành thành công để đóng nhiệm vụ.' : 'Nhiệm vụ đã chờ ban hành; không cần cập nhật lại khi chỉ mở xem.')
      : (state.userRole === 'leader' ? 'Tiện ích đang theo dõi nút Ký. Chỉ đổi trạng thái sau khi iOffice xác nhận ký thành công.' : 'Nhiệm vụ chưa ở trạng thái chờ ban hành; chưa tự đóng khi Văn thư chỉ mở xem.');
    render(`
      <div class="tw-head">🔗 Phát hiện văn bản kết quả · ${esc(role)}</div>
      <div class="tw-row"><span class="tw-symbol">${esc(t.sourceSymbol || '')}</span> · ${esc(t.taskText || t.sourceSubject || '')}</div>
      ${t.deadline ? `<div class="tw-row"><b>Hạn:</b> ${esc(deadlineLabel(t.deadline))}</div>` : ''}
      <div class="tw-row"><b>Trạng thái:</b> <span class="tw-status">${esc(status)}</span></div>
      <div class="tw-small">${esc(actionHint)}</div>
    `, t.businessStatus === 'WAITING_PUBLISH' ? 'wait' : '');
  }

  function renderReview(data) {
    const cs = data?.candidates || [];
    const top = cs[0];
    render(`
      <div class="tw-head">⚠ Văn bản có liên quan nhưng chưa đủ chắc chắn</div>
      ${top ? `<div class="tw-row">Ứng viên: <b>${esc(top.sourceSymbol || '')}</b> · ${esc(top.taskText || top.sourceSubject || '')}</div>` : ''}
      <div class="tw-small">Sổ chưa đổi trạng thái. Cần kiểm tra quan hệ văn bản nguồn trước.</div>
    `, 'wait');
  }

  function send(type, data = {}) {
    return new Promise((resolve) => {
      try {
        chrome.runtime.sendMessage({type, data}, r => {
          if (chrome.runtime.lastError) return resolve({ok:false,error:chrome.runtime.lastError.message});
          resolve(r || {ok:false,error:'NO_RESPONSE'});
        });
      } catch (e) { resolve({ok:false,error:e.message || String(e)}); }
    });
  }

  async function matchCurrentOutgoing(force = false) {
    if (!state.enabled || !detectOutgoing() || state.busy || state.pendingAction) return;
    const relatedDocs = readRelatedDocuments();
    if (!relatedDocs.length) {
      state.lastMatchKey = ''; state.currentMatch = null; state.currentRelatedDocs = []; state.currentContext = null;
      hideCard(); return;
    }
    const ctx = readOutgoingContext();
    const key = `${outgoingKey(ctx)}|${relatedDocs.map(x=>`${x.relatedIofficeId}:${x.symbol}`).join('|')}`;
    if (!force && key && key === state.lastMatchKey && state.currentMatch) { renderMatch(); return; }
    state.lastMatchKey = key;
    state.busy = true;
    render('<div class="tw-head">📒 Đang đối chiếu Văn bản liên quan với Sổ theo dõi…</div>', 'wait');
    try {
      const r = await send('TRACKER_MATCH', {
        relatedDocs,
        ...ctx
      });
      if (!r?.ok) throw new Error(r?.error || 'Không kết nối được Tracker.');
      const d = r.data || {};
      state.currentRelatedDocs = relatedDocs;
      state.currentContext = ctx;
      state.currentMatch = d;
      if (d.matched) renderMatch();
      else if (d.needsReview) renderReview(d);
      else hideCard();
    } catch (e) {
      render(`<div class="tw-head">⚠ Không đối chiếu được Sổ theo dõi</div><div class="tw-small">${esc(e.message || e)}</div>`, 'err');
    } finally { state.busy = false; }
  }

  function scheduleScan(delay = 180) {
    clearTimeout(state.scanTimer);
    state.scanTimer = setTimeout(() => matchCurrentOutgoing(false), delay);
  }

  function alertText() {
    const selectors = '[role="alert"],.alert,.toast,.toast-message,.swal2-popup,.bootbox,.modal.show,.modal.in,.ui-dialog';
    return [...document.querySelectorAll(selectors)].filter(visible).map(x => norm(x.textContent)).filter(Boolean).join(' | ').slice(0,12000);
  }

  function classifyText(text, action) {
    const t = norm(text).toLowerCase();
    if (!t) return '';
    if (/không thành công|khong thanh cong|thất bại|that bai|có lỗi|co loi|không thể|khong the|"success"\s*:\s*false|"status"\s*:\s*0|\berror\b/.test(t)) return 'failure';
    if (/thành công|thanh cong|"success"\s*:\s*true|"status"\s*:\s*1|"status"\s*:\s*"(?:success|ok)"/.test(t)) {
      if (action === 'sign' && /(ký|ky|sign|duyệt|duyet)/.test(t)) return 'success';
      if (action === 'publish' && /(ban hành|ban hanh|publish|phát hành|phat hanh)/.test(t)) return 'success';
      if (/^\s*(?:true|1)\s*$/.test(t)) return 'success';
    }
    return '';
  }

  function responseClassification(watchId, action) {
    const list = state.actionResponses.get(watchId) || [];
    let hasSuccess = false;
    for (const x of list) {
      const c = classifyText(`${x.text || ''} ${x.url || ''}`, action);
      if (c === 'failure') return 'failure';
      if (c === 'success') hasSuccess = true;
    }
    return hasSuccess ? 'success' : '';
  }

  function armNetworkWatch(pending) {
    try {
      window.postMessage({
        channel: ACTION_CHANNEL,
        type: 'arm',
        watchId: pending.watchId,
        action: pending.action,
        untilMs: 90000
      }, location.origin);
    } catch (_) {}
  }

  async function finishActionSuccess(pending, evidence) {
    if (state.pendingAction !== pending) return;
    const ctx = readOutgoingContext();
    const match = state.currentMatch;
    const task = match?.task;
    if (!task?.taskId) {
      state.pendingAction = null;
      render('<div class="tw-head">⚠ Không còn xác định được nhiệm vụ nguồn</div><div class="tw-small">Sổ chưa đổi trạng thái.</div>', 'err');
      return;
    }
    let type, data;
    if (pending.action === 'sign') {
      type = 'TRACKER_MARK_SIGNED';
      data = {
        taskId: task.taskId,
        resultId: match.resultId || '',
        ...ctx,
        matchedSourceIofficeId: state.currentRelatedDocs[0]?.relatedIofficeId || '',
        matchedSourceSymbol: state.currentRelatedDocs[0]?.symbol || task.sourceSymbol || '',
        matchMethod: 'RELATED_DOCUMENT',
        matchScore: 100,
        relatedRawText: state.currentRelatedDocs[0]?.rawText || '',
        signedAt: new Date().toISOString()
      };
      render('<div class="tw-head">✓ iOffice đã xác nhận ký · đang cập nhật Sổ…</div>', 'wait');
    } else {
      if (!ctx.resultSymbol) {
        state.pendingAction = null;
        render('<div class="tw-head">⚠ Đã thấy tín hiệu Ban hành nhưng chưa đọc được Số/Ký hiệu</div><div class="tw-small">Sổ chưa đánh dấu hoàn thành để tránh sai dữ liệu.</div>', 'err');
        return;
      }
      type = 'TRACKER_MARK_PUBLISHED';
      data = {
        taskId: task.taskId,
        resultId: match.resultId || '',
        ...ctx,
        matchedSourceIofficeId: state.currentRelatedDocs[0]?.relatedIofficeId || '',
        matchedSourceSymbol: state.currentRelatedDocs[0]?.symbol || task.sourceSymbol || '',
        matchMethod: 'RELATED_DOCUMENT',
        matchScore: 100,
        relatedRawText: state.currentRelatedDocs[0]?.rawText || '',
        publishedAt: new Date().toISOString()
      };
      render('<div class="tw-head">✓ iOffice đã xác nhận Ban hành · đang hoàn thành nhiệm vụ…</div>', 'wait');
    }
    const r = await send(type, data);
    state.pendingAction = null;
    if (!r?.ok) {
      render(`<div class="tw-head">⚠ iOffice đã xử lý nhưng cập nhật Sổ lỗi</div><div class="tw-small">${esc(r?.error || 'Không rõ lỗi')} · Không thực hiện lại thao tác iOffice; chỉ cần đồng bộ Sổ.</div>`, 'err');
      return;
    }
    const d = r.data || {};
    if (state.currentMatch?.task) state.currentMatch.task.businessStatus = d.businessStatus || (pending.action === 'sign' ? 'WAITING_PUBLISH' : 'COMPLETED');
    const label = pending.action === 'sign' ? 'Đã xử lý - chờ ban hành' : 'Đã hoàn thành';
    render(`<div class="tw-head">✓ ${esc(label)}</div><div class="tw-row"><b>${esc(task.sourceSymbol || '')}</b>${ctx.resultSymbol ? ` → ${esc(ctx.resultSymbol)}` : ''}</div><div class="tw-small">Căn cứ xác nhận: ${esc(evidence)}</div>`, pending.action === 'sign' ? 'wait' : '');
    setTimeout(() => scheduleScan(600), 800);
  }

  function finishActionFailure(pending, evidence) {
    if (state.pendingAction !== pending) return;
    state.pendingAction = null;
    render(`<div class="tw-head">✕ iOffice chưa ${pending.action === 'sign' ? 'ký' : 'ban hành'} thành công</div><div class="tw-small">${esc(evidence)} · Sổ không đổi trạng thái.</div>`, 'err');
  }

  async function watchAction(pending) {
    const deadline = Date.now() + 90000;
    let publishGoneSince = 0;
    while (state.pendingAction === pending && Date.now() < deadline) {
      await new Promise(r => setTimeout(r, 280));
      const net = responseClassification(pending.watchId, pending.action);
      if (net === 'failure') return finishActionFailure(pending, 'Phản hồi từ iOffice báo không thành công');
      if (net === 'success') return finishActionSuccess(pending, 'phản hồi máy chủ iOffice');

      const uiText = alertText();
      const ui = classifyText(uiText, pending.action);
      if (ui === 'failure') return finishActionFailure(pending, 'Thông báo trên iOffice báo lỗi/không thành công');
      if (ui === 'success') return finishActionSuccess(pending, 'thông báo thành công trên iOffice');

      if (pending.action === 'sign') {
        const nowSig = signatureFingerprint();
        if (nowSig && nowSig !== pending.beforeSignature) {
          return finishActionSuccess(pending, 'tệp/chữ ký số trên iOffice đã thay đổi');
        }
      } else {
        const finalBtnVisible = [...document.querySelectorAll('#btnBanhanh')].some(visible);
        const formVisible = [...document.querySelectorAll('#btn_vdi_savedoc,#TRICH_YEU')].some(visible);
        const keyChanged = outgoingKey(readOutgoingContext()) && outgoingKey(readOutgoingContext()) !== pending.beforeDocKey;
        if ((!finalBtnVisible && !formVisible) || keyChanged) {
          if (!publishGoneSince) publishGoneSince = Date.now();
          if (Date.now() - publishGoneSince > 1200) return finishActionSuccess(pending, 'màn hình Ban hành đã đóng/chuyển sau thao tác');
        } else publishGoneSince = 0;
      }
    }
    if (state.pendingAction === pending) {
      state.pendingAction = null;
      render(`<div class="tw-head">⚠ Chưa xác nhận được ${pending.action === 'sign' ? 'Ký' : 'Ban hành'} thành công</div><div class="tw-small">Sổ chưa đổi trạng thái để tránh ghi sai. Có thể mở lại văn bản để tiện ích đối chiếu.</div>`, 'wait');
    }
  }

  function beginAction(action) {
    if (!state.currentMatch?.matched || !state.currentMatch?.task?.taskId || state.pendingAction) return;
    const task = state.currentMatch.task;
    if (action === 'sign') {
      if (state.userRole !== 'leader' || task.businessStatus === 'COMPLETED' || task.businessStatus === 'WAITING_PUBLISH') return;
    } else {
      if (state.userRole !== 'clerk' || task.businessStatus === 'COMPLETED') return;
      if (task.businessStatus !== 'WAITING_PUBLISH') {
        render('<div class="tw-head">⚠ Nhiệm vụ chưa ở trạng thái Chờ ban hành</div><div class="tw-small">Tiện ích không tự hoàn thành trước khi lãnh đạo ký/xử lý văn bản.</div>', 'err');
        return;
      }
    }
    const ctx = readOutgoingContext();
    if (action === 'publish' && !ctx.resultSymbol) {
      render('<div class="tw-head">⚠ Chưa có Số/Ký hiệu văn bản đi</div><div class="tw-small">Tiện ích sẽ không đánh dấu hoàn thành cho đến khi văn bản đã được vào số.</div>', 'err');
      return;
    }
    const pending = {
      action,
      watchId: `tw-${Date.now()}-${Math.random().toString(36).slice(2,8)}`,
      beforeSignature: signatureFingerprint(),
      beforeDocKey: outgoingKey(ctx),
      startedAt: Date.now()
    };
    state.pendingAction = pending;
    state.actionResponses.set(pending.watchId, []);
    armNetworkWatch(pending);
    render(`<div class="tw-head">⏳ Đang chờ iOffice xác nhận ${action === 'sign' ? 'Ký' : 'Ban hành'}…</div><div class="tw-small">Chưa cập nhật Sổ cho tới khi có tín hiệu thành công.</div>`, 'wait');
    void watchAction(pending);
  }

  document.addEventListener('click', (ev) => {
    if (!state.enabled || !detectOutgoing()) return;
    const target = ev.target instanceof Element ? ev.target : null;
    if (!target) return;
    if (target.closest('#btn_ky_vbTrinhKy') && state.userRole === 'leader') {
      beginAction('sign');
      return;
    }
    if (target.closest('#btnBanhanh') && state.userRole === 'clerk') {
      beginAction('publish');
      return;
    }
  }, true);

  window.addEventListener('message', (event) => {
    if (event.source !== window || event.origin !== location.origin) return;
    const d = event.data;
    if (!d || d.channel !== ACTION_CHANNEL || d.type !== 'response' || !d.watchId) return;
    const arr = state.actionResponses.get(d.watchId) || [];
    arr.push({url:norm(d.url), text:norm(d.text).slice(0,6000), status:Number(d.status || 0), method:norm(d.method)});
    if (arr.length > 30) arr.shift();
    state.actionResponses.set(d.watchId, arr);
  });

  async function loadSettings() {
    try {
      const s = await chrome.storage.local.get({trackerEnabled:false,userRole:'leader'});
      state.enabled = s.trackerEnabled === true;
      state.userRole = s.userRole === 'clerk' ? 'clerk' : 'leader';
      if (!state.enabled) hideCard();
      else scheduleScan(120);
    } catch (_) {}
  }

  try {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== 'local') return;
      if (changes.trackerEnabled) state.enabled = changes.trackerEnabled.newValue === true;
      if (changes.userRole) state.userRole = changes.userRole.newValue === 'clerk' ? 'clerk' : 'leader';
      state.lastMatchKey = '';
      state.currentMatch = null;
      if (!state.enabled) hideCard(); else scheduleScan(80);
    });
  } catch (_) {}

  const observer = new MutationObserver(() => scheduleScan(180));
  observer.observe(document.documentElement, {subtree:true, childList:true, attributes:true, attributeFilter:['style','class','value']});
  document.addEventListener('visibilitychange', () => { if (!document.hidden) scheduleScan(80); });
  document.addEventListener('click', () => setTimeout(() => scheduleScan(180), 200), true);

  loadSettings();
})();
