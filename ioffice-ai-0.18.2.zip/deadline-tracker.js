(() => {
  'use strict';

  const STORAGE_KEY = 'deadlineTasksV1';
  const MAX_TASKS = 1500;

  const norm = (v) => String(v || '').replace(/\u00a0/g, ' ').replace(/\s+/g, ' ').trim();
  const pad2 = (n) => String(n).padStart(2, '0');

  function baseYearFromContext(ctx = {}) {
    const m = String(ctx.documentDate || ctx.receivedDate || '').match(/(?:^|\D)(20\d{2})(?:\D|$)/);
    return m ? Number(m[1]) : new Date().getFullYear();
  }

  function validDate(year, month, day, hour = 23, minute = 59) {
    year = Number(year); month = Number(month); day = Number(day); hour = Number(hour); minute = Number(minute);
    if (year < 2000 || year > 2100 || month < 1 || month > 12 || day < 1 || day > 31 || hour < 0 || hour > 23 || minute < 0 || minute > 59) return null;
    const d = new Date(year, month - 1, day, hour, minute, 0, 0);
    if (d.getFullYear() !== year || d.getMonth() !== month - 1 || d.getDate() !== day) return null;
    return d;
  }

  function parseDateCandidate(text, baseYear) {
    const s = norm(text);
    if (!s) return null;

    let m = s.match(/(?:trước\s*)?(\d{1,2})\s*(?:giờ|h|:)\s*(\d{1,2})?(?:\s*phút)?\s*(?:,?\s*ngày\s*)?(\d{1,2})[\/.\-](\d{1,2})(?:[\/.\-](\d{2,4}))?/i);
    if (m) {
      let y = m[5] ? Number(m[5]) : Number(baseYear);
      if (y < 100) y += 2000;
      const d = validDate(y, m[4], m[3], m[1], m[2] || 0);
      if (d) return { dueAt: d.getTime(), timeExplicit: true, matchedText: m[0] };
    }

    m = s.match(/(?:ngày\s*)?(\d{1,2})[\/.\-](\d{1,2})(?:[\/.\-](\d{2,4}))?(?:\s+(?:lúc\s*)?(\d{1,2})\s*(?::|giờ|h)\s*(\d{1,2})?)?/i);
    if (m) {
      let y = m[3] ? Number(m[3]) : Number(baseYear);
      if (y < 100) y += 2000;
      const d = validDate(y, m[2], m[1], m[4] == null ? 23 : m[4], m[4] == null ? 59 : (m[5] || 0));
      if (d) return { dueAt: d.getTime(), timeExplicit: m[4] != null, matchedText: m[0] };
    }

    m = s.match(/(?:ngày\s*)?(\d{1,2})\s+tháng\s+(\d{1,2})(?:\s+năm\s+(\d{4}))?(?:\s+(?:lúc\s*)?(\d{1,2})\s*(?:giờ|h|:)\s*(\d{1,2})?)?/i);
    if (m) {
      const y = m[3] ? Number(m[3]) : Number(baseYear);
      const d = validDate(y, m[2], m[1], m[4] == null ? 23 : m[4], m[4] == null ? 59 : (m[5] || 0));
      if (d) return { dueAt: d.getTime(), timeExplicit: m[4] != null, matchedText: m[0] };
    }
    return null;
  }

  function findInstructionDeadline(instruction, baseYear) {
    const text = norm(instruction);
    if (!text) return null;
    const dateRe = /(?:\d{1,2}\s*(?:giờ|h|:)\s*\d{0,2}\s*(?:,?\s*ngày\s*)?\d{1,2}[\/.\-]\d{1,2}(?:[\/.\-]\d{2,4})?|(?:ngày\s*)?\d{1,2}[\/.\-]\d{1,2}(?:[\/.\-]\d{2,4})?(?:\s+(?:lúc\s*)?\d{1,2}\s*(?::|giờ|h)\s*\d{0,2})?|(?:ngày\s*)?\d{1,2}\s+tháng\s+\d{1,2}(?:\s+năm\s+\d{4})?)/ig;
    const cueRe = /(?:hạn(?:\s+xử\s+lý)?|chậm\s+nhất|trước|hoàn\s+thành|gửi|báo\s+cáo|tham\s+mưu|xử\s+lý|nộp)/i;
    let best = null;
    for (const match of text.matchAll(dateRe)) {
      const start = Math.max(0, match.index - 95);
      const end = Math.min(text.length, match.index + match[0].length);
      const window = text.slice(start, end);
      if (!cueRe.test(window)) continue;
      const parsed = parseDateCandidate(match[0], baseYear);
      if (!parsed) continue;
      if (!best || parsed.dueAt < best.dueAt) best = { ...parsed, evidence: window };
    }
    return best;
  }

  function detect(ctx = {}, instruction = '') {
    const baseYear = baseYearFromContext(ctx);
    const nativeText = norm(ctx.processingDeadline || '');
    if (nativeText) {
      const parsed = parseDateCandidate(nativeText, baseYear);
      if (parsed) return { ...parsed, source: 'ioffice', sourceLabel: 'Hạn xử lý trên iOffice', raw: nativeText };
    }
    const fromInstruction = findInstructionDeadline(instruction, baseYear);
    if (fromInstruction) return { ...fromInstruction, source: 'instruction', sourceLabel: 'Ý kiến đề xuất', raw: norm(fromInstruction.matchedText) };
    return null;
  }

  function keyFor(ctx = {}) {
    if (ctx.documentId) return `id:${norm(ctx.documentId)}`;
    return ['doc', ctx.symbol, ctx.documentDate, ctx.sender, ctx.trichYeu].map(norm).join('|').toLowerCase();
  }

  function formatDeadline(deadlineOrMs, withTime = null) {
    const dueAt = typeof deadlineOrMs === 'object' ? Number(deadlineOrMs?.dueAt) : Number(deadlineOrMs);
    const timeExplicit = withTime == null && typeof deadlineOrMs === 'object' ? !!deadlineOrMs.timeExplicit : !!withTime;
    if (!Number.isFinite(dueAt)) return '—';
    const d = new Date(dueAt);
    const date = `${pad2(d.getDate())}/${pad2(d.getMonth() + 1)}/${d.getFullYear()}`;
    return timeExplicit ? `${date} ${pad2(d.getHours())}:${pad2(d.getMinutes())}` : date;
  }

  function remainingText(task, now = Date.now()) {
    if (!task || task.status === 'completed') return 'Đã hoàn thành';
    const diff = Number(task.dueAt) - now;
    if (!Number.isFinite(diff)) return '—';
    const absHours = Math.abs(diff) / 36e5;
    if (diff < 0) {
      if (absHours < 24) return `Quá hạn ${Math.max(1, Math.ceil(absHours))} giờ`;
      return `Quá hạn ${Math.ceil(absHours / 24)} ngày`;
    }
    if (absHours < 24) return `Còn ${Math.max(1, Math.ceil(absHours))} giờ`;
    return `Còn ${Math.ceil(absHours / 24)} ngày`;
  }


  async function cloudConfig() {
    const raw = await chrome.storage.local.get({ deadlineCloudEnabled: false, deadlineCloudEndpoint: '', deadlineCloudToken: '', deadlineSheetUrl: '' });
    return { enabled: raw.deadlineCloudEnabled === true, endpoint: norm(raw.deadlineCloudEndpoint), token: norm(raw.deadlineCloudToken), sheetUrl: norm(raw.deadlineSheetUrl) };
  }

  function runtimeMessage(message) {
    return new Promise((resolve) => {
      try {
        chrome.runtime.sendMessage(message, (response) => {
          if (chrome.runtime.lastError) return resolve({ ok: false, error: chrome.runtime.lastError.message });
          resolve(response || { ok: false, error: 'Không có phản hồi.' });
        });
      } catch (e) { resolve({ ok: false, error: e?.message || String(e) }); }
    });
  }

  async function cloudRequest(action, payload = {}) {
    const config = await cloudConfig();
    if (!config.enabled || !config.endpoint) return { ok: false, skipped: true, error: 'cloud-disabled' };
    return runtimeMessage({ type: 'DEADLINE_CLOUD_REQUEST', action, config, payload });
  }

  async function markCloudState(key, patch = {}) {
    const tasks = await getTasks();
    const next = tasks.map((t) => t.key === key ? { ...t, ...patch } : t);
    await writeTasks(next);
  }

  async function syncTask(task) {
    if (!task?.key) return { ok: false, skipped: true };
    const result = await cloudRequest('upsert', { task });
    await markCloudState(task.key, result?.ok ? { cloudSyncedAt: Date.now(), cloudSyncError: '' } : { cloudSyncError: result?.skipped ? '' : norm(result?.error || 'Không đồng bộ được') });
    return result;
  }

  async function getTasks() {
    const raw = await chrome.storage.local.get({ [STORAGE_KEY]: [] });
    return Array.isArray(raw[STORAGE_KEY]) ? raw[STORAGE_KEY] : [];
  }

  async function writeTasks(tasks) {
    const clean = (Array.isArray(tasks) ? tasks : []).slice(0, MAX_TASKS);
    await chrome.storage.local.set({ [STORAGE_KEY]: clean });
    return clean;
  }

  async function upsert(ctx, suggestion = {}, deadline = null) {
    deadline = deadline || detect(ctx, suggestion.instruction || '');
    if (!deadline) return { saved: false, reason: 'no-deadline' };
    const tasks = await getTasks();
    const key = keyFor(ctx);
    const now = Date.now();
    const previous = tasks.find((x) => x.key === key);
    const task = {
      key,
      documentId: norm(ctx.documentId),
      symbol: norm(ctx.symbol),
      trichYeu: norm(ctx.trichYeu),
      sender: norm(ctx.sender),
      documentDate: norm(ctx.documentDate),
      receivedDate: norm(ctx.receivedDate),
      processingDeadline: norm(ctx.processingDeadline),
      dueAt: Number(deadline.dueAt),
      timeExplicit: !!deadline.timeExplicit,
      deadlineText: formatDeadline(deadline),
      deadlineSource: deadline.source,
      deadlineSourceLabel: deadline.sourceLabel,
      deadlineRaw: norm(deadline.raw),
      instruction: norm(suggestion.instruction),
      mainUnit: norm(suggestion.mainUnit),
      coordinationUnits: Array.isArray(suggestion.coordinationUnits) ? suggestion.coordinationUnits.slice() : [],
      viewUnits: Array.isArray(suggestion.viewUnits) ? suggestion.viewUnits.slice() : [],
      status: previous?.status === 'completed' && Number(previous?.dueAt) === Number(deadline.dueAt) ? 'completed' : 'pending',
      completedAt: previous?.status === 'completed' && Number(previous?.dueAt) === Number(deadline.dueAt) ? previous.completedAt : null,
      createdAt: previous?.createdAt || now,
      updatedAt: now,
      documentUrl: location.href
    };
    const next = [task, ...tasks.filter((x) => x.key !== key)].sort((a, b) => {
      const ad = a.status === 'completed' ? 1 : 0, bd = b.status === 'completed' ? 1 : 0;
      return ad - bd || Number(a.dueAt || 0) - Number(b.dueAt || 0);
    });
    await writeTasks(next);
    void syncTask(task);
    return { saved: true, task, updated: !!previous };
  }

  async function setStatus(key, status) {
    const tasks = await getTasks();
    const now = Date.now();
    const next = tasks.map((t) => t.key === key ? { ...t, status: status === 'completed' ? 'completed' : 'pending', completedAt: status === 'completed' ? now : null, updatedAt: now } : t);
    await writeTasks(next);
    const changed = next.find((t) => t.key === key);
    if (changed) void syncTask(changed);
    return next;
  }

  async function remove(key) {
    const tasks = await getTasks();
    const existing = tasks.find((t) => t.key === key);
    const next = await writeTasks(tasks.filter((t) => t.key !== key));
    if (existing) void cloudRequest('delete', { key });
    return next;
  }

  function stats(tasks, now = Date.now()) {
    const list = Array.isArray(tasks) ? tasks : [];
    const pending = list.filter((t) => t.status !== 'completed');
    return {
      total: list.length,
      pending: pending.length,
      overdue: pending.filter((t) => Number(t.dueAt) < now).length,
      dueSoon: pending.filter((t) => Number(t.dueAt) >= now && Number(t.dueAt) - now <= 48 * 36e5).length,
      completed: list.filter((t) => t.status === 'completed').length
    };
  }

  globalThis.IOfficeDeadlineTracker = { STORAGE_KEY, detect, keyFor, formatDeadline, remainingText, getTasks, writeTasks, upsert, setStatus, remove, stats, cloudConfig, cloudRequest, syncTask };
})();
