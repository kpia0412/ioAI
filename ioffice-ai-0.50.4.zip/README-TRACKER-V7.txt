iOffice AI 0.50.4 — AUTO UPDATE — tương thích Tracker V7

- Nâng cấp trực tiếp từ 0.50.2, giữ nguyên cấu hình nếu vẫn dùng đúng thư mục Load unpacked và cùng ID tiện ích.
- Tự kiểm tra GitHub mỗi 5 phút. Khi có bản mới, tự tải, kiểm tra SHA-256, sao lưu và thay tệp.
- Nếu iOffice đang phân tích hoặc có nội dung chưa lưu, cập nhật được hoãn và tự thử lại.
- Sau khi cập nhật thành công, tiện ích tự Reload và tự làm mới các tab iOffice đã được đánh dấu an toàn.
- Cần cài Native Helper trên Windows một lần bằng bộ cài đi kèm.


0.50.4: AI bật/tắt; phân luồng thủ công luôn hiện; Sổ theo dõi luôn bật và bắt buộc hạn xử lý; XLC Tracker bám mục 1; ý kiến chỉ đạo AI rút gọn.
