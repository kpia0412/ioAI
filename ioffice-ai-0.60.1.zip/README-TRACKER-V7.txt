iOffice AI 0.60.1 — Local Rule Pro 0.60.0 — Tracker 7.0.15

NÂNG CẤP
Được tạo từ bản đầy đủ 0.50.5, tích hợp nguyên bộ rule 0.60.0-local-rule-pro.
Giữ luồng chọn đơn vị Liên thông nội bộ, Ý kiến chỉ đạo và các thiết lập hiện có.

GIAO DIỆN
- Tự bật Thêm vào Sổ theo dõi khi kết quả phân tích có hạn; có thể chủ động tắt.
- Nút chưa bật màu đỏ, đã bật màu xanh; Hạn xử lý và XLC lớn hơn.
- Chọn hạn thủ công cũng bật theo dõi. Xóa hạn thì tắt, không tự khôi phục hạn cũ.
- Mở sổ theo dõi không tải lại iOffice. Đóng sổ mới tải lại trang nhận diện VB đi/đến.
- Không hiển thị thông báo danh sách rỗng trong lúc đang tải hoặc lỗi tải.

GỬI NGẦM VÀ LỊCH SỬ
Trước khi tiện ích bấm Chuyển, nhiệm vụ được lưu bền vững trong máy.
Sau khi nhận diện cửa sổ Chuyển đã đóng, tiện ích chuyển nhiệm vụ vào hàng đợi gửi ngầm.
Có thể mở văn bản khác khi đã vào hàng đợi; tiến trình nền tiếp tục gửi.
Lịch sử gửi Sổ ở góc dưới bên trái hiển thị số văn bản, nội dung, giờ và mã nhiệm vụ.
Chỉ báo Đã gửi hoàn tất khi Tracker trả mã nhiệm vụ hợp lệ.
Nếu tải lại trang trước khi xác nhận được Chuyển: mở Lịch sử, kiểm tra văn bản thực sự
đã chuyển trên iOffice rồi bấm Đã chuyển iOffice · Gửi vào Sổ; chưa chuyển thì hủy lượt gửi.
Nếu mất mạng/mất phản hồi: báo Chưa xác định kết quả và mở cổng quản lý kiểm tra.
Không tự gửi lại yêu cầu chưa rõ kết quả vì Tracker 7.0.15 không có khóa chống tạo trùng.
Nếu chắc chắn chưa có nhiệm vụ, tạo thủ công trên cổng quản lý.
Hàng đợi và lịch sử nằm trên máy hiện tại, gắn với URL/TOKEN đang cấu hình.
Giữ Chrome mở để gửi; hàng đợi chưa bắt đầu được tiếp tục khi tiến trình nền hoạt động lại.
Cơ chế này áp dụng cho nút Chuyển do tiện ích điều khiển; không tự bắt mọi thao tác
bấm trực tiếp nút Chuyển gốc của iOffice ở ngoài luồng tiện ích.

CẬP NHẬT GITHUB
1. Đưa ioffice-ai-0.60.1.zip lên thư mục gốc repo ioAI.
2. Sau khi ZIP đã có trên GitHub Pages, thay latest.json bằng tệp đi kèm.
3. Máy dùng bộ cập nhật Windows đã cài sẽ kiểm tra và tải theo cơ chế hiện có.
URL ZIP: https://kpia0412.github.io/ioAI/ioffice-ai-0.60.1.zip
URL JSON: https://kpia0412.github.io/ioAI/latest.json
Giữ nguyên tên ZIP để khớp JSON và SHA-256. Không sửa ZIP sau khi tạo JSON.
Nếu cập nhật thủ công, giải nén đè đúng thư mục hiện tại rồi Reload tiện ích và F5 iOffice.
Không gỡ tiện ích; cùng ID/thư mục sẽ giữ các thiết lập trong chrome.storage.
Không cần tạo lại Sheet hay thay Tracker 7.0.15. Không đưa TOKEN vào GitHub.

NÚT CẬP NHẬT NGAY
Từ 0.60.1, thông báo và Cấu hình luôn có Đồng ý cập nhật ngay khi có phiên bản mới,
kể cả đang bật tự động. Sau xác nhận, có thể bỏ qua trạng thái văn bản chưa lưu;
nội dung chưa lưu trên các tab iOffice có thể mất khi tải lại.
Vẫn chờ nếu AI đang chạy, đang chuyển văn bản hoặc có nhiệm vụ trong hàng đợi gửi.
Nút mới chỉ xuất hiện sau khi đã cài 0.60.1; để nâng từ 0.50.5 lần đầu vẫn dùng
cơ chế cập nhật cũ hoặc giải nén thủ công. Cần giữ bộ hỗ trợ Windows đã cài;
gói này không chứa bộ cài Native Helper.

KIỂM TRA
- 12/12 kiểm thử hồi quy rule từ bộ 0.60.0.
- Kiểm thử mô phỏng lưu trước chuyển, gửi thành công, chống bấm trùng, khởi động lại,
  mất phản hồi không gửi lặp, khôi phục hàng đợi, hủy bản chờ.
- Kiểm thử trạng thái hạn, nút bật/tắt, mở/đóng sổ và thông báo tải/rỗng.
- Kiểm thử cập nhật: tự động chờ nội dung chưa lưu; chủ động cập nhật có xác nhận;
  không cập nhật giữa lúc gửi Sổ.
- Toàn bộ JavaScript và JSON kiểm tra cú pháp hợp lệ.
Đã đối chiếu API trong mã nguồn Tracker 7.0.15; chưa thử trên phiên iOffice và
Apps Script thực tế của người dùng. Chưa kiểm tra hình ảnh giao diện trong Chrome thực.
