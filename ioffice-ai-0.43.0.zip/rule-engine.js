/* iOffice AI · Local nhanh — phân tích văn bản bằng quy tắc cục bộ, không gửi dữ liệu ra ngoài. */
(() => {
  'use strict';

  const VERSION = '0.43.0-local-fast';
  const DAY_MS = 86400000;
  const norm = (v) => String(v || '')
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .replace(/đ/g, 'd').replace(/Đ/g, 'D')
    .toLowerCase().replace(/\s+/g, ' ').trim();
  const clean = (v) => String(v || '').replace(/\r/g, '').replace(/[ \t]+/g, ' ').replace(/\n{3,}/g, '\n\n').trim();
  const uniq = (a) => [...new Set((a || []).filter(Boolean))];
  const arr = (v) => Array.isArray(v) ? v : [];
  const cap = (v, n=220) => { const s=clean(v); return s.length>n ? s.slice(0,n-1).trimEnd()+'…' : s; };

  const DIRECT_SUBJECT_PATTERNS = [
    /\bubnd\s+(?:xa|cac xa|cac xa, phuong|cac xa phuong)\b/i,
    /\buy ban nhan dan\s+(?:xa|cac xa|cac xa, phuong|cac xa phuong)\b/i,
    /\bxa\s+ea\s+ly\b/i,
    /\bubnd\s+xa\s+ea\s+ly\b/i,
    /\bcac\s+xa,?\s*phuong\b/i,
    /\buy ban nhan dan cac xa,?\s*phuong\b/i,
    /\bcac dia phuong\b/i
  ];
  const OTHER_SUBJECT_PATTERNS = [
    /\bdoi voi\s+(?:trung tam y te|benh vien|cac truong|nha truong|so\b|cac so\b|don vi truc thuoc|co quan chuyen mon)/i,
    /\btrung tam y te\b/i, /\bbenh vien\b/i, /\bcac truong\b/i,
    /\bso\s+[a-z]/i, /\bphong\s+nghiep vu\b/i
  ];
  const ACTION_PATTERNS = [
    /\bbao cao\b/i, /\bcung cap\b/i, /\bgui\b/i, /\bco y kien\b/i, /\btham gia y kien\b/i,
    /\bgop y\b/i, /\bphan bien\b/i, /\bxac nhan\b/i, /\bra soat\b/i, /\btham muu\b/i,
    /\bxay dung\b/i, /\blap ke hoach\b/i, /\bto chuc thuc hien\b/i, /\btrien khai\b/i,
    /\bniem yet\b/i, /\bcong khai\b/i, /\bbo tri\b/i, /\bkiem tra\b/i, /\bthong ke\b/i,
    /\btong hop\b/i, /\bdang ky\b/i, /\bcu\s+(?:can bo|cong chuc|dai bieu|nguoi)\b/i,
    /\btham du\b/i, /\btham gia\b/i, /\btuyen truyen\b/i, /\bpho bien\b/i,
    /\bhoan thanh\b/i, /\bcap nhat\b/i, /\bkhac phuc\b/i, /\bde xuat\b/i, /\bthuc hien\b/i
  ];
  const PRODUCT_PATTERNS = [
    /\bbao cao\b/i, /\bdanh sach\b/i, /\bbieu mau\b/i, /\bso lieu\b/i, /\bvan ban\b/i,
    /\by kien\b/i, /\bke hoach\b/i, /\bket qua\b/i, /\bho so\b/i, /\bphuong an\b/i,
    /\bdu thao\b/i, /\bbien ban\b/i, /\bniem yet\b/i, /\bxac nhan\b/i
  ];
  const COORDINATION_PATTERNS = [
    /\bphoi hop\s+(?:voi\s+)?ubnd\b/i,
    /\bphoi hop\s+(?:voi\s+)?uy ban nhan dan\b/i,
    /\blam viec\s+voi\s+(?:chu tich\s+)?ubnd\b/i,
    /\bde nghi\s+ubnd\s+.*\s+phoi hop\b/i,
    /\bde nghi\s+uy ban nhan dan\s+.*\s+phoi hop\b/i,
    /\bho tro\s+khi\b/i,
    /\bkhi\s+co\s+yeu\s+cau\b/i,
    /\bkhi\s+[^.;\n]{0,80}\s+de\s+nghi\b/i,
    /\btheo\s+de\s+nghi\s+cua\b/i
  ];
  const INFORMATION_PATTERNS = [
    /\bde biet\b/i, /\bnghien cuu,?\s*trien khai thuc hien theo quy dinh\b/i,
    /\bgui .* de nghien cuu\b/i, /\bthong tin den\b/i, /\bpho bien de biet\b/i
  ];
  const DEADLINE_CUES = /(?:truoc|cham nhat|hoan thanh|gui|bao cao|nop|phan hoi|co y kien|ket thuc|den het|thoi han)/i;

  function foldLines(text) {
    return clean(text).split(/\n+/).map((raw, index) => ({ raw:clean(raw), n:norm(raw), index })).filter(x=>x.raw);
  }
  function sentences(text) {
    return clean(text).split(/(?<=[.!?;:])\s+|\n+/).map(clean).filter(x=>x.length>=12);
  }
  function hasAny(text, patterns) { const n=norm(text); return patterns.some(r=>r.test(n)); }
  function phraseMatches(haystack, phrases) {
    const h = norm(haystack); if (!h) return [];
    return uniq(arr(phrases).filter(raw => { const p=norm(raw); return p && h.includes(p); }).map(String));
  }
  function cleanRule(rule) {
    const weights = rule?.weights || {};
    return {
      ...rule, enabled: rule?.enabled !== false, priority:Number(rule?.priority||0), minScore:Math.max(0,Number(rule?.minScore||0)),
      match:{senderAny:arr(rule?.match?.senderAny),subjectAny:arr(rule?.match?.subjectAny),contentAny:arr(rule?.match?.contentAny),attachmentAny:arr(rule?.match?.attachmentAny),excludeAny:arr(rule?.match?.excludeAny)},
      weights:{sender:Number(weights.sender??18),subject:Number(weights.subject??14),content:Number(weights.content??9),attachment:Number(weights.attachment??5)}
    };
  }
  function categoryScore(matches, weight, capMatches=3) { return Math.min(capMatches,matches.length)*Math.max(0,Number(weight)||0); }

  function bundleText(context) {
    const b=context?.documentBundle||{};
    return clean([
      b?.primaryDocument?.text || '',
      ...arr(b?.supportingDocuments).map(x=>x?.text||''),
      context?.previewText || '',
      b?.combinedText || ''
    ].filter(Boolean).join('\n'));
  }

  function looksHeading(line) {
    const s=clean(line), n=norm(s);
    if (!s || s.length>180) return false;
    if (/^(?:\d+|[ivxlcdm]+)[.)\-:]\s+/i.test(s)) return true;
    if (/^(?:doi voi|ubnd|uy ban nhan dan|cac xa|cac so|cac don vi|trung tam|benh vien|cac truong|nha truong)\b/i.test(n)) return true;
    return /:$/.test(s) && s.length<130;
  }

  function classifyHeadingSubject(line) {
    let n=norm(line);
    if (!n) return 'unknown';
    n=n.replace(/^(?:\d+|[ivxlcdm]+)[.)\-:]\s*/i,'').replace(/^[-–•]\s*/,'');
    // Chỉ coi chủ thể là “rõ” khi nằm ở đầu dòng/tiêu đề. Không để cụm như “báo cáo Sở ...”
    // ở cuối một nhiệm vụ của UBND xã làm đổi nhầm chủ thể sang Sở.
    if (/^(?:doi voi\s+)?(?:ubnd|uy ban nhan dan)\s+(?:xa\s+ea\s+ly|(?:cac\s+)?xa(?:,?\s*phuong)?|cac dia phuong)\b/i.test(n) || /^(?:doi voi\s+)?cac\s+(?:xa|dia phuong)\b/i.test(n)) return 'ealy';
    if (/^(?:doi voi\s+)?(?:trung tam y te|benh vien|cac truong|nha truong|cac so\b|so\s+[a-z]|don vi truc thuoc|co quan chuyen mon|phong nghiep vu)\b/i.test(n)) return 'other';
    return 'unknown';
  }

  function buildScopedLines(text) {
    const lines=foldLines(text); let scope='unknown'; let heading='';
    return lines.map(x=>{
      if (looksHeading(x.raw)) {
        const hscope=classifyHeadingSubject(x.raw);
        if (hscope!=='unknown') { scope=hscope; heading=x.raw; }
      }
      const explicit=classifyHeadingSubject(x.raw);
      return {...x, scope:explicit!=='unknown'?explicit:scope, heading};
    });
  }

  function documentTargetsEa(text) {
    const n=norm(String(text||'').slice(0,12000));
    if(!n) return false;
    // Chỉ dùng “Kính gửi” như prior khi không có tiêu đề chủ thể cụ thể hơn ở đoạn đang xét.
    return /kinh gui.{0,700}(?:ubnd|uy ban nhan dan)\s+(?:(?:cac\s+)?xa(?:,?\s*phuong)?|xa\s+ea\s+ly)\b/i.test(n)
      || /kinh gui.{0,700}cac\s+dia\s+phuong\b/i.test(n);
  }

  function parseDate(day, month, year) {
    let y=Number(year),m=Number(month),d=Number(day); if(y<100)y+=2000;
    const dt=new Date(y,m-1,d); if(dt.getFullYear()!==y||dt.getMonth()!==m-1||dt.getDate()!==d)return null;
    return `${y}-${String(m).padStart(2,'0')}-${String(d).padStart(2,'0')}`;
  }
  function addDaysIso(iso, count, working=false) {
    const m=String(iso||'').match(/^(\d{4})-(\d{2})-(\d{2})$/); if(!m)return '';
    const d=new Date(Number(m[1]),Number(m[2])-1,Number(m[3])); let left=Math.max(0,Number(count)||0);
    while(left>0){d.setDate(d.getDate()+1); if(!working || ![0,6].includes(d.getDay()))left--;}
    return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
  }
  function extractDeadline(text, documentDate='') {
    const raw=clean(text), n=norm(raw);
    const explicit=[];
    const pushExplicit=(match, day, month, year)=>{
      const iso=parseDate(day,month,year); if(!iso)return;
      explicit.push({iso,index:match.index||0,evidence:raw.slice(Math.max(0,(match.index||0)-90),Math.min(raw.length,(match.index||0)+match[0].length+110))});
    };
    // Dạng 30/09/2026, có hoặc không kèm giờ: “trước 16h30 ngày ...”, “chậm nhất ngày ...”.
    const reNumeric=/(?:truoc\s+(?:(?:\d{1,2})\s*(?:gio|h)(?:\s*\d{1,2})?\s*)?ngay|cham\s+nhat\s+(?:vao\s+)?ngay|den\s+het\s+ngay|den\s+ngay|hoan\s+thanh\s+truoc\s+ngay|gui\s+[^.;\n]{0,80}?truoc\s+ngay|bao\s+cao\s+[^.;\n]{0,80}?truoc\s+ngay)\s+(\d{1,2})[\/\-.](\d{1,2})[\/\-.](\d{2,4})/gi;
    let m; while((m=reNumeric.exec(n))) pushExplicit(m,m[1],m[2],m[3]);
    // Dạng “trước ngày 30 tháng 9 năm 2026”.
    const reWords=/(?:truoc\s+ngay|cham\s+nhat\s+(?:vao\s+)?ngay|den\s+het\s+ngay|den\s+ngay|hoan\s+thanh\s+truoc\s+ngay)\s+(\d{1,2})\s+thang\s+(\d{1,2})\s+nam\s+(\d{4})/gi;
    while((m=reWords.exec(n))) pushExplicit(m,m[1],m[2],m[3]);
    if(explicit.length){
      explicit.sort((a,b)=>a.index-b.index); const x=explicit[0];
      return{deadline:x.iso,deadlineText:x.iso,deadlineEvidence:cap(x.evidence,280),deadlineSource:'document',certainty:'high'};
    }
    const rel=n.match(/(?:trong\s+(?:vong|thoi\s+han)\s+)(\d{1,3})\s+ngay(\s+lam\s+viec)?(?:\s+ke\s+tu\s+([^.;\n]{0,120}))?/i);
    if(rel){
      const count=Number(rel[1]),working=!!rel[2],anchor=clean(rel[3]||'');
      let anchorIso=''; const dm=norm(anchor).match(/(\d{1,2})[\/\-.](\d{1,2})[\/\-.](\d{2,4})/); if(dm)anchorIso=parseDate(dm[1],dm[2],dm[3]);
      if(!anchorIso && /ngay ban hanh|ngay ky/.test(norm(anchor)) && /^\d{4}-\d{2}-\d{2}$/.test(documentDate||''))anchorIso=documentDate;
      const deadline=anchorIso?addDaysIso(anchorIso,count,working):'';
      return{deadline,deadlineText:`trong ${count} ngày${working?' làm việc':''}${anchor?` kể từ ${anchor}`:''}`,deadlineEvidence:cap(raw.match(new RegExp(`.{0,90}trong\\s+(?:vong|thoi\\s+han)\\s+${count}\\s+ngay.{0,180}`,'i'))?.[0]||raw,280),deadlineSource:deadline?'derived-explicit-relative':'document',certainty:deadline?'medium':'relative'};
    }
    // Hạn định kỳ không quy đổi thành một ngày tuyệt đối.
    const recurring=n.match(/(?:truoc|cham nhat)\s+ngay\s+(\d{1,2})\s+(?:hang|hằng)\s+(thang|tháng)/i);
    if(recurring)return{deadline:'',deadlineText:`trước ngày ${recurring[1]} hằng tháng`,deadlineEvidence:cap(raw,260),deadlineSource:'document',certainty:'relative'};
    // Chỉ lấy ngày rời khi chính câu có tín hiệu hạn; không lấy mọi ngày xuất hiện trong hồ sơ.
    if(DEADLINE_CUES.test(n)){
      const dm=n.match(/(\d{1,2})[\/\-.](\d{1,2})[\/\-.](\d{2,4})/); if(dm){const iso=parseDate(dm[1],dm[2],dm[3]); if(iso)return{deadline:iso,deadlineText:dm[0],deadlineEvidence:cap(raw,260),deadlineSource:'document',certainty:'medium'};}
    }
    return{deadline:'',deadlineText:'',deadlineEvidence:'',deadlineSource:'none',certainty:'none'};
  }

  function scoreUnits(context, config, availableUnits, content, taskText='') {
    const rules=arr(config?.rules).map(cleanRule).filter(r=>r.enabled&&/^U\d+$/.test(r.mainUnit||''));
    const allowed=new Set((availableUnits||[]).map(u=>u.value||u.id).filter(x=>/^U\d+$/.test(x)));
    for(const u of arr(config?.units))if(/^U\d+$/.test(u.id||''))allowed.add(u.id);
    const attachmentText=arr(context?.attachmentNames).join(' | '), whole=[context?.trichYeu,context?.sender,content,taskText,attachmentText].join('\n');
    const unitScores=new Map(),matched=[]; const coordination=new Map(),view=new Map();
    for(const rule of rules){
      if(!allowed.has(rule.mainUnit)||phraseMatches(whole,rule.match.excludeAny).length)continue;
      const sender=phraseMatches(context?.sender,rule.match.senderAny),subject=phraseMatches(context?.trichYeu,rule.match.subjectAny),body=phraseMatches(`${content}\n${taskText}`,rule.match.contentAny),attachment=phraseMatches(attachmentText,rule.match.attachmentAny);
      const any=rule.match.senderAny.length||rule.match.subjectAny.length||rule.match.contentAny.length||rule.match.attachmentAny.length;
      if(any&&!(sender.length||subject.length||body.length||attachment.length))continue;
      let score=5+categoryScore(sender,rule.weights.sender,2)+categoryScore(subject,rule.weights.subject,3)+categoryScore(body,rule.weights.content,5)+categoryScore(attachment,rule.weights.attachment,2)+Math.max(0,Math.min(10,rule.priority/20));
      if(score<rule.minScore)continue;
      unitScores.set(rule.mainUnit,(unitScores.get(rule.mainUnit)||0)+score);
      for(const id of arr(rule.coordinationUnits))if(allowed.has(id)&&id!==rule.mainUnit)coordination.set(id,(coordination.get(id)||0)+score);
      for(const id of arr(rule.viewUnits))if(allowed.has(id)&&id!==rule.mainUnit)view.set(id,(view.get(id)||0)+score);
      matched.push({rule,score,sender,subject,body,attachment});
    }
    const n=norm(`${context?.trichYeu||''}\n${taskText}\n${content.slice(0,12000)}`);
    const directBoost=(id,rx,points=80)=>{if(allowed.has(id)&&rx.test(n))unitScores.set(id,(unitScores.get(id)||0)+points);};
    directBoost('U221',/(?:giao|de nghi|yeu cau)\s+truong\s+(?:thcs|trung hoc co so)\s+ea\s+ly/,150);
    directBoost('U222',/(?:giao|de nghi|yeu cau)\s+truong\s+tieu hoc\s+ea\s+ly/,150);
    directBoost('U240',/(?:giao|de nghi|yeu cau)\s+truong\s+(?:mau giao|mam non)\s+ea\s+ly/,150);
    directBoost('U200',/(?:giao|de nghi|yeu cau)\s+tram\s+y\s+te\s+(?:xa\s+)?ea\s+ly/,150);
    directBoost('U120',/(?:trung tam phuc vu hanh chinh cong|bo phan mot cua|tra ket qua|tiep nhan ho so)/,60);
    // Từ điển chức năng cấp xã bổ sung để Local nhanh vẫn phân loại được khi routing-rules chưa có cụm từ cụ thể.
    directBoost('U140',/(?:tiep cong dan|khieu nai|to cao|phong chong tham nhung|pho bien giao duc phap luat|ho tich|chung thuc|phap che|lich cong tac|lich hop|thong bao ket luan|doi ngoai)/,42);
    directBoost('U141',/(?:dat dai|quyen su dung dat|gcnqsd|tai nguyen|moi truong|nong nghiep|lam nghiep|thuy loi|phong chong thien tai|mua lon|ngap lut|tai chinh|ngan sach|du toan|quyet toan|dau tu cong|tai san cong|xay dung|giao thong|cong thuong|thuong mai|cap nuoc|cum cong nghiep|vat lieu xay dung)/,42);
    directBoost('U142',/(?:noi vu|cai cach hanh chinh|cchc|van thu luu tru|giao duc|dao tao|y te|dan so|lao dong|nguoi co cong|bao tro xa hoi|an sinh xa hoi|van hoa|the thao|du lich|cong nghe thong tin|chuyen doi so|khoa hoc cong nghe|doi moi sang tao)/,42);
    directBoost('U340',/(?:an ninh trat tu|antt|phong chay chua chay|pccc|cuu nan cuu ho|an toan giao thong|atgt|cu tru|toi pham|ma tuy)/,55);
    directBoost('U360',/(?:quoc phong|quan su|nghia vu quan su|nvqs|dan quan tu ve|du bi dong vien|san sang chien dau|phong thu dan su)/,55);
    directBoost('U260',/(?:hoi dong nhan dan|hdnd|thuong truc hdnd|ban hdnd)/,55);
    const senderN=norm(context?.sender||'');
    if(/so tai chinh|kho bac|thue/.test(senderN)&&allowed.has('U141'))unitScores.set('U141',(unitScores.get('U141')||0)+24);
    if(/so noi vu|so giao duc|so y te|so van hoa|so khoa hoc/.test(senderN)&&allowed.has('U142'))unitScores.set('U142',(unitScores.get('U142')||0)+18);
    if(/cong an/.test(senderN)&&allowed.has('U340'))unitScores.set('U340',(unitScores.get('U340')||0)+16);
    if(/bo chi huy quan su|quan su/.test(senderN)&&allowed.has('U360'))unitScores.set('U360',(unitScores.get('U360')||0)+16);
    const ranking=[...unitScores.entries()].sort((a,b)=>b[1]-a[1]);
    const main=ranking[0]?.[0] || (allowed.has('U140')?'U140':([...allowed][0]||null));
    const top=ranking[0]?.[1]||0, second=ranking[1]?.[1]||0;
    const coord=[...coordination.entries()].filter(([id])=>id!==main).sort((a,b)=>b[1]-a[1]).filter(([,s])=>s>=Math.max(18,top*.2)).slice(0,4).map(([id])=>id);
    return{mainUnit:main,coordinationUnits:uniq(coord),viewUnits:[],ranking,top,second,matched:matched.sort((a,b)=>b.score-a.score)};
  }

  function findTaskCandidates(context, text) {
    const scoped=buildScopedLines(text); const candidates=[]; const addressedToEa=documentTargetsEa(text);
    for(let i=0;i<scoped.length;i++){
      const x=scoped[i];
      // Tiêu đề chỉ xác lập chủ thể cho các gạch đầu dòng sau, không bao giờ tự biến thành nhiệm vụ.
      if(looksHeading(x.raw)) continue;
      const lineN=norm(x.raw);
      if(!hasAny(lineN,ACTION_PATTERNS))continue;
      const explicitSubject=classifyHeadingSubject(x.raw);
      const appliesToEa = explicitSubject==='ealy'
        || (explicitSubject==='unknown' && x.scope==='ealy')
        || (explicitSubject==='unknown' && x.scope==='unknown' && addressedToEa);
      const blocked = explicitSubject==='other' || (x.scope==='other' && explicitSubject!=='ealy');
      if(!appliesToEa || blocked)continue;
      const informational=INFORMATION_PATTERNS.some(r=>r.test(lineN));
      const coordination=COORDINATION_PATTERNS.some(r=>r.test(lineN));
      const product=PRODUCT_PATTERNS.some(r=>r.test(lineN));
      const strongProduct=/\b(bao cao|cung cap|gui|xac nhan|co y kien|tham gia y kien|gop y|danh sach|so lieu|van ban|ket qua|ke hoach|phuong an|du thao)\b/i.test(lineN);
      const operational=/\b(to chuc thuc hien|trien khai|niem yet|kiem tra|ra soat|bo tri|cap nhat|xay dung|tong hop|bao cao|cung cap|co y kien|xac nhan|dang ky|cu\s+(?:can bo|cong chuc|dai bieu|nguoi)|tham du)\b/i.test(lineN);
      const coordinationOnly=coordination&&!strongProduct;
      const direct=!informational&&!coordinationOnly&&(product||operational);
      if(!direct&&!coordinationOnly)continue;

      // Hạn ưu tiên ngay trong chính dòng nhiệm vụ. Chỉ ghép dòng sau nếu nó là dòng “Hạn/Thời hạn/Hoàn thành...”,
      // tuyệt đối không lấy hạn của nhiệm vụ trước hoặc mục chủ thể kế bên.
      let deadlineText=x.raw;
      const next=scoped[i+1];
      if(next && next.scope===x.scope && !looksHeading(next.raw) && !extractDeadline(x.raw,context?.documentDate||'').deadlineText
         && /^(?:han|thoi han|hoan thanh|gui|bao cao|cham nhat|truoc)\b/i.test(norm(next.raw))) deadlineText += ' ' + next.raw;
      const deadline=extractDeadline(deadlineText,context?.documentDate||'');
      candidates.push({raw:cap(x.raw,420),window:cap(deadlineText,700),scope:direct?'direct':'coordination',deadline,heading:x.heading});
    }
    const out=[]; const seen=new Set();
    for(const c of candidates){const k=norm(c.raw).replace(/\d+/g,'#').slice(0,120); if(!k||seen.has(k))continue;seen.add(k);out.push(c);}
    return out.slice(0,8);
  }

  function taskLabel(text, subject='') {
    let s=clean(text).replace(/^[-–•\d.)\s]+/,'').replace(/^(?:ubnd|uy ban nhan dan)\s+(?:cac\s+)?xa,?\s*phuong\s*[:,-]?\s*/i,'');
    s=s.replace(/^(?:de nghi|yeu cau|giao)\s+/i,'');
    s=s.replace(/^(?:cac\s+don\s+vi|cac\s+co\s+quan,?\s*don\s+vi|cac\s+dia\s+phuong)\s+/i,'');
    if(s.length<18)s=clean(subject)||s;
    return cap(s,220);
  }

  function summaryFrom(context,text,candidates,scope) {
    if(candidates.some(x=>x.scope==='direct')) return `Văn bản có yêu cầu trực tiếp đối với UBND xã; phát hiện ${candidates.filter(x=>x.scope==='direct').length} nội dung cần thực hiện${candidates.some(x=>x.deadline?.deadline||x.deadline?.deadlineText)?' và có thông tin thời hạn':''}.`;
    if(scope==='coordination') return 'Văn bản chủ yếu giao cơ quan/đơn vị khác chủ trì; UBND xã được nêu ở vai trò phối hợp, chưa phát hiện sản phẩm độc lập phải nộp.';
    const first=sentences(text).find(s=>s.length>=30&&!/cong hoa xa hoi|doc lap - tu do|kinh gui/i.test(norm(s)));
    return cap(first||context?.trichYeu||'Văn bản nhận để nghiên cứu, theo dõi.',280);
  }

  function instructionFor(mainName, candidates, scope, deadline) {
    if(scope==='direct'){
      const t=taskLabel(candidates.find(x=>x.scope==='direct')?.raw||'thực hiện nội dung văn bản');
      const taskN=norm(t), dueDate=deadline?.deadline?deadline.deadline.split('-').reverse().join('/'):'';
      const alreadyHasDue=(dueDate&&taskN.includes(norm(dueDate))) || (deadline?.deadlineText&&taskN.includes(norm(deadline.deadlineText)));
      const due=alreadyHasDue?'':deadline?.deadline?` Hoàn thành trước ngày ${dueDate}.`:deadline?.deadlineText?` Theo dõi thời hạn: ${deadline.deadlineText}.`:'';
      return `Giao ${mainName} chủ trì ${t.charAt(0).toLowerCase()+t.slice(1)}.${due}`.replace(/\.\s*\./g,'.').trim();
    }
    if(scope==='coordination')return `Giao ${mainName} tiếp nhận, theo dõi nội dung và phối hợp khi có yêu cầu; chưa phát sinh báo cáo hoặc sản phẩm độc lập của UBND xã.`;
    return `Giao ${mainName} tiếp nhận, nghiên cứu để biết; chưa phát sinh nhiệm vụ bắt buộc theo văn bản.`;
  }

  function analyzeIncoming(context, config, availableUnits) {
    const text=bundleText(context); const candidates=findTaskCandidates(context,text);
    const direct=candidates.filter(x=>x.scope==='direct'), coord=candidates.filter(x=>x.scope==='coordination');
    let taskScope=direct.length?'direct':coord.length?'coordination':'information';
    // Nếu văn bản nói rõ “để biết” và không có nhiệm vụ trực tiếp, giữ information.
    if(!direct.length&&INFORMATION_PATTERNS.some(r=>r.test(norm(`${context?.trichYeu||''}\n${text.slice(0,12000)}`))))taskScope='information';
    const score=scoreUnits(context,config,availableUnits,text,direct.map(x=>x.raw).join('\n'));
    const units=new Map(arr(config?.units).map(u=>[u.id,u.name]));
    const mainUnit=score.mainUnit; const mainName=units.get(mainUnit)||mainUnit||'đơn vị chuyên môn';
    const tasks=direct.map((c,index)=>{
      const d=c.deadline||{};
      return{task:taskLabel(c.raw,context?.trichYeu),deadline:d.deadline||'',deadlineText:d.deadlineText||'',deadlineEvidence:d.deadlineEvidence||'',deadlineSource:d.deadlineSource||'none',responsibleUnit:mainUnit,scope:'direct',trackRecommended:true,index:index+1};
    });
    const bestDeadline=tasks.find(t=>t.deadline||t.deadlineText)||null;
    const unreadable=Number(context?.documentBundle?.stats?.unreadableCount||0), scan=Number(context?.documentBundle?.stats?.scanSkippedCount||0);
    const structural=direct.length?0.88:coord.length?0.79:0.72;
    const domain=score.top>0?Math.min(.08,score.top/500):0;
    let confidence=Math.min(.96,structural+domain-((unreadable||scan)?0.08:0));
    if(!text||text.length<180)confidence=Math.min(confidence,.58);
    if(!score.top)confidence=Math.min(confidence,.66);
    const requiresReview=confidence<.72||unreadable>0||scan>0;
    const summary=summaryFrom(context,text,candidates,taskScope);
    const topRule=score.matched[0]?.rule?.name||'';
    const signals=[];
    if(direct.length)signals.push(`Phát hiện ${direct.length} yêu cầu trực tiếp áp dụng cho UBND xã.`);
    else if(coord.length)signals.push('UBND xã được nêu ở vai trò phối hợp; không gán hạn của đơn vị chủ trì khác.');
    else signals.push('Không phát hiện câu giao sản phẩm độc lập cho UBND xã trong phần text đã đọc.');
    if(bestDeadline?.deadline||bestDeadline?.deadlineText)signals.push(`Hạn: ${bestDeadline.deadline||bestDeadline.deadlineText}.`);
    if(topRule)signals.push(`Lĩnh vực: ${topRule}.`);
    if(unreadable||scan)signals.push('Có tệp chưa đọc được dạng text; kết quả Local cần kiểm tra lại.');
    return{
      workflow:'leader-incoming',actionRequired:direct.length>0,mainUnit,coordinationUnits:score.coordinationUnits.filter(x=>x!==mainUnit),viewUnits:[],
      instruction:instructionFor(mainName,candidates,taskScope,bestDeadline),tasks,taskScope,trackRecommended:direct.length>0,
      trackingReason:direct.length?'UBND xã có nội dung/sản phẩm trực tiếp cần theo dõi.':taskScope==='coordination'?'UBND xã chỉ phối hợp, chưa có sản phẩm độc lập.':'Không phát hiện nhiệm vụ bắt buộc; lãnh đạo vẫn có thể chủ động tạo nhiệm vụ thủ công.',
      reason:summary,confidence:Number(confidence.toFixed(3)),requiresReview,signals:signals.slice(0,5),recipientNames:[],reviewSummary:'',reviewIssues:[],
      provider:'local-fast',providerLabel:'Local nhanh',model:'Rule Engine '+VERSION,
      localRuleMeta:{version:VERSION,ranking:score.ranking.slice(0,6).map(([unit,s])=>({unit,score:Number(s.toFixed(1))})),candidates:candidates.map(x=>({scope:x.scope,text:x.raw,deadline:x.deadline?.deadline||'',deadlineText:x.deadline?.deadlineText||''})).slice(0,8)}
    };
  }

  function analyzeOutgoing(context) {
    const text=bundleText(context), n=norm(text); const issues=[];
    const add=(severity,category,detail,evidence='')=>issues.push({severity,category,detail,evidence:cap(evidence,220)});
    if(!/cong hoa xa hoi chu nghia viet nam/.test(n))add('medium','Quốc hiệu','Chưa phát hiện dòng “CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM” trong text đọc được.');
    if(!/doc lap\s*[-–]\s*tu do\s*[-–]\s*hanh phuc/.test(n))add('medium','Tiêu ngữ','Chưa phát hiện “Độc lập - Tự do - Hạnh phúc” trong text đọc được.');
    if(!/(?:so|số)\s*[:：]?\s*\d+[\/\-]/i.test(text)&&!context?.symbol)add('medium','Số/Ký hiệu','Chưa phát hiện Số/Ký hiệu rõ ràng.');
    if(!/(?:ngay|ngày)\s+\d{1,2}\s+thang\s+\d{1,2}\s+nam\s+\d{4}/i.test(text)&&!context?.documentDate)add('low','Ngày văn bản','Chưa phát hiện ngày, tháng, năm trong text đọc được.');
    if(!/(kinh gui|kính gửi|noi nhan|nơi nhận)/i.test(text))add('low','Nơi nhận','Chưa phát hiện “Kính gửi” hoặc “Nơi nhận” trong text đọc được.');
    if(!/(chu tich|pho chu tich|tm\.|kt\.|tl\.|t\.l\.|ky thay|ký thay)/i.test(text))add('low','Khối ký','Chưa phát hiện rõ chức danh/khối ký trong phần text đọc được.');
    const unreadable=Number(context?.documentBundle?.stats?.unreadableCount||0),scan=Number(context?.documentBundle?.stats?.scanSkippedCount||0);
    if(unreadable||scan)add('high','Dữ liệu','Có tệp/scan chưa đọc được text; Local nhanh không thể kiểm tra đầy đủ nội dung/trình bày.');
    const confidence=Math.max(.45,Math.min(.93,.88-issues.filter(x=>x.severity==='high').length*.2-issues.filter(x=>x.severity==='medium').length*.06));
    return{workflow:'leader-outgoing',actionRequired:false,mainUnit:null,coordinationUnits:[],viewUnits:[],instruction:'',tasks:[],taskScope:'information',trackRecommended:false,trackingReason:'',recipientNames:[],reviewSummary:issues.length?`Local nhanh phát hiện ${issues.length} điểm cần đối chiếu. Kiểm tra trình bày trực quan PDF vẫn cần người dùng xác nhận.`:'Không phát hiện lỗi đáng chú ý trong phần text kiểm tra tự động. Trình bày trực quan PDF vẫn cần người dùng xác nhận.',reviewIssues:issues,reason:'Đã kiểm tra nhanh FILE TRÌNH KÝ bằng quy tắc cục bộ.',confidence:Number(confidence.toFixed(3)),requiresReview:issues.some(x=>x.severity==='high')||confidence<.72,signals:issues.slice(0,5).map(x=>`${x.category}: ${x.detail}`),provider:'local-fast',providerLabel:'Local nhanh',model:'Rule Engine '+VERSION};
  }

  function analyze(context, config, availableUnits = []) {
    const workflow=String(context?.workflow||context?.analysisWorkflow||'');
    return workflow==='leader-outgoing' ? analyzeOutgoing(context) : analyzeIncoming(context,config,availableUnits);
  }

  globalThis.IOfficeRuleEngine = Object.freeze({ VERSION, analyze, analyzeIncoming, analyzeOutgoing, extractDeadline });
})();
