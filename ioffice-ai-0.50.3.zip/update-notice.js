(() => {
  if (window.top !== window) return;
  let host, message, button, hideTimer, refreshing = false;

  function hideLater(ms = 8000) {
    clearTimeout(hideTimer);
    hideTimer = setTimeout(() => { if (host) host.hidden = true; }, ms);
  }

  function show(text, action = null, label = '') {
    clearTimeout(hideTimer);
    if (!host) {
      host = document.createElement('div');
      host.style.cssText = 'position:fixed;top:16px;left:50%;transform:translateX(-50%);z-index:2147483647;max-width:min(620px,calc(100vw - 24px));width:max-content';
      const root = host.attachShadow({ mode: 'closed' });
      const box = document.createElement('div');
      box.style.cssText = 'background:#123d48;color:white;padding:13px 16px;border-radius:12px;box-shadow:0 8px 28px #0005;font:600 14px/1.5 Arial;display:flex;align-items:center;gap:12px';
      message = document.createElement('div');
      button = document.createElement('button');
      button.style.cssText = 'padding:8px 12px;cursor:pointer;border:0;border-radius:8px;background:#ccf3e0;color:#123d48;font-weight:bold;white-space:nowrap';
      box.append(message, button);
      root.append(box);
      document.documentElement.append(host);
    }
    host.hidden = false;
    message.textContent = text;
    button.hidden = !action;
    button.textContent = label || 'Mở';
    button.disabled = !action;
    button.onclick = action ? event => { if (event.isTrusted) action(); } : null;
  }

  async function render(s = {}) {
    if (refreshing) return;
    const { internetAutoUpdate = true } = await chrome.storage.local.get({ internetAutoUpdate: true });
    if (s.phase === 'applying') {
      show(`⬇ Đang tự tải và cài iOffice AI ${s.version || ''}… giữ Chrome mở.`);
    } else if (s.phase === 'restarting') {
      show(`✓ Đã cài ${s.current || s.version || ''}. Đang nạp lại tiện ích…`);
    } else if (s.phase === 'waiting' && s.newer) {
      show(`⏳ Có bản ${s.version}. ${s.waitReason || 'Đang chờ thời điểm an toàn để tự cập nhật.'}`);
      hideLater(9000);
    } else if (s.newer && internetAutoUpdate) {
      show(`⬆ Đã phát hiện iOffice AI ${s.version}. Hệ thống sẽ tự cập nhật khi trang an toàn.`);
      hideLater(7000);
    } else if (s.newer) {
      show(`iOffice AI có bản ${s.version}.`, async () => {
        button.disabled = true;
        try {
          const r = await chrome.runtime.sendMessage({ type: 'INTERNET_UPDATE_APPLY' });
          if (!r?.ok) throw new Error(r?.error || 'Chưa cập nhật được.');
        } catch (e) {
          show(e.message || 'Chưa cập nhật được.', () => chrome.runtime.sendMessage({ type: 'INTERNET_UPDATE_OPTIONS' }), 'Mở cài đặt');
        }
      }, 'Cập nhật');
    } else if (s.phase === 'installed' && s.justUpdatedAt && Date.now() - Number(s.justUpdatedAt) < 120000) {
      show(`✅ iOffice AI đã tự động cập nhật lên ${s.current || chrome.runtime.getManifest().version}.`);
      hideLater(9000);
    } else if (host) {
      host.hidden = true;
    }
  }

  chrome.storage.local.get('internetUpdate').then(x => render(x.internetUpdate || {}));
  chrome.storage.onChanged.addListener((c, area) => {
    if (area === 'local' && c.internetUpdate) render(c.internetUpdate.newValue || {});
  });
})();
