(() => {
  'use strict';
  const UNITS={U140:'Văn phòng',U141:'Phòng Kinh tế',U142:'Phòng VH-XH',U120:'Trung tâm PVHCC',U183:'Trung tâm Cung ứng',U340:'Công an',U360:'BCHQS',U200:'Trạm Y tế',U221:'THCS',U222:'Tiểu học',U240:'Mẫu giáo',U260:'HĐND'};
  const state={root:null,container:null,matchContainer:null,getContext:()=>({}),notify:()=>{},openTracker:()=>{},tasks:[],loading:false,busy:false,selectedId:'',unitFilter:'all',addOpen:false,message:'',messageKind:'info',matchRun:0,matchBusy:false,stale:false};
  const norm=v=>String(v??'').replace(/\s+/g,' ').trim();
  const fold=v=>norm(v).normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/đ/g,'d').replace(/Đ/g,'D').toLowerCase();
  const esc=v=>String(v??'').replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;').replaceAll("'",'&#039;');
  const viDate=v=>norm(v).replace(/^(\d{4})-(\d{2})-(\d{2})$/,'$3/$2/$1');
  function runtime(message){return new Promise(resolve=>{try{chrome.runtime.sendMessage(message,r=>resolve(chrome.runtime.lastError?{ok:false,error:chrome.runtime.lastError.message}:r||{ok:false,error:'Không có phản hồi từ tiện ích.'}));}catch(e){resolve({ok:false,error:e.message});}});}
  function notice(text,kind='info'){state.message=text;state.messageKind=kind;try{state.notify(text,kind);}catch(_){} }

  function ensureStyle(){
    if(!state.root||state.root.getElementById('trackerBoardStyle'))return;
    const style=document.createElement('style');style.id='trackerBoardStyle';style.textContent=`
      .tracker-board{font-family:Arial,Helvetica,sans-serif;color:#172033}.tb-head{display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:8px}.tb-title{font-size:14px;font-weight:900;color:#17365d}.tb-tools{display:flex;gap:5px}.tb-btn{border:1px solid #d6e0eb;border-radius:9px;background:#fff;color:#31516f;padding:6px 9px;font-size:10px;font-weight:800;cursor:pointer}.tb-btn.primary{background:#0b72d7;color:#fff;border-color:#0b72d7}.tb-btn.warn{background:#fff8e8;color:#8a5a00;border-color:#eed38f}.tb-btn:disabled{opacity:.5;cursor:not-allowed}.tb-board-note{font-size:9.5px;color:#64748b;line-height:1.42;margin:0 0 8px}.tb-filter{width:100%;min-height:36px;padding:6px 8px;border:1px solid #d5dee9;border-radius:9px;background:#fff;font-size:10.5px;margin-bottom:8px}.tb-list{display:grid;gap:7px}.tb-row{border:1px solid #dfe7ef;border-radius:12px;background:#fff;overflow:hidden;transition:.14s ease}.tb-row:hover{border-color:#c6d6e7;box-shadow:0 2px 9px rgba(31,65,99,.06)}.tb-row.overdue{border-left:5px solid #dc2626}.tb-row.soon{border-left:5px solid #f59e0b}.tb-row.selected{border-color:#8dbde7;background:#fafdff;box-shadow:0 4px 15px rgba(37,99,235,.09)}.tb-row-main{display:grid;grid-template-columns:36px minmax(0,1fr);gap:9px;padding:9px 10px;cursor:pointer}.tb-stt{width:30px;height:30px;border-radius:9px;background:#edf5ff;color:#235b94;display:flex;align-items:center;justify-content:center;font-size:10px;font-weight:900;border:1px solid #d3e4f7}.tb-row-title{font-size:11.5px;font-weight:850;line-height:1.42;color:#1f344b}.tb-subject{margin-top:3px;font-size:9.4px;line-height:1.35;color:#7b8797;display:-webkit-box;-webkit-line-clamp:1;-webkit-box-orient:vertical;overflow:hidden}.tb-row-meta{margin-top:5px;display:flex;gap:6px;flex-wrap:wrap;font-size:9.4px;color:#64748b}.tb-meta-pill{display:inline-flex;align-items:center;gap:3px;padding:2px 6px;border-radius:999px;background:#f4f7fa}.tb-status{font-weight:850;color:#0f766e}.tb-status.overdue{color:#b91c1c;background:#fff1f2}.tb-evidence{font-weight:800;color:#6d28d9;background:#f5f3ff}.tb-remind{font-weight:800;color:#a16207;background:#fff8e8}.tb-symbol{font-weight:750;color:#415a77}.tb-empty,.tb-loading{padding:18px 10px;text-align:center;color:#64748b;font-size:10.5px;border:1px dashed #d6dee8;border-radius:10px}.tb-detail{border-top:1px solid #dce7f1;background:#f8fbfe;padding:10px 11px 11px 55px}.tb-detail-grid{display:grid;grid-template-columns:1fr 1fr;gap:6px}.tb-detail-item{padding:7px 8px;border:1px solid #e1e8f0;border-radius:8px;background:#fff;font-size:9.7px;color:#475569;line-height:1.4}.tb-detail-item.full{grid-column:1/-1}.tb-detail-item b{color:#253e57}.tb-add{margin:8px 0;border:1px solid #d7e1ec;border-radius:11px;background:#f9fbfd;padding:10px}.tb-add h4{margin:0 0 8px;font-size:11.8px;color:#223c56}.tb-grid{display:grid;grid-template-columns:1fr 1fr;gap:7px}.tb-field{display:grid;gap:4px}.tb-field.full{grid-column:1/-1}.tb-field label{font-size:9px;font-weight:800;color:#64748b}.tb-field input,.tb-field textarea,.tb-field select{width:100%;border:1px solid #ced9e4;border-radius:8px;padding:7px 8px;background:#fff;font:10.5px Arial;color:#172033}.tb-field textarea{min-height:64px;resize:vertical}.tb-actions{display:flex;gap:6px;flex-wrap:wrap;margin-top:8px}.tb-message{margin-bottom:8px;padding:7px 9px;border-radius:8px;font-size:9.8px;background:#eef5ff;color:#285e9d}.tb-message.success{background:#eaf8f0;color:#166534}.tb-message.error{background:#fff0f0;color:#a23535}.tb-confirm{position:absolute;inset:0;z-index:20;background:rgba(15,23,42,.38);display:flex;align-items:center;justify-content:center;padding:18px}.tb-confirm-box{width:min(330px,100%);background:#fff;border-radius:12px;padding:13px;box-shadow:0 15px 40px rgba(0,0,0,.25)}.tb-confirm-title{font-size:12px;font-weight:900}.tb-confirm-text{margin-top:6px;font-size:10.5px;line-height:1.45;color:#475569;white-space:pre-line}.tb-confirm-actions{display:flex;justify-content:flex-end;gap:6px;margin-top:11px}.tracker-match{margin-top:9px;padding:10px 11px;border:1px solid #cfe0ef;border-left:5px solid #0f766e;border-radius:11px;background:#f2fbfa;font-size:10px;line-height:1.5;color:#31544f}.tracker-match.hidden{display:none!important}.tracker-match .tm-title{font-weight:900;font-size:10.7px}.tracker-match .tm-task{margin-top:3px;font-weight:800;color:#163f3a}.tracker-match .tm-meta{margin-top:3px;color:#64748b}.tracker-match .tm-actions{display:flex;gap:6px;flex-wrap:wrap;margin-top:8px}.tracker-match button{border:1px solid #b9d7d2;border-radius:8px;background:#fff;color:#0f5f58;padding:6px 8px;font-size:9.6px;font-weight:850;cursor:pointer}.tracker-match button.primary{background:#0f766e;color:#fff;border-color:#0f766e}
      @media(max-width:520px){.tb-grid,.tb-detail-grid{grid-template-columns:1fr}.tb-field.full,.tb-detail-item.full{grid-column:auto}.tb-detail{padding-left:10px}}
    `;state.root.appendChild(style);
  }

  function confirmAction(title,text,confirmLabel='Xác nhận'){
    return new Promise(resolve=>{const host=state.root?.host;if(!host){resolve(false);return;}const overlay=document.createElement('div');overlay.className='tb-confirm';overlay.innerHTML=`<div class="tb-confirm-box"><div class="tb-confirm-title">${esc(title)}</div><div class="tb-confirm-text">${esc(text)}</div><div class="tb-confirm-actions"><button class="tb-btn" data-cancel>Hủy</button><button class="tb-btn primary" data-ok>${esc(confirmLabel)}</button></div></div>`;const card=state.root.querySelector('.card');if(card){card.style.position='relative';card.appendChild(overlay);}else host.appendChild(overlay);const done=v=>{overlay.remove();resolve(v);};overlay.querySelector('[data-cancel]').onclick=()=>done(false);overlay.querySelector('[data-ok]').onclick=()=>done(true);overlay.addEventListener('click',e=>{if(e.target===overlay)done(false);});});
  }

  function parseRelatedDocs(){
    const root=document.querySelector('[id$="_RelList"]');if(!root)return[];
    const rows=[...root.querySelectorAll(':scope > div, [class*="-fitem"]')];const out=[];const seen=new Set();
    for(const row of rows){
      const raw=norm(row.getAttribute?.('title')||row.querySelector?.('[class*="-fname"]')?.textContent||row.textContent||'');if(!raw)continue;
      const sm=raw.match(/Số\s*ký\s*hiệu\s*:\s*([^()]+?)(?=\s*\(|$)/i);const tm=raw.match(/Trích\s*yếu\s*:\s*(.+?)(?=\s*Số\s*ký\s*hiệu\s*:|\s*\(Người\s*gửi|$)/i);
      const symbol=norm(sm?.[1]||'');const subject=norm(tm?.[1]||'').replace(/^\d+\.\s*/,'');if(!symbol&&!subject)continue;
      const key=`${fold(symbol)}|${fold(subject)}`;if(seen.has(key))continue;seen.add(key);out.push({symbol,subject,relatedIofficeId:''});
    }
    return out;
  }

  function unitOptions(selected='',all=false){return (all?'<option value="all">Tất cả đơn vị</option>':'<option value="">— Chọn XLC —</option>')+Object.entries(UNITS).map(([id,name])=>`<option value="${id}" ${selected===id?'selected':''}>${esc(name)}</option>`).join('');}
  function today(){const d=new Date();return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;}
  function deadlineState(t){const d=norm(t.deadline);if(!d)return '';const diff=Math.ceil((new Date(d+'T23:59:59').getTime()-Date.now())/86400000);return diff<0?'overdue':diff<=3?'soon':'';}
  function detailHtml(t){
    if(!t||t.taskId!==state.selectedId)return '';
    return `<div class="tb-detail"><div class="tb-detail-grid"><div class="tb-detail-item"><b>Văn bản</b><br>${esc(t.sourceSymbol||'—')}</div><div class="tb-detail-item"><b>Hạn xử lý</b><br>${esc(viDate(t.deadline)||'—')}</div><div class="tb-detail-item"><b>Xử lý chính</b><br>${esc(t.mainUnit||'—')}</div><div class="tb-detail-item"><b>Minh chứng</b><br>${Number(t.evidenceCount)||0}</div><div class="tb-detail-item full"><b>Trích yếu</b><br>${esc(t.sourceSubject||'—')}</div><div class="tb-detail-item full"><b>Kết quả</b><br>${esc(t.resultText||'Chưa có')}</div>${t.note?`<div class="tb-detail-item full"><b>Ghi chú</b><br>${esc(t.note)}</div>`:''}</div><div class="tb-actions"><button class="tb-btn primary" data-tb="complete" data-task-id="${esc(t.taskId)}">Xác nhận Hoàn thành</button><button class="tb-btn" data-tb="manage">Mở cổng quản lý</button><button class="tb-btn" data-tb="close-detail">Thu gọn</button></div></div>`;
  }
  function rowHtml(t){
    const stateClass=deadlineState(t),selected=t.taskId===state.selectedId;
    const status=stateClass==='overdue'?'Trễ hạn':'Đang xử lý';
    return `<div class="tb-row ${stateClass} ${selected?'selected':''}" data-row-id="${esc(t.taskId)}"><div class="tb-row-main" data-task-open="${esc(t.taskId)}" aria-expanded="${selected?'true':'false'}"><div class="tb-stt">${esc(t.stt||'—')}</div><div><div class="tb-row-title">${esc(t.taskText)}</div>${t.sourceSubject?`<div class="tb-subject">${esc(t.sourceSubject)}</div>`:''}<div class="tb-row-meta"><span class="tb-meta-pill">${esc(t.mainUnit)}</span><span class="tb-meta-pill">${esc(viDate(t.deadline)||'—')}</span><span class="tb-meta-pill tb-status ${stateClass==='overdue'?'overdue':''}">${status}</span>${t.reminderActive?`<span class="tb-meta-pill tb-remind">🔔 Đã đôn đốc ${Number(t.reminderCount)||1}</span>`:''}${t.evidenceCount?`<span class="tb-meta-pill tb-evidence">📎 ${Number(t.evidenceCount)}</span>`:''}</div>${t.sourceSymbol?`<div class="tb-row-meta tb-symbol">${esc(t.sourceSymbol)}</div>`:''}</div></div>${detailHtml(t)}</div>`;
  }
  function addHtml(){return `<div class="tb-add"><h4>Thêm nhiệm vụ</h4><p class="tb-board-note">Nhập đủ 3 trường bắt buộc. Chỉ bấm gửi một lần.</p><div class="tb-grid"><div class="tb-field full"><label>Nội dung nhiệm vụ *</label><textarea id="tbAddTitle" required maxlength="3000"></textarea></div><div class="tb-field"><label>Xử lý chính *</label><select id="tbAddOwner" required>${unitOptions()}</select></div><div class="tb-field"><label>Hạn xử lý *</label><input id="tbAddDeadline" type="date" required></div><div class="tb-field full"><label>Ghi chú</label><textarea id="tbAddNote" maxlength="3000"></textarea></div></div><div class="tb-actions"><button class="tb-btn primary" data-tb="create">Tạo nhiệm vụ</button><button class="tb-btn" data-tb="cancel-add">Hủy</button></div></div>`;}

  function renderBoard(){
    const c=state.container;if(!c)return;
    const tasks=state.tasks.filter(t=>state.unitFilter==='all'||t.mainUnitId===state.unitFilter).sort((a,b)=>Number(b.reminderActive)-Number(a.reminderActive)||norm(a.deadline).localeCompare(norm(b.deadline)));
    c.innerHTML=`<div class="tb-head"><div class="tb-title">📒 Nhiệm vụ đang theo dõi</div><div class="tb-tools"><button class="tb-btn" data-tb="manage">↗ Quản lý</button><button class="tb-btn" data-tb="refresh">↻</button><button class="tb-btn primary" data-tb="add">＋ Thêm</button></div></div><div class="tb-board-note">Hiển thị nhiệm vụ chưa hoàn thành. STT dùng đúng số của Tracker; bấm vào từng nhiệm vụ để mở chi tiết ngay tại dòng đó.</div>${state.message?`<div class="tb-message ${esc(state.messageKind)}">${esc(state.message)}</div>`:''}<select class="tb-filter" id="tbUnitFilter">${unitOptions(state.unitFilter,true)}</select>${state.addOpen?addHtml():''}${state.loading?'<div class="tb-loading">Đang tải dữ liệu mới…</div>':''}<div class="tb-list">${tasks.map(rowHtml).join('')||'<div class="tb-empty">Không có nhiệm vụ trong danh sách hiện tại.</div>'}</div>`;
    c.querySelector('#tbUnitFilter')?.addEventListener('change',e=>{state.unitFilter=e.target.value;state.selectedId='';renderBoard();});
    c.querySelectorAll('[data-tb]').forEach(b=>{b.disabled=state.busy||state.loading||((b.dataset.tb==='complete')&&state.stale);b.addEventListener('click',e=>{e.stopPropagation();void act(b.dataset.tb,b);});});
    c.querySelectorAll('[data-task-open]').forEach(row=>row.addEventListener('click',()=>{if(!state.busy)openTask(row.dataset.taskOpen);}));
    if(state.selectedId)requestAnimationFrame(()=>c.querySelector(`[data-row-id="${CSS.escape(state.selectedId)}"]`)?.scrollIntoView({block:'nearest'}));
  }
  async function loadIndex(force=true){if(state.loading)return;state.loading=true;renderBoard();const r=await runtime({type:'TRACKER_CACHE_REFRESH',data:{force}});state.loading=false;
    if(r?.ok){state.tasks=r.cache.tasks;state.stale=false;if(!state.tasks.some(t=>t.taskId===state.selectedId))state.selectedId='';}else{state.stale=true;notice((r?.error||'Không tải được dữ liệu.')+' Danh sách cũ có thể chưa cập nhật.','error');}renderBoard();}
  function openTask(id){id=norm(id);state.selectedId=state.selectedId===id?'':id;renderBoard();}
  async function openManage(){const r=await runtime({type:'TRACKER_OPEN_MANAGE'});if(!r?.ok){notice(r?.error||'Không mở được cổng quản lý.','error');renderBoard();}}
  async function complete(t){if(!t?.taskId||state.matchBusy)return;state.matchBusy=true;
    try{if(!await confirmAction('Xác nhận hoàn thành',`“${t.taskText}”\nĐang xử lý → Hoàn thành`,'Hoàn thành'))return;
      const btn=state.matchContainer?.querySelector('[data-tm-complete]');if(btn){btn.disabled=true;btn.textContent='Đang cập nhật…';}
      const r=await runtime({type:'TRACKER_COMPLETE_LEADER',data:{taskId:t.taskId}});
      if(!r?.ok){notice((r?.error||'Không cập nhật được trạng thái.')+' Hãy tải lại Sổ để kiểm tra.','error');renderMatch(null,'Chưa xác định kết quả cập nhật. Tải lại Sổ hoặc mở cổng quản lý để kiểm tra.');return;}
      state.tasks=state.tasks.filter(x=>x.taskId!==t.taskId);state.selectedId='';notice('Đã xác nhận hoàn thành trên Tracker.','success');renderMatch(null,'✓ Đã xác nhận hoàn thành trên Tracker.');await loadIndex(true);
    }finally{state.matchBusy=false;renderBoard();}}
  async function act(action,btn){if(state.busy)return;state.busy=true;btn.disabled=true;const label=btn.textContent;btn.textContent='Đang xử lý…';
    try{
      if(action==='refresh')return await loadIndex(true);
      if(action==='manage')return await openManage();
      if(action==='add'){state.addOpen=!state.addOpen;return;}
      if(action==='cancel-add'){state.addOpen=false;return;}
      if(action==='close-detail'){state.selectedId='';return;}
      if(action==='complete')return await complete(state.tasks.find(t=>t.taskId===norm(btn.dataset.taskId||state.selectedId)));
      if(action==='create'){
        const c=state.container,taskText=norm(c.querySelector('#tbAddTitle')?.value),mainUnitId=c.querySelector('#tbAddOwner')?.value,deadline=c.querySelector('#tbAddDeadline')?.value,note=c.querySelector('#tbAddNote')?.value||'';
        if(!taskText||!mainUnitId||!deadline){notice('Nhập đủ Nội dung nhiệm vụ, Xử lý chính và Hạn xử lý.','error');return;}
        const r=await runtime({type:'TRACKER_UPSERT',data:{taskText,mainUnitId,deadline,note}});
        if(!r?.ok){notice(r?.error||'Không tạo được nhiệm vụ.','error');return;}
        state.addOpen=false;notice(r.data?.alreadyCreated?'Nhiệm vụ này đã được gửi từ tiện ích.':'Đã tạo nhiệm vụ trên Tracker.','success');await loadIndex(true);
      }
    }catch(e){notice(e.message,'error');}finally{state.busy=false;btn.disabled=false;btn.textContent=label;
      if(state.addOpen&&action==='create'){state.notify(state.message,state.messageKind);}else renderBoard();}
  }
  function renderMatch(t,message=''){const box=state.matchContainer;if(!box)return;box.classList.remove('hidden');box.innerHTML=`<div class="tm-title">📌 NHIỆM VỤ LIÊN QUAN</div>${t?`<div class="tm-task">${esc(t.taskText)}</div><div class="tm-meta">${esc(t.mainUnit)} · Hạn ${esc(viDate(t.deadline))} · ${esc(t.sourceSymbol)}</div>${t.note?`<div class="tm-meta">Ghi chú: ${esc(t.note)}</div>`:''}`:`<div class="tm-meta">${esc(message)}</div>`}<div class="tm-actions">${t?'<button class="primary" data-tm-complete>Xác nhận Hoàn thành</button>':''}<button data-tm-open>Mở cổng quản lý</button></div>`;box.querySelector('[data-tm-complete]')?.addEventListener('click',()=>void complete(t));box.querySelector('[data-tm-open]')?.addEventListener('click',()=>void openManage());}
  async function matchCurrentOutgoing(){const run=++state.matchRun,ctx=JSON.stringify(state.getContext()),docs=parseRelatedDocs();if(!docs.length){renderMatch(null,'Không có Văn bản liên quan để đối chiếu.');return null;}renderMatch(null,'Đang đối chiếu nhiệm vụ chưa hoàn thành…');const r=await runtime({type:'TRACKER_MATCH',data:{relatedDocs:docs}});if(run!==state.matchRun||ctx!==JSON.stringify(state.getContext()))return null;
    if(!r?.ok){renderMatch(null,r?.error||'Không đối chiếu được Sổ.');return null;}const data=r.data;if(data.needsReview){renderMatch(null,'Có nhiều nhiệm vụ cùng số văn bản. Mở cổng quản lý để chọn đúng nhiệm vụ.');return null;}if(!data.matched){renderMatch(null,'Chưa tìm thấy nhiệm vụ đang theo dõi khớp Số/Ký hiệu.');return null;}renderMatch(data.task);return data.task;}
  function init(opts={}){Object.assign(state,{root:opts.root,container:opts.container,matchContainer:opts.matchContainer,getContext:opts.getContext||state.getContext,notify:opts.notify||state.notify,openTracker:opts.openTracker||state.openTracker});ensureStyle();}
  function activate(){state.container?.classList.remove('hidden');void loadIndex(true);}
  function deactivate(){state.container?.classList.add('hidden');}
  globalThis.IOfficeTrackerBoard={init,activate,deactivate,refresh:()=>loadIndex(true),openTask,matchCurrentOutgoing,createFromPayload:payload=>runtime({type:'TRACKER_UPSERT',data:payload})};
})();
