'use strict';
(() => {
  const $=id=>document.getElementById(id);
  function runtime(m){return new Promise(resolve=>{try{chrome.runtime.sendMessage(m,r=>resolve(chrome.runtime.lastError?{ok:false,error:chrome.runtime.lastError.message}:(r||{ok:false,error:'Không có phản hồi'})));}catch(e){resolve({ok:false,error:e.message});}});}
  function fmtTime(ts){if(!ts)return 'chưa có';try{return new Date(ts).toLocaleString('vi-VN');}catch(_){return ''}}
  function render(s){
    const meta=$('ruleInternetMeta'),status=$('ruleInternetStatus'),apply=$('ruleInternetApply');
    if($('ruleInternetAuto')) $('ruleInternetAuto').checked=s?.auto!==false;
    if($('ruleInternetFeed')) $('ruleInternetFeed').textContent=s?.feedUrl||'https://kpia0412.github.io/ioAI/latest-rules.json';
    if(meta) meta.textContent=`Đang dùng: ${s?.currentVersion||'—'} · nguồn ${s?.source||'embedded'} · kiểm tra gần nhất: ${fmtTime(s?.checkedAt)}`;
    if(status){
      if(s?.phase==='available'){status.textContent=`Có Rule Pack mới ${s.version}${s.notes?` · ${s.notes}`:''}`;status.className='status ok';}
      else if(s?.phase==='installed'){status.textContent=`✓ Đã áp dụng Rule Pack ${s.currentVersion||s.version}.`;status.className='status ok';}
      else if(s?.phase==='checking'){status.textContent='Đang kiểm tra Rule Pack mới…';status.className='status';}
      else if(s?.phase==='error'){status.textContent='✕ '+(s.error||'Không kiểm tra được Rule Pack.');status.className='status err';}
      else if(s?.phase==='current'){status.textContent='✓ Rule Pack đang là bản mới nhất.';status.className='status ok';}
      else{status.textContent='Chưa kiểm tra.';status.className='status';}
    }
    if(apply) apply.hidden=!(s?.phase==='available'&&s?.newer);
  }
  async function refresh(){const r=await runtime({type:'RULE_UPDATE_STATUS'});if(r?.ok)render(r.data);else render({phase:'error',error:r?.error});}
  $('ruleInternetAuto')?.addEventListener('change',async e=>{await runtime({type:'RULE_AUTO_SET',enabled:e.target.checked});await refresh();});
  $('ruleInternetCheck')?.addEventListener('click',async()=>{render({phase:'checking',auto:$('ruleInternetAuto')?.checked,feedUrl:'https://kpia0412.github.io/ioAI/latest-rules.json'});const r=await runtime({type:'RULE_UPDATE_CHECK'});r?.ok?render({...r.data,auto:$('ruleInternetAuto')?.checked,source:'local'}):render({phase:'error',error:r?.error});});
  $('ruleInternetApply')?.addEventListener('click',async()=>{const b=$('ruleInternetApply');if(b)b.disabled=true;const r=await runtime({type:'RULE_UPDATE_APPLY'});if(b)b.disabled=false;if(!r?.ok){render({phase:'error',error:r?.error});return;}await refresh();setTimeout(()=>location.reload(),500);});
  refresh();
})();