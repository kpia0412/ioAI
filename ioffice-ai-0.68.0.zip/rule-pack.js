(() => {
  'use strict';
  const FORMAT = 'ioffice-ai-incoming-rules-v1';
  const SCHEMA_VERSION = 1;
  const ALLOWED_UNIT_IDS = new Set(['U140','U141','U142','U120','U183','U340','U360','U260','DUUBND']);
  const DEFAULT_PACK = {
  "format": "ioffice-ai-incoming-rules-v1",
  "schemaVersion": 1,
  "version": "2026.09.30.04",
  "name": "Ea Ly Incoming Rules",
  "description": "Bộ quy tắc nghiệp vụ độc lập cho phân tích văn bản đến của UBND xã Ea Ly.",
  "inputPolicy": {
    "includeSummary": true,
    "includeSymbol": true,
    "includeSender": true,
    "includeDocumentDate": true,
    "includeDocType": true,
    "includeUrgency": true,
    "includeAttachmentNames": true,
    "includePrimaryText": true,
    "includeSupportingDocuments": true,
    "includeOtherFileNames": true,
    "maxPrimaryChars": 42000,
    "maxSupportingChars": 18000,
    "maxTotalChars": 78000,
    "neverDuplicatePreviewAndBundle": true,
    "neverGuessUnreadFiles": true,
    "sendEvenWhenIncomplete": true,
    "additionalReadPolicy": {
      "mode": "task-deadline-aware",
      "autoReadStrongAppendix": true,
      "suggestMoreAfterPrimaryAnalysis": true,
      "maxAdditionalFiles": 6,
      "appendixNameKeywords": [
        "phụ lục",
        "danh sách",
        "biểu",
        "mẫu biểu",
        "appendix"
      ],
      "taskKeywords": [
        "giao",
        "đề nghị",
        "yêu cầu",
        "thực hiện",
        "rà soát",
        "báo cáo",
        "cung cấp",
        "xác nhận",
        "có ý kiến",
        "triển khai",
        "xây dựng kế hoạch",
        "gửi kết quả"
      ],
      "deadlineKeywords": [
        "trước ngày",
        "chậm nhất",
        "hoàn thành trước",
        "gửi trước",
        "hạn",
        "thời hạn",
        "trong ngày",
        "trong vòng"
      ]
    }
  },
  "scopeRules": [
    "Xác định CHỦ THỂ của mục/tiểu mục trước khi đọc từng gạch đầu dòng; chủ thể của tiêu đề mục được kế thừa cho đến khi văn bản chuyển chủ thể.",
    "Chỉ coi là nhiệm vụ trực tiếp của UBND xã Ea Ly khi văn bản giao trực tiếp cho Ea Ly hoặc giao cho nhóm UBND xã/phường mà Ea Ly thuộc phạm vi áp dụng, đồng thời Ea Ly có hành động hoặc sản phẩm cụ thể phải hoàn thành.",
    "Nếu cơ quan/đơn vị khác là chủ thể chính và UBND xã chỉ được nêu là phối hợp/hỗ trợ/làm việc cùng thì taskScope=coordination, actionRequired=false, tasks=[], trackRecommended=false.",
    "Nếu văn bản chỉ để biết thì taskScope=information, actionRequired=false, tasks=[], trackRecommended=false.",
    "Nếu nhiệm vụ thuộc xã/phường khác thì taskScope=other-locality, actionRequired=false, tasks=[], trackRecommended=false.",
    "Nếu chưa chắc phạm vi, chủ thể, sản phẩm hoặc hạn thuộc ai thì taskScope=ambiguous, actionRequired=false, tasks=[], trackRecommended=false, requiresReview=true.",
    "Yêu cầu phản hồi có điều kiện không phải nhiệm vụ bắt buộc: nếu văn bản nêu không phản hồi được hiểu là không có thông tin, trường hợp không có thì không cần phản hồi, hoặc chỉ khi có thông tin mới cung cấp, thì không tạo nhiệm vụ/hạn Tracker chỉ vì có ngày đề nghị phản hồi."
  ],
  "deadlineRules": [
    "Chỉ gắn deadline khi câu/đoạn chứng minh hạn áp dụng trực tiếp cho Ea Ly hoặc cho sản phẩm Ea Ly phải nộp.",
    "Không lấy ngày ban hành, lịch họp, hạn của Trung tâm Y tế/Bệnh viện/trường/Sở/ngành/xã khác rồi gán cho Ea Ly.",
    "Không tự đặt deadline cho các từ khẩn trương, sớm, kịp thời.",
    "Nếu có deadline thì deadlineEvidence phải chứa đúng câu/đoạn chứng minh; nếu bằng chứng không rõ thì không gán deadline và requiresReview=true."
  ],
  "trackingRules": [
    "trackRecommended=true chỉ khi taskScope=direct và có nhiệm vụ/sản phẩm cụ thể cần theo dõi; nếu có deadline trực tiếp thì ưu tiên true.",
    "Không tự tạo Tracker nếu chỉ phối hợp, theo dõi, để biết, địa phương khác hoặc chưa chắc phạm vi.",
    "Người dùng có thể chủ động bật Thêm vào Sổ theo dõi nên AI phải thận trọng, không tạo task chỉ để lấp cấu trúc."
  ],
  "routingRules": [
    "Mọi văn bản đến cần đúng 1 mainUnit làm đầu mối nhận trên iOffice; mainUnit không đồng nghĩa luôn có nhiệm vụ Tracker.",
    "coordinationUnits chỉ dùng cho đơn vị thật sự cần phối hợp; viewUnits luôn trả []. Cá nhân xem để biết do người dùng chọn riêng.",
    "Không đưa Văn phòng vào phối hợp chỉ để nắm tình hình.",
    "Thiên tai, đất đai, giao thông, nông nghiệp, tài chính-ngân sách, đầu tư, xây dựng, công thương thường thuộc Phòng Kinh tế.",
    "Giáo dục, y tế, nội vụ, CCHC, chuyển đổi số, văn hóa-xã hội thường thuộc Phòng Văn hóa - Xã hội.",
    "Trường học và Trạm Y tế không là đầu mối phân luồng độc lập; nhiệm vụ liên quan được quy về Phòng Văn hóa - Xã hội.",
    "Trung tâm Phục vụ hành chính công chỉ làm mainUnit khi đúng nhiệm vụ một cửa/TTHC; Trung tâm Cung ứng khi đúng hoạt động sự nghiệp công/tuyên truyền/dịch vụ được giao.",
    "Đảng ủy UBND xã khác Đảng ủy xã. Chỉ chọn Đảng ủy UBND khi văn bản giao đích danh Đảng ủy/Đảng bộ UBND xã, chi bộ trực thuộc hoặc công tác Đảng nội bộ khối UBND. Văn bản của Đảng ủy xã giao UBND xã thực hiện quản lý nhà nước phải phân về phòng chuyên môn tương ứng."
  ],
  "instructionRules": [
    "instruction là Ý kiến chỉ đạo tóm gọn nhưng phải đủ toàn bộ đầu việc/sản phẩm trực tiếp của Ea Ly; bỏ bối cảnh/căn cứ dư thừa, không cắt chuỗi bằng giới hạn ký tự và không dùng dấu … để bỏ nhiệm vụ.",
    "Nếu nhiều đầu việc, dùng 1-3 câu hoặc các vế ngăn bằng dấu chấm phẩy; nêu đơn vị, hành động/sản phẩm và hạn trực tiếp nếu có.",
    "Nếu chỉ phối hợp: viết ngắn theo dạng Giao [đơn vị] tiếp nhận, theo dõi và phối hợp theo yêu cầu.",
    "Nếu chỉ để biết: viết Giao [đơn vị] tiếp nhận, nghiên cứu để biết."
  ],
  "appendixRules": [
    "Chỉ cần đọc thêm Phụ lục/Danh sách/Biểu khi chính văn có dấu hiệu giao nhiệm vụ/hạn và phụ lục được dùng để xác định đối tượng, địa phương, chỉ tiêu, sản phẩm, biểu mẫu hoặc thời hạn.",
    "Nếu phụ lục đã được đọc thì dùng nội dung phụ lục để xác định Ea Ly có thuộc đối tượng hay chưa hoàn thành hay không.",
    "Nếu phụ lục cần thiết nhưng chưa đọc được, không suy đoán; requiresReview=true. Tuy nhiên vẫn phải phân tích phần dữ liệu chính đã đọc được và nêu rõ giới hạn.",
    "Không được chặn toàn bộ lượt gửi AI chỉ vì thiếu một tệp phụ; luôn gửi dữ liệu chính đã đọc được cùng trạng thái thiếu dữ liệu."
  ],
  "specialCases": [
    "Nếu mục có tiêu đề Đối với Trung tâm Y tế/Bệnh viện và gạch đầu dòng yêu cầu phối hợp UBND xã nhưng hạn gửi Sở thuộc Trung tâm Y tế/Bệnh viện, không tạo task hạn cho Ea Ly; mainUnit Phòng VH-XH, actionRequired=false, trackRecommended=false.",
    "Nếu văn bản gửi chung các xã/phường để rà soát/cung cấp thông tin nhưng quy định không phản hồi được hiểu là không có thông tin, chọn đơn vị chuyên môn rà soát nhưng không tự tạo Tracker."
  ],
  "outputRules": [
    "taskScope chỉ dùng direct|coordination|information|other-locality|ambiguous.",
    "Mỗi nhiệm vụ trực tiếp độc lập là một phần tử tasks và giữ đúng thứ tự xuất hiện.",
    "task.task viết theo hành động/sản phẩm cụ thể, không chép nguyên đoạn dài.",
    "reason 1-2 câu; signals tối đa 5 ý ngắn.",
    "Nếu dữ liệu chính thiếu hoặc có tệp quan trọng chưa đọc được thì requiresReview=true và confidence<0.7."
  ],
  "units": [
    {
      "id": "U140",
      "name": "Văn phòng HĐND và UBND",
      "functions": [
        "tham mưu tổng hợp HĐND/UBND",
        "chương trình công tác, lịch họp, thông báo kết luận",
        "văn thư nghiệp vụ, pháp chế, tiếp công dân theo phân công"
      ]
    },
    {
      "id": "U141",
      "name": "Phòng Kinh tế",
      "functions": [
        "tài chính ngân sách, kế hoạch, đầu tư",
        "đất đai, tài nguyên, môi trường",
        "nông nghiệp, thủy lợi, thiên tai",
        "xây dựng, giao thông, thương mại, công thương"
      ]
    },
    {
      "id": "U142",
      "name": "Phòng Văn hóa - Xã hội",
      "functions": [
        "nội vụ, CCHC, thi đua",
        "giáo dục và đào tạo",
        "y tế, dân số",
        "văn hóa, xã hội, thông tin, khoa học công nghệ, chuyển đổi số",
        "đầu mối quản lý trường học và Trạm Y tế"
      ]
    },
    {
      "id": "U120",
      "name": "Trung tâm Phục vụ hành chính công",
      "functions": [
        "một cửa, TTHC, dịch vụ công, tiếp nhận và trả kết quả"
      ]
    },
    {
      "id": "U183",
      "name": "Trung tâm Cung ứng dịch vụ sự nghiệp công",
      "functions": [
        "dịch vụ sự nghiệp công, tuyên truyền, truyền thông, nhiệm vụ sự nghiệp được giao"
      ]
    },
    {
      "id": "U340",
      "name": "Công an xã",
      "functions": [
        "an ninh trật tự, quản lý hành chính, PCCC, ATGT theo chức năng"
      ]
    },
    {
      "id": "U360",
      "name": "Ban CHQS xã",
      "functions": [
        "quốc phòng, quân sự địa phương, dân quân, nghĩa vụ quân sự, phòng thủ dân sự"
      ]
    },
    {
      "id": "U260",
      "name": "HĐND xã",
      "functions": [
        "hoạt động HĐND, Thường trực HĐND và các Ban HĐND"
      ]
    },
    {
      "id": "DUUBND",
      "name": "Đảng ủy UBND xã Ea Ly",
      "functions": [
        "công tác Đảng nội bộ Đảng bộ/Đảng ủy UBND xã và chi bộ trực thuộc"
      ]
    }
  ],
  "examples": [
    {
      "name": "Chỉ phối hợp với đơn vị y tế chủ trì",
      "expected": {
        "taskScope": "coordination",
        "actionRequired": false,
        "trackRecommended": false,
        "mainUnit": "U142",
        "tasks": []
      }
    },
    {
      "name": "Phản hồi có điều kiện không bắt buộc",
      "expected": {
        "taskScope": "coordination",
        "actionRequired": false,
        "trackRecommended": false,
        "tasks": []
      }
    }
  ]
};

  const clone = v => JSON.parse(JSON.stringify(v));
  const clean = v => String(v ?? '').replace(/\u0000/g,'').trim();
  const arrStrings = (v, name, max=100) => {
    if (!Array.isArray(v)) throw new Error(`${name} phải là mảng.`);
    if (v.length > max) throw new Error(`${name} quá nhiều mục.`);
    return v.map((x,i)=>{ if(typeof x!=='string') throw new Error(`${name}[${i}] phải là chuỗi.`); const s=clean(x); if(!s) throw new Error(`${name}[${i}] rỗng.`); if(s.length>1600) throw new Error(`${name}[${i}] quá dài.`); return s; });
  };
  const num = (v, min, max, name) => {
    const n=Number(v); if(!Number.isFinite(n)||n<min||n>max) throw new Error(`${name} không hợp lệ.`); return n;
  };

  function migrate(value) {
    if (!value || typeof value!=='object') return value;
    if (value.format === 'ioffice-ai-prompt-rules-v1') {
      const p=clone(DEFAULT_PACK);
      const incoming=clean(value.incomingRules||'');
      if (incoming) p.specialCases=[...(p.specialCases||[]),`Quy tắc tùy chỉnh được chuyển từ bản cũ: ${incoming.slice(0,12000)}`];
      return p;
    }
    return value;
  }

  function validate(value) {
    value=migrate(value);
    if(!value || Array.isArray(value) || typeof value!=='object') throw new Error('Rule Pack phải là object JSON.');
    if(value.format!==FORMAT) throw new Error(`Sai format Rule Pack. Cần ${FORMAT}.`);
    if(Number(value.schemaVersion)!==SCHEMA_VERSION) throw new Error(`schemaVersion chưa hỗ trợ: ${value.schemaVersion}.`);
    if(!/^\d{4}\.\d{2}\.\d{2}\.\d{2}$/.test(String(value.version||''))) throw new Error('version Rule Pack phải dạng YYYY.MM.DD.NN.');
    const p=clone(value);
    p.name=clean(p.name||'Ea Ly Incoming Rules').slice(0,120);
    p.description=clean(p.description||'').slice(0,1000);

    const ip=p.inputPolicy||{};
    const boolKeys=['includeSummary','includeSymbol','includeSender','includeDocumentDate','includeDocType','includeUrgency','includeAttachmentNames','includePrimaryText','includeSupportingDocuments','includeOtherFileNames','neverDuplicatePreviewAndBundle','neverGuessUnreadFiles','sendEvenWhenIncomplete'];
    for(const k of boolKeys) if(typeof ip[k]!=='boolean') throw new Error(`inputPolicy.${k} phải là boolean.`);
    ip.maxPrimaryChars=num(ip.maxPrimaryChars,1000,120000,'inputPolicy.maxPrimaryChars');
    ip.maxSupportingChars=num(ip.maxSupportingChars,500,60000,'inputPolicy.maxSupportingChars');
    ip.maxTotalChars=num(ip.maxTotalChars,2000,180000,'inputPolicy.maxTotalChars');
    const ar=ip.additionalReadPolicy||{};
    if(!['task-deadline-aware','off'].includes(String(ar.mode||''))) throw new Error('additionalReadPolicy.mode không hợp lệ.');
    if(typeof ar.autoReadStrongAppendix!=='boolean'||typeof ar.suggestMoreAfterPrimaryAnalysis!=='boolean') throw new Error('additionalReadPolicy thiếu cờ boolean.');
    ar.maxAdditionalFiles=num(ar.maxAdditionalFiles,0,12,'additionalReadPolicy.maxAdditionalFiles');
    ar.appendixNameKeywords=arrStrings(ar.appendixNameKeywords||[],'appendixNameKeywords',30);
    ar.taskKeywords=arrStrings(ar.taskKeywords||[],'taskKeywords',60);
    ar.deadlineKeywords=arrStrings(ar.deadlineKeywords||[],'deadlineKeywords',40);
    ip.additionalReadPolicy=ar; p.inputPolicy=ip;

    for(const key of ['scopeRules','deadlineRules','trackingRules','routingRules','instructionRules','appendixRules','specialCases','outputRules']) p[key]=arrStrings(p[key]||[],key,100);
    if(!Array.isArray(p.units) || !p.units.length) throw new Error('Rule Pack thiếu units.');
    const seen=new Set();
    p.units=p.units.map((u,i)=>{
      if(!u||typeof u!=='object') throw new Error(`units[${i}] không hợp lệ.`);
      const id=clean(u.id); if(!ALLOWED_UNIT_IDS.has(id)) throw new Error(`Unit ID không được phép: ${id}.`);
      if(seen.has(id)) throw new Error(`Unit ID bị trùng: ${id}.`); seen.add(id);
      const name=clean(u.name); if(!name) throw new Error(`units[${i}].name rỗng.`);
      return {id,name:name.slice(0,160),functions:arrStrings(u.functions||[],`units[${i}].functions`,40)};
    });
    if(seen.size!==ALLOWED_UNIT_IDS.size) {
      const missing=[...ALLOWED_UNIT_IDS].filter(x=>!seen.has(x));
      throw new Error(`Rule Pack thiếu đơn vị bắt buộc: ${missing.join(', ')}.`);
    }
    if(!Array.isArray(p.examples)) p.examples=[];
    if(JSON.stringify(p).length>150000) throw new Error('Rule Pack quá lớn.');
    return p;
  }

  function resolvePack(value) {
    try { return validate(value); } catch (_) { return validate(DEFAULT_PACK); }
  }

  function section(title, items) {
    if(!Array.isArray(items)||!items.length) return '';
    return `\n${title}:\n`+items.map((x,i)=>`${i+1}) ${x}`).join('\n');
  }

  function compilePrompt(pack, payload={}) {
    const p=resolvePack(pack);
    const units=p.units.map(u=>({id:u.id,name:u.name,functions:u.functions}));
    return `

BỘ QUY TẮC NGHIỆP VỤ VĂN BẢN ĐẾN ĐANG ÁP DỤNG
Rule Pack: ${p.name} · ${p.version}
Đây là dữ liệu cấu hình nghiệp vụ, không được thay đổi JSON schema kỹ thuật.
${section('PHẠM VI / CHỦ THỂ',p.scopeRules)}
${section('HẠN XỬ LÝ',p.deadlineRules)}
${section('SỔ THEO DÕI',p.trackingRules)}
${section('PHÂN LUỒNG ĐƠN VỊ',p.routingRules)}
${section('Ý KIẾN CHỈ ĐẠO',p.instructionRules)}
${section('PHỤ LỤC / DANH SÁCH / BIỂU',p.appendixRules)}
${section('TRƯỜNG HỢP ĐẶC BIỆT',p.specialCases)}
${section('ĐẦU RA',p.outputRules)}
DANH MỤC ĐƠN VỊ VÀ CHỨC NĂNG THAM CHIẾU: ${JSON.stringify(units)}
TỰ KIỂM TRA TRƯỚC KHI TRẢ KẾT QUẢ: Ai được giao? Có phải Ea Ly không? Ea Ly phải làm sản phẩm gì? Hạn đó của ai? Ea Ly chủ trì hay chỉ phối hợp?`;
  }

  function compactDoc(d, maxChars) {
    if(!d) return null;
    return {
      name:clean(d.name), ext:clean(d.ext), status:clean(d.status), source:clean(d.source),
      pagesRead:Number(d.pagesRead||0), totalPages:Number(d.totalPages||0), truncated:!!d.truncated,
      relevance:Number(d.relevance||0), charsOriginal:Number(d.charsOriginal||0), wordsOriginal:Number(d.wordsOriginal||0),
      text:String(d.text||'').slice(0,maxChars)
    };
  }

  function buildSelectedAiInput(ctx={}, packValue) {
    const p=resolvePack(packValue), ip=p.inputPolicy||{}, b=ctx.documentBundle||null;
    const context={
      direction:ctx.direction||'',
      trichYeu:ip.includeSummary?ctx.trichYeu||'':'',
      sender:ip.includeSender?ctx.sender||'':'',
      symbol:ip.includeSymbol?ctx.symbol||'':'',
      documentDate:ip.includeDocumentDate?ctx.documentDate||'':'',
      docType:ip.includeDocType?ctx.docType||'':'',
      urgency:ip.includeUrgency?ctx.urgency||'':'',
      attachmentNames:ip.includeAttachmentNames?Array.from(ctx.attachmentNames||[]):[]
    };
    if(b && (b.primaryDocument || (b.supportingDocuments||[]).length)) {
      const primary=ip.includePrimaryText?compactDoc(b.primaryDocument,ip.maxPrimaryChars):compactDoc({...b.primaryDocument,text:''},0);
      let remaining=Math.max(0,ip.maxTotalChars-String(primary?.text||'').length);
      const supports=[];
      if(ip.includeSupportingDocuments) for(const d of (b.supportingDocuments||[])) {
        if(remaining<=0) break;
        const c=compactDoc(d,Math.min(ip.maxSupportingChars,remaining));
        supports.push(c); remaining-=String(c?.text||'').length;
      }
      context.previewText='';
      context.documentBundle={
        version:b.version||'',
        readMode:b.readMode||'primary',
        sourceSection:b.sourceSection||'',
        signingFileName:b.signingFileName||'',
        primaryDocument:primary,
        supportingDocuments:supports,
        otherFiles:ip.includeOtherFileNames?(b.otherFiles||[]).map(x=>({name:clean(x.name),ext:clean(x.ext),scopeKind:clean(x.scopeKind),status:clean(x.status)})).slice(0,80):[],
        skippedScans:(b.skippedScans||[]).slice(0,30),
        unreadable:(b.unreadable||[]).slice(0,30),
        duplicates:(b.duplicates||[]).slice(0,30),
        stats:b.stats||{},
        aiReady:b.aiReady!==false,
        blockedByScanOnly:!!b.blockedByScanOnly,
        aiBlockedReason:clean(b.aiBlockedReason||''),
        appendixReferenced:!!b.appendixReferenced,
        likelyTaskDeadline:!!b.likelyTaskDeadline,
        appendixRequired:!!b.appendixRequired,
        appendixRequiredMissing:!!b.appendixRequiredMissing,
        additionalReadSuggested:!!b.additionalReadSuggested
      };
    } else {
      context.previewText=ip.includePrimaryText?String(ctx.previewText||'').slice(0,ip.maxPrimaryChars):'';
      context.documentBundle=null;
    }
    return {context, rulePackVersion:p.version, inputPolicyVersion:p.schemaVersion};
  }

  globalThis.IOfficeRulePack=Object.freeze({
    FORMAT,SCHEMA_VERSION,ALLOWED_UNIT_IDS:Object.freeze([...ALLOWED_UNIT_IDS]),
    defaultPack:()=>clone(DEFAULT_PACK),migrate,validate,resolvePack,compilePrompt,buildSelectedAiInput
  });
})();
