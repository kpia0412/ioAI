/* Tracker V7.x: only ping, createTask, listClientCache and completeTask.
 * No automatic write retries: the supplied Sheet API has no idempotency key.
 */
(() => {
  'use strict';
  const UNITS = {U140:'Văn phòng',U141:'Phòng Kinh tế',U142:'Phòng VH-XH',U120:'Trung tâm PVHCC',U183:'Trung tâm Cung ứng',U340:'Công an',U360:'BCHQS',U200:'Trạm Y tế',U221:'THCS',U222:'Tiểu học',U240:'Mẫu giáo',U260:'HĐND'};
  const clean = v => String(v ?? '').trim();
  const symbol = v => clean(v).toUpperCase().replace(/\s+/g,'');
  const flights = new Map();
  const epochs = new Map();
  let writes = Promise.resolve();
  function date(v, required=false) {
    let s=clean(v),m=s.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
    if(m)s=`${m[3]}-${m[2].padStart(2,'0')}-${m[1].padStart(2,'0')}`;
    if(!s&&!required)return '';
    m=s.match(/^(\d{4})-(\d{2})-(\d{2})$/);
    if(!m)throw new Error('Ngày phải có dạng dd/MM/yyyy hoặc yyyy-MM-dd.');
    const d=new Date(+m[1],+m[2]-1,+m[3]);
    if(d.getFullYear()!==+m[1]||d.getMonth()!==+m[2]-1||d.getDate()!==+m[3])throw new Error('Ngày không hợp lệ.');
    return s;
  }
  function payload(d) {
    const unit=UNITS[clean(d.mainUnitId||d.ownerUnitId)] || clean(d.mainUnit||d.xuLyChinh);
    if(!Object.values(UNITS).includes(unit))throw new Error('Đơn vị Xử lý chính không khớp Tracker V7.');
    const taskText=clean(d.taskText||d.nhiemVu);
    if(!taskText)throw new Error('Nội dung nhiệm vụ là bắt buộc.');
    return {sourceNo:clean(d.sourceNo||d.sourceSymbol||d.soKyHieu),sourceDate:date(d.sourceDate||d.ngayVanBan),sourceSubject:clean(d.sourceSubject||d.trichYeu),taskText,mainUnit:unit,deadline:date(d.deadline||d.hanXuLy,true),note:clean(d.note||d.ghiChu)};
  }
  function task(t) {
    return {...t,taskId:clean(t.id),taskText:clean(t.task),sourceSymbol:clean(t.sourceNo),sourceSubject:clean(t.subject),mainUnit:clean(t.unit),mainUnitId:Object.keys(UNITS).find(id=>UNITS[id]===clean(t.unit))||'',deadline:date(t.deadline),businessStatus:t.state==='COMPLETED'?'COMPLETED':'PROCESSING',details:clean(t.note),completedAt:clean(t.confirmedAt)};
  }
  function endpoint(raw) {
    const u=new URL(clean(raw));
    if(u.protocol!=='https:'||u.hostname!=='script.google.com'||!/^\/macros\/s\/[^/]+\/exec$/.test(u.pathname)||u.username||u.password)throw new Error('Nhập URL Apps Script dạng https://script.google.com/macros/s/.../exec.');
    u.search='';u.hash='';return u.href;
  }
  async function hash(s) {return [...new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(s)))].map(b=>b.toString(16).padStart(2,'0')).join('');}
  async function config() {
    const s=await getSettings();
    if(!s.trackerEnabled)throw new Error('Chưa bật kết nối Sổ theo dõi.');
    if(!clean(s.trackerApiUrl)||!clean(s.trackerToken))throw new Error('Nhập URL Web App và TOKEN tiện ích trong Cấu hình.');
    const url=endpoint(s.trackerApiUrl),token=clean(s.trackerToken);
    return {url,token,scope:await hash(url+'|'+token)};
  }
  async function call(c,action,data={}) {
    if(!['ping','createTask','listClientCache','completeTask'].includes(action))throw new Error('Lệnh không thuộc giao thức Tracker V7.');
    if(!await chrome.permissions.contains({origins:['https://script.google.com/*','https://script.googleusercontent.com/*']})){const e=new Error('Chưa cấp quyền Apps Script. Mở Cấu hình và Kiểm tra kết nối.');e.beforeSend=true;throw e;}
    const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),25000);
    try {
      const r=await fetch(c.url,{method:'POST',headers:{'Content-Type':'text/plain;charset=utf-8'},body:JSON.stringify({action,token:c.token,data}),redirect:'follow',signal:controller.signal});
      let out;try {out=JSON.parse(await r.text());}catch(_){throw new Error('Apps Script không trả JSON. Kiểm tra URL /exec và quyền triển khai Web App.');}
      if(out?.ok===false){const e=new Error(out.error||'Tracker từ chối yêu cầu.');e.rejected=true;throw e;}
      if(!r.ok||out?.ok!==true)throw new Error(`Phản hồi Tracker không hợp lệ (HTTP ${r.status}).`);
      return out;
    }catch(e){if(e.name==='AbortError')throw new Error('Tracker chưa phản hồi sau 25 giây.');throw e;}finally{clearTimeout(timer);}
  }
  async function refresh(c,force=false) {
    const key='trackerCacheV7:'+c.scope,old=(await chrome.storage.local.get(key))[key];
    if(!force&&old&&Date.now()-old.updatedAt<30000)return old;
    const epoch=epochs.get(c.scope)||0,flightKey=key+':'+epoch;
    if(flights.has(flightKey))return flights.get(flightKey);
    const p=(async()=>{const out=await call(c,'listClientCache');if(!Array.isArray(out.tasks))throw new Error('Danh sách nhiệm vụ không hợp lệ.');const cache={updatedAt:Date.now(),tasks:out.tasks.map(task)};if((epochs.get(c.scope)||0)!==epoch)return refresh(c,true);await chrome.storage.local.set({[key]:cache});return cache;})();
    flights.set(flightKey,p);try{return await p;}finally{flights.delete(flightKey);}
  }
  async function create(c,d) {
    const data=payload(d),key='trackerCreateV7:'+c.scope+':'+await hash(clean(d.syncKey)||JSON.stringify(data));
    const old=(await chrome.storage.local.get(key))[key];
    if(old?.taskId)return {ok:true,data:{ok:true,taskId:old.taskId,alreadyCreated:true}};
    if(old)throw new Error('Lần gửi trước chưa rõ kết quả. Mở cổng quản lý kiểm tra trước; tiện ích không tự gửi lại để tránh trùng. Nếu chưa có, dùng Thêm nhiệm vụ trên cổng quản lý.');
    // Persist BEFORE fetch so a worker restart cannot replay an uncertain create.
    await chrome.storage.local.set({[key]:{status:'sending',at:Date.now()}});
    let out;
    try{out=await call(c,'createTask',data);}catch(e){if(e.beforeSend||(e.rejected&&/^(TOKEN không hợp lệ\.|Nội dung nhiệm vụ là bắt buộc\.|Xử lý chính là bắt buộc\.|Hạn xử lý là bắt buộc\.|Đơn vị xử lý chính không hợp lệ\.)$/.test(e.message)))await chrome.storage.local.remove(key);else e.message+=' Chưa xác định đã ghi Sheet hay chưa; hãy kiểm tra cổng quản lý. Không tự gửi lại.';throw e;}
    if(!clean(out.taskId))throw new Error('Tracker chưa trả mã nhiệm vụ; kiểm tra cổng quản lý trước khi tạo lại.');
    await chrome.storage.local.set({[key]:{taskId:out.taskId,at:Date.now()}});
    epochs.set(c.scope,(epochs.get(c.scope)||0)+1);
    await chrome.storage.local.remove('trackerCacheV7:'+c.scope);
    return {ok:true,data:out};
  }
  async function handle(message) {
    const c=await config(),d=message.data||{};
    switch(message.type) {
      case 'TRACKER_TEST': {const data=await call(c,'ping');if(!/^7\./.test(clean(data.version)))throw new Error('Bản tiện ích này cần Tracker V7.');await refresh(c,true);return {ok:true,data};}
      case 'TRACKER_CACHE_REFRESH':return {ok:true,cache:await refresh(c,d.force===true)};
      case 'TRACKER_UPSERT':return create(c,d);
      case 'TRACKER_MATCH': {
        const cache=await refresh(c,true),docs=Array.isArray(d.relatedDocs)?d.relatedDocs:[];
        const matches=cache.tasks.filter(t=>symbol(t.sourceSymbol)&&docs.some(r=>symbol(r.symbol)===symbol(t.sourceSymbol)));
        return {ok:true,data:{matched:matches.length===1,needsReview:matches.length>1,task:matches.length===1?matches[0]:null}};
      }
      case 'TRACKER_COMPLETE_LEADER': {
        const taskId=clean(d.taskId);if(!taskId)throw new Error('Thiếu mã nhiệm vụ.');
        const data=await call(c,'completeTask',{taskId});
        epochs.set(c.scope,(epochs.get(c.scope)||0)+1);
    await chrome.storage.local.remove('trackerCacheV7:'+c.scope);return {ok:true,data};
      }
      case 'TRACKER_OPEN_MANAGE': {const u=new URL(c.url);u.searchParams.set('app','manage');await chrome.tabs.create({url:u.href});return {ok:true};}
      default:throw new Error('Chức năng này không được API Tracker V7 hỗ trợ. Hãy mở cổng quản lý.');
    }
  }
  globalThis.IOfficeTrackerClient={UNITS,date,payload,task,endpoint,handle(message){
    // Serialize writes, including duplicate clicks from different iOffice tabs.
    if(['TRACKER_UPSERT','TRACKER_COMPLETE_LEADER'].includes(message.type)){
      const p=writes.then(()=>handle(message));writes=p.catch(()=>{});return p;
    }
    return handle(message);
  }};
})();
