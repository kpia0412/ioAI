iOffice AI 0.50.5 — AUTO UPDATE — tương thích Tracker V7

- Nâng cấp trực tiếp từ 0.50.2, giữ nguyên cấu hình nếu vẫn dùng đúng thư mục Load unpacked và cùng ID tiện ích.
- Tự kiểm tra GitHub mỗi 5 phút. Khi có bản mới, tự tải, kiểm tra SHA-256, sao lưu và thay tệp.
- Nếu iOffice đang phân tích hoặc có nội dung chưa lưu, cập nhật được hoãn và tự thử lại.
- Sau khi cập nhật thành công, tiện ích tự Reload và tự làm mới các tab iOffice đã được đánh dấu an toàn.
- Cần cài Native Helper trên Windows một lần bằng bộ cài đi kèm.


0.50.5: XLC/PH/Xem đơn vị chọn đúng bảng Liên thông nội bộ; Sổ theo dõi bật theo từng văn bản sau khi có hạn; hiển thị trạng thái kết nối Tracker; hạn thủ công đồng bộ iOffice.
