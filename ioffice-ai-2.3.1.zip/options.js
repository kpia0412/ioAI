'use strict';
const $=id=>document.getElementById(id);
const API_PROVIDER='gemini-openai';
const API_BASE_URL='https://generativelanguage.googleapis.com/v1beta/openai/';
const API_MODELS=[
  {id:'gemini-3.5-flash-lite',label:'Gemini 3.5 Flash-Lite'},
  {id:'gemini-3.1-flash-lite',label:'Gemini 3.1 Flash-Lite'},
  {id:'gemini-3.8-flash',label:'Gemini 3.8 Flash'}
];
const MODEL_IDS=API_MODELS.map(x=>x.id);
const DEFAULT_CHAIN=[
  {id:'route-primary-35',enabled:true,model:'gemini-3.5-flash-lite',keyMode:'primary',apiKey:''},
  {id:'route-primary-31',enabled:true,model:'gemini-3.1-flash-lite',keyMode:'primary',apiKey:''},
  {id:'route-primary-38',enabled:true,model:'gemini-3.8-flash',keyMode:'primary',apiKey:''}
];
const defaults={
  analysisMode:'api',readerTimeoutMs:5000,readerMaxFileSizeMb:10,readerConcurrency:0,
  trackerApiUrl:'',trackerToken:'',trackerActorEmail:'',instructionPrefixEnabled:false,instructionPrefixText:'VP đề xuất:',
  providerConfigs:{},apiFallbackChain:DEFAULT_CHAIN,aiRulePack:null,aiRulePackVersion:'',aiRulePackSource:'embedded',
  aiRulePackUpdatedAt:0,ruleAutoUpdate:true
};
let current={...defaults},chain=[],activeRulePack=null,recipientData=null,recipientDirectory=[],recipientDefaultLeaders=[],recipientDraftSelection=new Set(),recipientDraftRole='',healthRunning=false;

function msg(t,ok=true){const el=$('msg');if(!el)return;el.textContent=t;el.className='msg '+(ok?'ok':'err');}
function runtime(m){return new Promise(resolve=>{try{chrome.runtime.sendMessage(m,r=>resolve(chrome.runtime.lastError?{ok:false,error:chrome.runtime.lastError.message}:(r||{ok:false,error:'Không có phản hồi'})));}catch(e){resolve({ok:false,error:e.message});}});}
function routeId(){return 'route-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,7);}
function cloneDefaultChain(){return DEFAULT_CHAIN.map(x=>({...x}));}
function normalizeChain(raw){const arr=Array.isArray(raw)&&raw.length?raw:cloneDefaultChain(),out=[];for(const x of arr.slice(0,8)){if(!x||typeof x!=='object')continue;const model=MODEL_IDS.includes(String(x.model||''))?String(x.model):MODEL_IDS[0],keyMode=x.keyMode==='custom'?'custom':'primary';out.push({id:String(x.id||routeId()),enabled:x.enabled!==false,model,keyMode,apiKey:keyMode==='custom'?String(x.apiKey||''):''});}return out.length?out:cloneDefaultChain();}
function geminiCfg(){const cfg=current.providerConfigs?.[API_PROVIDER]||{},legacyCustom=current.providerConfigs?.custom||{},legacyGemini=current.providerConfigs?.gemini||{},googleCustom=/generativelanguage\.googleapis\.com\/v1beta\/openai/i.test(String(legacyCustom.baseUrl||''));return {model:MODEL_IDS.includes(cfg.model)?cfg.model:MODEL_IDS[0],apiKey:cfg.apiKey||(googleCustom?legacyCustom.apiKey:'')||legacyGemini.apiKey||''};}
function maskKey(key){const s=String(key||'');return s.length<8?'••••':`${s.slice(0,4)}••••${s.slice(-3)}`;}
function modelOptions(selected){return API_MODELS.map(m=>`<option value="${m.id}" ${m.id===selected?'selected':''}>${m.label}</option>`).join('');}
function esc(v){return String(v??'').replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;');}
function toggleSecret(input,button){if(!input)return;const show=input.type==='password';input.type=show?'text':'password';if(button)button.textContent=show?'🙈':'👁';}
document.addEventListener('click',e=>{const b=e.target.closest('[data-secret-target]');if(b){toggleSecret($(b.dataset.secretTarget),b);return;}const dyn=e.target.closest('[data-secret-dynamic]');if(dyn){const input=dyn.closest('.secret-wrap')?.querySelector('input');toggleSecret(input,dyn);}});

function renderChain(){
  const box=$('apiChain');if(!box)return;
  box.innerHTML=chain.map((r,i)=>`<div class="api-route" data-route-id="${esc(r.id)}">
    <div class="api-route-priority">${i+1}</div>
    <label class="api-route-enabled" title="Bật/tắt tuyến"><input type="checkbox" data-f="enabled" ${r.enabled?'checked':''}><span>Bật</span></label>
    <div class="api-route-field"><label>Model</label><select data-f="model">${modelOptions(r.model)}</select></div>
    <div class="api-route-field"><label>API key</label><select data-f="keyMode"><option value="primary" ${r.keyMode==='primary'?'selected':''}>Key chính</option><option value="custom" ${r.keyMode==='custom'?'selected':''}>Key riêng</option></select></div>
    <div class="api-route-field api-route-key ${r.keyMode==='custom'?'':'hidden'}"><label>Key riêng</label><div class="secret-wrap"><input data-f="apiKey" type="password" autocomplete="off" value="${esc(r.apiKey||'')}" placeholder="API key dự phòng"><button class="secret-toggle" type="button" data-secret-dynamic title="Hiện/ẩn mã">👁</button></div></div>
    <div class="api-route-actions"><button class="mini" data-act="test">Test</button><button class="mini" data-act="up" ${i===0?'disabled':''}>↑</button><button class="mini" data-act="down" ${i===chain.length-1?'disabled':''}>↓</button><button class="mini danger" data-act="delete" ${chain.length<=1?'disabled':''}>×</button></div>
    <div class="api-route-status" data-status>${r.keyMode==='custom'&&r.apiKey?`Key riêng ${maskKey(r.apiKey)}`:(r.keyMode==='primary'?'Dùng API key chính':'')}</div>
  </div>`).join('');
  $('apiChainCount').textContent=`${chain.filter(x=>x.enabled).length}/${chain.length} tuyến bật`;
}
function syncRouteFromDom(row){const r=chain.find(x=>x.id===row?.dataset?.routeId);if(!r)return null;r.enabled=!!row.querySelector('[data-f="enabled"]')?.checked;r.model=row.querySelector('[data-f="model"]')?.value||r.model;r.keyMode=row.querySelector('[data-f="keyMode"]')?.value==='custom'?'custom':'primary';r.apiKey=r.keyMode==='custom'?(row.querySelector('[data-f="apiKey"]')?.value||'').trim():'';return r;}
function effectiveRouteConfig(r){return {apiKey:r.keyMode==='custom'?r.apiKey:$('apiKey').value.trim(),model:r.model,baseUrl:API_BASE_URL,authMode:'bearer'};}
async function testRoute(r,row=null){const status=row?.querySelector('[data-status]');if(status){status.textContent='Đang kiểm tra…';status.className='api-route-status checking';}try{const cfg=effectiveRouteConfig(r);if(!cfg.apiKey)throw new Error(r.keyMode==='custom'?'Chưa nhập key riêng.':'Chưa nhập key chính.');const res=await runtime({type:'AI_TEST_API_ROUTE',config:cfg});if(!res?.ok)throw new Error(res?.error||'Không kết nối được API/model.');if(status){status.textContent=`✓ OK · ${r.model}`;status.className='api-route-status ok';}return {ok:true};}catch(e){if(status){status.textContent='✕ '+e.message;status.className='api-route-status err';}return {ok:false,error:e.message};}}
function validateTrackerUrl(url){const u=new URL(String(url||'').trim());if(u.protocol!=='https:'||u.hostname!=='script.google.com'||!/^\/macros\/s\/[^/]+\/exec$/.test(u.pathname)||u.username||u.password)throw new Error('URL phải dạng https://script.google.com/macros/s/.../exec');return u.origin+u.pathname;}
async function loadRulePack(){const r=await runtime({type:'RULE_PACK_GET'});if(!r?.ok)throw new Error(r?.error||'Không tải được Rules.');activeRulePack=r.data?.active||globalThis.IOfficeRulePack.defaultPack();return r.data;}


function setRecipientStatus(text,kind=''){const el=$('recipientStatus');if(!el)return;el.textContent=text;el.className='status '+kind;}
function normUnitText(v){return String(v||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/đ/gi,'d').toLowerCase().replace(/[^a-z0-9]+/g,' ').trim();}
const UNIT_ALIASES={
  U140:['van phong hdnd va ubnd','van phong hdnd ubnd','van phong'],
  U141:['phong kinh te'],U142:['phong van hoa xa hoi','van hoa xa hoi'],
  U120:['trung tam phuc vu hanh chinh cong','phuc vu hanh chinh cong'],
  U183:['trung tam cung ung dich vu su nghiep cong','cung ung dich vu su nghiep cong'],
  U340:['cong an xa','cong an'],U360:['ban chqs','ban chi huy quan su','chqs'],
  U260:['hoi dong nhan dan','hdnd xa'],DUUBND:['dang uy ubnd','dang bo ubnd']
};
function unitName(unitId){const u=(activeRulePack?.units||[]).find(x=>String(x.id||'')===String(unitId||''));return u?.name||String(unitId||'');}
function personBelongsToUnit(person,unitId){
  const pu=String(person?.parentUnit||'').toUpperCase(),uid=String(unitId||'').toUpperCase();if(pu===uid)return true;
  const parent=normUnitText(person?.parentName||'');if(!parent)return false;
  if(uid==='U260'&&parent.includes('van phong'))return false;
  return (UNIT_ALIASES[uid]||[normUnitText(unitName(uid))]).some(a=>a&&parent.includes(a));
}
function allRecipientPeople(){return recipientDirectory.filter(x=>(!x?.type||x.type==='person')&&x?.key);}
function peopleForUnit(unitId){return allRecipientPeople().filter(x=>personBelongsToUnit(x,unitId));}
function directoryPerson(personKey){return allRecipientPeople().find(x=>String(x.key||'')===String(personKey||''))||null;}
function rolesForUnit(unitId){return (recipientData?.rules?.roles||[]).filter(r=>String(r.unitId||'')===String(unitId||''));}
function recipientBindingsForRole(roleKey){return (recipientData?.bindings||[]).filter(x=>String(x.roleKey||'')===String(roleKey||'')&&x.enabled!==false);}
function boundRoleKeys(){return new Set((recipientData?.bindings||[]).filter(x=>x.enabled!==false&&x.personKey).map(x=>String(x.roleKey||'')));}
function cleanRecipientDisplayName(name,parentName=''){
  let s=String(name||'').replace(/\s+/g,' ').trim();
  if(!s)return '';
  const parent=String(parentName||'').replace(/\s+/g,' ').trim();
  const tail=s.match(/\s*\(([^()]*)\)\s*$/);
  if(tail){
    const inside=tail[1].trim();
    if(!parent||normUnitText(inside)===normUnitText(parent)||normUnitText(parent).includes(normUnitText(inside))||normUnitText(inside).includes(normUnitText(parent)))s=s.slice(0,tail.index).trim();
  }
  const words=s.split(/\s+/).filter(Boolean);
  if(words.length>=4&&words.length%2===0){
    const half=words.length/2,a=words.slice(0,half).join(' '),b=words.slice(half).join(' ');
    if(normUnitText(a)===normUnitText(b))s=a;
  }
  return s||String(name||'').trim();
}
function currentRole(){return (recipientData?.rules?.roles||[]).find(r=>r.key===$('recipientRole')?.value)||null;}
function defaultLeaderForUnit(unitId){return recipientDefaultLeaders.find(x=>x?.enabled!==false&&String(x.unitId||'')===String(unitId||''))||null;}
function leaderItemFromPerson(unitId,p){return p?{unitId:String(unitId||''),personKey:String(p.key||''),personName:String(p.name||''),parentUnit:String(p.parentUnit||unitId||''),parentName:String(p.parentName||unitName(unitId)||''),enabled:true}:null;}
async function saveLeaderList(leaders){const r=await runtime({type:'RECIPIENT_LEADERS_SET',leaders});if(!r?.ok)throw new Error(r?.error||'Không lưu được lãnh đạo mặc định.');recipientDefaultLeaders=Array.isArray(r.data)?r.data:leaders;return recipientDefaultLeaders;}
function renderRecipientLeader(){
  const sel=$('recipientDefaultLeader'),unitId=$('recipientUnit')?.value||'';if(!sel)return;
  const people=peopleForUnit(unitId),saved=defaultLeaderForUnit(unitId),chosenKey=String(saved?.personKey||people[0]?.key||'');
  sel.innerHTML=people.length?people.map(p=>`<option value="${esc(p.key)}" ${String(p.key)===chosenKey?'selected':''}>${esc(cleanRecipientDisplayName(p.name||p.key,p.parentName||''))}</option>`).join(''):'<option value=""></option>';
  sel.disabled=!people.length;
}
async function ensureFirstLeaders(){
  const units=[...new Set((recipientData?.rules?.roles||[]).map(r=>String(r.unitId||'')))];let next=[...recipientDefaultLeaders],changed=false;
  for(const unitId of units){if(defaultLeaderForUnit(unitId))continue;const p=peopleForUnit(unitId)[0];if(!p)continue;const item=leaderItemFromPerson(unitId,p);if(item){next.push(item);recipientDefaultLeaders=next;changed=true;}}
  if(changed)await saveLeaderList(next);return changed;
}
async function publishPersonnelConfig({quiet=true}={}){
  try{const r=await runtime({type:'TRACKER_PERSONNEL_PUSH'});if(!r?.ok)throw new Error(r?.error||'Không đồng bộ được phân công.');setHealth('personnelHealth','ok','Đã đồng bộ');return r.data;}catch(e){if(!quiet)setRecipientStatus('Đã lưu trên máy · chưa đồng bộ Tracker: '+e.message,'err');setHealth('personnelHealth','err','Chưa đồng bộ');return null;}
}
function resetRecipientDraft(roleKey){recipientDraftRole=String(roleKey||'');recipientDraftSelection=new Set(recipientBindingsForRole(recipientDraftRole).map(x=>String(x.personKey||'')).filter(Boolean));}
function updateRecipientSelectedUi(){
  const n=recipientDraftSelection.size,count=$('recipientSelectedCount'),add=$('recipientAdd');if(count)count.textContent=n?`${n} người đã chọn`:'Chưa chọn';if(add){add.disabled=!currentRole()||!n;add.textContent=n?`Lưu phân công (${n})`:'Lưu phân công';}
}
function recipientPeopleForCurrentRole(){const role=currentRole();if(!role)return[];return $('recipientCrossUnit')?.checked?allRecipientPeople():peopleForUnit(role.unitId);}
function renderRecipientPeople(){
  const box=$('recipientPersonList');if(!box)return;const role=currentRole(),people=recipientPeopleForCurrentRole(),q=normUnitText($('recipientPersonSearch')?.value||'');
  const filtered=people.filter(p=>!q||normUnitText(`${p.name||''} ${p.parentName||''}`).includes(q)).sort((a,b)=>String(a.name||'').localeCompare(String(b.name||''),'vi'));
  if(!role){box.innerHTML='<div class="person-choice-empty">Chọn lĩnh vực trước.</div>';updateRecipientSelectedUi();return;}
  if(!people.length){box.innerHTML=`<div class="person-choice-empty">${$('recipientCrossUnit')?.checked?'Chưa đồng bộ được danh bạ iOffice.':'Chưa có người thuộc '+esc(unitName(role.unitId))+'.'}</div>`;updateRecipientSelectedUi();return;}
  if(!filtered.length){box.innerHTML='<div class="person-choice-empty">Không tìm thấy cán bộ phù hợp từ khóa.</div>';updateRecipientSelectedUi();return;}
  box.innerHTML=filtered.map(p=>{const key=String(p.key||''),parent=String(p.parentName||unitName(p.parentUnit)||'').trim(),displayName=cleanRecipientDisplayName(p.name||key,parent),checked=recipientDraftSelection.has(key),cross=!personBelongsToUnit(p,role.unitId);return `<label class="person-choice ${checked?'selected':''}"><input type="checkbox" value="${esc(key)}" ${checked?'checked':''}><span class="person-choice-meta"><b>${esc(displayName||key)}</b><small>${esc(parent||'Không rõ đơn vị')}</small></span>${cross?'<span class="exception-badge">Khác đơn vị</span>':''}</label>`;}).join('');
  updateRecipientSelectedUi();
}
function renderRecipientPicker(preferredRole=''){
  if(!recipientData?.rules)return;const unitSel=$('recipientUnit'),roleSel=$('recipientRole'),crossEl=$('recipientCrossUnit');if(!unitSel||!roleSel)return;
  const roles=recipientData.rules.roles||[],units=[...new Set(roles.map(r=>r.unitId))],bound=boundRoleKeys();const preferred=roles.find(r=>r.key===preferredRole),selectedUnit=preferred?.unitId||unitSel.value||units[0]||'';
  unitSel.innerHTML=units.map(id=>`<option value="${esc(id)}" ${id===selectedUnit?'selected':''}>${esc(unitName(id))}</option>`).join('');
  const unitRoles=rolesForUnit(unitSel.value),desired=preferredRole||roleSel.value,selectedRole=unitRoles.some(r=>r.key===desired)?desired:(unitRoles[0]?.key||'');
  roleSel.innerHTML=unitRoles.map(r=>`<option value="${esc(r.key)}" ${r.key===selectedRole?'selected':''}>${esc(r.label)}${bound.has(r.key)?` · ${recipientBindingsForRole(r.key).length} người`:''}</option>`).join('');
  const bindings=recipientBindingsForRole(roleSel.value);if(crossEl)crossEl.checked=bindings.some(x=>x.crossUnit===true);
  if(recipientDraftRole!==roleSel.value||preferredRole)resetRecipientDraft(roleSel.value);
  if($('recipientPersonSearch'))$('recipientPersonSearch').value='';renderRecipientLeader();renderRecipientPeople();
}
function renderRecipientBindings(){
  const box=$('recipientBindings');if(!box||!recipientData?.rules)return;const roles=new Map((recipientData.rules.roles||[]).map(r=>[r.key,r])),all=(recipientData.bindings||[]).filter(b=>roles.has(b.roleKey)&&b.enabled!==false);
  const groups=new Map();for(const b of all){if(!groups.has(b.roleKey))groups.set(b.roleKey,[]);groups.get(b.roleKey).push(b);}const total=recipientData.rules.roles.length,peopleCount=all.length;
  $('recipientBindingCount').textContent=`Đã phân công ${groups.size}/${total} lĩnh vực · ${peopleCount} người`;const un=$('recipientUnboundCount');if(un)un.textContent=groups.size<total?`${total-groups.size} chưa gắn`:'Đã gắn đủ';
  if(!groups.size){box.innerHTML='<div class="recipient-empty">Chưa có phân công. Chọn lĩnh vực và đánh dấu một hoặc nhiều người ở phía trên.</div>';return;}
  const ordered=[...groups.entries()].sort((a,b)=>{const ra=roles.get(a[0]),rb=roles.get(b[0]);return unitName(ra?.unitId).localeCompare(unitName(rb?.unitId),'vi')||String(ra?.label||'').localeCompare(String(rb?.label||''),'vi');});
  box.innerHTML=ordered.map(([roleKey,bindings])=>{const role=roles.get(roleKey),uid=role?.unitId||bindings[0]?.unitId||'';const people=bindings.map(b=>{const p=directoryPerson(b.personKey),rawName=String(p?.name||b.personName||b.personKey||'Không còn trong danh bạ'),punit=String(p?.parentName||b.parentName||unitName(p?.parentUnit||b.parentUnit)||'').trim(),name=cleanRecipientDisplayName(rawName,punit),cross=b.crossUnit===true||!!(p&&!personBelongsToUnit(p,uid));return `<span class="assigned-person"><span class="assigned-person-copy"><b>${esc(name)}</b>${punit?`<small>${esc(punit)}</small>`:''}</span>${cross?'<em>Khác đơn vị</em>':''}<button type="button" title="Bỏ người này" data-recipient-act="delete-person" data-person-key="${esc(b.personKey)}">×</button></span>`;}).join('');return `<div class="recipient-row recipient-row-group" data-role-key="${esc(roleKey)}"><div class="rr-unit">${esc(unitName(uid))}</div><div class="rr-role"><b>${esc(role?.label||'Lĩnh vực')}</b><small>${esc((role?.topics||[]).slice(0,4).join(' · '))}</small></div><div class="assigned-people">${people}</div><div class="rr-actions"><button class="mini" type="button" data-recipient-act="edit">Sửa</button><button class="mini danger" type="button" data-recipient-act="delete">Xóa tất cả</button></div></div>`;}).join('');
}
async function loadRecipientRules(){
  const r=await runtime({type:'RECIPIENT_RULES_GET'});if(!r?.ok)throw new Error(r?.error||'Không tải được Recipient Rules.');recipientData=r.data||{};recipientDefaultLeaders=Array.isArray(recipientData.defaultLeaders)?recipientData.defaultLeaders:[];const store=await chrome.storage.local.get({leaderWatcherDirectory:[]});recipientDirectory=Array.isArray(store.leaderWatcherDirectory)?store.leaderWatcherDirectory:[];
  await ensureFirstLeaders().catch(()=>{});recipientData.defaultLeaders=recipientDefaultLeaders;const rv=$('recipientRulesVersion'),rs=$('recipientRulesSource');if(rv)rv.textContent=recipientData.rules?.version||'—';const phase=recipientData.meta?.phase||'';if(rs)rs.textContent=phase==='installed'?'Đã cập nhật':phase==='available'?'Có bản mới':'Đang áp dụng';recipientDraftRole='';recipientDraftSelection=new Set();renderRecipientPicker();renderRecipientBindings();return recipientData;
}
async function saveRecipientAssignment(){
  const role=currentRole();if(!role)throw new Error('Chưa chọn lĩnh vực.');if(!recipientDraftSelection.size)throw new Error('Hãy chọn ít nhất một người được giao.');const allowCross=!!$('recipientCrossUnit')?.checked,newBindings=[];
  for(const personKey of recipientDraftSelection){const person=directoryPerson(personKey);if(!person)continue;const belongs=personBelongsToUnit(person,role.unitId);if(!belongs&&!allowCross)throw new Error(`${person.name||'Người được chọn'} không thuộc ${unitName(role.unitId)}. Bật “Ngoại lệ khác đơn vị” nếu đây là phân công thực tế.`);newBindings.push({roleKey:role.key,unitId:role.unitId,personKey:String(person.key),personName:String(person.name||''),parentUnit:String(person.parentUnit||''),parentName:String(person.parentName||''),crossUnit:!belongs,enabled:true});}
  if(!newBindings.length)throw new Error('Không tìm thấy người đã chọn trong danh bạ iOffice.');const keep=(recipientData?.bindings||[]).filter(x=>x.roleKey!==role.key);const res=await runtime({type:'RECIPIENT_BINDINGS_SET',bindings:[...keep,...newBindings]});if(!res?.ok)throw new Error(res?.error||'Không lưu được phân công.');recipientData.bindings=res.data||[];resetRecipientDraft(role.key);renderRecipientBindings();renderRecipientPicker(role.key);setRecipientStatus(`✓ Đã lưu ${newBindings.length} người cho lĩnh vực “${role.label}”.`,'ok');void publishPersonnelConfig({quiet:true});
}
async function deleteRecipientAssignment(roleKey,personKey=''){
  const role=(recipientData?.rules?.roles||[]).find(r=>r.key===roleKey);let bindings=(recipientData?.bindings||[]).filter(x=>personKey?!(x.roleKey===roleKey&&String(x.personKey)===String(personKey)):x.roleKey!==roleKey);const res=await runtime({type:'RECIPIENT_BINDINGS_SET',bindings});if(!res?.ok)throw new Error(res?.error||'Không xóa được phân công.');recipientData.bindings=res.data||bindings;recipientDraftRole='';renderRecipientBindings();renderRecipientPicker(roleKey);setRecipientStatus(personKey?`✓ Đã bỏ một người khỏi “${role?.label||'lĩnh vực'}”.`:`✓ Đã xóa toàn bộ phân công của “${role?.label||'lĩnh vực'}”.`,'ok');void publishPersonnelConfig({quiet:true});
}

function syncPrefixSetting(){const enabled=$('instructionPrefixEnabled')?.checked===true,text=$('instructionPrefixText');if(text){text.disabled=!enabled;text.title=enabled?'Tiền tố sẽ được thêm trước nội dung đề xuất.':'Bật “Thêm tiền tố tự động” để sử dụng trường này.';}}

function setHealth(id,kind,text){const el=$(id);if(!el)return;el.classList.remove('ok','err','checking');if(kind)el.classList.add(kind);const small=el.querySelector('small');if(small)small.textContent=text;}
async function saveTrackerFieldsForCheck(){
  let trackerApiUrl=$('trackerApiUrl')?.value.trim()||'',trackerToken=$('trackerToken')?.value.trim()||'',trackerActorEmail=String($('trackerActorEmail')?.value||'').trim().toLowerCase();
  if(trackerApiUrl)trackerApiUrl=validateTrackerUrl(trackerApiUrl);if(trackerActorEmail&&!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(trackerActorEmail))throw new Error('Email Tracker không hợp lệ.');
  await chrome.storage.local.set({trackerApiUrl,trackerToken,trackerActorEmail});current={...current,trackerApiUrl,trackerToken,trackerActorEmail};return {trackerApiUrl,trackerToken,trackerActorEmail};
}
async function checkApiHealth(){
  setHealth('apiHealth','checking','Đang kiểm tra…');const el=$('apiStatus');if(el){el.textContent='Đang kiểm tra chuỗi API…';el.className='status';}
  for(const row of [...document.querySelectorAll('.api-route')])syncRouteFromDom(row);const enabled=chain.filter(x=>x.enabled);if(!enabled.length){setHealth('apiHealth','err','Chưa cấu hình');if(el){el.textContent='Chưa bật tuyến API nào.';el.className='status err';}return false;}
  let ok=0;for(const r of enabled){const row=document.querySelector(`.api-route[data-route-id="${CSS.escape(r.id)}"]`),rs=await testRoute(r,row);if(rs.ok)ok++;}
  const full=ok===enabled.length;setHealth('apiHealth',full?'ok':ok?'checking':'err',`${ok}/${enabled.length} tuyến`);if(el){el.textContent=full?`✓ ${ok}/${enabled.length} tuyến sẵn sàng.`:`⚠ ${ok}/${enabled.length} tuyến sẵn sàng.`;el.className='status '+(full?'ok':'err');}return ok>0;
}
async function checkTrackerHealth(){
  setHealth('trackerHealth','checking','Đang kiểm tra…');setHealth('personnelHealth','checking','Đang đồng bộ…');const el=$('trackerStatus');if(el){el.textContent='Đang kiểm tra Sổ theo dõi…';el.className='status';}
  try{const c=await saveTrackerFieldsForCheck();if(!c.trackerApiUrl||!c.trackerToken)throw new Error('Chưa nhập URL/TOKEN');const r=await runtime({type:'TRACKER_TEST'});if(!r?.ok)throw new Error(r?.error||'Không kết nối được Tracker.');setHealth('trackerHealth','ok',`Tracker ${r.data?.version||''}`.trim());const ps=r.data?.personnel;if(ps?.synced){setHealth('personnelHealth','ok','Đã đồng bộ');await loadRecipientRules();}else if(ps?.unsupported){setHealth('personnelHealth','err','Cần Tracker 8.0.1');}else{const hasLocal=Boolean((recipientData?.bindings||[]).length||(recipientDefaultLeaders||[]).length);const seeded=hasLocal&&c.trackerActorEmail?await publishPersonnelConfig({quiet:true}):null;setHealth('personnelHealth',seeded?'ok':'checking',seeded?'Đã đồng bộ':'Chưa có cấu hình chung');}if(el){el.textContent=`✓ Tracker ${r.data?.version||''} · ${Number(r.data?.taskCount||0)} nhiệm vụ đang mở.`;el.className='status ok';}return true;}catch(e){setHealth('trackerHealth','err','Không kết nối');setHealth('personnelHealth','err','Dùng bản trên máy');if(el){el.textContent='✕ '+e.message;el.className='status err';}return false;}
}
async function checkConnections(){if(healthRunning)return;healthRunning=true;const b=$('recheckConnections');if(b)b.disabled=true;try{await Promise.all([checkApiHealth(),checkTrackerHealth()]);}finally{healthRunning=false;if(b)b.disabled=false;}}

async function load(){
  current=await chrome.storage.local.get(defaults);$('version').textContent='v'+chrome.runtime.getManifest().version;
  $('analysisMode').value=['api','gemini-web','chatgpt-web'].includes(current.analysisMode)?current.analysisMode:'api';
  $('instructionPrefixEnabled').checked=current.instructionPrefixEnabled===true;$('instructionPrefixText').value=current.instructionPrefixText||'VP đề xuất:';syncPrefixSetting();
  $('trackerApiUrl').value=current.trackerApiUrl||'';$('trackerToken').value=current.trackerToken||'';$('trackerActorEmail').value=current.trackerActorEmail||'';
  $('readerTimeoutSec').value=String(Math.round((current.readerTimeoutMs||5000)/1000));$('readerMaxFileSizeMb').value=String(current.readerMaxFileSizeMb||10);
  const cpu=await runtime({type:'SYSTEM_CPU_INFO'}),logical=Math.max(1,Number(cpu?.data?.numOfProcessors||navigator.hardwareConcurrency||1)),sel=$('readerConcurrency');
  sel.innerHTML='<option value="0">Tự động tối đa theo CPU</option>'+Array.from({length:logical},(_,i)=>`<option value="${i+1}">${i+1} luồng</option>`).join('');sel.value=String(Math.max(0,Math.min(logical,Number(current.readerConcurrency)||0)));
  const model=String(cpu?.data?.modelName||'CPU không xác định').trim(),arch=String(cpu?.data?.archName||'').trim();$('cpuInfo').textContent=`CPU: ${model}${arch?` · ${arch}`:''} · ${logical} luồng logic · tự động tối đa.`;
  const cfg=geminiCfg();$('apiBaseUrl').value=API_BASE_URL;$('apiKey').value=cfg.apiKey;chain=normalizeChain(current.apiFallbackChain);renderChain();await loadRulePack();await loadRecipientRules();const cs=$('componentSummary');if(cs)cs.textContent=`Tiện ích ${chrome.runtime.getManifest().version} · Rules ${activeRulePack?.version||'—'} · Recipient ${recipientData?.rules?.version||'—'} · Privacy Shield 2.1`;setTimeout(()=>void checkConnections(),0);
}

$('instructionPrefixEnabled')?.addEventListener('change',syncPrefixSetting);

$('apiChain')?.addEventListener('change',e=>{const row=e.target.closest('.api-route');if(!row)return;syncRouteFromDom(row);if(e.target.dataset.f==='keyMode')renderChain();else $('apiChainCount').textContent=`${chain.filter(x=>x.enabled).length}/${chain.length} tuyến bật`;});
$('apiChain')?.addEventListener('input',e=>{const row=e.target.closest('.api-route');if(row)syncRouteFromDom(row);});
$('apiChain')?.addEventListener('click',async e=>{const b=e.target.closest('[data-act]');if(!b)return;const row=b.closest('.api-route'),idx=chain.findIndex(x=>x.id===row.dataset.routeId);if(idx<0)return;syncRouteFromDom(row);const act=b.dataset.act;if(act==='up'&&idx>0)[chain[idx-1],chain[idx]]=[chain[idx],chain[idx-1]];else if(act==='down'&&idx<chain.length-1)[chain[idx+1],chain[idx]]=[chain[idx],chain[idx+1]];else if(act==='delete'&&chain.length>1)chain.splice(idx,1);else if(act==='test'){await testRoute(chain[idx],row);return;}renderChain();});
$('addSameKeyRoute')?.addEventListener('click',()=>{if(chain.length>=8)return msg('Tối đa 8 tuyến API.',false);const used=new Set(chain.filter(x=>x.keyMode==='primary').map(x=>x.model)),model=MODEL_IDS.find(x=>!used.has(x))||MODEL_IDS[0];chain.push({id:routeId(),enabled:true,model,keyMode:'primary',apiKey:''});renderChain();});
$('addCustomKeyRoute')?.addEventListener('click',()=>{if(chain.length>=8)return msg('Tối đa 8 tuyến API.',false);chain.push({id:routeId(),enabled:true,model:MODEL_IDS[0],keyMode:'custom',apiKey:''});renderChain();});

$('recipientUnit')?.addEventListener('change',()=>{recipientDraftRole='';if($('recipientCrossUnit'))$('recipientCrossUnit').checked=false;renderRecipientPicker();setRecipientStatus('Chọn lĩnh vực và một hoặc nhiều người được giao.','');});
$('recipientDefaultLeader')?.addEventListener('change',async()=>{try{const unitId=$('recipientUnit')?.value||'',person=directoryPerson($('recipientDefaultLeader')?.value||'');let next=recipientDefaultLeaders.filter(x=>String(x.unitId||'')!==unitId);const item=leaderItemFromPerson(unitId,person);if(item)next.push(item);await saveLeaderList(next);recipientData.defaultLeaders=recipientDefaultLeaders;setRecipientStatus(item?`✓ Lãnh đạo mặc định ${unitName(unitId)}: ${cleanRecipientDisplayName(person.name||person.key,person.parentName||'')}.`:'✓ Đã bỏ lãnh đạo mặc định.','ok');void publishPersonnelConfig({quiet:true});}catch(e){setRecipientStatus('✕ '+e.message,'err');}});
$('recipientRole')?.addEventListener('change',()=>{recipientDraftRole='';if($('recipientCrossUnit'))$('recipientCrossUnit').checked=false;renderRecipientPicker($('recipientRole')?.value||'');});
$('recipientCrossUnit')?.addEventListener('change',()=>{if(!$('recipientCrossUnit').checked){const allowed=new Set(peopleForUnit(currentRole()?.unitId||'').map(x=>String(x.key||'')));recipientDraftSelection=new Set([...recipientDraftSelection].filter(k=>allowed.has(k)));}renderRecipientPeople();});
$('recipientPersonSearch')?.addEventListener('input',()=>renderRecipientPeople());
$('recipientPersonList')?.addEventListener('change',e=>{const input=e.target.closest('input[type="checkbox"]');if(!input)return;input.checked?recipientDraftSelection.add(String(input.value)):recipientDraftSelection.delete(String(input.value));renderRecipientPeople();});
$('recipientAdd')?.addEventListener('click',async()=>{try{await saveRecipientAssignment();}catch(e){setRecipientStatus('✕ '+e.message,'err');}});
$('recipientBindings')?.addEventListener('click',async e=>{const b=e.target.closest('[data-recipient-act]');if(!b)return;const row=b.closest('.recipient-row'),roleKey=row?.dataset?.roleKey||'';if(!roleKey)return;try{if(b.dataset.recipientAct==='edit'){const role=(recipientData?.rules?.roles||[]).find(r=>r.key===roleKey);if(role){$('recipientUnit').value=role.unitId;recipientDraftRole='';renderRecipientPicker(roleKey);$('recipientPersonSearch')?.focus();setRecipientStatus('Đã nạp danh sách hiện tại. Chọn/bỏ người rồi bấm Lưu phân công.','');}}else if(b.dataset.recipientAct==='delete-person')await deleteRecipientAssignment(roleKey,b.dataset.personKey||'');else if(b.dataset.recipientAct==='delete')await deleteRecipientAssignment(roleKey);}catch(err){setRecipientStatus('✕ '+err.message,'err');}});
$('recheckConnections')?.addEventListener('click',()=>void checkConnections());

$('save')?.addEventListener('click',async()=>{try{
  for(const row of [...document.querySelectorAll('.api-route')])syncRouteFromDom(row);
  const apiKey=$('apiKey').value.trim(),enabledRoutes=chain.filter(x=>x.enabled);if(!enabledRoutes.length)throw new Error('Cần bật ít nhất 1 tuyến API.');if(enabledRoutes.some(x=>x.keyMode==='primary')&&!apiKey)throw new Error('Chưa nhập API key chính.');if(enabledRoutes.some(x=>x.keyMode==='custom'&&!x.apiKey))throw new Error('Có tuyến key riêng nhưng chưa nhập key.');
  const providerConfigs={...(current.providerConfigs||{})};providerConfigs[API_PROVIDER]={...(providerConfigs[API_PROVIDER]||{}),model:enabledRoutes[0].model,baseUrl:API_BASE_URL,apiKey,authMode:'bearer'};
  let trackerApiUrl=$('trackerApiUrl').value.trim(),trackerToken=$('trackerToken').value.trim(),trackerActorEmail=String($('trackerActorEmail')?.value||'').trim().toLowerCase();if((trackerApiUrl&&!trackerToken)||(!trackerApiUrl&&trackerToken))throw new Error('Tracker cần nhập đủ URL và TOKEN.');if(trackerActorEmail&&!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(trackerActorEmail))throw new Error('Email tài khoản Tracker không hợp lệ.');if(trackerApiUrl)trackerApiUrl=validateTrackerUrl(trackerApiUrl);
  const settings={userRole:'leader',aiAnalysisEnabled:true,analysisMode:$('analysisMode').value,fallbackAnalysisMode:'none',webAiEnabled:true,webGeminiForeground:false,webGeminiFirstForeground:false,webChatgptForeground:false,webChatgptFirstForeground:false,webGeminiMaxTurns:3,webChatgptMaxTurns:3,webGeminiTimeoutMs:150000,webChatgptTimeoutMs:150000,aiRequireCompleteFiles:false,readerMode:'primary',readerTimeoutMs:Math.max(2000,Math.min(60000,Number($('readerTimeoutSec').value||5)*1000)),readerMaxFileSizeMb:Math.max(1,Math.min(50,Number($('readerMaxFileSizeMb').value||10))),readerIncludeRelated:false,readerConcurrency:Math.max(0,Math.min(64,Number($('readerConcurrency')?.value||0))),readerDeduplicateContent:true,readerScanEnabled:false,trackerApiUrl,trackerToken,trackerActorEmail,instructionPrefixEnabled:$('instructionPrefixEnabled').checked,instructionPrefixText:String($('instructionPrefixText').value||'VP đề xuất:').trim(),providerOrder:[API_PROVIDER,'none','none','none'],providerConfigs,apiFallbackChain:normalizeChain(chain),retriesPerProvider:1,requestTimeoutMs:45000};
  await chrome.storage.local.set(settings);await chrome.storage.local.remove(['trackerEnabled','trackerReminderDays','qualityEscalationEnabled','qualityEscalationThreshold']);current={...current,...settings};msg(`✓ Đã lưu · ${enabledRoutes.length} tuyến API · đang tải lại…`,true);$('save').disabled=true;$('save').textContent='Đã lưu';setTimeout(()=>location.reload(),650);
}catch(e){msg(e.message,false);}});


chrome.storage.onChanged.addListener((changes,area)=>{if(area==='local'&&(changes.recipientRules||changes.recipientRulesMeta||changes.recipientLocalBindings||changes.recipientDefaultLeaders||changes.leaderWatcherDirectory))void loadRecipientRules().catch(()=>{});});

load().catch(e=>msg('Không tải được cấu hình: '+e.message,false));
