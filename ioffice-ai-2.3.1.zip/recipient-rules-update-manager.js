(() => {
  'use strict';
  const FEED_URL='https://kpia0412.github.io/ioAI/latest-recipient.json';
  const ALARM='ioffice-recipient-rules-update';
  const PERIOD_MIN=15;
  const RULES_KEY='recipientRules';
  const META_KEY='recipientRulesMeta';
  const AUTO_KEY='recipientRulesAutoUpdate';
  const BINDINGS_KEY='recipientLocalBindings';
  const LEADERS_KEY='recipientDefaultLeaders';
  const SHARED_META_KEY='recipientSharedConfigMeta';
  const now=()=>Date.now();

  function validVersion(v){return /^\d+(?:\.\d+){2}$/.test(String(v||''));}
  function validate(data){
    if(!data||data.format!=='ioffice-recipient-rules-v1')throw new Error('Recipient Rules sai format.');
    if(!validVersion(data.version))throw new Error('Version Recipient Rules không hợp lệ.');
    const seen=new Set();
    const roles=(Array.isArray(data.roles)?data.roles:[]).map((r,i)=>{
      const key=String(r?.key||'').trim(),unitId=String(r?.unitId||'').trim().toUpperCase();
      if(!/^(?:U\d+|DUUBND)-R\d+$/i.test(key))throw new Error(`Lĩnh vực #${i+1} có key không hợp lệ.`);
      if(!/^(?:U\d+|DUUBND)$/i.test(unitId))throw new Error(`Lĩnh vực ${key} có unitId không hợp lệ.`);
      if(seen.has(key))throw new Error(`Trùng mã lĩnh vực ${key}.`);seen.add(key);
      const label=String(r.label||'').trim();if(!label)throw new Error(`Lĩnh vực ${key} thiếu tên hiển thị.`);
      // File công khai tuyệt đối không được chứa trường người thật/ID người dùng.
      for(const forbidden of ['personName','fullName','personId','personKey','userId','email','phone'])if(r?.[forbidden])throw new Error(`Lĩnh vực ${key} chứa trường cá nhân không được phép: ${forbidden}.`);
      return {key,unitId,label:label.slice(0,180),topics:(Array.isArray(r.topics)?r.topics:[]).map(x=>String(x).trim()).filter(Boolean).slice(0,50)};
    });
    if(!roles.length)throw new Error('Recipient Rules chưa có lĩnh vực.');
    return {format:data.format,version:String(data.version),name:String(data.name||'Recipient Roles').slice(0,120),updatedAt:String(data.updatedAt||''),minConfidence:Math.max(.7,Math.min(.98,Number(data.minConfidence)||.86)),policy:{alwaysKeepMainUnit:true,additionalRecipientOnly:true,requireSameUnit:true,neverSendPersonNameToAI:true,fallbackToUnitOnly:true,...(data.policy||{})},roles};
  }
  async function fetchText(url,timeoutMs=15000){
    const u=new URL(String(url||''));if(u.protocol!=='https:'||u.username||u.password)throw new Error('Recipient update chỉ chấp nhận HTTPS.');
    const c=new AbortController(),timer=setTimeout(()=>c.abort(),timeoutMs);
    try{const r=await fetch(u.href,{cache:'no-store',credentials:'omit',signal:c.signal,headers:{Accept:'application/json'}});if(!r.ok)throw new Error(`HTTP ${r.status}`);return {text:await r.text(),url:u.href};}finally{clearTimeout(timer);}
  }
  async function sha256Hex(text){const h=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(String(text)));return [...new Uint8Array(h)].map(x=>x.toString(16).padStart(2,'0')).join('');}
  function validateRelease(data,currentVersion){
    if(!data||data.format!=='ioffice-recipient-release-v1')throw new Error('latest-recipient.json sai format.');
    const version=String(data.version||'');if(!validVersion(version))throw new Error('Version Recipient Rules không hợp lệ.');
    const u=new URL(String(data.downloadUrl||''));if(u.protocol!=='https:'||u.username||u.password)throw new Error('downloadUrl Recipient phải dùng HTTPS.');
    const sha=String(data.sha256||'').toLowerCase();if(!/^[a-f0-9]{64}$/.test(sha))throw new Error('latest-recipient.json thiếu SHA-256 hợp lệ.');
    return {version,newer:globalThis.IOfficeCore.compareVersions(version,String(currentVersion||'0.0.0'))>0,downloadUrl:u.href,sha256:sha,notes:String(data.notes||'').slice(0,1200)};
  }
  async function embedded(){const r=await fetch(chrome.runtime.getURL('recipient.json'),{cache:'no-store'});if(!r.ok)throw new Error('Không đọc được Recipient Rules mặc định.');return validate(await r.json());}
  async function current(){const raw=await chrome.storage.local.get({[RULES_KEY]:null,[META_KEY]:{},[AUTO_KEY]:true,[BINDINGS_KEY]:[],[LEADERS_KEY]:[],[SHARED_META_KEY]:{}});const rules=raw[RULES_KEY]?validate(raw[RULES_KEY]):await embedded();return {rules,meta:raw[META_KEY]||{},auto:raw[AUTO_KEY]!==false,bindings:Array.isArray(raw[BINDINGS_KEY])?raw[BINDINGS_KEY]:[],leaders:Array.isArray(raw[LEADERS_KEY])?raw[LEADERS_KEY]:[],sharedMeta:raw[SHARED_META_KEY]||{}};}
  async function setMeta(patch){const raw=await chrome.storage.local.get({[META_KEY]:{}});const next={...(raw[META_KEY]||{}),...patch};await chrome.storage.local.set({[META_KEY]:next});return next;}
  async function check(){
    const cur=await current();await setMeta({phase:'checking',error:'',checkedAt:now(),currentVersion:cur.rules.version,feedUrl:FEED_URL});
    try{const feed=JSON.parse((await fetchText(FEED_URL)).text),rel=validateRelease(feed,cur.rules.version);return await setMeta({...rel,phase:rel.newer?'available':'current',error:'',checkedAt:now(),currentVersion:cur.rules.version,feedUrl:FEED_URL});}
    catch(e){return await setMeta({phase:'error',newer:false,error:`Không kiểm tra được Recipient Rules: ${e.message}`,checkedAt:now(),currentVersion:cur.rules.version,feedUrl:FEED_URL});}
  }
  async function apply(release=null){
    const cur=await current(),rel=release||cur.meta;if(!rel?.downloadUrl)throw new Error('Chưa có Recipient Rules mới để áp dụng.');
    const metaRelease=validateRelease({format:'ioffice-recipient-release-v1',version:rel.version,downloadUrl:rel.downloadUrl,sha256:rel.sha256,notes:rel.notes||''},cur.rules.version);
    await setMeta({...metaRelease,phase:'applying',error:'',currentVersion:cur.rules.version});
    const fetched=await fetchText(metaRelease.downloadUrl),actual=await sha256Hex(fetched.text);if(actual!==metaRelease.sha256)throw new Error('SHA-256 Recipient Rules không khớp. Không áp dụng bản tải về.');
    const remote=validate(JSON.parse(fetched.text));if(remote.version!==metaRelease.version)throw new Error(`Version trong Recipient Rules (${remote.version}) không khớp feed (${metaRelease.version}).`);
    await chrome.storage.local.set({[RULES_KEY]:remote});await setMeta({phase:'installed',newer:false,version:remote.version,currentVersion:remote.version,error:'',installedAt:now(),feedUrl:FEED_URL,downloadUrl:metaRelease.downloadUrl,sha256:actual,notes:metaRelease.notes||''});return remote;
  }
  async function autoCycle(){await chrome.storage.local.set({[AUTO_KEY]:true});const st=await check();if(st.newer){try{return {ok:true,rules:await apply(st)};}catch(e){await setMeta({phase:'error',error:e.message});return {ok:false,error:e.message};}}return {ok:true,state:st};}
  async function ensureAlarm(){if(!await chrome.alarms.get(ALARM))await chrome.alarms.create(ALARM,{delayInMinutes:2,periodInMinutes:PERIOD_MIN});}

  function sanitizeBindings(bindings,rules){
    const roles=new Map((rules.roles||[]).map(r=>[r.key,r])),seen=new Set(),out=[];
    for(const x of (Array.isArray(bindings)?bindings:[])){
      const roleKey=String(x?.roleKey||''),role=roles.get(roleKey),unitId=String(x?.unitId||role?.unitId||'').toUpperCase();
      const item={roleKey,unitId,personKey:String(x?.personKey||''),personName:String(x?.personName||''),parentUnit:String(x?.parentUnit||''),parentName:String(x?.parentName||''),crossUnit:x?.crossUnit===true,enabled:x?.enabled!==false};
      if(!role||!item.personKey||item.unitId!==String(role.unitId||'').toUpperCase())continue;
      const p=String(item.parentUnit||'').toUpperCase();if(/^(?:U\d+|DUUBND)$/.test(p)&&p!==item.unitId&&!item.crossUnit)continue;
      const key=`${item.roleKey}::${item.personKey}`;if(seen.has(key))continue;seen.add(key);out.push(item);
    }
    return out;
  }

  function sanitizeLeaders(leaders){
    const seen=new Set(),out=[];
    for(const x of (Array.isArray(leaders)?leaders:[])){
      const unitId=String(x?.unitId||'').trim().toUpperCase(),personKey=String(x?.personKey||'').trim();
      if(!/^(?:U\d+|DUUBND)$/.test(unitId)||!personKey||seen.has(unitId))continue;
      seen.add(unitId);out.push({unitId,personKey,personName:String(x?.personName||'').trim().slice(0,180),parentUnit:String(x?.parentUnit||unitId).trim().toUpperCase(),parentName:String(x?.parentName||'').trim().slice(0,180),enabled:x?.enabled!==false});
    }
    return out;
  }
  async function getLeaders(){const cur=await current();return sanitizeLeaders(cur.leaders);}
  async function setLeaders(leaders){const clean=sanitizeLeaders(leaders);await chrome.storage.local.set({[LEADERS_KEY]:clean});return clean;}
  async function exportSharedConfig(){const cur=await current();return {format:'ioffice-personnel-config-v1',rulesVersion:cur.rules.version,updatedAt:new Date().toISOString(),bindings:sanitizeBindings(cur.bindings,cur.rules),defaultLeaders:sanitizeLeaders(cur.leaders)};}
  async function importSharedConfig(cfg,meta={}){
    if(!cfg||cfg.format!=='ioffice-personnel-config-v1')throw new Error('Cấu hình phân công dùng chung không hợp lệ.');
    const cur=await current(),bindings=sanitizeBindings(cfg.bindings,cur.rules),leaders=sanitizeLeaders(cfg.defaultLeaders);
    await chrome.storage.local.set({[BINDINGS_KEY]:bindings,[LEADERS_KEY]:leaders,[SHARED_META_KEY]:{version:String(meta.version||cfg.version||''),updatedAt:String(meta.updatedAt||cfg.updatedAt||''),updatedBy:String(meta.updatedBy||''),syncedAt:Date.now(),source:'tracker'}});
    return {bindings,defaultLeaders:leaders};
  }

  async function getAiCandidates(){const cur=await current();const bound=new Set(sanitizeBindings(cur.bindings,cur.rules).filter(x=>x.enabled).map(x=>x.roleKey));return (cur.rules.roles||[]).filter(r=>bound.has(r.key)).map(r=>({key:r.key,unitId:r.unitId,label:r.label,topics:r.topics}));}
  async function getBindings(roleKey){const cur=await current();return sanitizeBindings(cur.bindings,cur.rules).filter(x=>x.enabled&&x.roleKey===String(roleKey||''));}
  async function getBinding(roleKey){return (await getBindings(roleKey))[0]||null;}
  async function setBindings(bindings){const cur=await current();const clean=sanitizeBindings(bindings,cur.rules);await chrome.storage.local.set({[BINDINGS_KEY]:clean});return clean;}

  chrome.alarms.onAlarm.addListener(a=>{if(a.name===ALARM)autoCycle().catch(()=>{});});
  chrome.runtime.onStartup.addListener(()=>{ensureAlarm().then(autoCycle).catch(()=>{});});
  chrome.runtime.onInstalled.addListener(()=>{ensureAlarm().then(autoCycle).catch(()=>{});});
  ensureAlarm().catch(()=>{});

  chrome.runtime.onMessage.addListener((m,_s,reply)=>{
    const t=m?.type;if(!t||!t.startsWith('RECIPIENT_'))return;
    (async()=>{
      if(t==='RECIPIENT_RULES_GET'){const cur=await current();return {ok:true,data:{rules:cur.rules,meta:cur.meta,auto:cur.auto,bindings:sanitizeBindings(cur.bindings,cur.rules),defaultLeaders:sanitizeLeaders(cur.leaders),sharedMeta:cur.sharedMeta||{},feedUrl:FEED_URL}};}
      if(t==='RECIPIENT_UPDATE_CHECK')return {ok:true,data:await check()};
      if(t==='RECIPIENT_UPDATE_APPLY')return {ok:true,data:await apply()};
      if(t==='RECIPIENT_AUTO_SET'){await chrome.storage.local.set({[AUTO_KEY]:true});return {ok:true,forced:true};}
      if(t==='RECIPIENT_BINDINGS_SET')return {ok:true,data:await setBindings(m.bindings)};
      if(t==='RECIPIENT_BINDINGS_GET')return {ok:true,data:await getBindings(m.roleKey)};
      if(t==='RECIPIENT_BINDING_GET')return {ok:true,data:await getBinding(m.roleKey)};
      if(t==='RECIPIENT_LEADERS_GET')return {ok:true,data:await getLeaders()};
      if(t==='RECIPIENT_LEADERS_SET')return {ok:true,data:await setLeaders(m.leaders)};
      if(t==='RECIPIENT_CONFIG_EXPORT')return {ok:true,data:await exportSharedConfig()};
      if(t==='RECIPIENT_CONFIG_IMPORT')return {ok:true,data:await importSharedConfig(m.config,m.meta||{})};
      throw new Error('Lệnh Recipient Rules không hỗ trợ.');
    })().then(reply).catch(e=>reply({ok:false,error:e.message}));return true;
  });

  globalThis.IOfficeRecipientRulesManager=Object.freeze({current,getAiCandidates,getBindings,getBinding,setBindings,getLeaders,setLeaders,exportSharedConfig,importSharedConfig,check,apply,validate});
})();
