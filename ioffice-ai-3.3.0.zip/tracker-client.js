/* Tracker API Stable 1.x: optimized for Tracker V8, backward-compatible with Tracker 7.x during migration.
 * V8 supports idempotent syncKey, advisor assignment and Important state from authorized Tracker accounts.
 */
(() => {
  'use strict';
  const UNITS={U140:'Văn phòng',U141:'Phòng Kinh tế',U142:'Phòng VH-XH',U120:'Trung tâm PVHCC',U183:'Trung tâm Cung ứng',U340:'Công an',U360:'BCHQS',U200:'Trạm Y tế',U221:'THCS',U222:'Tiểu học',U240:'Mẫu giáo',U260:'HĐND',DUUBND:'Đảng ủy UBND'};
  const clean = v => String(v ?? '').trim();
  const symbol = v => clean(v).toUpperCase().replace(/\s+/g,'');
  const flights = new Map();
  const epochs = new Map();
  let writes = Promise.resolve();
  function date(v, required=false) {
    let s=clean(v),m=s.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
    if(m)s=`${m[3]}-${m[2].padStart(2,'0')}-${m[1].padStart(2,'0')}`;
    if(!s&&!required)return '';
    m=s.match(/^(\d{4})-(\d{2})-(\d{2})$/);
    if(!m)throw new Error('Ngày phải có dạng dd/MM/yyyy hoặc yyyy-MM-dd.');
    const d=new Date(+m[1],+m[2]-1,+m[3]);
    if(d.getFullYear()!==+m[1]||d.getMonth()!==+m[2]-1||d.getDate()!==+m[3])throw new Error('Ngày không hợp lệ.');
    return s;
  }
  function canonicalUnitName(id,name='') {
    const byId=UNITS[clean(id)]; if(byId)return byId;
    const raw=clean(name),f=raw.normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/đ/g,'d').replace(/Đ/g,'D').toLowerCase();
    if(/(?:dang uy|dang bo)\s+(?:ubnd|uy ban nhan dan)/.test(f))return 'Đảng ủy UBND';
    if(/van phong/.test(f))return 'Văn phòng';
    if(/phong kinh te/.test(f))return 'Phòng Kinh tế';
    if(/phong van hoa|vh-xh|van hoa - xa hoi/.test(f))return 'Phòng VH-XH';
    if(/phuc vu hanh chinh cong|pvhcc/.test(f))return 'Trung tâm PVHCC';
    if(/cung ung/.test(f))return 'Trung tâm Cung ứng';
    if(/cong an/.test(f))return 'Công an';
    if(/bchqs|ban chi huy quan su/.test(f))return 'BCHQS';
    if(/hdnd|hoi dong nhan dan/.test(f))return 'HĐND';
    return raw;
  }
  function payload(d) {
    const unit=canonicalUnitName(d.mainUnitId||d.ownerUnitId,d.mainUnit||d.xuLyChinh);
    if(!Object.values(UNITS).includes(unit))throw new Error('Đơn vị Xử lý chính không khớp Tracker 1.0.');
    const taskText=clean(d.taskText||d.nhiemVu);
    if(!taskText)throw new Error('Nội dung nhiệm vụ là bắt buộc.');
    const out={sourceNo:clean(d.sourceNo||d.sourceSymbol||d.soKyHieu),sourceDate:date(d.sourceDate||d.ngayVanBan),sourceSubject:clean(d.sourceSubject||d.trichYeu),taskText,mainUnit:unit,deadline:date(d.deadline||d.hanXuLy,true),note:clean(d.note||d.ghiChu),syncKey:clean(d.syncKey),actorEmail:clean(d.actorEmail).toLowerCase(),actorName:clean(d.actorName),isImportant:d.isImportant===true,advisors:Array.isArray(d.advisors)?d.advisors.map(x=>({id:clean(x?.id||x?.personKey),name:clean(x?.name||x?.personName),unit:canonicalUnitName(x?.unit||x?.parentUnit,x?.parentName||'')})).filter(x=>x.id||x.name):[]};
    const a=d.attachment;
    if(a&&clean(a.name)&&clean(a.base64)){
      const size=Number(a.size||0),max=20*1024*1024;
      if(size>max)throw new Error('Tệp giao kèm vượt quá 20 MB.');
      out.attachment={name:clean(a.name).slice(0,220),mimeType:clean(a.mimeType)||'application/pdf',size,base64:String(a.base64)};
    }
    return out;
  }
  function task(t) {
    return {...t,taskId:clean(t.id),taskText:clean(t.task),sourceSymbol:clean(t.sourceNo),sourceSubject:clean(t.subject),mainUnit:clean(t.unit),mainUnitId:Object.keys(UNITS).find(id=>UNITS[id]===clean(t.unit))||'',deadline:date(t.deadline),businessStatus:t.state==='COMPLETED'?'COMPLETED':'PROCESSING',displayStatus:clean(t.status),details:clean(t.note),completedAt:clean(t.confirmedAt)};
  }
  function endpoint(raw) {
    const u=new URL(clean(raw));
    if(u.protocol!=='https:'||u.hostname!=='script.google.com'||!/^\/macros\/s\/[^/]+\/exec$/.test(u.pathname)||u.username||u.password)throw new Error('Nhập URL Apps Script dạng https://script.google.com/macros/s/.../exec.');
    u.search='';u.hash='';return u.href;
  }
  async function hash(s) {return [...new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(s)))].map(b=>b.toString(16).padStart(2,'0')).join('');}
  async function config() {
    const s=await getSettings();
    if(!clean(s.trackerApiUrl)||!clean(s.trackerToken))throw new Error('Nhập URL Web App và TOKEN tiện ích trong Cấu hình.');
    const url=endpoint(s.trackerApiUrl),token=clean(s.trackerToken);
    return {url,token,actorEmail:clean(s.trackerActorEmail).toLowerCase(),scope:await hash(url+'|'+token)};
  }
  async function call(c,action,data={}) {
    if(!['ping','createTask','upsertTask','listClientCache','completeTask','matchTask','getPersonnelConfig','setPersonnelConfig','createMeeting','getMeetingPeople','analyzeMeetingInvitation','getMeetingRules','listMeetings','syncPersonnelDirectory'].includes(action))throw new Error('Lệnh không thuộc giao thức Tracker.');
    const uploadBytes=['createTask','upsertTask','createMeeting','getMeetingPeople','analyzeMeetingInvitation','getMeetingRules','listMeetings','syncPersonnelDirectory'].includes(action)?Number(data?.attachment?.size||0):0;
    const timeoutMs=action==='analyzeMeetingInvitation'?150000:uploadBytes>0?90000:25000;
    const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),timeoutMs);
    try {
      const r=await fetch(c.url,{method:'POST',headers:{'Content-Type':'text/plain;charset=utf-8'},body:JSON.stringify({action,token:c.token,data}),redirect:'follow',signal:controller.signal});
      let out;try {out=JSON.parse(await r.text());}catch(_){throw new Error('Apps Script không trả JSON. Kiểm tra URL /exec và quyền triển khai Web App.');}
      if(out?.ok===false){const e=new Error(out.error||'Tracker từ chối yêu cầu.');e.rejected=true;throw e;}
      if(!r.ok||out?.ok!==true)throw new Error(`Phản hồi Tracker không hợp lệ (HTTP ${r.status}).`);
      return out;
    }catch(e){if(e.name==='AbortError'&&action==='analyzeMeetingInvitation')throw new Error('AI chưa phản hồi sau 150 giây. Bấm lại để lấy kết quả đã xử lý.');if(e.name==='AbortError')throw new Error(uploadBytes>0?'Tracker chưa phản hồi sau 90 giây khi tải tệp giao kèm.':'Tracker chưa phản hồi sau 25 giây.');throw e;}finally{clearTimeout(timer);}
  }
  async function refresh(c,force=false) {
    const key='trackerCacheV8:'+c.scope,old=(await chrome.storage.local.get(key))[key];
    if(!force&&old&&Date.now()-old.updatedAt<30000)return old;
    const epoch=epochs.get(c.scope)||0,flightKey=key+':'+epoch;
    if(flights.has(flightKey))return flights.get(flightKey);
    const p=(async()=>{const out=await call(c,'listClientCache');if(!Array.isArray(out.tasks))throw new Error('Danh sách nhiệm vụ không hợp lệ.');const cache={updatedAt:Date.now(),tasks:out.tasks.map(task)};if((epochs.get(c.scope)||0)!==epoch)return refresh(c,true);await chrome.storage.local.set({[key]:cache});return cache;})();
    flights.set(flightKey,p);try{return await p;}finally{flights.delete(flightKey);}
  }
  async function create(c,d) {
    const data=payload(d),key='trackerCreateV8:'+c.scope+':'+await hash(clean(d.syncKey)||JSON.stringify(data));
    const old=(await chrome.storage.local.get(key))[key];
    if(old?.taskId)return {ok:true,data:{ok:true,taskId:old.taskId,alreadyCreated:true}};
    if(old)throw new Error('Lần gửi trước chưa rõ kết quả. Mở cổng quản lý kiểm tra trước; tiện ích không tự gửi lại để tránh trùng. Nếu chưa có, dùng Thêm nhiệm vụ trên cổng quản lý.');
    // Persist BEFORE fetch so a worker restart cannot replay an uncertain create.
    await chrome.storage.local.set({[key]:{status:'sending',at:Date.now()}});
    let out;
    try{out=await call(c,'createTask',data);}catch(e){if(e.beforeSend||(e.rejected&&/^(TOKEN không hợp lệ\.|Nội dung nhiệm vụ là bắt buộc\.|Xử lý chính là bắt buộc\.|Hạn xử lý là bắt buộc\.|Đơn vị xử lý chính không hợp lệ\.|Tệp giao kèm .*)$/.test(e.message)))await chrome.storage.local.remove(key);else e.message+=' Chưa xác định đã ghi Sheet hay chưa; hãy kiểm tra cổng quản lý. Không tự gửi lại.';throw e;}
    if(!clean(out.taskId))throw new Error('Tracker chưa trả mã nhiệm vụ; kiểm tra cổng quản lý trước khi tạo lại.');
    await chrome.storage.local.set({[key]:{taskId:out.taskId,at:Date.now()}});
    epochs.set(c.scope,(epochs.get(c.scope)||0)+1);
    await chrome.storage.local.remove('trackerCacheV8:'+c.scope);
    return {ok:true,data:out};
  }
  async function pullPersonnel(c){
    const local=await chrome.storage.local.get({personnelConfigDirty:false,leaderWatcherDirectory:[]});
    const out=await call(c,'getPersonnelConfig',{actorEmail:c.actorEmail});
    if(Array.isArray(out.directory)){
      // v2.4.5: Tracker nhận một bản sao danh bạ dùng chung nhưng không được ghi đè nguồn LIVE đọc từ iOffice.
      const patch={trackerPersonnelDirectory:out.directory,personnelDirectoryMeta:{version:out.directoryVersion||'',updatedAt:out.directoryUpdatedAt||'',source:'tracker-mirror',account:out.account||{}}};
      if(!Array.isArray(local.leaderWatcherDirectory)||!local.leaderWatcherDirectory.length)patch.leaderWatcherDirectory=out.directory;
      await chrome.storage.local.set(patch);
    }
    if(local.personnelConfigDirty)return {ok:true,synced:false,pending:true,error:'Phân công trên máy chưa gửi; giữ bản đang sửa.',account:out.account,directoryCount:out.directory?.length||0};
    if(out?.hasConfig&&out?.config){
      const mgr=globalThis.IOfficeRecipientRulesManager;
      if(!mgr?.importSharedConfig)throw new Error('Bộ đồng bộ phân công chưa sẵn sàng.');
      const applied=await mgr.importSharedConfig(out.config,{version:out.version,updatedAt:out.updatedAt,updatedBy:out.updatedBy});
      return {ok:true,synced:true,version:clean(out.version),updatedAt:clean(out.updatedAt),updatedBy:clean(out.updatedBy),counts:{bindings:applied.bindings?.length||0,leaders:applied.defaultLeaders?.length||0}};
    }
    return {ok:true,synced:false,version:clean(out?.version),updatedAt:clean(out?.updatedAt),updatedBy:clean(out?.updatedBy),counts:{bindings:0,leaders:0}};
  }
  async function pushPersonnel(c){
    if(!c.actorEmail)throw new Error('Hãy nhập Email tài khoản Tracker để xác nhận quyền Admin.');
    const mgr=globalThis.IOfficeRecipientRulesManager;
    if(!mgr?.exportSharedConfig)throw new Error('Bộ phân công chưa sẵn sàng.');
    const cfg=await mgr.exportSharedConfig();
    const out=await call(c,'setPersonnelConfig',{actorEmail:c.actorEmail,config:cfg});
    if(out?.config&&mgr?.importSharedConfig)await mgr.importSharedConfig(out.config,{version:out.version,updatedAt:out.updatedAt,updatedBy:out.updatedBy});
    return {ok:true,synced:true,version:clean(out.version),updatedAt:clean(out.updatedAt),updatedBy:clean(out.updatedBy),counts:out.counts||{}};
  }
  async function syncDirectory(c,d){if(!c.actorEmail)throw Error('Chưa lưu Email tài khoản Tracker.');const source=Array.isArray(d.directory)?d.directory:[],fingerprint=await hash(JSON.stringify(source.map(p=>({key:p.key,name:p.name,parentUnit:p.parentUnit,parentName:p.parentName})).sort((a,b)=>String(a.key).localeCompare(String(b.key))))),key='personnelDirectorySent:'+c.scope+':'+c.actorEmail,local=await chrome.storage.local.get({[key]:'',personnelDirectoryMeta:{}});if(local.personnelDirectoryMeta?.account?.canSyncDirectory===false)throw Error('Tài khoản này chỉ nhận danh bạ; Admin mới được cập nhật từ iOffice.');if(!d.force&&local[key]===fingerprint)return {ok:true,unchanged:true,accepted:local.personnelDirectoryMeta.accepted??source.length,total:local.personnelDirectoryMeta.total??0,skipped:local.personnelDirectoryMeta.skipped??0};if(!source.length)throw Error('iOffice chưa tải danh bạ. Mở cây Xem để biết trước khi đồng bộ.');const out=await call(c,'syncPersonnelDirectory',{directory:source,actorEmail:c.actorEmail});if(out.accepted===0)throw Error('Tracker chưa nhận được người hợp lệ; hãy kiểm tra đơn vị và mã nhân sự.');await chrome.storage.local.set({personnelDirectorySyncError:'',[key]:fingerprint,trackerPersonnelDirectory:Array.isArray(out.directory)?out.directory:source,personnelDirectoryMeta:{...local.personnelDirectoryMeta,source:'ioffice-sync',version:out.directoryVersion||'',updatedAt:out.updatedAt||'',error:'',changed:out.changed||0,accepted:out.accepted??source.length,skipped:out.skipped||0,total:out.total||0}});return out;}
  async function handle(message) {
    const c=await config(),d=message.data||{};
    switch(message.type) {
      case 'TRACKER_TEST': {const data=await call(c,'ping',{actorEmail:c.actorEmail});const ver=clean(data.version),proto=clean(data.protocol);if(!(proto==='ioffice-tracker-api-v1'||/^1\./.test(ver)||/^7\./.test(ver)||/^8\./.test(ver)))throw new Error(`Tracker không tương thích (version ${ver||'không rõ'}).`);const cache=await refresh(c,true);let personnel={synced:false,unsupported:false};try{personnel=await pullPersonnel(c);}catch(e){personnel={synced:false,unsupported:/Action không hỗ trợ|không hỗ trợ|unsupported|unknown action/i.test(clean(e.message)),error:e.message};}return {ok:true,data:{...data,taskCount:cache.tasks.length,endpoint:c.url,personnel}};}
      case 'TRACKER_CACHE_REFRESH':return {ok:true,cache:await refresh(c,d.force===true)};
      case 'TRACKER_DIRECTORY_SYNC':return {ok:true,data:await syncDirectory(c,d)};
      case 'TRACKER_PERSONNEL_PULL':return {ok:true,data:await pullPersonnel(c)};
      case 'TRACKER_PERSONNEL_PUSH':return {ok:true,data:await pushPersonnel(c)};
      case 'TRACKER_MEETING_RULES':return {ok:true,data:await call(c,'getMeetingRules',{actorEmail:c.actorEmail})};
      case 'TRACKER_MEETING_LIST':return {ok:true,data:await call(c,'listMeetings',{...d,actorEmail:c.actorEmail})};
      case 'TRACKER_MEETING_ANALYZE':return {ok:true,data:await call(c,'analyzeMeetingInvitation',{...d,actorEmail:c.actorEmail})};
      case 'TRACKER_MEETING_PEOPLE':return {ok:true,data:await call(c,'getMeetingPeople',{actorEmail:c.actorEmail})};
      case 'TRACKER_MEETING_CREATE':return {ok:true,data:await call(c,'createMeeting',{...d,actorEmail:c.actorEmail})};
      case 'TRACKER_OPEN_CALENDAR': {const u=new URL(c.url);u.searchParams.set('app','manage');u.searchParams.set('view','meetings');await chrome.tabs.create({url:u.href});return {ok:true};}
      case 'TRACKER_UPSERT':return create(c,d);
      case 'TRACKER_MATCH': {
        const docs=Array.isArray(d.relatedDocs)?d.relatedDocs:[];
        try {
          const out=await call(c,'matchTask',{relatedDocs:docs,resultIofficeId:clean(d.resultIofficeId),resultSymbol:clean(d.resultSymbol),resultSubject:clean(d.resultSubject)});
          const candidates=Array.isArray(out.candidates)?out.candidates.map(x=>({...x,task:x.task?task(x.task):null})):[];
          return {ok:true,data:{...out,task:out.task?task(out.task):null,candidates,legacy:false}};
        } catch (e) {
          if(!/Action không hỗ trợ|không hỗ trợ|unsupported|unknown action/i.test(clean(e.message)))throw e;
          const cache=await refresh(c,true);
          const tokenSet=v=>new Set(clean(v).normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/đ/g,'d').replace(/Đ/g,'D').toLowerCase().split(/[^a-z0-9]+/).filter(w=>w.length>=4));
          const subjectScore=(a,b)=>{const A=tokenSet(a),B=tokenSet(b);if(!A.size||!B.size)return 0;let hit=0;for(const w of A)if(B.has(w))hit++;return hit/Math.min(A.size,B.size);};
          const ranked=[];
          for(const t of cache.tasks){
            let best=0,method='',related=null;
            for(const r of docs){
              if(symbol(t.sourceSymbol)&&symbol(r.symbol)&&symbol(t.sourceSymbol)===symbol(r.symbol)){best=100;method='symbol-exact';related=r;break;}
              const sf=subjectScore(t.sourceSubject,r.subject);if(sf>=.72&&70+Math.round(sf*20)>best){best=70+Math.round(sf*20);method='subject-local';related=r;}
            }
            if(best)ranked.push({task:t,score:best,method,matchedRelated:related});
          }
          ranked.sort((a,b)=>b.score-a.score);
          const top=ranked[0],second=ranked[1],needsReview=!!(top&&second&&top.score-second.score<8);
          return {ok:true,data:{matched:!!top&&!needsReview,needsReview,task:top&&!needsReview?top.task:null,score:top?.score||0,method:top?.method||'',matchedRelated:top?.matchedRelated||null,candidates:ranked.slice(0,5),legacy:true}};
        }
      }
      case 'TRACKER_COMPLETE_LEADER': {
        const taskId=clean(d.taskId);if(!taskId)throw new Error('Thiếu mã nhiệm vụ.');
        const data=await call(c,'completeTask',{taskId,actorEmail:c.actorEmail});
        epochs.set(c.scope,(epochs.get(c.scope)||0)+1);
    await chrome.storage.local.remove('trackerCacheV8:'+c.scope);return {ok:true,data};
      }
      case 'TRACKER_OPEN_MANAGE': {const u=new URL(c.url);u.searchParams.set('app','manage');await chrome.tabs.create({url:u.href});return {ok:true};}
      default:throw new Error('Chức năng này không được API Tracker hỗ trợ. Hãy mở cổng quản lý.');
    }
  }
  // Durable outbox. No token is copied to a delivery record.
  const DELIVERY_PREFIX='trackerDeliveryV1:';
  let draining=false;
  async function deliveries(c) {
    const all=await chrome.storage.local.get(null);
    return Object.entries(all).filter(([k,v])=>k.startsWith(DELIVERY_PREFIX)&&v.scope===c.scope).map(([id,v])=>({id,...v})).sort((a,b)=>b.updatedAt-a.updatedAt);
  }
  async function saveDelivery(id, record, patch) {
    const next={...record,...patch,updatedAt:Date.now()};delete next.id;
    await chrome.storage.local.set({[id]:next});return next;
  }
  function stripAttachmentBinary(data={}) {
    if(!data?.attachment)return data;
    const a=data.attachment;
    return {...data,attachment:{name:clean(a.name),mimeType:clean(a.mimeType),size:Number(a.size||0),uploaded:true}};
  }
  async function deliveryHandle(message) {
    const c=await config(),d=message.data||{};
    if(message.type==='TRACKER_DELIVERY_LIST')return {ok:true,items:await deliveries(c)};
    if(message.type==='TRACKER_DELIVERY_CLEAR_HISTORY'){
      const all=await deliveries(c);
      const removable=all.filter(x=>['sent','cancelled','failed','unknown'].includes(x.status)).map(x=>x.id);
      if(removable.length)await chrome.storage.local.remove(removable);
      return {ok:true,removed:removable.length,kept:all.length-removable.length};
    }
    if(message.type==='TRACKER_DELIVERY_PREPARE'){
      const data=payload(d),id=DELIVERY_PREFIX+c.scope+':'+await hash(clean(d.syncKey)||JSON.stringify(data));
      const old=(await chrome.storage.local.get(id))[id];
      if(old&&old.status==='awaiting_transfer'){await saveDelivery(id,old,{data:{...data,syncKey:d.syncKey}});return {ok:true,id,status:old.status};}
      if(old&&old.status!=='cancelled')return {ok:true,id,status:old.status};
      await saveDelivery(id,{scope:c.scope,createdAt:Date.now(),data:{...data,syncKey:d.syncKey}}, {status:'awaiting_transfer'});
      return {ok:true,id,status:'awaiting_transfer'};
    }
    const id=clean(d.id),old=(await chrome.storage.local.get(id))[id];
    if(!id.startsWith(DELIVERY_PREFIX)||!old||old.scope!==c.scope)throw new Error('Không tìm thấy lượt gửi của kết nối hiện tại.');
    if(message.type==='TRACKER_DELIVERY_COMMIT'){
      if(old.status==='awaiting_transfer')await saveDelivery(id,old,{status:'queued'});
      void drain();return {ok:true,id};
    }
    if(message.type==='TRACKER_DELIVERY_CANCEL'){
      if(old.status!=='awaiting_transfer')throw new Error('Chỉ hủy được nhiệm vụ chưa bắt đầu gửi.');
      await saveDelivery(id,old,{status:'cancelled',data:stripAttachmentBinary(old.data)});return {ok:true};
    }
    throw new Error('Lệnh hàng đợi không hợp lệ.');
  }
  async function drain() {
    if(draining)return;draining=true;
    try {
      const c=await config();
      for(const record of (await deliveries(c)).reverse()){
        if(!['queued','sending'].includes(record.status))continue;
        const id=record.id;
        if(record.status==='sending') {
          // A worker restart might occur after Sheet accepted the POST.
          const key='trackerCreateV8:'+c.scope+':'+await hash(clean(record.data.syncKey)||JSON.stringify(payload(record.data)));
          const marker=(await chrome.storage.local.get(key))[key];
          if(marker?.taskId){await saveDelivery(id,record,{status:'sent',taskId:marker.taskId,data:stripAttachmentBinary(record.data)});continue;}
          await saveDelivery(id,record,{status:'unknown',error:'Tiến trình bị gián đoạn. Kiểm tra Sổ trước khi tạo lại để tránh trùng.'});continue;
        }
        await saveDelivery(id,record,{status:'sending'});
        try {
          const r=await globalThis.IOfficeTrackerClient.handle({type:'TRACKER_UPSERT',data:record.data});
          await saveDelivery(id,record,{status:'sent',taskId:r.data.taskId,error:'',data:stripAttachmentBinary(record.data)});
        }catch(e){await saveDelivery(id,record,{status:e.beforeSend||(e.rejected&&/^(TOKEN không hợp lệ\.|Nội dung nhiệm vụ là bắt buộc\.|Xử lý chính là bắt buộc\.|Hạn xử lý là bắt buộc\.|Đơn vị xử lý chính không hợp lệ\.|Tệp giao kèm .*)$/.test(e.message))?'failed':'unknown',error:e.message});}
      }
    }catch(_){}finally{draining=false;}
  }
  globalThis.IOfficeTrackerDeliveryBusy=async()=>{
    const all=await chrome.storage.local.get(null);
    return Object.entries(all).some(([k,v])=>k.startsWith(DELIVERY_PREFIX)&&['queued','sending'].includes(v.status));
  };
  chrome.alarms.create('tracker-delivery-v1',{periodInMinutes:1});
  chrome.alarms.onAlarm.addListener(a=>{if(a.name==='tracker-delivery-v1')void drain();});
  setTimeout(()=>void drain(),0);

  globalThis.IOfficeTrackerClient={UNITS,date,payload,task,endpoint,handle(message){
    if(message.type.startsWith('TRACKER_DELIVERY_')) {
      const p=writes.then(()=>deliveryHandle(message));writes=p.catch(()=>{});return p;
    }
    // Serialize writes, including duplicate clicks from different iOffice tabs.
    if(['TRACKER_UPSERT','TRACKER_COMPLETE_LEADER','TRACKER_PERSONNEL_PUSH','TRACKER_DIRECTORY_SYNC','TRACKER_MEETING_CREATE'].includes(message.type)){
      const p=writes.then(()=>handle(message));writes=p.catch(()=>{});return p;
    }
    return handle(message);
  }};
})();
