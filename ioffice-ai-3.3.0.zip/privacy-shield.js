(() => {
  'use strict';

  const VERSION='2.1.0';
  const SECRET_RE=/(^|\n)\s*(?:\[?\s*)?(?:(?:ĐỘ|MỨC\s*ĐỘ)\s*MẬT\s*[:\-]\s*)?(TUYỆT\s*MẬT|TỐI\s*MẬT|MẬT)(?:\s*\]?)?\s*(?=\n|$)/iu;
  const TOKEN_RE=/⟦[A-Z_]+_\d{2,4}⟧/gu;
  const MASK_TOKEN_RE=/⟦[A-Z_]+_\d{2,4}⟧/u;
  const clone=v=>v==null?v:JSON.parse(JSON.stringify(v));
  const statsTemplate=()=>({persons:0,addresses:0,phones:0,emails:0,ids:0,dob:0,bankAccounts:0,credentials:0,sensitive:0,parcel:0,coordinates:0,fileNames:0,other:0,total:0,blockedSecret:false,riskLevel:'normal'});

  const TYPE_TO_STAT={PERSON:'persons',ADDRESS:'addresses',PHONE:'phones',EMAIL:'emails',ID:'ids',DOB:'dob',BANK:'bankAccounts',CREDENTIAL:'credentials',SENSITIVE:'sensitive',PARCEL:'parcel',COORD:'coordinates',FILE:'fileNames'};
  function token(type,index){return `⟦${type}_${String(index).padStart(2,'0')}⟧`;}
  function normalizeKey(v){return String(v||'').normalize('NFC').trim().replace(/\s+/g,' ').toLocaleLowerCase('vi-VN');}
  function escapeRe(s){return String(s).replace(/[.*+?^${}()|[\]\\]/g,'\\$&');}
  function makeContext(baseMap={},baseStats=null){
    const ctx={map:{...(baseMap||{})},counts:{},reverse:{},stats:{...statsTemplate(),...(baseStats||{})}};
    for(const [k,v] of Object.entries(ctx.map)){
      const m=/^⟦([A-Z_]+)_(\d+)⟧$/.exec(k);if(!m)continue;
      const type=m[1],idx=Number(m[2])||0;ctx.counts[type]=Math.max(ctx.counts[type]||0,idx);
      (ctx.reverse[type]||(ctx.reverse[type]=new Map())).set(normalizeKey(v),k);
    }
    return ctx;
  }
  function put(ctx,type,value){
    const raw=String(value??'');if(!raw.trim())return raw;
    const norm=normalizeKey(raw),rev=ctx.reverse[type]||(ctx.reverse[type]=new Map());
    if(rev.has(norm))return rev.get(norm);
    const key=token(type,(ctx.counts[type]||0)+1);ctx.counts[type]=(ctx.counts[type]||0)+1;ctx.map[key]=raw;rev.set(norm,key);
    const statKey=TYPE_TO_STAT[type]||'other';ctx.stats[statKey]=(Number(ctx.stats[statKey])||0)+1;ctx.stats.total=(Number(ctx.stats.total)||0)+1;
    return key;
  }
  function replaceWith(text,re,ctx,type,group=0,validator=null){
    return String(text).replace(re,(...args)=>{
      const full=args[0],g=group?args[group]:full;if(g==null)return full;
      if(MASK_TOKEN_RE.test(String(g)))return full;
      if(validator&&!validator(String(g),full,args))return full;
      const replacement=put(ctx,type,g);return group?full.replace(g,replacement):replacement;
    });
  }
  function looksOrgName(v){return /^(?:Sở|Phòng|Ban|Bộ|Cục|Chi\s*cục|Trung\s*tâm|Trường|UBND|HĐND|Đảng\s*ủy|Ủy\s*ban|Công\s*an|Văn\s*phòng)(?:\s|$)/iu.test(String(v||'').trim());}
  function looksPersonName(v){
    const s=String(v||'').trim();if(!s||looksOrgName(s)||/^(?:KT\.?|CHỦ TỊCH|PHÓ CHỦ TỊCH|GIÁM ĐỐC|PHÓ GIÁM ĐỐC|TRƯỞNG PHÒNG|PHÓ TRƯỞNG PHÒNG|BÍ THƯ|PHÓ BÍ THƯ|TRƯỞNG BAN|PHÓ TRƯỞNG BAN)$/iu.test(s))return false;
    const words=s.split(/\s+/).filter(Boolean);if(words.length<2||words.length>6)return false;
    return words.every(w=>{const ch=[...w][0]||'';return ch&&ch===ch.toLocaleUpperCase('vi-VN')&&ch!==ch.toLocaleLowerCase('vi-VN');});
  }
  function collectKnownNames(value){
    const out=[];const add=v=>{const s=String(v||'').trim();if(s.split(/\s+/).length>=2&&s.length>=5&&!looksOrgName(s))out.push(s);};
    if(Array.isArray(value?._privacyKnownNames))for(const x of value._privacyKnownNames)add(x);
    const visit=(v,k='')=>{if(v==null)return;if(typeof v==='string'){if(/personName|fullName|hoTen|họTên/i.test(k))add(v);return;}if(Array.isArray(v)){for(const x of v)visit(x,k);return;}if(typeof v==='object')for(const [kk,x] of Object.entries(v)){if(kk==='_privacyKnownNames')continue;visit(x,kk);}};
    visit(value);return [...new Set(out)].sort((a,b)=>b.length-a.length).slice(0,800);
  }
  function flattenText(value){
    const parts=[];const visit=(v,k='')=>{if(v==null)return;if(typeof v==='string'){if(k!=='base64'&&!k.startsWith('_privacy'))parts.push(v);return;}if(Array.isArray(v)){for(const x of v)visit(x,k);return;}if(typeof v==='object')for(const [kk,x] of Object.entries(v)){if(kk==='base64'||kk.startsWith('_privacy'))continue;visit(x,kk);}};visit(value);return parts.join('\n');
  }

  const personWord="[A-ZĐÀÁÂÃÈÉÊÌÍÒÓÔÕÙÚĂẠẢẤẦẨẪẬẮẰẲẴẶẸẺẼỀẾỂỄỆỈỊỌỎỐỒỔỖỘỚỜỞỠỢỤỦỨỪỬỮỰỲỴỶỸ][\\p{L}'’\\-]*";
  const personName=`${personWord}(?:[ \\t]+${personWord}){1,5}`;
  const PERSON_LABEL_RE=new RegExp(`(?:^|[ \\t,;(])(?:ông|bà|anh|chị|đồng[ \\t]*chí|họ[ \\t]*và[ \\t]*tên|họ[ \\t]*tên|người[ \\t]*đại[ \\t]*diện|người[ \\t]*kiến[ \\t]*nghị|người[ \\t]*khiếu[ \\t]*nại|người[ \\t]*tố[ \\t]*cáo|người[ \\t]*sử[ \\t]*dụng[ \\t]*đất|chủ[ \\t]*sử[ \\t]*dụng|công[ \\t]*dân|bệnh[ \\t]*nhân|người[ \\t]*bệnh|học[ \\t]*sinh|trẻ[ \\t]*em|chủ[ \\t]*hộ)[ \\t]*(?:[:|\\-])?[ \\t]*(${personName})`,'giu');
  const RELATION_NAME_RE=new RegExp(`(?:^|[ \\t,;(])(?:cha|mẹ|bố|vợ|chồng|con|người[ \\t]*giám[ \\t]*hộ|người[ \\t]*đại[ \\t]*diện[ \\t]*theo[ \\t]*pháp[ \\t]*luật)[ \\t]*(?:[:|\\-])?[ \\t]*(${personName})`,'giu');
  const ROLE_NAME_RE=new RegExp(`(?:^|[\\n;,.]|[ \\t]{2,})(?:KT\\.[ \\t]*)?(?:CHỦ[ \\t]*TỊCH|PHÓ[ \\t]*CHỦ[ \\t]*TỊCH|GIÁM[ \\t]*ĐỐC|PHÓ[ \\t]*GIÁM[ \\t]*ĐỐC|TRƯỞNG[ \\t]*(?:PHÒNG|BAN|THÔN)|PHÓ[ \\t]*TRƯỞNG[ \\t]*(?:PHÒNG|BAN)|BÍ[ \\t]*THƯ|PHÓ[ \\t]*BÍ[ \\t]*THƯ|CÔNG[ \\t]*CHỨC|CHUYÊN[ \\t]*VIÊN|CÁN[ \\t]*BỘ|NGƯỜI[ \\t]*KÝ)[ \\t]*(?:[:|\\-])?[ \\t]+(${personName})(?=\\s*(?:[\\n;,.)]|$))`,'giu');
  const SIGNATURE_NAME_RE=new RegExp(`(^|\\n)\\s*(?:KT\\.\\s*[^\\n]{2,80}\\n\\s*)?(?:CHỦ TỊCH|PHÓ CHỦ TỊCH|GIÁM ĐỐC|PHÓ GIÁM ĐỐC|TRƯỞNG PHÒNG|PHÓ TRƯỞNG PHÒNG|BÍ THƯ|PHÓ BÍ THƯ|TRƯỞNG BAN|PHÓ TRƯỞNG BAN)\\s*(?:\\n|[ \\t]{2,})\\s*(${personName})(?=\\s*(?:\\n|$))`,'gimu');

  function protectKnownNames(s,ctx,knownNames){
    for(const name of knownNames||[]){
      const re=new RegExp(`(?<![\\p{L}])${escapeRe(name).replace(/\\ /g,'\\s+')}((?![\\p{L}]))`,'giu');
      s=String(s).replace(re,m=>put(ctx,'PERSON',m.trimEnd())+m.slice(m.trimEnd().length));
    }
    return s;
  }

  function leadingPersonName(tail){
    const src=String(tail||''),parts=src.match(/[\p{L}'’\-]+/gu)||[],good=[];
    for(const w of parts.slice(0,6)){
      const ch=[...w][0]||'';if(!(ch&&ch===ch.toLocaleUpperCase('vi-VN')&&ch!==ch.toLocaleLowerCase('vi-VN')))break;good.push(w);
    }
    if(good.length<2)return '';
    const name=good.join(' ');return looksPersonName(name)?name:'';
  }
  function maskNameAfterPrefix(text,re,ctx){
    return String(text).replace(re,(full,prefix,tail)=>{const name=leadingPersonName(tail);if(!name)return full;const at=String(tail).indexOf(name);if(at<0)return full;return String(prefix)+String(tail).slice(0,at)+put(ctx,'PERSON',name)+String(tail).slice(at+name.length);});
  }


  function protectText(input,ctx,knownNames=[]){
    let s=String(input??'');if(!s)return s;
    s=protectKnownNames(s,ctx,knownNames);
    // Credentials first: values themselves must never leave the browser.
    s=replaceWith(s,/\b(?:mật\s*khẩu|password|passcode|mã\s*PIN|PIN|OTP|mã\s*xác\s*thực|secret|access\s*token|refresh\s*token|API\s*key)\s*(?:[:=|\-])\s*([^\s,;]{4,160})/giu,ctx,'CREDENTIAL',1);
    s=replaceWith(s,/\b(?:tên\s*đăng\s*nhập|username|user\s*name)\s*(?:[:=|\-])\s*([^\s,;]{3,120})/giu,ctx,'CREDENTIAL',1);
    // High-confidence contact and identity patterns.
    s=replaceWith(s,/\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b/giu,ctx,'EMAIL');
    s=replaceWith(s,/(?<!\d)(?:\+?84|0)(?:[ .-]?\d){8,10}(?!\d)/g,ctx,'PHONE');
    s=replaceWith(s,/\b(?:CCCD|CMND|Căn\s*cước(?:\s*công\s*dân)?|Số\s*định\s*danh|ĐDCN|Hộ\s*chiếu|Giấy\s*phép\s*lái\s*xe|GPLX)\s*(?:số|:|-)?\s*([A-Z0-9]{6,24})\b/giu,ctx,'ID',1);
    s=replaceWith(s,/\b(?:BHXH|BHYT|mã\s*số\s*thuế(?:\s*cá\s*nhân)?)\s*(?:số|:|-)?\s*([A-Z0-9.-]{6,30})\b/giu,ctx,'ID',1);
    s=replaceWith(s,/(?<![\p{L}\p{N}_])(?:mã\s*(?:bệnh\s*nhân|học\s*sinh|sinh\s*viên|khách\s*hàng)|số\s*hợp\s*đồng\s*bảo\s*hiểm|số\s*tài\s*khoản\s*chứng\s*khoán|tài\s*khoản\s*VNeID)\s*(?:số|:|=|-)?\s*([A-Z0-9._/-]{3,40})(?![\p{L}\p{N}_])/giu,ctx,'ID',1);
    s=replaceWith(s,/\b(?:biển\s*(?:số\s*)?(?:xe|phương\s*tiện)|license\s*plate)\s*(?:số|:|-)?\s*([0-9A-ZĐ][0-9A-ZĐ .-]{4,14})\b/giu,ctx,'ID',1);
    s=replaceWith(s,/\b(?:tài\s*khoản\s*(?:mạng\s*xã\s*hội|MXH)|Facebook|Zalo|Telegram|TikTok|ID\s*tài\s*khoản)\s*(?:[:=|\-])\s*(@?[A-Z0-9._-]{3,120})/giu,ctx,'ID',1);
    // 12-digit national-ID-like values are masked when not embedded in a document code/path.
    // Financial data.
    s=replaceWith(s,/\b(?:số\s*tài\s*khoản|tài\s*khoản\s*ngân\s*hàng|STK|số\s*thẻ|thẻ\s*ngân\s*hàng)\s*(?:số|:|-)?\s*([0-9][0-9 .-]{5,28}[0-9])\b/giu,ctx,'BANK',1);
    s=replaceWith(s,/\b(?:CVV|CVC)\s*(?:[:|-])?\s*(\d{3,4})\b/giu,ctx,'BANK',1);
    s=replaceWith(s,/(?<![\d/.-])\d{12}(?![\d/.-])/g,ctx,'ID');
    // Birth/age.
    s=replaceWith(s,/\b(?:ngày\s*sinh|sinh\s*ngày|DOB)\s*(?:[:|-])?\s*((?:\d{1,2}[\/.-]){2}\d{2,4})\b/giu,ctx,'DOB',1);
    s=replaceWith(s,/\b(?:năm\s*sinh)\s*(?:[:|-])?\s*((?:19|20)\d{2})\b/giu,ctx,'DOB',1);
    // Coordinates and precise location.
    s=replaceWith(s,/\b(?:tọa\s*độ|kinh\s*độ|vĩ\s*độ|GPS)\s*(?:[:|-])?\s*(-?\d{1,3}(?:\.\d{3,})?\s*[,;/]\s*-?\d{1,3}(?:\.\d{3,})?)/giu,ctx,'COORD',1);
    s=replaceWith(s,/(?:^|[\s,;(])(?:địa\s*chỉ(?:\s*thường\s*trú|\s*tạm\s*trú|\s*liên\s*hệ|\s*nhà|\s*thửa\s*đất)?|nơi\s*cư\s*trú|thường\s*trú|tạm\s*trú|trú\s*tại|nơi\s*ở\s*hiện\s*tại|quê\s*quán|nơi\s*sinh)\s*(?:[:|-])?\s*([^\n;.]{4,220}?)(?=\s*(?:[,;.]?\s*(?:SĐT|điện\s*thoại|email|CCCD|CMND|Căn\s*cước|ngày\s*sinh|sinh\s*ngày|năm\s*sinh|giới\s*tính|dân\s*tộc|quốc\s*tịch)(?![\p{L}\p{N}_])|[;.\n]|$))/giu,ctx,'ADDRESS',1);
    // Land/property identifiers are not necessary for routing and can combine to identify a person/property.
    // Require the identifier to start with a digit so words such as "thửa đất cũ/mới" are never masked as parcel numbers.
    s=replaceWith(s,/(?<![\p{L}\p{N}_])(?:thửa\s*(?:đất\s*)?(?:số)?|tờ\s*bản\s*đồ(?:\s*số)?|số\s*thửa|số\s*tờ)\s*[:#-]?\s*([0-9][A-Z0-9./-]{0,23})(?![\p{L}\p{N}_])/giu,ctx,'PARCEL',1);
    s=replaceWith(s,/\b(?:diện\s*tích)\s*[:=-]?\s*([0-9][0-9.,\s]{0,20}\s*(?:m2|m²|ha))\b/giu,ctx,'PARCEL',1);
    // Sensitive/basic attributes when attached to a person record.
    s=replaceWith(s,/\b(?:dân\s*tộc|tôn\s*giáo|tín\s*ngưỡng|giới\s*tính|tình\s*trạng\s*hôn\s*nhân|quốc\s*tịch|tình\s*trạng\s*sức\s*khỏe|sức\s*khỏe|chẩn\s*đoán|bệnh\s*lý|mức\s*độ\s*khuyết\s*tật|loại\s*khuyết\s*tật|nhóm\s*máu|thu\s*nhập|mức\s*thu\s*nhập|tình\s*trạng\s*hộ\s*nghèo|đời\s*sống\s*tình\s*dục|xu\s*hướng\s*tình\s*dục|quan\s*điểm\s*chính\s*trị|đặc\s*điểm\s*di\s*truyền|dữ\s*liệu\s*sinh\s*trắc\s*học)\s*[:=-]\s*([^\n;,]{1,100})/giu,ctx,'SENSITIVE',1);
    // Person names anchored by labels/titles/relationships.
    s=maskNameAfterPrefix(s,/((?:^|[ \t,;(])(?:ông|bà|anh|chị|đồng[ \t]*chí|họ[ \t]*và[ \t]*tên|họ[ \t]*tên|người[ \t]*đại[ \t]*diện|người[ \t]*kiến[ \t]*nghị|người[ \t]*khiếu[ \t]*nại|người[ \t]*tố[ \t]*cáo|người[ \t]*sử[ \t]*dụng[ \t]*đất|chủ[ \t]*sử[ \t]*dụng|công[ \t]*dân|bệnh[ \t]*nhân|người[ \t]*bệnh|học[ \t]*sinh|trẻ[ \t]*em|chủ[ \t]*hộ)[ \t]*(?:[:|\-])?[ \t]*)([^\n;,]{3,120})/giu,ctx);
    s=maskNameAfterPrefix(s,/((?:^|[ \t,;(])(?:cha|mẹ|bố|vợ|chồng|con|người[ \t]*giám[ \t]*hộ|người[ \t]*đại[ \t]*diện[ \t]*theo[ \t]*pháp[ \t]*luật)[ \t]*(?:[:|\-])?[ \t]*)([^\n;,]{3,120})/giu,ctx);
    s=maskNameAfterPrefix(s,/((?:^|[\n;,.]|[ \t]{2,})(?:KT\.[ \t]*)?(?:CHỦ[ \t]*TỊCH|PHÓ[ \t]*CHỦ[ \t]*TỊCH|GIÁM[ \t]*ĐỐC|PHÓ[ \t]*GIÁM[ \t]*ĐỐC|TRƯỞNG[ \t]*(?:PHÒNG|BAN|THÔN)|PHÓ[ \t]*TRƯỞNG[ \t]*(?:PHÒNG|BAN)|BÍ[ \t]*THƯ|PHÓ[ \t]*BÍ[ \t]*THƯ|CÔNG[ \t]*CHỨC|CHUYÊN[ \t]*VIÊN|CÁN[ \t]*BỘ|NGƯỜI[ \t]*KÝ)[ \t]*(?:[:|\-])?[ \t]+)([^\n;,]{3,120})/giu,ctx);
    s=replaceWith(s,SIGNATURE_NAME_RE,ctx,'PERSON',2,v=>looksPersonName(v));
    return s;
  }

  function looksLikePersonalSender(v){
    const s=String(v||'').trim();if(!s||/(ubnd|ủy ban|sở |phòng |ban |trung tâm|công an|bộ |cục |chi cục|trường |công ty|doanh nghiệp|văn phòng|hđnd|đảng ủy)/iu.test(s))return false;
    return new RegExp(`^${personName}$`,'u').test(s);
  }
  function walk(value,ctx,key='',knownNames=[]){
    if(typeof value==='string'){
      if((key==='attachmentNames'||key==='name'||key==='signingFileName')&&/\.(?:pdf|docx?|xlsx?|pptx?|rar|zip|7z)$/i.test(value.trim()))return put(ctx,'FILE',value.trim());
      if(/personName|fullName|hoTen|họTên/i.test(key))return put(ctx,'PERSON',value);
      // Field-aware protection catches structured metadata that may not contain a textual label.
      if(/(?:personId|userId|employeeId|citizenId|personalId|identityId|accountUserId)$/i.test(key)&&value.trim())return put(ctx,'ID',value);
      if(/(?:phone|mobile|telephone)$/i.test(key)&&value.trim())return put(ctx,'PHONE',value);
      if(/email$/i.test(key)&&value.trim())return put(ctx,'EMAIL',value);
      if(/(?:birthDate|dateOfBirth|dob)$/i.test(key)&&value.trim())return put(ctx,'DOB',value);
      if(/(?:homeAddress|residenceAddress|permanentAddress|temporaryAddress|contactAddress)$/i.test(key)&&value.trim())return put(ctx,'ADDRESS',value);
      if(/(?:bankAccount|accountNumber|cardNumber|creditNumber)$/i.test(key)&&value.trim())return put(ctx,'BANK',value);
      if(/(?:licensePlate|vehiclePlate)$/i.test(key)&&value.trim())return put(ctx,'ID',value);
      if(key==='sender'&&looksLikePersonalSender(value))return put(ctx,'PERSON',value);
      return protectText(value,ctx,knownNames);
    }
    if(Array.isArray(value))return value.map(v=>walk(v,ctx,key,knownNames));
    if(value&&typeof value==='object'){
      const out={};
      for(const [k,v] of Object.entries(value)){
        if(k.startsWith('_privacy'))continue;
        // Raw binary PDF/base64 is handled by the caller. Never inspect or duplicate it here.
        if(k==='base64')out[k]=v; else out[k]=walk(v,ctx,k,knownNames);
      }
      return out;
    }
    return value;
  }

  function detectSecret(value){
    let found=false;const visit=v=>{if(found||v==null)return;if(typeof v==='string'){if(SECRET_RE.test(v))found=true;return;}if(Array.isArray(v)){for(const x of v)visit(x);return;}if(typeof v==='object'){for(const [k,x] of Object.entries(v)){if(k!=='base64'&&!k.startsWith('_privacy'))visit(x);}}};visit(value);return found;
  }
  function countMatches(text,re){const m=String(text||'').match(re);return m?m.length:0;}
  function classifyRisk(value){
    const text=flattenText(value),lower=text.toLocaleLowerCase('vi-VN');
    const evidence={
      id:countMatches(text,/\b(?:CCCD|CMND|Căn\s*cước|Số\s*định\s*danh|Hộ\s*chiếu|BHXH|BHYT)\b/giu),
      phone:countMatches(text,/(?<!\d)(?:\+?84|0)(?:[ .-]?\d){8,10}(?!\d)/g),
      email:countMatches(text,/\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b/giu),
      dob:countMatches(text,/\b(?:ngày\s*sinh|sinh\s*ngày|năm\s*sinh|DOB)\b/giu),
      address:countMatches(text,/(?<![\p{L}\p{N}_])(?:địa\s*chỉ|nơi\s*cư\s*trú|thường\s*trú|tạm\s*trú|nơi\s*ở|quê\s*quán)(?![\p{L}\p{N}_])/giu),
      person:countMatches(text,/(?:^|[^\p{L}])(?:ông|bà|họ\s*tên|người\s*khiếu\s*nại|người\s*tố\s*cáo|bệnh\s*nhân|chủ\s*hộ)(?=$|[^\p{L}])/gimu)
    };
    const personalEvidence=Object.values(evidence).reduce((a,b)=>a+b,0);
    const flags=[];
    const hasCredential=/\b(?:mật\s*khẩu|password|passcode|mã\s*pin|otp|access\s*token|refresh\s*token|api\s*key)\s*[:=|-]\s*\S{4,}/iu.test(text);
    if(hasCredential)flags.push('credentials');
    const highDefs=[
      ['medical',/(?:bệnh\s*án|hồ\s*sơ\s*sức\s*khỏe|phiếu\s*khám|kết\s*quả\s*xét\s*nghiệm|chẩn\s*đoán|bệnh\s*nhân|HIV|khuyết\s*tật)/iu],
      ['children',/(?:hồ\s*sơ\s*trẻ\s*em|danh\s*sách\s*trẻ\s*em|khai\s*sinh|trẻ\s*em\s*có\s*hoàn\s*cảnh|danh\s*sách\s*học\s*sinh)/iu],
      ['poverty-social',/(?:danh\s*sách\s*hộ\s*(?:nghèo|cận\s*nghèo)|hồ\s*sơ\s*hộ\s*(?:nghèo|cận\s*nghèo)|bảo\s*trợ\s*xã\s*hội\s*cá\s*nhân)/iu],
      ['complaint-denunciation',/(?:đơn\s*khiếu\s*nại|đơn\s*tố\s*cáo|hồ\s*sơ\s*khiếu\s*nại|hồ\s*sơ\s*tố\s*cáo|người\s*khiếu\s*nại|người\s*tố\s*cáo)/iu],
      ['law-enforcement',/(?:bị\s*can|bị\s*cáo|tiền\s*án|tiền\s*sự|hồ\s*sơ\s*vụ\s*án|dữ\s*liệu\s*tội\s*phạm)/iu],
      ['banking',/(?:sao\s*kê|lịch\s*sử\s*giao\s*dịch|tài\s*khoản\s*ngân\s*hàng|thẻ\s*ngân\s*hàng|thông\s*tin\s*tín\s*dụng)/iu],
      ['biometric',/(?:sinh\s*trắc\s*học|vân\s*tay|mống\s*mắt|DNA|ADN|đặc\s*điểm\s*di\s*truyền)/iu],
      ['private-family',/(?:bí\s*mật\s*(?:cá\s*nhân|gia\s*đình)|đời\s*tư\s*cá\s*nhân|hồ\s*sơ\s*ly\s*hôn|bạo\s*lực\s*gia\s*đình)/iu],
      ['online-behavior',/(?:lịch\s*sử\s*truy\s*cập|lịch\s*sử\s*duyệt\s*web|dữ\s*liệu\s*theo\s*dõi\s*hành\s*vi|nhật\s*ký\s*hoạt\s*động\s*mạng)/iu]
    ];
    for(const [key,re] of highDefs)if(re.test(text))flags.push(key);
    const listLike=/\b(?:danh\s*sách|phụ\s*lục)\b/iu.test(text)&&/\b(?:họ\s*(?:và\s*)?tên|ngày\s*sinh|cccd|địa\s*chỉ|chủ\s*hộ)\b/iu.test(text);
    let level='normal',wouldBlock=false,reason='';
    if(hasCredential){level='critical';wouldBlock=true;reason='Phát hiện thông tin đăng nhập/mật khẩu/token trong dữ liệu nguồn. Privacy Shield sẽ che giá trị nhận diện được nhưng vẫn cho phép gửi theo chế độ cảnh báo.';}
    else if(listLike && personalEvidence>0){
      level='high';wouldBlock=true;reason='Phát hiện danh sách/phụ lục có trường dữ liệu cá nhân. Privacy Shield sẽ cố gắng khử nhận dạng và vẫn cho phép gửi; cần kiểm tra mục Tiến trình xử lý trước khi dùng kết quả.';
    } else if(flags.some(x=>x==='medical'||x==='children'||x==='poverty-social'||x==='complaint-denunciation'||x==='law-enforcement'||x==='banking'||x==='biometric'||x==='private-family'||x==='online-behavior') && personalEvidence>0){
      level='high';wouldBlock=true;reason='Phát hiện hồ sơ có dữ liệu cá nhân/rủi ro cao. Privacy Shield chuyển sang chế độ cảnh báo, vẫn cho phép gửi sau khi khử nhận dạng tự động.';
    } else if(flags.length||personalEvidence>=2){level='elevated';reason='Phát hiện dữ liệu cá nhân cần chú ý; vẫn cho phép gửi sau khi khử nhận dạng tự động.';}
    return {level,flags:[...new Set(flags)],personalEvidence,listLike,block:false,wouldBlock,reason,evidence};
  }

  function auditText(text,{knownValues=[]}={}){
    const s=String(text??'').replace(TOKEN_RE,'⟦MASKED⟧'),findings=[];
    const add=(type,re)=>{const m=(s.match(re)||[]).filter(x=>!String(x).includes('⟦MASKED⟧'));if(m.length)findings.push({type,count:m.length,sample:String(m[0]).slice(0,80)});};
    add('email',/\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b/giu);
    add('phone',/(?<!\d)(?:\+?84|0)(?:[ .-]?\d){8,10}(?!\d)/g);
    add('identity',/\b(?:CCCD|CMND|Căn\s*cước(?:\s*công\s*dân)?|Số\s*định\s*danh|ĐDCN|Hộ\s*chiếu|BHXH|BHYT)\s*(?:số|:|-)?\s*[A-Z0-9.-]{6,24}\b/giu);
    add('vehicle-plate',/\b(?:biển\s*(?:số\s*)?(?:xe|phương\s*tiện)|license\s*plate)\s*(?:số|:|-)?\s*[0-9A-ZĐ][0-9A-ZĐ .-]{4,14}\b/giu);
    add('digital-account',/\b(?:tài\s*khoản\s*(?:mạng\s*xã\s*hội|MXH)|Facebook|Zalo|Telegram|TikTok|ID\s*tài\s*khoản)\s*(?:[:=|\-])\s*@?[A-Z0-9._-]{3,120}/giu);
    add('dob',/\b(?:ngày\s*sinh|sinh\s*ngày|DOB)\s*(?:[:|-])?\s*(?:\d{1,2}[\/.-]){2}\d{2,4}\b/giu);
    add('bank',/\b(?:số\s*tài\s*khoản|tài\s*khoản\s*ngân\s*hàng|STK|số\s*thẻ)\s*(?:số|:|-)?\s*[0-9][0-9 .-]{5,28}[0-9]\b/giu);
    add('credential',/\b(?:mật\s*khẩu|password|passcode|mã\s*PIN|OTP|access\s*token|refresh\s*token|API\s*key)\s*(?:[:=|\-])\s*[^\s,;]{4,160}/giu);
    add('address',/(?<![\p{L}\p{N}_])(?:địa\s*chỉ(?:\s*thường\s*trú|\s*tạm\s*trú|\s*liên\s*hệ|\s*nhà|\s*thửa\s*đất)?|nơi\s*cư\s*trú|thường\s*trú|tạm\s*trú|nơi\s*ở\s*hiện\s*tại|quê\s*quán)\s*(?:[:|-])?(?!\s*⟦MASKED⟧)\s*[^\n;.]{4,120}/giu);
    add('sensitive-attribute',/\b(?:dân\s*tộc|tôn\s*giáo|tín\s*ngưỡng|tình\s*trạng\s*sức\s*khỏe|chẩn\s*đoán|tình\s*trạng\s*hôn\s*nhân)\s*[:=-](?!\s*⟦MASKED⟧)\s*[^\n;,]{1,80}/giu);
    // Audit names with the same capitalization validator used by masking. Raw regex-only
    // matching is intentionally avoided here because Vietnamese labels such as
    // "trẻ em trên địa bàn xã" can otherwise look like a false personal name.
    const anchoredNamePatterns=[
      /((?:^|[ \t,;(])(?:ông|bà|anh|chị|đồng[ \t]*chí|họ[ \t]*và[ \t]*tên|họ[ \t]*tên|người[ \t]*đại[ \t]*diện|người[ \t]*kiến[ \t]*nghị|người[ \t]*khiếu[ \t]*nại|người[ \t]*tố[ \t]*cáo|người[ \t]*sử[ \t]*dụng[ \t]*đất|chủ[ \t]*sử[ \t]*dụng|công[ \t]*dân|bệnh[ \t]*nhân|người[ \t]*bệnh|học[ \t]*sinh|trẻ[ \t]*em|chủ[ \t]*hộ)[ \t]*(?:[:|\-])?[ \t]*)([^\n;,]{3,120})/giu,
      /((?:^|[ \t,;(])(?:cha|mẹ|bố|vợ|chồng|con|người[ \t]*giám[ \t]*hộ|người[ \t]*đại[ \t]*diện[ \t]*theo[ \t]*pháp[ \t]*luật)[ \t]*(?:[:|\-])?[ \t]*)([^\n;,]{3,120})/giu,
      /((?:^|[\n;,.]|[ \t]{2,})(?:KT\.[ \t]*)?(?:CHỦ[ \t]*TỊCH|PHÓ[ \t]*CHỦ[ \t]*TỊCH|GIÁM[ \t]*ĐỐC|PHÓ[ \t]*GIÁM[ \t]*ĐỐC|TRƯỞNG[ \t]*(?:PHÒNG|BAN|THÔN)|PHÓ[ \t]*TRƯỞNG[ \t]*(?:PHÒNG|BAN)|BÍ[ \t]*THƯ|PHÓ[ \t]*BÍ[ \t]*THƯ|CÔNG[ \t]*CHỨC|CHUYÊN[ \t]*VIÊN|CÁN[ \t]*BỘ|NGƯỜI[ \t]*KÝ)[ \t]*(?:[:|\-])?[ \t]+)([^\n;,]{3,120})/giu
    ];
    let anchoredCount=0,anchoredSample='';
    for(const re of anchoredNamePatterns){
      re.lastIndex=0; let m;
      while((m=re.exec(s))){const name=leadingPersonName(m[2]);if(name){anchoredCount++;if(!anchoredSample)anchoredSample=name;}if(m[0]==='')re.lastIndex++;}
    }
    const sigRe=new RegExp(SIGNATURE_NAME_RE.source,SIGNATURE_NAME_RE.flags);let sm;
    while((sm=sigRe.exec(s))){if(looksPersonName(sm[2])){anchoredCount++;if(!anchoredSample)anchoredSample=sm[2];}if(sm[0]==='')sigRe.lastIndex++;}
    if(anchoredCount)findings.push({type:'person-name',count:anchoredCount,sample:String(anchoredSample).slice(0,80)});
    for(const raw of knownValues||[]){const v=String(raw||'').trim();if(v.length<5||TOKEN_RE.test(v))continue;const re=new RegExp(escapeRe(v).replace(/\\ /g,'\\s+'),'iu');if(re.test(s)){findings.push({type:'known-raw-value',count:1,sample:v.slice(0,80)});break;}}
    return {ok:findings.length===0,findings};
  }

  function protect(value){
    const ctx=makeContext();
    let risk=classifyRisk(value);
    if(detectSecret(value)){
      ctx.stats.blockedSecret=true;
      risk={...risk,level:'critical',flags:[...new Set([...(risk.flags||[]),'state-secret'])],block:false,wouldBlock:true,reason:'Phát hiện dấu mức độ bí mật nhà nước (MẬT/TỐI MẬT/TUYỆT MẬT). Privacy Shield 2.1 chỉ cảnh báo, không tự chặn gửi.'};
    }
    ctx.stats.riskLevel=risk.level;
    const knownNames=collectKnownNames(value),safe=walk(clone(value),ctx,'',knownNames);
    const warnings=[];
    if(risk.reason)warnings.push(risk.reason);
    return {value:safe,map:ctx.map,stats:ctx.stats,blocked:false,risk,reason:'',warnings};
  }

  function protectPrompt(prompt,base={}){
    const ctx=makeContext(base.map||{},base.stats||null),knownValues=Object.values(base.map||{}).filter(v=>String(v||'').trim().length>=5);
    const text=protectText(String(prompt??''),ctx,[]);
    const audit=auditText(text,{knownValues});
    const warnings=[];
    if(!audit.ok)warnings.push(`Prompt cuối còn dấu hiệu dữ liệu chưa khử nhận dạng hoàn toàn: ${audit.findings.map(x=>x.type).join(', ')}.`);
    return {text,map:ctx.map,stats:ctx.stats,audit,blocked:false,reason:'',warnings};
  }

  function restoreText(text,map){
    let s=String(text??'');const entries=Object.entries(map||{});for(let pass=0;pass<4;pass++){const before=s;for(const [k,v] of entries)s=s.split(k).join(String(v));if(s===before)break;}return s;
  }
  function restore(value,map){if(typeof value==='string')return restoreText(value,map);if(Array.isArray(value))return value.map(v=>restore(v,map));if(value&&typeof value==='object'){const out={};for(const [k,v] of Object.entries(value))out[k]=restore(v,map);return out;}return value;}

  globalThis.IOfficePrivacyShield=Object.freeze({VERSION,protect,protectPrompt,auditText,restore,restoreText,detectSecret,classifyRisk});
})();
