(() => {
  'use strict';
  function run(){
    const P=globalThis.IOfficePrivacyShield;if(!P)return {ok:false,total:0,passed:0,failures:['Privacy Shield chưa sẵn sàng']};
    const failures=[],cases=[];const add=(name,fn)=>cases.push({name,fn});
    const protect=text=>P.protect({text});
    add('P01 mask email',()=>/⟦EMAIL_/.test(protect('Email: abc@example.com').value.text));
    add('P02 mask phone',()=>/⟦PHONE_/.test(protect('Liên hệ 0975345779').value.text));
    add('P03 mask CCCD label',()=>/⟦ID_/.test(protect('CCCD: 024066000645').value.text));
    add('P04 mask CCCD 12 digit',()=>/⟦ID_/.test(protect('Mã cá nhân 024066000645').value.text));
    add('P05 mask DOB',()=>/⟦DOB_/.test(protect('Ngày sinh: 02/06/1966').value.text));
    add('P06 mask bank account',()=>/⟦BANK_/.test(protect('Số tài khoản: 123456789012').value.text));
    add('P07 mask address',()=>/⟦ADDRESS_/.test(protect('Địa chỉ: Thôn Tân An, xã Ea Ly, tỉnh Đắk Lắk').value.text));
    add('P08 mask land address',()=>/⟦ADDRESS_/.test(protect('địa chỉ thửa đất cũ tại xã Cuôr Đăng, huyện Cư M’gar').value.text));
    add('P09 mask parcel',()=>/⟦PARCEL_/.test(protect('thửa số 856, tờ bản đồ số 48').value.text));
    add('P10 mask title name',()=>/⟦PERSON_/.test(protect('Phó Chủ tịch Trần Văn Phước;').value.text));
    add('P11 mask signature name',()=>/⟦PERSON_/.test(protect('KT. CHỦ TỊCH\nPHÓ CHỦ TỊCH\nTrần Văn Phước').value.text));
    add('P12 mask known directory name',()=>/⟦PERSON_/.test(P.protect({text:'Người ký: Trần Văn Phước',_privacyKnownNames:['Trần Văn Phước']}).value.text));
    add('P13 preserve locality',()=>protect('UBND xã Cuôr Đăng phối hợp thực hiện.').value.text.includes('UBND xã Cuôr Đăng'));
    add('P14 preserve organization',()=>protect('Sở Tư pháp tỉnh Đắk Lắk hướng dẫn.').value.text.includes('Sở Tư pháp'));
    add('P15 warn state secret without blocking',()=>{const r=P.protect({text:'MẬT\nNội dung'});return r.blocked===false&&r.risk?.level==='critical'&&(r.risk?.flags||[]).includes('state-secret');});
    add('P16 warn health dossier without blocking',()=>{const r=P.protect({text:'Bệnh án bệnh nhân Nguyễn Văn A, ngày sinh 01/01/1980'});return r.blocked===false&&r.risk?.level==='high'&&/⟦PERSON_/.test(r.value.text);});
    add('P17 warn child personal list',()=>{const r=P.protect({text:'Danh sách học sinh: Nguyễn Văn A, ngày sinh 01/01/2015'});return r.blocked===false&&r.risk?.level==='high';});
    add('P18 allow general child policy',()=>P.protect({text:'Kế hoạch bảo vệ trẻ em trên địa bàn xã năm 2026'}).blocked===false);
    add('P19 warn poverty list',()=>{const r=P.protect({text:'Danh sách hộ nghèo: Ông Nguyễn Văn A, CCCD 024066000645'});return r.blocked===false&&r.risk?.level==='high'&&/⟦ID_/.test(r.value.text);});
    add('P20 warn complaint dossier',()=>{const r=P.protect({text:'Đơn khiếu nại của ông Nguyễn Văn A, địa chỉ: Thôn 1, xã Ea Ly'});return r.blocked===false&&r.risk?.level==='high';});
    add('P21 mask credentials but do not block',()=>{const r=P.protect({text:'Mật khẩu: Secret123!'});return r.blocked===false&&r.risk?.level==='critical'&&/⟦CREDENTIAL_/.test(r.value.text);});
    add('P22 final prompt second pass',()=>{const r=P.protect({text:'Nội dung thường'}),f=P.protectPrompt('Ghi chú bổ sung email: abc@example.com',{map:r.map,stats:r.stats});return f.blocked===false&&/⟦EMAIL_/.test(f.text)&&f.audit.ok;});
    add('P23 audit catches residual',()=>P.auditText('CCCD: 024066000645').ok===false);
    add('P24 no raw known value after prompt',()=>{let r=P.protect({text:'Ông Nguyễn Văn A đề nghị xem xét'});let f=P.protectPrompt('PROMPT '+r.value.text,{map:r.map,stats:r.stats});return f.audit.ok&&!f.text.includes('Nguyễn Văn A');});
    add('P25 mask vehicle plate',()=>/⟦ID_/.test(protect('Biển số xe: 47A-123.45').value.text));
    add('P26 mask social account',()=>/⟦ID_/.test(protect('Tài khoản mạng xã hội: @nguyenvana').value.text));
    add('P27 structured userId masked',()=>/⟦ID_/.test(P.protect({userId:'person-928371',text:'Nội dung'}).value.userId));
    add('P28 structured phone masked',()=>/⟦PHONE_/.test(P.protect({mobile:'0975345779'}).value.mobile));
    add('P29 structured home address masked',()=>/⟦ADDRESS_/.test(P.protect({homeAddress:'123 đường A, phường B'}).value.homeAddress));
    add('P30 warn private family dossier',()=>{const r=P.protect({text:'Hồ sơ ly hôn của bà Nguyễn Thị A, địa chỉ: Thôn 1, xã Ea Ly'});return r.blocked===false&&r.risk?.level==='high';});
    add('P31 warn online behavior dossier',()=>{const r=P.protect({text:'Lịch sử truy cập của ông Nguyễn Văn A, CCCD 024066000645'});return r.blocked===false&&r.risk?.level==='high';});
    add('P32 mask sensitive political attribute',()=>/⟦SENSITIVE_/.test(protect('Quan điểm chính trị: nội dung riêng tư').value.text));
    add('P33 warn degree secret label',()=>{const r=P.protect({text:'ĐỘ MẬT: MẬT\nNội dung'});return r.blocked===false&&r.risk?.level==='critical';});
    add('P34 no false name on child phrase',()=>{const r=P.protect({text:'Kế hoạch bảo vệ trẻ em trên địa bàn xã Ea Ly'});const f=P.protectPrompt(r.value.text,{map:r.map,stats:r.stats});return !f.blocked&&f.audit.ok;});
    add('P35 warn generic personal list',()=>{const r=P.protect({text:'DANH SÁCH\nSTT | Họ và tên | Ngày sinh\n1 | Nguyễn Văn A | 01/01/1980'});return r.blocked===false&&r.risk?.level==='high';});
    add('P36 warn patient and mask customer-insurance IDs',()=>{const med=P.protect({text:'Bệnh án bệnh nhân Nguyễn Văn A; Mã bệnh nhân: BN12345'});const a=protect('Mã khách hàng: KH12345; số hợp đồng bảo hiểm: BH987654').value.text;return med.blocked===false&&med.risk?.level==='high'&&(a.match(/⟦ID_/g)||[]).length>=2;});
    for(const c of cases){try{if(!c.fn())failures.push(c.name);}catch(e){failures.push(`${c.name}: ${e.message}`);}}
    return {ok:failures.length===0,total:cases.length,passed:cases.length-failures.length,failures};
  }
  globalThis.IOfficePrivacyTests=Object.freeze({run});
})();
