const PROVIDER_CATALOG = {
  'gemini-openai': {
    label: 'Google Gemini', vendor: 'Google', group: 'Ưu tiên', type: 'openai-chat',
    baseUrl: 'https://generativelanguage.googleapis.com/v1beta/openai/',
    defaultModel: 'gemini-3.5-flash-lite', needsKey: true, canListModels: true,
    presets: [
      { id: 'gemini-3.5-flash-lite', label: 'Gemini 3.5 Flash-Lite' },
      { id: 'gemini-3.1-flash-lite', label: 'Gemini 3.1 Flash-Lite' },
      { id: 'gemini-3.8-flash', label: 'Gemini 3.8 Flash' }
    ]
  },
  gemini: {
    label: 'Google Gemini', vendor: 'Google', group: 'Chính thức', type: 'gemini',
    baseUrl: 'https://generativelanguage.googleapis.com/v1beta',
    defaultModel: '', needsKey: true, canListModels: true,
    presets: []
  },
  openai: {
    label: 'OpenAI', vendor: 'OpenAI', group: 'Chính thức', type: 'openai-responses',
    baseUrl: 'https://api.openai.com/v1',
    defaultModel: '', needsKey: true, canListModels: true,
    presets: []
  },
  anthropic: {
    label: 'Anthropic Claude', vendor: 'Anthropic', group: 'Chính thức', type: 'anthropic',
    baseUrl: 'https://api.anthropic.com/v1',
    defaultModel: '', needsKey: true, canListModels: true,
    presets: []
  },
  openrouter: {
    label: 'OpenRouter', vendor: 'OpenRouter', group: 'Bộ định tuyến nhiều model', type: 'openai-chat',
    baseUrl: 'https://openrouter.ai/api/v1',
    defaultModel: '', needsKey: true, canListModels: true,
    presets: []
  },
  groq: {
    label: 'GroqCloud', vendor: 'Groq', group: 'OpenAI-compatible', type: 'openai-chat',
    baseUrl: 'https://api.groq.com/openai/v1',
    defaultModel: '', needsKey: true, canListModels: true,
    presets: []
  },
  deepseek: {
    label: 'DeepSeek', vendor: 'DeepSeek', group: 'OpenAI-compatible', type: 'openai-chat',
    baseUrl: 'https://api.deepseek.com/v1',
    defaultModel: '', needsKey: true, canListModels: true,
    presets: []
  },
  xai: {
    label: 'xAI', vendor: 'xAI', group: 'OpenAI-compatible', type: 'openai-chat',
    baseUrl: 'https://api.x.ai/v1',
    defaultModel: '', needsKey: true, canListModels: true,
    presets: []
  },
  mistral: {
    label: 'Mistral AI', vendor: 'Mistral', group: 'OpenAI-compatible', type: 'openai-chat',
    baseUrl: 'https://api.mistral.ai/v1',
    defaultModel: '', needsKey: true, canListModels: true,
    presets: []
  },
  together: {
    label: 'Together AI', vendor: 'Together', group: 'OpenAI-compatible', type: 'openai-chat',
    baseUrl: 'https://api.together.xyz/v1',
    defaultModel: '', needsKey: true, canListModels: true,
    presets: []
  },
  fireworks: {
    label: 'Fireworks AI', vendor: 'Fireworks', group: 'OpenAI-compatible', type: 'openai-chat',
    baseUrl: 'https://api.fireworks.ai/inference/v1',
    defaultModel: '', needsKey: true, canListModels: true,
    presets: []
  },
  cerebras: {
    label: 'Cerebras Inference', vendor: 'Cerebras', group: 'OpenAI-compatible', type: 'openai-chat',
    baseUrl: 'https://api.cerebras.ai/v1',
    defaultModel: '', needsKey: true, canListModels: true,
    presets: []
  },
  perplexity: {
    label: 'Perplexity API', vendor: 'Perplexity', group: 'OpenAI-compatible', type: 'openai-chat',
    baseUrl: 'https://api.perplexity.ai',
    defaultModel: '', needsKey: true, canListModels: true,
    presets: []
  },
  github: {
    label: 'GitHub Models', vendor: 'GitHub', group: 'OpenAI-compatible', type: 'openai-chat',
    baseUrl: 'https://models.github.ai/inference',
    defaultModel: '', needsKey: true, canListModels: true,
    presets: []
  },
  ollama: {
    label: 'Ollama (máy local)', vendor: 'Local', group: 'AI chạy trên máy', type: 'ollama',
    baseUrl: 'http://127.0.0.1:11434',
    defaultModel: '', needsKey: false, canListModels: true,
    presets: []
  },
  lmstudio: {
    label: 'LM Studio (máy local)', vendor: 'Local', group: 'AI chạy trên máy', type: 'openai-chat',
    baseUrl: 'http://127.0.0.1:1234/v1',
    defaultModel: '', needsKey: false, canListModels: true,
    presets: []
  },
  azure: {
    label: 'Azure OpenAI', vendor: 'Microsoft Azure', group: 'Doanh nghiệp', type: 'azure-openai',
    baseUrl: '', defaultModel: '', needsKey: true, canListModels: false, presets: []
  },
  custom: {
    label: 'API tùy chỉnh (OpenAI-compatible)', vendor: 'Tùy chỉnh', group: 'Tùy chỉnh', type: 'openai-chat',
    baseUrl: '', defaultModel: '', needsKey: false, canListModels: true, presets: []
  },
  gateway: {
    label: 'Local/Internal Gateway', vendor: 'Nội bộ', group: 'Tùy chỉnh', type: 'gateway',
    baseUrl: 'http://127.0.0.1:8787/analyze', defaultModel: '', needsKey: false, canListModels: false, presets: []
  }
};

if (typeof globalThis !== 'undefined') globalThis.IOFFICE_PROVIDER_CATALOG = PROVIDER_CATALOG;
