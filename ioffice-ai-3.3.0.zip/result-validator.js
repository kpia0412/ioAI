(() => {
  'use strict';

  const SCOPES = new Set(['direct','coordination','information','other-locality','ambiguous']);
  const norm = v => String(v ?? '').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/đ/g,'d').replace(/Đ/g,'D').toLowerCase().replace(/\s+/g,' ').trim();
  const clean = v => String(v ?? '').replace(/\u0000/g,'').replace(/\s+/g,' ').trim();
  const uniq = a => [...new Set((Array.isArray(a)?a:[]).map(String).filter(Boolean))];
  const clamp = (n,min,max)=>Math.max(min,Math.min(max,n));

  function evidenceCorpus(context={}) {
    const b=context.documentBundle||{};
    const parts=[];
    if (b.primaryDocument?.text) parts.push(b.primaryDocument.text);
    for (const d of b.supportingDocuments||[]) if (d?.text) parts.push(d.text);
    if (!parts.length && context.previewText) parts.push(context.previewText);
    return norm(parts.join('\n'));
  }

  function evidenceMatches(evidence, deadline, corpus) {
    const e=norm(evidence);
    if(!e || e.length<10 || !corpus) return false;
    if(corpus.includes(e)) return true;
    const words=[...new Set(e.split(/\s+/).filter(w=>w.length>=3))];
    if(words.length<4) return false;
    const hit=words.filter(w=>corpus.includes(w)).length/words.length;
    const d=String(deadline||'');
    const [y,m,day]=/^\d{4}-\d{2}-\d{2}$/.test(d)?d.split('-'):[];
    const dateHint = y && (corpus.includes(`${day}/${m}/${y}`) || corpus.includes(`${day}-${m}-${y}`) || corpus.includes(`${day}.${m}.${y}`) || corpus.includes(`${day}/${m}`));
    return hit>=0.72 && (!!dateHint || hit>=0.86);
  }

  function validate(raw, opts={}) {
    const workflow=String(opts.workflow||raw?.workflow||'leader-incoming');
    const incoming=workflow==='leader-incoming';
    const allowed=new Set((opts.allowedUnitIds||[]).map(String));
    const context=opts.context||{};
    const warnings=[];
    if(!raw || Array.isArray(raw) || typeof raw!=='object') throw new Error('Kết quả AI không phải object JSON.');

    const unitOk=id=>!id || allowed.size===0 || allowed.has(String(id));
    let mainUnit=raw.mainUnit==null||raw.mainUnit===''?null:String(raw.mainUnit);
    if(mainUnit && !unitOk(mainUnit)) throw new Error(`AI trả XLC không hợp lệ: ${mainUnit}`);

    if(!Array.isArray(raw.coordinationUnits)) throw new Error('AI trả coordinationUnits sai cấu trúc.');
    if(!Array.isArray(raw.viewUnits)) throw new Error('AI trả viewUnits sai cấu trúc.');
    if([...raw.coordinationUnits,...raw.viewUnits].some(id=>!unitOk(id))) throw new Error('AI trả mã đơn vị PH/Xem không hợp lệ.');
    let coordinationUnits=uniq(raw.coordinationUnits).filter(id=>unitOk(id)&&id!==mainUnit);
    let viewUnits=uniq(raw.viewUnits).filter(id=>unitOk(id)&&id!==mainUnit&&!coordinationUnits.includes(id));
    if(incoming) viewUnits=[]; // Xem để biết đơn vị đã bỏ; cá nhân do người dùng chọn.

    const rawConfidence=Number(raw.confidence);
    if(!Number.isFinite(rawConfidence)) throw new Error('AI không trả confidence hợp lệ.');
    let requiresReview=typeof raw.requiresReview==='boolean'?raw.requiresReview:true;
    if(typeof raw.requiresReview!=='boolean') warnings.push('AI thiếu requiresReview; chuyển sang cần kiểm tra.');

    let actionRequired;
    if(typeof raw.actionRequired==='boolean') actionRequired=raw.actionRequired;
    else {
      // Không được suy từ mainUnit: mainUnit chỉ là đầu mối nhận iOffice, không chứng minh có nhiệm vụ.
      actionRequired=false;
      requiresReview=true;
      warnings.push('AI thiếu actionRequired; không tự suy từ XLC/nhiệm vụ.');
    }

    let taskScope=SCOPES.has(String(raw.taskScope||''))?String(raw.taskScope):'ambiguous';
    if(!SCOPES.has(String(raw.taskScope||''))) {
      requiresReview=true;
      warnings.push('AI thiếu/không hợp lệ taskScope; chuyển ambiguous.');
    }

    let trackRecommended=raw.trackRecommended===true;
    const trackingReason=clean(raw.trackingReason||'');
    const corpus=evidenceCorpus(context);
    let deadlineRejected=false;
    const rawTasks=Array.isArray(raw.tasks)?raw.tasks:[];
    const tasks=rawTasks.map((task,index)=>{
      task=task&&typeof task==='object'?task:{};
      const scope=SCOPES.has(String(task.scope||''))?String(task.scope):taskScope;
      const responsibleUnit=task.responsibleUnit&&unitOk(task.responsibleUnit)?String(task.responsibleUnit):(task.responsibleUnit?null:mainUnit);
      if(task.responsibleUnit && !unitOk(task.responsibleUnit)) warnings.push(`Nhiệm vụ ${index+1}: responsibleUnit không hợp lệ.`);
      let deadline=/^\d{4}-\d{2}-\d{2}$/.test(String(task.deadline||''))?String(task.deadline):null;
      const deadlineText=clean(task.deadlineText||'');
      const deadlineEvidence=clean(task.deadlineEvidence||'');
      let deadlineSource=clean(task.deadlineSource||(deadline?'document':'none'));
      let taskTrack=task.trackRecommended===true;
      if(incoming && deadline) {
        if(scope!=='direct' || taskScope!=='direct' || actionRequired!==true) {
          warnings.push(`Nhiệm vụ ${index+1}: bỏ hạn vì phạm vi không phải nhiệm vụ trực tiếp của Ea Ly.`);
          deadline=null; deadlineSource='rejected-scope'; taskTrack=false; deadlineRejected=true;
        } else if(!evidenceMatches(deadlineEvidence,deadline,corpus)) {
          warnings.push(`Nhiệm vụ ${index+1}: bỏ hạn vì deadlineEvidence không được xác minh trong tài liệu đã đọc.`);
          deadline=null; deadlineSource='rejected-evidence'; taskTrack=false; deadlineRejected=true; requiresReview=true;
        }
      }
      return {
        index:index+1,
        task:clean(task.task||''),
        deadline,
        deadlineText,
        deadlineEvidence,
        deadlineSource,
        responsibleUnit,
        scope,
        trackRecommended:taskTrack
      };
    }).filter(t=>t.task||t.deadline||t.deadlineText||t.deadlineEvidence);

    if(incoming && taskScope!=='direct') {
      actionRequired=false;
      trackRecommended=false;
      for(const t of tasks) t.trackRecommended=false;
    }
    if(incoming && actionRequired!==true) trackRecommended=false;
    if(incoming && trackRecommended && !tasks.some(t=>t.trackRecommended || t.deadline)) {
      trackRecommended=false;
      warnings.push('Tắt đề xuất theo dõi vì không còn nhiệm vụ/hạn đã được xác minh.');
    }

    const incomplete=context?.documentBundle?.requiresReviewForUnreadable===true || context?.documentBundle?.appendixRequiredMissing===true;
    let confidence=clamp(rawConfidence,0,incomplete?0.69:1);
    if(warnings.length) confidence=Math.min(confidence,0.69);
    if(deadlineRejected) confidence=Math.min(confidence,0.64);


    const recipientCandidates=new Map((Array.isArray(opts.recipientCandidates)?opts.recipientCandidates:[]).map(x=>[String(x?.key||''),x]).filter(([k])=>k));
    const recipientMin=Math.max(.7,Math.min(.98,Number(opts.recipientPolicy?.minConfidence)||.85));
    let additionalRecipientKey=clean(raw.additionalRecipientKey||'');
    let recipientConfidence=Number(raw.recipientConfidence||0);
    if(!Number.isFinite(recipientConfidence))recipientConfidence=0;
    recipientConfidence=clamp(recipientConfidence,0,1);
    if(additionalRecipientKey){
      const candidate=recipientCandidates.get(additionalRecipientKey);
      const valid=recipientCandidates.size===0 ? (/^(?:U\d+|DUUBND)-R\d+$/i.test(additionalRecipientKey) && (!mainUnit || additionalRecipientKey.toUpperCase().startsWith(String(mainUnit).toUpperCase()+'-')) && recipientConfidence>=recipientMin) : (!!candidate && !!mainUnit && String(candidate.unitId||'')===String(mainUnit) && recipientConfidence>=recipientMin);
      if(!valid){
        additionalRecipientKey='';recipientConfidence=0;
      }
    }

    const recipientNames=incoming?[]:uniq(raw.recipientNames).map(clean).filter(Boolean).slice(0,80);
    const documentSummary=clean(raw.documentSummary||'').slice(0,1600);
    const reviewIssues=(Array.isArray(raw.reviewIssues)?raw.reviewIssues:[]).slice(0,30).map(x=>({
      severity:['high','medium','low'].includes(String(x?.severity||'').toLowerCase())?String(x.severity).toLowerCase():'low',
      category:clean(x?.category||''),detail:clean(x?.detail||''),evidence:clean(x?.evidence||'')
    })).filter(x=>x.detail);
    const signals=uniq([...(Array.isArray(raw.signals)?raw.signals.map(clean):[]),...warnings]).filter(Boolean).slice(0,12);

    return {
      workflow,
      actionRequired,
      mainUnit,
      coordinationUnits,
      viewUnits,
      instruction:clean(raw.instruction||''),
      meetingCheckComplete:raw.meetingCheckComplete===false?false:Array.isArray(raw.meetings),
      meetings:(Array.isArray(raw.meetings)?raw.meetings:[]).slice(0,1).filter(m=>m&&typeof m==='object').map(m=>({title:clean(m.title).slice(0,600),date:clean(m.date),time:clean(m.time),endTime:clean(m.endTime),location:clean(m.location).slice(0,600),participants:clean(m.participants).slice(0,1500),evidence:clean(m.evidence).slice(0,2000),requiresReview:raw.meetings.length>1||m.requiresReview===true})),
      tasks,
      recipientNames,
      additionalRecipientKey,
      recipientConfidence,
      documentSummary,
      reviewSummary:clean(raw.reviewSummary||''),
      reviewIssues,
      taskScope,
      trackRecommended,
      trackingReason,
      reason:clean(raw.reason||''),
      confidence,
      requiresReview:requiresReview || incomplete || warnings.length>0 || (incoming && taskScope==='direct' && !mainUnit),
      signals,
      validationWarnings:warnings,
      deadlineEvidenceRejected:deadlineRejected
    };
  }

  globalThis.IOfficeResultValidator=Object.freeze({SCOPES:Object.freeze([...SCOPES]),validate,evidenceMatches,evidenceCorpus});
})();
