(() => {
  'use strict';
  if (globalThis.__iofficeUnifiedWebBridge040) return;
  globalThis.__iofficeUnifiedWebBridge040 = true;

  const core = globalThis.IOfficeCore;
  const platform = location.hostname === 'gemini.google.com' ? 'gemini' : 'chatgpt';
  const label = platform === 'gemini' ? 'Gemini' : 'ChatGPT';
  let active = null;

  const visible = el => !!el && el.getClientRects().length > 0 && getComputedStyle(el).visibility !== 'hidden';
  const enabled = el => !!el && !el.disabled && el.getAttribute('aria-disabled') !== 'true';
  const message = m => chrome.runtime.sendMessage(m);
  const cancelled = () => new DOMException('Đã dừng phân tích.', 'AbortError');
  const assert = signal => { if (signal?.aborted) throw cancelled(); };
  const pick = selectors => {
    for (const selector of selectors) {
      try {
        const hit = [...document.querySelectorAll(selector)].find(visible);
        if (hit) return hit;
      } catch (_) {}
    }
    return null;
  };

  function waitFor(check, timeout, signal, error) {
    assert(signal);
    return new Promise((resolve, reject) => {
      let observer, interval, deadline, done = false;
      const finish = (err, value) => {
        if (done) return;
        done = true;
        observer?.disconnect();
        clearInterval(interval);
        clearTimeout(deadline);
        signal?.removeEventListener('abort', abort);
        err ? reject(err) : resolve(value);
      };
      const abort = () => finish(cancelled());
      const scan = () => {
        try { assert(signal); const value = check(); if (value) finish(null, value); }
        catch (error) { finish(error); }
      };
      observer = new MutationObserver(scan);
      observer.observe(document.body || document.documentElement, {
        subtree: true, childList: true, characterData: true, attributes: true,
        attributeFilter: ['disabled', 'aria-disabled', 'aria-busy', 'data-state']
      });
      // MutationObserver là đường chính; polling thưa chỉ là fallback khi SPA đổi ngoài vùng observer.
      interval = setInterval(scan, 1800);
      deadline = setTimeout(() => finish(new Error(error)), timeout);
      signal?.addEventListener('abort', abort, { once: true });
      scan();
    });
  }

  function composer() {
    return platform === 'gemini'
      ? pick([
          'rich-textarea [contenteditable="true"]',
          '.ql-editor[contenteditable="true"]',
          '[contenteditable="true"][role="textbox"]',
          'div[contenteditable="true"][aria-label*="prompt" i]',
          'div[contenteditable="true"][aria-label*="message" i]',
          'textarea'
        ])
      : pick([
          '#prompt-textarea',
          'textarea[data-testid="prompt-textarea"]',
          'main form [contenteditable="true"][role="textbox"]',
          'main form .ProseMirror[contenteditable="true"]',
          'main [contenteditable="true"][role="textbox"]'
        ]);
  }

  const composerText = el => String(el?.value ?? el?.innerText ?? el?.textContent ?? '').trim();

  function composerRoot() {
    const c = composer();
    return c?.closest('form,[data-testid*="composer" i],[class*="composer" i],input-container,.input-area-container,.input-area,.input-container')
      || c?.parentElement?.parentElement || c?.parentElement || null;
  }

  function stopButton() {
    const root = composerRoot() || document;
    const selectors = [
      'button[data-testid*="stop" i]',
      'button[aria-label*="Stop" i]',
      'button[aria-label*="Dừng" i]',
      'button[aria-label*="Cancel" i]'
    ];
    for (const sel of selectors) {
      const hit = [...root.querySelectorAll(sel)].find(visible);
      if (hit) return hit;
    }
    return null;
  }

  function sendButton() {
    const root = composerRoot();
    const strong = [
      'button[data-testid="send-button"]',
      'button[data-testid*="send" i]',
      'button[aria-label*="Send message" i]',
      'button[aria-label^="Send" i]',
      'button[aria-label*="Gửi" i]',
      'button.send-button'
    ];
    if (root) {
      for (const sel of [...strong, 'button[type="submit"]']) {
        const hit = [...root.querySelectorAll(sel)].find(el => visible(el) && enabled(el));
        if (hit) return hit;
      }
    }
    // Không fallback button[type=submit] toàn trang để tránh click nhầm nút khác.
    return pick(strong);
  }

  async function setText(el, text) {
    if (!el) throw new Error(`Không tìm thấy ô nhập ${label}.`);
    el.focus();
    if (el instanceof HTMLTextAreaElement || el instanceof HTMLInputElement) {
      const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
      const setter = Object.getOwnPropertyDescriptor(proto, 'value')?.set;
      if (setter) setter.call(el, text); else el.value = text;
      el.dispatchEvent(new Event('input', { bubbles: true }));
      el.dispatchEvent(new Event('change', { bubbles: true }));
    } else {
      const selection = window.getSelection(), range = document.createRange();
      range.selectNodeContents(el); selection.removeAllRanges(); selection.addRange(range);
      let inserted = false;
      try { inserted = document.execCommand('insertText', false, text); } catch (_) {}
      if (!inserted) el.textContent = text;
      el.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: text }));
      el.dispatchEvent(new Event('change', { bubbles: true }));
    }
    await new Promise(r => setTimeout(r, 45));
    if (!composerText(el)) {
      const current = composer();
      if (current && current !== el) {
        current.focus(); current.textContent = text;
        current.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: text }));
        await new Promise(r => setTimeout(r, 45));
        el = current;
      }
    }
    if (!composerText(el)) throw new Error(`Không dán được văn bản vào ${label}. Hãy mở tab kiểm tra ô nhập.`);
    return el;
  }

  const progress = async (job, phase, phaseMessage) => {
    try { return await message({ type: 'WEB_AUTOMATION_PROGRESS', provider: platform, jobId: job.jobId, phase, phaseMessage }); }
    catch (_) { return null; }
  };

  function newChatButton() {
    const selectors = platform === 'gemini'
      ? ['[data-test-id*="new-chat" i]','button[aria-label*="New chat" i]','a[aria-label*="New chat" i]','button[aria-label*="Cuộc trò chuyện mới" i]','a[aria-label*="Cuộc trò chuyện mới" i]']
      : ['a[data-testid="create-new-chat-button"]','button[data-testid="create-new-chat-button"]','a[aria-label*="New chat" i]','button[aria-label*="New chat" i]','a[aria-label*="Cuộc trò chuyện mới" i]','button[aria-label*="Cuộc trò chuyện mới" i]'];
    return pick(selectors) || [...document.querySelectorAll('button,a,[role="button"]')].find(el => visible(el) && /^(New chat|New conversation|Cuộc trò chuyện mới|Trò chuyện mới)$/i.test((el.innerText || el.getAttribute('aria-label') || '').trim()));
  }

  async function newChat(signal) {
    const oldUrl = location.href, oldComposer = composer(), button = newChatButton();
    if (!button) {
      const current = composer();
      if (current && !composerText(current)) return false;
      throw new Error(`${label} đang có bản nháp hoặc chưa sẵn sàng. Hãy kiểm tra tab ${label}.`);
    }
    assert(signal); button.click();
    const started = performance.now();
    let lastUrl = location.href, stableSince = started;
    try {
      await waitFor(() => {
        const current = composer();
        if (!current || composerText(current)) return false;
        const now = performance.now();
        if (location.href !== lastUrl) { lastUrl = location.href; stableSince = now; return false; }
        const changed = location.href !== oldUrl || current !== oldComposer;
        return ((changed && now - stableSince >= 140) || now - started >= 1000) ? current : false;
      }, 5500, signal, `${label} chưa sẵn sàng sau khi mở cuộc trò chuyện mới.`);
      return true;
    } catch (error) {
      if (error?.name === 'AbortError') throw error;
      const current = composer();
      if (current && !composerText(current)) return false;
      throw error;
    }
  }

  function responseNodes() {
    const selectors = platform === 'gemini'
      ? ['model-response','.model-response-text','[data-test-id*="model-response" i]','[data-author="assistant"]']
      : ['[data-message-author-role="assistant"]','[data-message-author-role="model"]','article[data-testid^="conversation-turn"]'];
    const out = [];
    for (const sel of selectors) {
      try { for (const node of document.querySelectorAll(sel)) if (!out.includes(node)) out.push(node); } catch (_) {}
    }
    return out;
  }

  function waitResult(job, signal) {
    return waitFor(() => {
      const nodes = responseNodes();
      for (const el of nodes.slice(-6).reverse()) {
        const text = el.innerText || el.textContent || '';
        if (!text.includes(job.jobId)) continue;
        const obj = core.parseRouting(text, job.jobId);
        if (obj) return JSON.stringify(obj);
      }
      return false;
    }, job.timeoutMs || 150000, signal, `Chưa nhận được JSON đúng phiên từ ${label}. Hãy mở tab kiểm tra phản hồi hoặc tăng thời gian chờ.`);
  }

  async function observeOnly(job, controller) {
    const signal = controller.signal;
    let heartbeat;
    try {
      heartbeat = setInterval(() => { void progress(job, 'waiting', `${label} đang xử lý · không gửi lại`); }, 15000);
      const text = await waitResult(job, signal);
      assert(signal);
      const result = await message({ type: 'WEB_AUTOMATION_RESULT', provider: platform, jobId: job.jobId, text });
      if (!result?.ok) throw new Error(result?.error || `Không lưu được kết quả ${label}.`);
    } catch (error) {
      if (error.name !== 'AbortError') await message({ type: 'WEB_AUTOMATION_ERROR', provider: platform, jobId: job.jobId, error: error.message || String(error) }).catch(() => {});
    } finally {
      clearInterval(heartbeat); controller.abort();
      if (active?.jobId === job.jobId) active = null;
    }
  }

  async function run(job, controller) {
    const signal = controller.signal;
    let heartbeat, resultPromise;
    try {
      heartbeat = setInterval(() => { void progress(job, 'waiting', `${label} đang xử lý văn bản`); }, 15000);
      const firstComposer = await waitFor(composer, 30000, signal, `Không tìm thấy ô nhập ${label}. Hãy đăng nhập ${label} và thử lại.`);
      await waitFor(() => !stopButton(), 15000, signal, `${label} vẫn đang tạo câu trả lời trước.`);
      if (job.newChatBeforeSend) { await progress(job, 'new-chat', 'Đang mở cuộc trò chuyện mới'); await newChat(signal); }
      if (composerText(composer())) throw new Error(`Tab ${label} có nội dung chưa gửi. Hãy xử lý bản nháp trước khi phân tích.`);
      assert(signal); await setText(composer() || firstComposer, job.prompt);
      await progress(job, 'prompt-ready', `Đã chuẩn bị nội dung · chờ khóa gửi ${label}`);
      const send = await waitFor(() => enabled(sendButton()) && sendButton(), 15000, signal, `Nút Gửi ${label} chưa sẵn sàng.`);
      resultPromise = waitResult(job, signal); resultPromise.catch(() => {});

      // QUAN TRỌNG: background phải ghi SEND_COMMITTED trước khi click. Sau mốc này
      // mọi reconnect/reload chỉ quan sát kết quả và không được gửi prompt lần hai.
      const committed = await message({ type: 'WEB_AUTOMATION_COMMIT_SEND', provider: platform, jobId: job.jobId });
      if (!committed?.ok) throw new Error(committed?.error || `Không khóa được thao tác gửi ${label}.`);
      if (committed.maySend !== false) {
        assert(signal); send.click();
        await progress(job, 'sent', `Đã gửi tới ${label} · đang chờ kết quả`);
      } else {
        await progress(job, 'waiting', `${label} đã có dấu gửi trước đó · chỉ chờ kết quả, không gửi lại`);
      }

      const text = await resultPromise;
      assert(signal);
      const result = await message({ type: 'WEB_AUTOMATION_RESULT', provider: platform, jobId: job.jobId, text });
      if (!result?.ok) throw new Error(result?.error || `Không lưu được kết quả ${label}.`);
    } catch (error) {
      if (error.name !== 'AbortError') await message({ type: 'WEB_AUTOMATION_ERROR', provider: platform, jobId: job.jobId, error: error.message || String(error) }).catch(() => {});
    } finally {
      clearInterval(heartbeat); controller.abort();
      if (active?.jobId === job.jobId) active = null;
    }
  }

  chrome.runtime.onMessage.addListener((m, sender, reply) => {
    if (sender.id !== chrome.runtime.id) return;
    if (m?.type === 'IOFFICE_WEB_BRIDGE_PING') {
      const c = composer();
      const send = sendButton();
      reply({ ok: true, platform, version: core.VERSION, ready: !!c, composerFound: !!c, sendFound: !!send, busy: !!active, url: location.href });
      return;
    }
    if (m?.type === 'IOFFICE_WEB_AI_CANCEL') {
      if (active?.jobId === m.jobId) { active.controller.abort(); try { stopButton()?.click(); } catch (_) {} }
      reply({ ok: true }); return;
    }
    if (m?.type === 'IOFFICE_WEB_AI_AUTORUN' && m.provider === platform) {
      if (active) { reply(active.jobId === m.jobId ? { ok: true, started: true } : { ok: false, error: `${label} đang xử lý phiên khác.` }); return; }
      const controller = new AbortController(); active = { jobId: m.jobId, controller };
      reply({ ok: true, started: true }); void run(m, controller); return;
    }
  });

  // Sau SPA/full-navigation, background quyết định rõ: tiếp tục trước bước gửi,
  // hoặc chỉ quan sát kết quả nếu đã SEND_COMMITTED. Không bao giờ tự gửi lại.
  setTimeout(() => {
    message({ type: 'WEB_BRIDGE_READY', platform })
      .then(r => {
        if (active || !r?.ok) return;
        if (r.observeOnly) {
          const controller = new AbortController(); active = { jobId: r.jobId, controller };
          void observeOnly({ jobId: r.jobId, timeoutMs: r.timeoutMs }, controller);
          return;
        }
        if (r.autoRun) {
          const controller = new AbortController(); active = { jobId: r.jobId, controller };
          void run(r, controller);
        }
      })
      .catch(() => {});
  }, 140);
})();
