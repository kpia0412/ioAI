'use strict';
(() => {
  const $=id=>document.getElementById(id);
  const button=$('systemUpdateAction'),status=$('systemUpdateStatus'),extEl=$('systemExtStatus'),ruleEl=$('systemRuleStatus'),auto=$('systemAutoUpdate');
  if(!button||!status||!extEl||!ruleEl||!auto)return;
  let pendingExtension=null,pendingRule=null,busy=false;
  const runtime=m=>new Promise(resolve=>{try{chrome.runtime.sendMessage(m,r=>resolve(chrome.runtime.lastError?{ok:false,error:chrome.runtime.lastError.message}:(r||{ok:false,error:'Không có phản hồi'})));}catch(e){resolve({ok:false,error:e.message});}});
  const set=(el,text,kind='')=>{el.textContent=text;el.className=kind;};
  function buttonLabel(){if(pendingExtension||pendingRule){const n=(pendingExtension?1:0)+(pendingRule?1:0);return n>1?'Cập nhật tiện ích + Rule':pendingExtension?`Cập nhật tiện ích v${pendingExtension.version}`:`Cập nhật Rule ${pendingRule.version}`;}return 'Kiểm tra cập nhật';}
  async function loadState(){
    const local=await chrome.storage.local.get({internetAutoUpdate:true,internetUpdate:{},ruleAutoUpdate:true});
    auto.checked=local.internetAutoUpdate!==false&&local.ruleAutoUpdate!==false;
    const ext=local.internetUpdate||{},cur=chrome.runtime.getManifest().version;
    pendingExtension=ext.newer?ext:null;
    if(ext.error)set(extEl,`v${cur} · lỗi kiểm tra`,'err');else if(ext.newer)set(extEl,`v${cur} → v${ext.version}`,'ok');else set(extEl,`v${cur}`,'ok');
    const rr=await runtime({type:'RULE_UPDATE_STATUS'});
    if(rr?.ok){const r=rr.data||{};pendingRule=r.newer?r:null;if(r.phase==='error')set(ruleEl,`${r.currentVersion||'—'} · lỗi kiểm tra`,'err');else if(r.newer)set(ruleEl,`${r.currentVersion||'—'} → ${r.version}`,'ok');else set(ruleEl,`${r.currentVersion||'—'}`,'ok');}
    else{pendingRule=null;set(ruleEl,'Không đọc được trạng thái','err');}
    button.textContent=buttonLabel();
  }
  async function checkAll(){
    busy=true;button.disabled=true;status.textContent='Đang kiểm tra tiện ích và Rule Pack…';status.className='status';
    try{
      const [extRes,ruleRes]=await Promise.all([runtime({type:'INTERNET_UPDATE_CHECK'}),runtime({type:'RULE_UPDATE_CHECK'})]);
      const errors=[];if(!extRes?.ok)errors.push('Tiện ích: '+(extRes?.error||'không kiểm tra được'));if(!ruleRes?.ok)errors.push('Rule: '+(ruleRes?.error||'không kiểm tra được'));
      await loadState();
      if(errors.length){status.textContent='⚠ '+errors.join(' | ');status.className='status err';}
      else if(pendingExtension||pendingRule){const parts=[];if(pendingExtension)parts.push(`tiện ích v${pendingExtension.version}`);if(pendingRule)parts.push(`Rule ${pendingRule.version}`);status.textContent=`Có cập nhật: ${parts.join(' + ')}.`;status.className='status ok';}
      else{status.textContent='✓ Tiện ích và Rule Pack đang ở bản mới nhất.';status.className='status ok';}
    }finally{busy=false;button.disabled=false;button.textContent=buttonLabel();}
  }
  async function applyAll(){
    if(!pendingExtension&&!pendingRule)return checkAll();
    if(!confirm('Áp dụng các bản cập nhật đang có? Rule sẽ áp dụng ngay; tiện ích chỉ cập nhật khi tab iOffice ở trạng thái an toàn.'))return;
    busy=true;button.disabled=true;status.textContent='Đang cập nhật hệ thống…';status.className='status';
    try{
      if(pendingRule){const rr=await runtime({type:'RULE_UPDATE_APPLY'});if(!rr?.ok)throw new Error('Rule: '+(rr?.error||'cập nhật thất bại'));pendingRule=null;}
      if(pendingExtension){const er=await runtime({type:'INTERNET_UPDATE_APPLY',forceDirty:true});if(!er?.ok)throw new Error('Tiện ích: '+(er?.error||'cập nhật thất bại'));return;}
      status.textContent='✓ Đã cập nhật Rule Pack.';status.className='status ok';await loadState();
    }catch(e){status.textContent='✕ '+e.message;status.className='status err';}
    finally{busy=false;button.disabled=false;button.textContent=buttonLabel();}
  }
  button.addEventListener('click',()=>pendingExtension||pendingRule?applyAll():checkAll());
  auto.addEventListener('change',async()=>{await chrome.storage.local.set({internetAutoUpdate:auto.checked,ruleAutoUpdate:auto.checked});await runtime({type:'RULE_AUTO_SET',enabled:auto.checked});status.textContent=auto.checked?'✓ Đã bật tự động cập nhật tiện ích + Rule Pack.':'Đã tắt tự động cập nhật.';status.className='status ok';if(auto.checked)void runtime({type:'INTERNET_UPDATE_AUTO_NOW'});});
  chrome.storage.onChanged.addListener((changes,area)=>{if(area==='local'&&(changes.internetUpdate||changes.ruleInternetUpdate||changes.internetAutoUpdate||changes.ruleAutoUpdate))void loadState();});
  loadState().catch(e=>{status.textContent='✕ '+e.message;status.className='status err';});
})();
