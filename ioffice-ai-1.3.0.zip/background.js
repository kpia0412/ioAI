importScripts('providers.js', 'core.js', 'rule-pack.js', 'result-validator.js', 'rule-engine.js', 'golden-tests.js', 'tracker-client.js');

const CATALOG = globalThis.IOFFICE_PROVIDER_CATALOG;
const PROVIDER_IDS = Object.keys(CATALOG);
const GEMINI_OPENAI_PROVIDER = 'gemini-openai';
const GEMINI_OPENAI_BASE = 'https://generativelanguage.googleapis.com/v1beta/openai/';
const GEMINI_OPENAI_MODELS = ['gemini-3.5-flash-lite','gemini-3.1-flash-lite','gemini-3.8-flash'];
const DEFAULT_API_FALLBACK_CHAIN = [
  { id:'route-primary-35', enabled:true, model:'gemini-3.5-flash-lite', keyMode:'primary', apiKey:'' },
  { id:'route-primary-31', enabled:true, model:'gemini-3.1-flash-lite', keyMode:'primary', apiKey:'' },
  { id:'route-primary-38', enabled:true, model:'gemini-3.8-flash', keyMode:'primary', apiKey:'' }
];

function normalizeApiFallbackChain(raw) {
  const source = Array.isArray(raw) && raw.length ? raw : DEFAULT_API_FALLBACK_CHAIN;
  const out = [];
  for (const item of source.slice(0, 8)) {
    if (!item || typeof item !== 'object') continue;
    const model = GEMINI_OPENAI_MODELS.includes(String(item.model || '')) ? String(item.model) : GEMINI_OPENAI_MODELS[0];
    const keyMode = item.keyMode === 'custom' ? 'custom' : 'primary';
    out.push({
      id: String(item.id || `route-${out.length + 1}`),
      enabled: item.enabled !== false,
      model,
      keyMode,
      apiKey: keyMode === 'custom' ? String(item.apiKey || '') : ''
    });
  }
  return out.length ? out : DEFAULT_API_FALLBACK_CHAIN.map(x => ({...x}));
}

function materializeApiRoutes(settings) {
  const primary = settings?.providerConfigs?.[GEMINI_OPENAI_PROVIDER] || {};
  const chain = normalizeApiFallbackChain(settings?.apiFallbackChain);
  const seen = new Set();
  const routes = [];
  for (const route of chain) {
    if (!route.enabled) continue;
    const apiKey = route.keyMode === 'custom' ? String(route.apiKey || '').trim() : String(primary.apiKey || '').trim();
    if (!apiKey) continue;
    const fingerprint = `${route.model}|${apiKey}`;
    if (seen.has(fingerprint)) continue;
    seen.add(fingerprint);
    routes.push({
      ...route,
      providerId: GEMINI_OPENAI_PROVIDER,
      cfg: { ...primary, apiKey, model: route.model, baseUrl: GEMINI_OPENAI_BASE, authMode: 'bearer' },
      label: route.keyMode === 'custom' ? `API key dự phòng · ${route.model}` : `API key chính · ${route.model}`
    });
  }
  return routes;
}

function immediateFailover(error) {
  const text = String(error?.message || '').toLowerCase();
  return Boolean(error?.kind?.auth || error?.kind?.model || error?.httpStatus === 429 || /quota|resource exhausted|rate limit|too many requests|high demand|exhausted|limit reached/.test(text));
}

function defaultProviderConfigs() {
  const out = {};
  for (const [id, p] of Object.entries(CATALOG)) {
    out[id] = {
      apiKey: '',
      model: p.defaultModel || '',
      baseUrl: p.baseUrl || '',
      authMode: 'bearer',
      customHeaderName: '',
      customHeaderValue: '',
      deployment: '',
      apiVersion: '2025-04-01-preview'
    };
  }
  return out;
}

const DEFAULT_SETTINGS = {
  providerOrder: ['gemini-openai', 'none', 'none', 'none'],
  retriesPerProvider: 1,
  requestTimeoutMs: 45000,
  fallbackRules: false,
  providerConfigs: defaultProviderConfigs(),
  apiFallbackChain: DEFAULT_API_FALLBACK_CHAIN.map(x => ({...x})),
  webAiEnabled: true,
  analysisMode: 'api',
  fallbackAnalysisMode: 'none',
  iofficeAssistantEnabled: true,
  webGeminiTimeoutMs: 150000,
  webGeminiMaxTurns: 3,
  webGeminiForeground: false,
  webGeminiFirstForeground: false,
  webChatgptTimeoutMs: 150000,
  webChatgptMaxTurns: 3,
  webChatgptForeground: false,
  webChatgptFirstForeground: false,
  userRole: 'leader',
  readerMode: 'primary',
  readerConcurrency: 0, readerIncludeRelated: false, readerDeduplicateContent: true, readerScanEnabled: false, readerTimeoutMs: 5000, readerMaxFileSizeMb: 10, aiRequireCompleteFiles: false,
  qualityEscalationEnabled: true, qualityEscalationThreshold: 0.72,
  aiRulePack: null, aiRulePackVersion: '', aiRulePackSource: 'embedded', aiRulePackUpdatedAt: 0, ruleAutoUpdate: true,
  trackerApiUrl: '', trackerToken: '',
  instructionPrefixEnabled: false,
  instructionPrefixText: 'VP đề xuất:',
  aiCustomRulesIncoming: '',
  aiCustomRulesOutgoing: '',
  leaderDefaultWatcherIds: [],
  leaderDefaultWatcherTargets: [],
  leaderDefaultViewUnitIds: [],
  leaderWatchersLocked: false
};

const ROUTING_SCHEMA = {
  type: 'object',
  properties: {
    workflow: { type: 'string' },
    actionRequired: { type: 'boolean' },
    mainUnit: { type: 'string' },
    coordinationUnits: { type: 'array', items: { type: 'string' } },
    viewUnits: { type: 'array', items: { type: 'string' } },
    instruction: { type: 'string' },
    tasks: { type: 'array', items: { type:'object', properties:{ task:{type:'string'}, deadline:{type:'string'}, deadlineText:{type:'string'}, deadlineEvidence:{type:'string'}, deadlineSource:{type:'string'}, responsibleUnit:{type:'string'}, scope:{type:'string'}, trackRecommended:{type:'boolean'} }, required:['task','deadline','deadlineText','deadlineEvidence','deadlineSource','responsibleUnit'] } },
    taskScope: { type:'string' },
    trackRecommended: { type:'boolean' },
    trackingReason: { type:'string' },
    recipientNames: { type: 'array', items: { type: 'string' } },
    reviewSummary: { type: 'string' },
    reviewIssues: { type: 'array', items: { type:'object', properties:{ severity:{type:'string'}, category:{type:'string'}, detail:{type:'string'}, evidence:{type:'string'} }, required:['severity','category','detail','evidence'] } },
    reason: { type: 'string' },
    confidence: { type: 'number' },
    requiresReview: { type: 'boolean' },
    signals: { type: 'array', items: { type: 'string' } }
  },
  required: ['mainUnit','coordinationUnits','viewUnits','instruction','reason','confidence','requiresReview','signals']
};

let defaultRoutingRulesCache = null;

function deepMerge(base, extra) {
  if (!extra || typeof extra !== 'object' || Array.isArray(extra)) return base;
  const out = { ...base };
  for (const [k, v] of Object.entries(extra)) {
    if (v && typeof v === 'object' && !Array.isArray(v) && base?.[k] && typeof base[k] === 'object' && !Array.isArray(base[k])) {
      out[k] = deepMerge(base[k], v);
    } else {
      out[k] = v;
    }
  }
  return out;
}

async function migrateSettings() {
  const raw = await chrome.storage.local.get(null);
  const oldCache=Object.keys(raw).filter(k=>k.startsWith('ioffice_reader_cache_'));
  if(oldCache.length)await chrome.storage.local.remove(oldCache);
  const base = DEFAULT_SETTINGS;
  let configs = deepMerge(defaultProviderConfigs(), raw.providerConfigs || {});

  // Migrate v0.5 keys if present.
  if (raw.geminiApiKey) configs.gemini.apiKey = raw.geminiApiKey;
  if (raw.geminiModel) configs.gemini.model = raw.geminiModel;
  if (raw.openaiApiKey) configs.openai.apiKey = raw.openaiApiKey;
  if (raw.openaiModel) configs.openai.model = raw.openaiModel;
  if (raw.anthropicApiKey) configs.anthropic.apiKey = raw.anthropicApiKey;
  if (raw.anthropicModel) configs.anthropic.model = raw.anthropicModel;
  if (raw.gatewayUrl) configs.gateway.baseUrl = raw.gatewayUrl;

  // v0.65: gom cấu hình Gemini OpenAI-compatible về một provider cố định.
  const oldCustom = configs.custom || {};
  const oldGemini = configs.gemini || {};
  const isGoogleCompat = /generativelanguage\.googleapis\.com\/v1beta\/openai/i.test(String(oldCustom.baseUrl || ''));
  if (!configs['gemini-openai'].apiKey) configs['gemini-openai'].apiKey = (isGoogleCompat ? oldCustom.apiKey : '') || oldGemini.apiKey || '';
  if (!configs['gemini-openai'].model || configs['gemini-openai'].model === 'gemini-3.5-flash-lite') {
    const legacyModel = isGoogleCompat ? oldCustom.model : '';
    if (['gemini-3.5-flash-lite','gemini-3.1-flash-lite','gemini-3.8-flash'].includes(legacyModel)) configs['gemini-openai'].model = legacyModel;
  }
  configs['gemini-openai'].baseUrl = 'https://generativelanguage.googleapis.com/v1beta/openai/';

  let order = raw.providerOrder;
  if (!Array.isArray(order)) order = ['gemini-openai','none','none','none'];
  if (order[0] === 'custom' && isGoogleCompat) order[0] = 'gemini-openai';
  order = [...order, 'none', 'none', 'none', 'none'].slice(0, 4);
  const apiFallbackChain = normalizeApiFallbackChain(raw.apiFallbackChain);

  await chrome.storage.local.set({
    apiFallbackChain,
    providerOrder: order,
    retriesPerProvider: Number.isFinite(Number(raw.retriesPerProvider)) ? Number(raw.retriesPerProvider) : base.retriesPerProvider,
    requestTimeoutMs: Number.isFinite(Number(raw.requestTimeoutMs)) ? Number(raw.requestTimeoutMs) : base.requestTimeoutMs,
    fallbackRules: false,
    providerConfigs: configs,
    webAiEnabled: true,
    analysisMode: ['gemini-web','chatgpt-web','api'].includes(raw.analysisMode) ? raw.analysisMode : 'api',
    fallbackAnalysisMode: 'none',
    iofficeAssistantEnabled: raw.iofficeAssistantEnabled !== false,
    webGeminiTimeoutMs: 150000,
    webGeminiMaxTurns: 3,
    webGeminiForeground: raw.webGeminiForeground === true,
    webGeminiFirstForeground: false,
    webChatgptTimeoutMs: 150000,
    webChatgptMaxTurns: 3,
    webChatgptForeground: raw.webChatgptForeground === true,
    webChatgptFirstForeground: false,
    readerConcurrency: Number.isFinite(Number(raw.readerConcurrency)) ? Math.max(0, Math.min(64, Number(raw.readerConcurrency))) : 0,
    userRole: 'leader',
    readerMode: ['primary','all'].includes(raw.readerMode) ? raw.readerMode : 'primary',
    readerTimeoutMs: !Number.isFinite(Number(raw.readerTimeoutMs)) ? 5000 : Math.max(2000, Math.min(60000, Number(raw.readerTimeoutMs))),
    // Chỉ bật Văn bản liên quan khi người dùng chủ động chọn trong Cài đặt.
    readerIncludeRelated: raw.readerIncludeRelated === true,
    readerDeduplicateContent: raw.readerDeduplicateContent !== false,
    readerMaxFileSizeMb: Number.isFinite(Number(raw.readerMaxFileSizeMb)) ? Math.max(1, Math.min(50, Number(raw.readerMaxFileSizeMb))) : 10,
    readerScanEnabled: false,
    aiRequireCompleteFiles: false,
    qualityEscalationEnabled: raw.qualityEscalationEnabled !== false,
    qualityEscalationThreshold: Number.isFinite(Number(raw.qualityEscalationThreshold)) ? Math.max(0.55,Math.min(0.9,Number(raw.qualityEscalationThreshold))) : 0.72,
    trackerApiUrl: String(raw.trackerApiUrl || ''),
    trackerToken: String(raw.trackerToken || ''),
    instructionPrefixEnabled: raw.instructionPrefixEnabled === true,
    instructionPrefixText: typeof raw.instructionPrefixText === 'string' ? raw.instructionPrefixText : 'VP đề xuất:',
    aiCustomRulesIncoming: normalizeCustomAiRule(raw.aiCustomRulesIncoming),
    aiCustomRulesOutgoing: normalizeCustomAiRule(raw.aiCustomRulesOutgoing),
    aiRulePack: raw.aiRulePack && typeof raw.aiRulePack==='object' ? raw.aiRulePack : null,
    aiRulePackVersion: typeof raw.aiRulePackVersion==='string' ? raw.aiRulePackVersion : '',
    aiRulePackSource: typeof raw.aiRulePackSource==='string' ? raw.aiRulePackSource : 'embedded',
    aiRulePackUpdatedAt: Number(raw.aiRulePackUpdatedAt||0),
    ruleAutoUpdate: raw.ruleAutoUpdate !== false,
      leaderDefaultWatcherIds: Array.isArray(raw.leaderDefaultWatcherIds) ? raw.leaderDefaultWatcherIds.map(String) : [],
    leaderDefaultWatcherTargets: Array.isArray(raw.leaderDefaultWatcherTargets) ? raw.leaderDefaultWatcherTargets : [],
    leaderDefaultViewUnitIds: Array.isArray(raw.leaderDefaultViewUnitIds) ? raw.leaderDefaultViewUnitIds.map(String) : [],
    leaderWatchersLocked: raw.leaderWatchersLocked === true
  });
  await chrome.storage.local.remove(['geminiApiKey','openaiApiKey','anthropicApiKey','geminiModel','openaiModel','anthropicModel','gatewayUrl','iofficeGeminiReuseState','webHandoffTarget','webHandoffEnabled','webHandoffAutoSend','webHandoffOpenActive','webHandoffKeepTab','webGeminiAutoClose','webGeminiReuseTab','webGeminiWorkerWindow','trackerEnabled','trackerReminderDays']);
}

async function syncAssistantAction(enabled = null) {
  let isEnabled = enabled;
  if (isEnabled == null) {
    const raw = await chrome.storage.local.get({ iofficeAssistantEnabled: true });
    isEnabled = raw.iofficeAssistantEnabled !== false;
  }
  await Promise.allSettled([
    chrome.action.setBadgeText({ text: isEnabled ? 'ON' : 'OFF' }),
    chrome.action.setBadgeBackgroundColor({ color: isEnabled ? '#087d77' : '#64748b' }),
    chrome.action.setTitle({ title: isEnabled
      ? 'iOffice AI đang bật · bấm để tắt và tự tải lại iOffice'
      : 'iOffice AI đang tắt · bấm để bật và tự tải lại iOffice' })
  ]);
}

async function reloadIofficeTabs(preferredTab = null) {
  const matches = /^https:\/\/ioffice\.vnptdaklak\.vn\/qlvbdh_dlk\//i;
  const ids = new Set();
  if (preferredTab?.id != null && matches.test(String(preferredTab.url || ''))) ids.add(preferredTab.id);
  try {
    const tabs = await chrome.tabs.query({ url: 'https://ioffice.vnptdaklak.vn/qlvbdh_dlk/*' });
    for (const tab of tabs || []) if (tab?.id != null) ids.add(tab.id);
  } catch (_) {}
  await Promise.allSettled([...ids].map((id) => chrome.tabs.reload(id)));
}

chrome.runtime.onInstalled.addListener(() => {
  migrateSettings().then(() => syncAssistantAction()).catch(console.error);
});
chrome.runtime.onStartup.addListener(() => {
  cleanupJobs().catch(console.error);
  syncAssistantAction().catch(console.error);

});
chrome.action.onClicked.addListener(async (tab) => {
  try {
    const raw = await chrome.storage.local.get({ iofficeAssistantEnabled: true });
    const next = raw.iofficeAssistantEnabled === false;
    await chrome.storage.local.set({ iofficeAssistantEnabled: next });
    await syncAssistantAction(next);
    await reloadIofficeTabs(tab);
  } catch (error) {
    console.error('Không bật/tắt được iOffice AI:', error);
  }
});
chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName === 'local' && changes.iofficeAssistantEnabled) {
    syncAssistantAction(changes.iofficeAssistantEnabled.newValue !== false).catch(() => {});
  }
});

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const uniq = (items) => [...new Set((items || []).filter(Boolean))];
const safeNumber = (v, fallback) => Number.isFinite(Number(v)) ? Number(v) : fallback;
const trimSlash = (s) => String(s || '').replace(/\/+$/, '');

async function getSettings() {
  const raw = await chrome.storage.local.get(DEFAULT_SETTINGS);
  const providerConfigs = deepMerge(defaultProviderConfigs(), raw.providerConfigs || {});
  return {
    ...DEFAULT_SETTINGS,
    ...raw,
    providerConfigs,
    apiFallbackChain: normalizeApiFallbackChain(raw.apiFallbackChain)
  };
}

async function getDefaultRoutingRules() {
  if (defaultRoutingRulesCache) return defaultRoutingRulesCache;
  const response = await fetch(chrome.runtime.getURL('routing-rules.json'));
  if (!response.ok) throw new Error(`Không đọc được routing-rules.json (HTTP ${response.status})`);
  defaultRoutingRulesCache = await response.json();
  return defaultRoutingRulesCache;
}

async function getRoutingRules() {
  const defaults = await getDefaultRoutingRules();
  const raw = await chrome.storage.local.get({ routingRulesCustom: null, aiRulePack:null });
  const custom = raw.routingRulesCustom;
  const merged = (!custom || typeof custom !== 'object' || !Array.isArray(custom.rules))
    ? { ...defaults }
    : { ...defaults, ...custom, policy: { ...(defaults.policy || {}), ...(custom.policy || {}) }, legalBasis: Array.isArray(custom.legalBasis) ? custom.legalBasis : defaults.legalBasis };
  // Rule Pack là nguồn sự thật duy nhất của 9 đầu mối. routing-rules.json chỉ giữ metadata/rule kỹ thuật.
  const pack = globalThis.IOfficeRulePack.resolvePack(raw.aiRulePack);
  const meta = new Map((defaults.units||[]).map(u=>[u.id,u]));
  merged.units = (pack.units||[]).map(u=>({...(meta.get(u.id)||{}),id:u.id,name:u.name,summary:u.summary||'',keywords:u.keywords||[],functions:u.functions||[]}));
  return merged;
}

function normalizeCustomAiRule(value) { return String(value || '').replace(/\u0000/g,'').trim().slice(0,20000); }
function buildPrompt(payload, requestId='', settings=null) {
  const base = IOfficeCore.prompt(payload, requestId);
  const workflow = String(payload?.workflow || 'leader-incoming');
  // Văn bản đi giữ bộ kiểm tra cơ bản cố định trong core.js.
  if (workflow === 'leader-outgoing') return base;
  const pack = globalThis.IOfficeRulePack?.resolvePack(settings?.aiRulePack);
  const compiled = globalThis.IOfficeRulePack?.compilePrompt(pack, payload) || '';
  // Giữ tương thích với ghi chú tùy chỉnh cũ của người dùng; Rule Pack mới là nguồn chính.
  const legacy = normalizeCustomAiRule(settings?.aiCustomRulesIncoming);
  return `${base}${compiled}${legacy ? `\n\nGHI CHÚ TÙY CHỈNH CŨ (được giữ để không mất cấu hình):\n${legacy}` : ''}`;
}

function extractJson(text) {
  let value = String(text || '').trim().replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/i, '').trim();
  try { return JSON.parse(value); } catch (_) {}
  const start = value.indexOf('{'), end = value.lastIndexOf('}');
  if (start >= 0 && end > start) {
    try { return JSON.parse(value.slice(start, end + 1)); } catch (_) {}
  }
  throw new Error('AI không trả JSON hợp lệ.');
}

function validateAndClean(result, payload, meta) {
  const allowed=(payload.availableUnits||[]).map(u=>u.id).filter(Boolean);
  const cleaned=globalThis.IOfficeResultValidator.validate(result,{
    workflow:String(payload.workflow||result?.workflow||'leader-incoming'),
    allowedUnitIds:allowed,
    context:payload.context||{}
  });
  return {
    ...cleaned,
    provider: meta.provider,
    providerLabel: meta.providerLabel,
    model: meta.model,
    primaryProvider: meta.primaryProvider,
    fallbackUsed: meta.fallbackUsed === true || meta.provider !== meta.primaryProvider,
    apiRouteIndex: meta.apiRouteIndex || 0,
    apiRouteCount: meta.apiRouteCount || 0,
    apiRouteKeyMode: meta.apiRouteKeyMode || '',
    triedApiRoutes: Array.isArray(meta.triedApiRoutes) ? meta.triedApiRoutes : [],
    attemptCount: meta.attemptCount,
    triedProviders: meta.triedProviders,
    promptChars: meta.promptChars,
    usageMetadata: meta.usageMetadata || null,
    qualityEscalated: meta.qualityEscalated === true,
    qualityEscalationFromModel: meta.qualityEscalationFromModel || '',
    source: `ai-${meta.provider}`
  };
}

function classifyError(status, message = '') {
  const text = String(message || '').toLowerCase();
  return {
    retryable: [408,409,425,429,500,502,503,504].includes(status) || /high demand|temporar|unavailable|resource exhausted|rate limit|overload|timeout|deadline|try again/.test(text),
    auth: [401,403].includes(status) || /api key|invalid key|permission denied|unauth|forbidden|credential/.test(text),
    model: status === 404 || /model.*not found|unknown model|does not exist|not supported/.test(text)
  };
}

async function fetchJson(url, init, timeoutMs, parentSignal) {
  const u=new URL(url);
  if(!await chrome.permissions.contains({origins:[u.protocol+'//'+u.hostname+'/*']}))throw new Error('Mở Cấu hình, cấp quyền cho máy chủ API rồi thử lại.');
  const controller = new AbortController();
  const abort=()=>controller.abort();
  if(parentSignal?.aborted)throw new Error('Đã dừng phân tích.');
  parentSignal?.addEventListener('abort',abort,{once:true});
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(url, { ...init, signal: controller.signal });
    const text = await response.text();
    let data = {};
    try { data = text ? JSON.parse(text) : {}; } catch (_) { data = { raw: text }; }
    if (!response.ok) {
      const message = data?.error?.message || data?.message || data?.detail || data?.raw || `HTTP ${response.status}`;
      const error = new Error(String(message).slice(0, 1200));
      error.httpStatus = response.status;
      error.kind = classifyError(response.status, message);
      throw error;
    }
    return data;
  } catch (error) {
    if(parentSignal?.aborted)throw new Error('Đã dừng phân tích.');
    if (error?.name === 'AbortError') {
      const timeout = new Error(`Timeout sau ${Math.round(timeoutMs / 1000)} giây.`);
      timeout.kind = { retryable: true, auth: false, model: false };
      throw timeout;
    }
    if (!error.kind) error.kind = { retryable: true, auth: false, model: false };
    throw error;
  } finally { clearTimeout(timer); parentSignal?.removeEventListener('abort',abort); }
}

function authHeaders(providerId, cfg) {
  const headers = { 'Content-Type': 'application/json' };
  if (providerId === 'anthropic') return headers;
  if (cfg.customHeaderName && cfg.customHeaderValue) headers[cfg.customHeaderName] = cfg.customHeaderValue;
  if (cfg.authMode === 'none' || !cfg.apiKey) return headers;
  if (cfg.authMode === 'x-api-key') headers['x-api-key'] = cfg.apiKey;
  else headers.Authorization = `Bearer ${cfg.apiKey}`;
  return headers;
}

async function callGemini(prompt, cfg, timeout, payload = null) {
  if (!cfg.apiKey) throw new Error('Chưa cấu hình API key Gemini.');
  if (!cfg.model) throw new Error('Chưa chọn model Gemini.');
  const scans = extractScanAttachments(payload || {});
  const parts = [{ text: prompt }];
  for (const file of scans) parts.push({ inlineData: { mimeType: file.mimeType || 'application/pdf', data: file.base64 } });
  const url = `${trimSlash(cfg.baseUrl || CATALOG.gemini.baseUrl)}/models/${encodeURIComponent(cfg.model)}:generateContent`;
  const headers = { 'Content-Type': 'application/json', 'x-goog-api-key': cfg.apiKey };
  const request = async (generationConfig) => fetchJson(url, {
    method: 'POST', headers,
    body: JSON.stringify({ contents: [{ role: 'user', parts }], generationConfig })
  }, timeout, cfg._signal);

  let data;
  try {
    // API 2026: responseFormat/text dùng enum APPLICATION_JSON.
    data = await request({ responseFormat: { text: { mimeType: 'APPLICATION_JSON', schema: ROUTING_SCHEMA } } });
  } catch (error) {
    // Tương thích endpoint/model cũ chỉ hiểu responseMimeType + responseSchema.
    const msg = String(error?.message || '');
    if (error?.httpStatus !== 400 || !/response.?format|mime.?type|schema|unknown field|invalid json payload/i.test(msg)) throw error;
    data = await request({ responseMimeType: 'application/json', responseSchema: ROUTING_SCHEMA });
  }
  const text = data?.candidates?.[0]?.content?.parts?.map((p) => p.text || '').join('') || '';
  if (!text) throw new Error('Gemini không trả nội dung.');
  return { parsed: extractJson(text), model: cfg.model, usageMetadata: data?.usageMetadata || null };
}

async function callAnthropic(prompt, cfg, timeout) {
  if (!cfg.apiKey) throw new Error('Chưa cấu hình API key Anthropic.');
  if (!cfg.model) throw new Error('Chưa chọn model Anthropic.');
  const data = await fetchJson(`${trimSlash(cfg.baseUrl || CATALOG.anthropic.baseUrl)}/messages`, {
    method: 'POST', headers: { 'Content-Type': 'application/json', 'x-api-key': cfg.apiKey, 'anthropic-version': '2023-06-01' },
    body: JSON.stringify({ model: cfg.model, max_tokens: 1600, messages: [{ role: 'user', content: prompt }] })
  }, timeout, cfg._signal);
  const text = (data?.content || []).filter((x) => x?.type === 'text').map((x) => x.text || '').join('');
  if (!text) throw new Error('Anthropic không trả nội dung text.');
  return { parsed: extractJson(text), model: cfg.model, usageMetadata: data?.usage || null };
}

async function callOpenAIResponses(prompt, cfg, timeout) {
  if (!cfg.apiKey) throw new Error('Chưa cấu hình API key.');
  if (!cfg.model) throw new Error('Chưa chọn model.');
  const data = await fetchJson(`${trimSlash(cfg.baseUrl)}/responses`, {
    method: 'POST', headers: authHeaders('openai', cfg), body: JSON.stringify({ model: cfg.model, input: prompt })
  }, timeout, cfg._signal);
  let text = data?.output_text || '';
  if (!text && Array.isArray(data?.output)) text = data.output.flatMap((i) => i?.content || []).map((p) => p?.text || '').join('');
  if (!text) throw new Error('API không trả nội dung text.');
  return { parsed: extractJson(text), model: cfg.model, usageMetadata: data?.usage || null };
}

async function callOpenAIChat(providerId, prompt, cfg, timeout) {
  if (CATALOG[providerId]?.needsKey && !cfg.apiKey) throw new Error('Chưa cấu hình API key.');
  if (!cfg.model) throw new Error('Chưa chọn model.');
  if (!cfg.baseUrl) throw new Error('Chưa cấu hình Base URL.');
  const data = await fetchJson(`${trimSlash(cfg.baseUrl)}/chat/completions`, {
    method: 'POST', headers: authHeaders(providerId, cfg),
    body: JSON.stringify({ model: cfg.model, messages: [{ role: 'user', content: prompt }] })
  }, timeout, cfg._signal);
  const text = data?.choices?.[0]?.message?.content || data?.choices?.[0]?.text || '';
  if (!text) throw new Error('API không trả nội dung text.');
  return { parsed: extractJson(text), model: cfg.model, usageMetadata: data?.usage || null };
}

async function callOllama(prompt, cfg, timeout) {
  if (!cfg.model) throw new Error('Chưa chọn model Ollama.');
  const base = trimSlash(cfg.baseUrl || CATALOG.ollama.baseUrl);
  const data = await fetchJson(`${base}/api/chat`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ model: cfg.model, stream: false, messages: [{ role: 'user', content: prompt }] })
  }, timeout, cfg._signal);
  const text = data?.message?.content || data?.response || '';
  if (!text) throw new Error('Ollama không trả nội dung.');
  return { parsed: extractJson(text), model: cfg.model, usageMetadata: null };
}

async function callAzure(prompt, cfg, timeout) {
  if (!cfg.apiKey) throw new Error('Chưa cấu hình Azure API key.');
  if (!cfg.baseUrl || !cfg.deployment) throw new Error('Azure cần Endpoint và Deployment.');
  const apiVersion = encodeURIComponent(cfg.apiVersion || '2025-04-01-preview');
  const url = `${trimSlash(cfg.baseUrl)}/openai/deployments/${encodeURIComponent(cfg.deployment)}/chat/completions?api-version=${apiVersion}`;
  const data = await fetchJson(url, {
    method: 'POST', headers: { 'Content-Type': 'application/json', 'api-key': cfg.apiKey },
    body: JSON.stringify({ messages: [{ role: 'user', content: prompt }] })
  }, timeout, cfg._signal);
  const text = data?.choices?.[0]?.message?.content || '';
  if (!text) throw new Error('Azure OpenAI không trả nội dung.');
  return { parsed: extractJson(text), model: cfg.deployment, usageMetadata: data?.usage || null };
}

async function callGateway(payload, cfg, timeout) {
  if (!cfg.baseUrl) throw new Error('Chưa cấu hình Local/Internal Gateway.');
  const data = await fetchJson(cfg.baseUrl, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) }, Math.max(timeout, 90000), cfg._signal);
  return { parsed: data, model: data?.model || 'gateway', usageMetadata: data?.usageMetadata || null, alreadyValidated: true };
}

async function callProvider(providerId, prompt, payload, cfg, timeout) {
  const type = CATALOG[providerId]?.type;
  if (type === 'gemini') return callGemini(prompt, cfg, timeout, payload);
  if (type === 'anthropic') return callAnthropic(prompt, cfg, timeout);
  if (type === 'openai-responses') return callOpenAIResponses(prompt, cfg, timeout);
  if (type === 'openai-chat') return callOpenAIChat(providerId, prompt, cfg, timeout);
  if (type === 'ollama') return callOllama(prompt, cfg, timeout);
  if (type === 'azure-openai') return callAzure(prompt, cfg, timeout);
  if (type === 'gateway') return callGateway(payload, cfg, timeout);
  throw new Error(`Chưa hỗ trợ provider ${providerId}`);
}

function providerConfigured(id, cfg) {
  const p = CATALOG[id];
  if (!p) return false;
  if (p.type === 'gateway') return Boolean(cfg.baseUrl);
  if (p.type === 'azure-openai') return Boolean(cfg.apiKey && cfg.baseUrl && cfg.deployment);
  if (p.type === 'ollama' || id === 'lmstudio') return Boolean(cfg.baseUrl && cfg.model);
  if (id === 'custom') return Boolean(cfg.baseUrl && cfg.model && (!p.needsKey || cfg.apiKey || cfg.authMode === 'none'));
  return Boolean(cfg.model && (!p.needsKey || cfg.apiKey));
}

function backoffMs(i) { return [900, 2200, 4500][Math.min(i, 2)]; }

function shouldEscalateQuality(result,payload,settings,currentModel='') {
  if(settings?.qualityEscalationEnabled===false) return false;
  if(String(payload?.workflow||'')!=='leader-incoming') return false;
  if(String(currentModel||'')==='gemini-3.8-flash') return false;
  const b=payload?.context?.documentBundle||{};
  // Model mạnh không thể bù cho dữ liệu nguồn chưa đọc; tránh tăng thời gian vô ích.
  if(b.appendixRequiredMissing===true || b.requiresReviewForUnreadable===true || b.aiReady===false) return false;
  const threshold=Math.max(.55,Math.min(.9,Number(settings?.qualityEscalationThreshold)||.72));
  return result?.taskScope==='ambiguous' || Number(result?.confidence||0)<threshold ||
    (result?.actionRequired===true && !result?.mainUnit) || result?.deadlineEvidenceRejected===true;
}
function qualityScore(r){
  let s=Number(r?.confidence||0)*100;
  if(r?.taskScope==='ambiguous')s-=22;
  if(r?.actionRequired===true&&!r?.mainUnit)s-=18;
  if(r?.deadlineEvidenceRejected)s-=12;
  if(r?.requiresReview)s-=4;
  return s;
}
function mergeUsage(a,b){
  const keys=['prompt_tokens','completion_tokens','total_tokens','input_tokens','output_tokens','totalTokenCount','promptTokenCount','candidatesTokenCount'];
  const out={};
  for(const k of keys){const n1=Number(a?.[k]),n2=Number(b?.[k]);if(Number.isFinite(n1)||Number.isFinite(n2))out[k]=(Number.isFinite(n1)?n1:0)+(Number.isFinite(n2)?n2:0);}
  return Object.keys(out).length?out:(b||a||null);
}

const apiRequests=new Map();
async function analyze(payload, signal) {
  const settings = await getSettings();
  const timeout = Math.max(10000, Math.min(120000, safeNumber(settings.requestTimeoutMs, 45000)));
  const prompt = buildPrompt(payload, '', settings);
  const errors = [];
  let attemptCount = 0;

  // v0.66: API-first dùng chuỗi tuyến theo thứ tự. Mỗi tuyến có thể dùng model khác
  // hoặc API key riêng. Không log/hiển thị API key.
  const apiRoutes = materializeApiRoutes(settings);
  if (apiRoutes.length) {
    const triedRoutes = [];
    const blockedAuthKeys = new Set();
    for (let index = 0; index < apiRoutes.length; index++) {
      if (signal?.aborted) throw new Error('Đã dừng phân tích.');
      const route = apiRoutes[index];
      const cfg = { ...route.cfg, _signal: signal };
      if (blockedAuthKeys.has(cfg.apiKey)) { errors.push(`Tuyến ${index + 1} · ${route.model}: bỏ qua vì API key này đã bị từ chối ở tuyến trước`); continue; }
      if (extractScanAttachments(payload).length && !['gemini','gateway'].includes(CATALOG[route.providerId]?.type)) {
        errors.push(`${route.label}: không hỗ trợ PDF scan trong phiên bản này`);
        continue;
      }
      triedRoutes.push(`${index + 1}:${route.model}${route.keyMode === 'custom' ? ':key-rieng' : ':key-chinh'}`);
      const maxAttempts = 2; // 1 lần + tối đa 1 retry cho timeout/5xx; quota/key/model chuyển ngay.
      for (let attempt = 1; attempt <= maxAttempts; attempt++) {
        if (signal?.aborted) throw new Error('Đã dừng phân tích.');
        attemptCount++;
        try {
          const response = await callProvider(route.providerId, prompt, payload, cfg, timeout);
          let cleaned = validateAndClean(response.parsed, payload, {
            provider: route.providerId, providerLabel: 'Google Gemini', model: response.model || route.model,
            primaryProvider: GEMINI_OPENAI_PROVIDER, fallbackUsed: index > 0, apiRouteIndex: index + 1,
            apiRouteCount: apiRoutes.length, apiRouteKeyMode: route.keyMode, attemptCount,
            triedProviders: [GEMINI_OPENAI_PROVIDER], triedApiRoutes: [...triedRoutes], promptChars: prompt.length,
            usageMetadata: response.usageMetadata
          });
          if(shouldEscalateQuality(cleaned,payload,settings,route.model)) {
            const strong=apiRoutes.find((r,j)=>j!==index&&r.enabled!==false&&r.model==='gemini-3.8-flash'&&!blockedAuthKeys.has(r.cfg.apiKey));
            if(strong){
              try{
                attemptCount++;
                const qPrompt = `${prompt}

QUALITY ESCALATION: Kết quả vòng đầu chưa đủ chắc chắn. Hãy phân tích lại độc lập, đặc biệt kiểm tra chủ thể, taskScope, XLC và bằng chứng deadline. Không suy đoán dữ liệu chưa đọc. Kết quả vòng đầu để đối chiếu: ${JSON.stringify({taskScope:cleaned.taskScope,actionRequired:cleaned.actionRequired,mainUnit:cleaned.mainUnit,confidence:cleaned.confidence,validationWarnings:cleaned.validationWarnings||[]})}`;
                const qResp=await callProvider(strong.providerId,qPrompt,payload,{...strong.cfg,_signal:signal},timeout);
                const upgraded=validateAndClean(qResp.parsed,payload,{
                  provider:strong.providerId,providerLabel:'Google Gemini',model:qResp.model||strong.model,
                  primaryProvider:GEMINI_OPENAI_PROVIDER,fallbackUsed:true,apiRouteIndex:apiRoutes.indexOf(strong)+1,
                  apiRouteCount:apiRoutes.length,apiRouteKeyMode:strong.keyMode,attemptCount,
                  triedProviders:[GEMINI_OPENAI_PROVIDER],triedApiRoutes:[...triedRoutes,`Q:${strong.model}`],
                  promptChars:prompt.length+qPrompt.length,usageMetadata:mergeUsage(response.usageMetadata,qResp.usageMetadata),
                  qualityEscalated:true,qualityEscalationFromModel:route.model
                });
                if(qualityScore(upgraded)>=qualityScore(cleaned)-2) cleaned=upgraded;
              }catch(qe){ errors.push(`Quality Escalation · ${strong.model}: ${qe.message}`); }
            }
          }
          return cleaned;
        } catch (error) {
          if (signal?.aborted) throw new Error('Đã dừng phân tích.');
          errors.push(`Tuyến ${index + 1} · ${route.model}: ${error.message}`);
          if (error?.kind?.auth) blockedAuthKeys.add(cfg.apiKey);
          if (immediateFailover(error)) break;
          const retryable = error?.kind?.retryable !== false;
          if (retryable && attempt < maxAttempts) { await sleep(backoffMs(attempt - 1)); continue; }
          break;
        }
      }
    }
    throw new Error(`Toàn bộ chuỗi API đã thất bại. ${errors.slice(-10).join(' | ')}`);
  }

  // Tương thích cấu hình cũ nếu chưa có chuỗi API hợp lệ.
  const retries = Math.max(0, Math.min(2, safeNumber(settings.retriesPerProvider, 1)));
  const requestedProvider = CATALOG[payload?.analysisProviderId] ? payload.analysisProviderId : '';
  const baseOrder = uniq(settings.providerOrder || []).filter((id) => id && id !== 'none' && CATALOG[id]);
  const order = requestedProvider ? [requestedProvider, ...baseOrder.filter(id => id !== requestedProvider)] : baseOrder;
  if (!order.length) throw new Error('Chưa cấu hình API trong Cấu hình.');
  const triedProviders = [];
  for (const providerId of order) {
    if(signal?.aborted)throw new Error('Đã dừng phân tích.');
    const cfg = {...(settings.providerConfigs?.[providerId] || {}), _signal:signal};
    if (providerId === requestedProvider && payload?.analysisModel) cfg.model = String(payload.analysisModel).trim();
    if(extractScanAttachments(payload).length && !['gemini','gateway'].includes(CATALOG[providerId]?.type)){errors.push(CATALOG[providerId].label+': không hỗ trợ PDF scan trong phiên bản này');continue;}
    if (!providerConfigured(providerId, cfg)) { errors.push(`${CATALOG[providerId].label}: chưa cấu hình đủ key/model/endpoint`); continue; }
    triedProviders.push(providerId);
    for (let attempt = 1; attempt <= retries + 1; attempt++) {
      if(signal?.aborted)throw new Error('Đã dừng phân tích.');
      attemptCount++;
      try {
        const response = await callProvider(providerId, prompt, payload, cfg, timeout);
        return validateAndClean(response.parsed, payload, { provider: providerId, providerLabel: CATALOG[providerId].label, model: response.model, primaryProvider: order[0], attemptCount, triedProviders: [...triedProviders], promptChars: prompt.length, usageMetadata: response.usageMetadata });
      } catch (error) {
        if(signal?.aborted)throw new Error('Đã dừng phân tích.');
        errors.push(`${CATALOG[providerId].label}: ${error.message}`);
        const retryable = error?.kind?.retryable !== false && !error?.kind?.auth && !error?.kind?.model;
        if (retryable && attempt <= retries) { await sleep(backoffMs(attempt - 1)); continue; }
        break;
      }
    }
  }
  throw new Error(`Các AI đã cấu hình đều thất bại. ${errors.slice(-8).join(' | ')}`);
}


function tabMessage(tabId, message) {
  return new Promise((resolve, reject) => {
    chrome.tabs.sendMessage(tabId, message, (response) => {
      if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
      else resolve(response);
    });
  });
}

async function waitForWebBridge(tabId, timeoutMs = 45000, signal) {
  const started = Date.now();
  let lastError = null;
  while (Date.now() - started < timeoutMs) {
    if(signal?.aborted)throw new Error('Đã dừng phân tích.');
    try {
      const response = await tabMessage(tabId, { type: 'IOFFICE_WEB_BRIDGE_PING' });
      if (response?.ok && response.version === IOfficeCore.VERSION && response.ready) return response;
      if (response?.ok && response.version === IOfficeCore.VERSION && !response.ready) lastError = new Error('Web AI đã mở nhưng chưa thấy ô nhập; kiểm tra đăng nhập/giao diện.');
    } catch (error) { lastError = error; }
    await sleep(180);
  }
  throw new Error(`Không kết nối được Web Bridge${lastError ? `: ${lastError.message}` : ''}`);
}

const WEB_JOB_PREFIX='iofficeWebAiJob:';
const WEB_TAB_PREFIX='iofficeWebAiTab:';
const WEB_FP_PREFIX='iofficeWebAiFp:';
const webLocks=new Map(), warmFlights=new Map(), startFlights=new Set();
const WEB_AI={
  gemini:{label:'Gemini',url:'https://gemini.google.com/app',origin:'https://gemini.google.com/',match:'https://gemini.google.com/*',timeoutKey:'webGeminiTimeoutMs',maxTurnsKey:'webGeminiMaxTurns',foregroundKey:'webGeminiForeground',firstForegroundKey:'webGeminiFirstForeground'},
  chatgpt:{label:'ChatGPT',url:'https://chatgpt.com/',origin:'https://chatgpt.com/',match:'https://chatgpt.com/*',timeoutKey:'webChatgptTimeoutMs',maxTurnsKey:'webChatgptMaxTurns',foregroundKey:'webChatgptForeground',firstForegroundKey:'webChatgptFirstForeground'}
};
const webJobKey=id=>WEB_JOB_PREFIX+id, webTabKey=id=>WEB_TAB_PREFIX+id, webFpKey=(provider,fp)=>`${WEB_FP_PREFIX}${provider}:${fp}`;
const terminal=job=>!job || ['done','error','cancelled'].includes(job.status);
const createWebJobId=provider=>`${provider==='chatgpt'?'cweb':'gweb'}_${crypto.randomUUID()}`;
async function serial(key,fn){const before=webLocks.get(key)||Promise.resolve();const p=before.catch(()=>{}).then(fn);webLocks.set(key,p);try{return await p;}finally{if(webLocks.get(key)===p)webLocks.delete(key);}}
function extractScanAttachments(payload){return(payload?.context?.documentBundle?.scanAttachments||[]).filter(x=>x.base64&&x.name).slice(0,3);}
function stripScanAttachmentData(payload){const b=payload.context?.documentBundle;return b?{...payload,context:{...payload.context,documentBundle:{...b,scanAttachments:(b.scanAttachments||[]).map(({base64,...meta})=>meta)}}}:payload;}
function fastHash(value){let h=2166136261;const s=String(value||'');for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619);}return (h>>>0).toString(36);}
function webPayloadFingerprint(provider,payload){const safe=stripScanAttachmentData(payload||{});return fastHash(provider+'|'+JSON.stringify(safe));}
function providerCfg(provider){const cfg=WEB_AI[provider];if(!cfg)throw new Error('Web AI không hợp lệ.');return cfg;}
async function readWebJob(id){return(await chrome.storage.session.get(webJobKey(id)))[webJobKey(id)]||null;}
async function updateWebJob(id,patch){return serial('job:'+id,async()=>{const j=await readWebJob(id);if(terminal(j))return j;Object.assign(j,patch);await chrome.storage.session.set({[webJobKey(id)]:j});return j;});}
async function getJobForTab(id){const map=await chrome.storage.session.get(webTabKey(id));return map[webTabKey(id)]?readWebJob(map[webTabKey(id)]):null;}
async function releaseTab(job){if(!job?.tabId)return;await serial('tab:'+job.tabId,async()=>{const map=await chrome.storage.session.get(webTabKey(job.tabId));if(map[webTabKey(job.tabId)]===job.jobId)await chrome.storage.session.remove(webTabKey(job.tabId));});}
async function readOwnedTab(provider){return(await chrome.storage.session.get(`webAiOwnedTab:${provider}`))[`webAiOwnedTab:${provider}`]||null;}
async function rememberWebTab(provider,tab,patch={}){const cfg=providerCfg(provider);if(!tab?.id||!String(tab.url||'').startsWith(cfg.origin))return;const prev=await readOwnedTab(provider),same=Number(prev?.tabId)===Number(tab.id);await chrome.storage.session.set({[`webAiOwnedTab:${provider}`]:{provider,tabId:tab.id,turns:same?Math.max(0,Number(prev?.turns)||0):0,reset:same?!!prev?.reset:false,url:tab.url,lastUsedAt:Date.now(),...patch}});}
async function findReusableWebTab(provider,sourceTabId){const cfg=providerCfg(provider),saved=await readOwnedTab(provider);if(saved?.tabId){try{const tab=await chrome.tabs.get(saved.tabId);if(String(tab.url||'').startsWith(cfg.origin))return tab;}catch(_){}}
  const tabs=await chrome.tabs.query({url:[cfg.match]});if(!tabs.length)return null;let source=null;try{source=sourceTabId?await chrome.tabs.get(sourceTabId):null;}catch(_){}const sameWindow=source?tabs.filter(t=>t.windowId===source.windowId):[];const pool=sameWindow.length?sameWindow:tabs;const tab=[...pool].sort((a,b)=>Number(b.lastAccessed||0)-Number(a.lastAccessed||0))[0];await rememberWebTab(provider,tab);return tab;}
async function putWebTabNextToSource(tab,sourceTabId){if(!tab?.id||!sourceTabId)return tab;let source=null;try{source=await chrome.tabs.get(sourceTabId);}catch(_){return tab;}try{const desired=Math.max(0,Number(source.index||0)+1);if(tab.windowId!==source.windowId||tab.index!==desired)tab=await chrome.tabs.move(tab.id,{windowId:source.windowId,index:desired});}catch(_){}try{await chrome.tabs.update(tab.id,{autoDiscardable:false});}catch(_){}try{return await chrome.tabs.get(tab.id);}catch(_){return tab;}}
async function pushWebJobEvent(job,kind,extra={}){if(!job?.sourceTabId)return;try{await tabMessage(job.sourceTabId,{type:'IOFFICE_WEB_AI_JOB_EVENT',provider:job.provider,jobId:job.jobId,kind,status:job.status,phase:job.phase||'',phaseMessage:job.phaseMessage||'',elapsedMs:Date.now()-job.createdAt,...extra});}catch(_){}}
async function ensureWarmWebTab(provider,sourceTabId,{foregroundLoad=false}={}){const cfg=providerCfg(provider);if(warmFlights.has(provider))return warmFlights.get(provider);const flight=(async()=>{if((await getSettings()).webAiEnabled===false)throw new Error('Web AI đang tắt trong Cấu hình.');let tab=await findReusableWebTab(provider,sourceTabId),reused=!!tab;if(tab)tab=await putWebTabNextToSource(tab,sourceTabId);if(!tab){let source;try{source=sourceTabId?await chrome.tabs.get(sourceTabId):null;}catch(_){}tab=await chrome.tabs.create({url:cfg.url,active:foregroundLoad===true,...(source?{windowId:source.windowId,index:Math.max(0,source.index+1)}:{})});reused=false;await rememberWebTab(provider,tab,{turns:0,reset:false});}
    try{await chrome.tabs.update(tab.id,{autoDiscardable:false});}catch(_){}if(foregroundLoad){try{await chrome.tabs.update(tab.id,{active:true});}catch(_){}}if(tab.discarded){try{await chrome.tabs.reload(tab.id);}catch(_){}}
    let ping;try{ping=await tabMessage(tab.id,{type:'IOFFICE_WEB_BRIDGE_PING'});}catch(_){}if(!ping?.ok||ping.version!==IOfficeCore.VERSION||ping.platform!==provider){if(reused){try{await chrome.tabs.reload(tab.id);}catch(_){}}await waitForWebBridge(tab.id,reused?16000:32000);}
    try{tab=await chrome.tabs.get(tab.id);}catch(_){}await rememberWebTab(provider,tab);return{tab,reused};})();warmFlights.set(provider,flight);try{return await flight;}finally{warmFlights.delete(provider);}}
async function rotateWebConversation(provider,tab){
  const cfg=providerCfg(provider);
  if(!tab?.id)return tab;
  // Gemini đổi giao diện nút "Cuộc trò chuyện mới" khá thường xuyên.
  // Sau đủ số lượt, điều hướng thẳng về /app để tạo phiên chat sạch thay vì phụ thuộc selector nút.
  if(provider!=='gemini')return tab;
  try{
    let before=null;try{before=await chrome.tabs.get(tab.id);}catch(_){}
    const currentUrl=String(before?.url||'').replace(/\/$/,'');
    const targetUrl=String(cfg.url||'').replace(/\/$/,'');
    if(currentUrl===targetUrl){
      await chrome.tabs.reload(tab.id);
      try{await chrome.tabs.update(tab.id,{autoDiscardable:false});}catch(_){}
    }else{
      await chrome.tabs.update(tab.id,{url:cfg.url,autoDiscardable:false});
    }
    const started=Date.now();
    while(Date.now()-started<32000){
      try{
        const current=await chrome.tabs.get(tab.id);
        const url=String(current?.url||'');
        if(url.startsWith(cfg.origin)&&current.status==='complete')break;
      }catch(_){}
      await sleep(180);
    }
    await waitForWebBridge(tab.id,32000);
    try{tab=await chrome.tabs.get(tab.id);}catch(_){}
    await rememberWebTab(provider,tab,{turns:0,reset:false,lastRotatedAt:Date.now()});
    return tab;
  }catch(error){
    throw new Error(`Không tạo được cuộc trò chuyện Gemini mới sau giới hạn lượt: ${error?.message||error}`);
  }
}
async function prewarmWebForSession(provider,sourceTabId){const cfg=providerCfg(provider),settings=await getSettings(),key=`webAiFirstForegroundDone:${provider}`;let first=false;try{first=(await chrome.storage.session.get({[key]:false}))[key]!==true;}catch(_){first=true;}const foregroundLoad=settings[cfg.firstForegroundKey]===true&&first;const result=await ensureWarmWebTab(provider,sourceTabId,{foregroundLoad});if(foregroundLoad){try{await chrome.storage.session.set({[key]:true});}catch(_){}if(settings[cfg.foregroundKey]!==true&&sourceTabId){try{await chrome.tabs.update(sourceTabId,{active:true});}catch(_){}}}return{...result,firstForeground:foregroundLoad};}
async function cleanupWebJobs(){const all=await chrome.storage.session.get(null),remove=[];for(const[key,j]of Object.entries(all)){if(key.startsWith('cancel:')&&Date.now()-Number(j)>600000)remove.push(key);if(key.startsWith(WEB_FP_PREFIX)&&Number(j?.expiresAt||0)<Date.now())remove.push(key);if(!key.startsWith(WEB_JOB_PREFIX))continue;if(terminal(j)&&Date.now()-(j.completedAt||j.createdAt)>600000)remove.push(key);else if(!terminal(j)&&Date.now()>j.deadline)await cancelWebJob(j.jobId,`${providerCfg(j.provider).label} đã quá thời gian chờ.`);}if(remove.length)await chrome.storage.session.remove(remove);}
async function startWebAutomation(provider,payload,sourceTabId,requestId){const cfg=providerCfg(provider);if(startFlights.has(provider))throw new Error(`Đang chuẩn bị một phiên ${cfg.label}. Vui lòng đợi.`);startFlights.add(provider);try{await cleanupWebJobs();const settings=await getSettings();if(settings.webAiEnabled===false)throw new Error('Web AI đang tắt trong Cấu hình.');if(!/^[gc]web_[a-zA-Z0-9_-]{8,80}$/.test(requestId||''))throw new Error('Mã phiên không hợp lệ.');const jobId=requestId,cancelledKey='cancel:'+jobId;if((await chrome.storage.session.get(cancelledKey))[cancelledKey])throw new Error('Đã dừng phân tích.');const fingerprint=webPayloadFingerprint(provider,payload),fpKey=webFpKey(provider,fingerprint);
    const existingFp=(await chrome.storage.session.get(fpKey))[fpKey];if(existingFp?.jobId){const old=await readWebJob(existingFp.jobId);if(old&&!terminal(old)){if(old.sourceTabId===sourceTabId)return{jobId:old.jobId,tabId:old.tabId,reused:true,deduped:true,message:`${cfg.label} đang xử lý đúng văn bản này · không gửi lại.`};throw new Error(`${cfg.label} đang xử lý đúng văn bản này ở tab iOffice khác.`);} }
    let {tab,reused}=await ensureWarmWebTab(provider,sourceTabId);if((await chrome.storage.session.get(cancelledKey))[cancelledKey]){await chrome.storage.session.remove(cancelledKey);throw new Error('Đã dừng phân tích.');}const existing=await getJobForTab(tab.id);if(!terminal(existing))throw new Error(`${cfg.label} đang xử lý văn bản ở tab iOffice khác.`);
    const saved=await readOwnedTab(provider),turns=Math.max(0,Number(saved?.turns)||0),maxTurns=Math.max(1,Math.min(10,Number(settings[cfg.maxTurnsKey])||3)),documentKey=String(payload?.documentKeyHint||fingerprint),newDocument=!!reused&&String(saved?.lastDocumentKey||'')!==documentKey,rotate=newDocument||turns>=maxTurns||!!saved?.reset;
    if(rotate&&provider==='gemini')tab=await rotateWebConversation(provider,tab);
    const safePayload=stripScanAttachmentData(payload);const prompt=buildPrompt(safePayload,jobId,settings);const timeoutMs=Math.max(30000,Math.min(240000,Number(settings[cfg.timeoutKey])||150000));const job={jobId,provider,fingerprint,tabId:tab.id,sourceTabId,payload:safePayload,createdAt:Date.now(),deadline:Date.now()+timeoutMs+90000,timeoutMs,status:'running',phase:'preparing',phaseMessage:`Đang chuẩn bị gửi văn bản tới ${cfg.label}`,promptChars:prompt.length,rotate,documentKey,foreground:settings[cfg.foregroundKey]===true,resumeAfterReload:false,sendCommittedAt:0};
    await chrome.storage.session.set({[webJobKey(jobId)]:job,[webTabKey(tab.id)]:jobId,[fpKey]:{jobId,status:'reserved',createdAt:Date.now(),expiresAt:Date.now()+600000}});
    await rememberWebTab(provider,tab,{turns:rotate?0:turns,reset:false});
    try{if(job.foreground)await chrome.tabs.update(tab.id,{active:true});if((await chrome.storage.session.get(cancelledKey))[cancelledKey]){await cancelWebJob(jobId);throw new Error('Đã dừng phân tích.');}const r=await tabMessage(tab.id,{type:'IOFFICE_WEB_AI_AUTORUN',provider,jobId,prompt,timeoutMs,newChatBeforeSend:rotate&&provider!=='gemini'});if(!r?.ok)throw new Error(r?.error||`Không khởi động được ${cfg.label}.`);}catch(e){await failWebJob({jobId,error:e.message},{tab:{id:tab.id}});throw e;}await pushWebJobEvent(job,'progress');return{jobId,tabId:tab.id,reused,message:rotate?`${cfg.label} đã tạo cuộc trò chuyện mới · lượt 1/${maxTurns}.`:`${cfg.label} đang phân tích · lượt ${turns+1}/${maxTurns}.`};
  }finally{startFlights.delete(provider);}}
async function handleWebBridgeReady(sender,platform){const tabId=sender?.tab?.id;if(!tabId||!WEB_AI[platform])return{ok:true,autoRun:false};const job=await getJobForTab(tabId);if(terminal(job)||job.provider!==platform)return{ok:true,autoRun:false};if(['send-committed','sent','waiting'].includes(job.phase)){return{ok:true,autoRun:false,observeOnly:true,provider:platform,jobId:job.jobId,timeoutMs:job.timeoutMs||150000};}if(!job.resumeAfterReload)return{ok:true,autoRun:false};const settings=await getSettings();const prompt=buildPrompt(job.payload||{},job.jobId,settings);const updated=await updateWebJob(job.jobId,{resumeAfterReload:false,phase:'preparing',phaseMessage:`${providerCfg(platform).label} đã tải xong · đang chuẩn bị lại trước khi gửi`,promptChars:prompt.length});await pushWebJobEvent(updated||job,'progress');return{ok:true,autoRun:true,provider:platform,jobId:job.jobId,prompt,timeoutMs:job.timeoutMs||150000,newChatBeforeSend:false};}
async function assertOwner(id,sender){const j=await readWebJob(id);if(j&&j.sourceTabId!==sender?.tab?.id)throw new Error('Phiên không thuộc tab iOffice này.');return j;}
async function returnToSource(job){if(!job?.foreground)return;try{const tab=await chrome.tabs.get(job.tabId);if(tab.active)await chrome.tabs.update(job.sourceTabId,{active:true});}catch(_){}}
async function commitWebSend(m,sender){return serial('job:'+m.jobId,async()=>{const job=await readWebJob(m.jobId);if(!job||job.tabId!==sender?.tab?.id||job.provider!==m.provider)return{ok:false,error:'Phiên Web AI không khớp tab.'};if(terminal(job))return{ok:false,error:'Phiên đã kết thúc.'};if(job.sendCommittedAt||['send-committed','sent','waiting'].includes(job.phase))return{ok:true,alreadyCommitted:true,maySend:false};job.sendCommittedAt=Date.now();job.phase='send-committed';job.phaseMessage=`Đã khóa gửi ${providerCfg(job.provider).label} · không gửi trùng`;await chrome.storage.session.set({[webJobKey(job.jobId)]:job,[webFpKey(job.provider,job.fingerprint)]:{jobId:job.jobId,status:'committed',committedAt:job.sendCommittedAt,expiresAt:Date.now()+600000}});
    // Chỉ tính "lượt" khi thao tác Gửi thực sự đã được khóa/commit.
    // Nhờ vậy lỗi chuẩn bị prompt/tab không làm mất quota 3 lượt của cuộc trò chuyện.
    try{const saved=await readOwnedTab(job.provider);const current=Number(saved?.tabId)===Number(job.tabId)?Math.max(0,Number(saved?.turns)||0):0;await rememberWebTab(job.provider,await chrome.tabs.get(job.tabId),{turns:current+1,reset:false,lastDocumentKey:String(job.documentKey||job.fingerprint||'')});}catch(_){}
    await pushWebJobEvent(job,'progress');return{ok:true,alreadyCommitted:false,maySend:true};});}
async function completeWebJob(m,sender){return serial('job:'+m.jobId,async()=>{const job=await readWebJob(m.jobId);if(!job||job.tabId!==sender?.tab?.id)throw new Error('Kết quả không khớp tab Web AI.');if(terminal(job))return{ok:true,ignored:true};const parsed=IOfficeCore.parseRouting(m.text,m.jobId);if(!parsed)throw new Error('JSON thiếu trường bắt buộc hoặc không đúng mã phiên.');const cfg=providerCfg(job.provider);const result=validateAndClean(parsed,job.payload,{provider:`${job.provider}-web-auto`,providerLabel:`${cfg.label} Web`,model:`Theo lựa chọn trên ${cfg.label}`,primaryProvider:`${job.provider}-web-auto`,attemptCount:1,triedProviders:[`${job.provider}-web-auto`],promptChars:job.promptChars+String(m.text).length,usageMetadata:null});Object.assign(job,{status:'done',phase:'done',phaseMessage:`Đã nhận kết quả ${cfg.label}`,completedAt:Date.now(),result});await chrome.storage.session.set({[webJobKey(job.jobId)]:job});await releaseTab(job);await pushWebJobEvent(job,'done',{result});await returnToSource(job);return{ok:true};});}
async function failWebJob(m,sender){const job=await readWebJob(m.jobId);if(terminal(job))return{ok:true};if(job.tabId!==sender?.tab?.id)return{ok:false};const cfg=providerCfg(job.provider),error=String(m.error||`${cfg.label} không hoàn tất.`).slice(0,1000);const updated=await updateWebJob(job.jobId,{status:'error',phase:'error',phaseMessage:error,error,completedAt:Date.now()});if(updated?.status==='error'){await releaseTab(job);try{await rememberWebTab(job.provider,await chrome.tabs.get(job.tabId),{turns:0,reset:true});}catch(_){}await pushWebJobEvent(updated,'error',{error});await returnToSource(job);}return{ok:true};}
const WEB_PHASE_RANK={preparing:1,'new-chat':2,upload:3,uploaded:4,'prompt-ready':5,'send-committed':6,sent:7,waiting:8,done:9,error:9,cancelled:9};
async function updateWebProgress(m,sender){const j=await readWebJob(m.jobId);if(terminal(j)||j.tabId!==sender?.tab?.id)return{ok:false};const next=String(m.phase||'waiting').slice(0,50),currentRank=WEB_PHASE_RANK[j.phase]||0,nextRank=WEB_PHASE_RANK[next]||currentRank;if(currentRank>=WEB_PHASE_RANK['send-committed']&&nextRank<WEB_PHASE_RANK['send-committed'])return{ok:true,ignored:true};const updated=await updateWebJob(j.jobId,{phase:next,phaseMessage:String(m.phaseMessage||'').slice(0,300)});if(!terminal(updated))await pushWebJobEvent(updated,'progress');return{ok:true};}
async function cancelWebJob(id,error=''){return serial('job:'+id,async()=>{const j=await readWebJob(id);if(!j){await chrome.storage.session.set({['cancel:'+id]:Date.now()});return{ok:true};}if(terminal(j))return{ok:true};Object.assign(j,{status:error?'error':'cancelled',phase:error?'error':'cancelled',phaseMessage:error||'Đã dừng phân tích.',error,completedAt:Date.now()});await chrome.storage.session.set({[webJobKey(id)]:j});await tabMessage(j.tabId,{type:'IOFFICE_WEB_AI_CANCEL',jobId:id,provider:j.provider}).catch(()=>{});await releaseTab(j);try{await rememberWebTab(j.provider,await chrome.tabs.get(j.tabId),{turns:0,reset:true});}catch(_){}await pushWebJobEvent(j,error?'error':'cancelled',{error});await returnToSource(j);return{ok:true};});}
async function getWebJobStatus(id){let j=await readWebJob(id);if(!j)throw new Error('Không tìm thấy phiên Web AI.');if(!terminal(j)&&Date.now()>j.deadline){await cancelWebJob(id,`${providerCfg(j.provider).label} đã quá thời gian chờ.`);j=await readWebJob(id);}return{jobId:id,provider:j.provider,status:j.status,phase:j.phase,phaseMessage:j.phaseMessage,error:j.error,result:j.result,elapsedMs:Date.now()-j.createdAt,tabId:j.tabId};}
async function consumeWebJob(id){const j=await readWebJob(id);if(j&&!terminal(j))return{ok:false};if(j)await releaseTab(j);await chrome.storage.session.remove([webJobKey(id),'cancel:'+id]);return{ok:true};}
async function webAiActiveJobCount(){const all=await chrome.storage.session.get(null);return Object.entries(all).filter(([k,j])=>k.startsWith(WEB_JOB_PREFIX)&&!terminal(j)).length;}
chrome.tabs.onUpdated.addListener((id,change)=>{if(!change.url&&!change.status)return;(async()=>{const j=await getJobForTab(id);if(terminal(j))return;const cfg=providerCfg(j.provider),url=String(change.url||'');if(url&&!url.startsWith(cfg.origin)){await failWebJob({jobId:j.jobId,error:`${cfg.label} đã chuyển sang trang khác. Hãy mở lại ${cfg.label} và phân tích lại.`},{tab:{id}});return;}if(change.status==='loading'){if(['send-committed','sent','waiting'].includes(j.phase)){const updated=await updateWebJob(j.jobId,{resumeAfterReload:false,phase:j.phase,phaseMessage:`${cfg.label} đang tải lại · chỉ nối lại quan sát, không gửi lại`});if(updated&&!terminal(updated))await pushWebJobEvent(updated,'progress');}else{const updated=await updateWebJob(j.jobId,{resumeAfterReload:true,phase:'preparing',phaseMessage:`${cfg.label} đang chuyển cuộc trò chuyện · sẽ tiếp tục trước bước gửi`});if(updated&&!terminal(updated))await pushWebJobEvent(updated,'progress');}}})().catch(()=>{});});
chrome.tabs.onRemoved.addListener(id=>{(async()=>{for(const provider of Object.keys(WEB_AI)){const saved=await readOwnedTab(provider);if(saved?.tabId===id)await chrome.storage.session.remove(`webAiOwnedTab:${provider}`);}const all=await chrome.storage.session.get(null);for(const[key,j]of Object.entries(all))if(key.startsWith(WEB_JOB_PREFIX)&&!terminal(j)&&(j.tabId===id||j.sourceTabId===id))await cancelWebJob(j.jobId,'Tab đang xử lý đã đóng.');})().catch(()=>{});});


async function listModels(providerId, cfg) {
  const p = CATALOG[providerId];
  if (!p) throw new Error('Provider không hợp lệ.');
  if (!p.canListModels) throw new Error('Provider này không hỗ trợ tải danh sách model tự động.');

  if (p.type === 'gemini') {
    if (!cfg.apiKey) throw new Error('Cần Gemini API key để tải danh sách model.');
    const data = await fetchJson(`${trimSlash(cfg.baseUrl || p.baseUrl)}/models?pageSize=1000`, { method: 'GET', headers: {'x-goog-api-key':cfg.apiKey} }, 30000);
    return (data.models || []).filter((m) => !m.supportedGenerationMethods || m.supportedGenerationMethods.includes('generateContent')).map((m) => ({ id: String(m.name || '').replace(/^models\//, ''), label: m.displayName || m.name })).filter((x) => x.id);
  }

  if (p.type === 'anthropic') {
    if (!cfg.apiKey) throw new Error('Cần Anthropic API key.');
    const data = await fetchJson(`${trimSlash(cfg.baseUrl || p.baseUrl)}/models?limit=1000`, { method: 'GET', headers: { 'x-api-key': cfg.apiKey, 'anthropic-version': '2023-06-01' } }, 30000);
    return (data.data || []).map((m) => ({ id: m.id, label: m.display_name || m.id })).filter((x) => x.id);
  }

  if (p.type === 'ollama') {
    const data = await fetchJson(`${trimSlash(cfg.baseUrl || p.baseUrl)}/api/tags`, { method: 'GET' }, 15000);
    return (data.models || []).map((m) => ({ id: m.name || m.model, label: m.name || m.model })).filter((x) => x.id);
  }

  if (p.type === 'azure-openai' || p.type === 'gateway') throw new Error('Không có endpoint model-list chuẩn cho cấu hình này.');

  if (!cfg.baseUrl) throw new Error('Chưa có Base URL.');
  if (p.needsKey && !cfg.apiKey) throw new Error('Chưa có API key.');
  const headers = authHeaders(providerId, cfg);
  const data = await fetchJson(`${trimSlash(cfg.baseUrl)}/models`, { method: 'GET', headers }, 30000);
  const list = data.data || data.models || [];
  return list.map((m) => ({ id: typeof m === 'string' ? m : (m.id || m.name || m.model), label: typeof m === 'string' ? m : (m.name || m.id || m.model) })).filter((x) => x.id);
}

async function testProvider(providerId, cfg) {
  const p = CATALOG[providerId];
  if (!p) throw new Error('Provider không hợp lệ.');
  if (p.type === 'gateway') {
    const base = String(cfg.baseUrl || '').replace(/\/analyze\/?$/, '');
    try { await fetchJson(`${trimSlash(base)}/health`, { method: 'GET' }, 10000); return { ok: true, message: 'Gateway phản hồi health-check.' }; }
    catch (_) { throw new Error('Không xác minh được /health của gateway. Kiểm tra địa chỉ và máy chủ.'); }
  }
  if (p.canListModels) {
    const models = await listModels(providerId, cfg);
    return { ok: true, message: `Kết nối được · thấy ${models.length} model.`, models: models.slice(0, 300) };
  }
  if (p.type === 'azure-openai') {
    if (!providerConfigured(providerId, cfg)) throw new Error('Azure cần key + endpoint + deployment.');
    return { ok: true, message: 'Cấu hình Azure đủ trường bắt buộc; sẽ xác minh thật ở lần phân tích.' };
  }
  return { ok: true, message: 'Cấu hình hợp lệ.' };
}


// V3/V5 pending writes are retained for reference but never replayed against Tracker.
try { chrome.alarms.clear('trackerPendingSyncV5'); } catch (_) {}

async function testGeminiOpenAiRoute(cfg) {
  if (!cfg?.apiKey) throw new Error('Chưa nhập API key.');
  if (!GEMINI_OPENAI_MODELS.includes(String(cfg.model || ''))) throw new Error('Model không nằm trong danh sách hỗ trợ nhanh.');
  const data = await fetchJson(`${trimSlash(GEMINI_OPENAI_BASE)}/chat/completions`, {
    method: 'POST',
    headers: authHeaders(GEMINI_OPENAI_PROVIDER, { ...cfg, authMode:'bearer' }),
    body: JSON.stringify({
      model: cfg.model,
      messages: [{ role:'user', content:'Reply with exactly: OK' }],
      max_tokens: 8
    })
  }, 20000);
  const text = String(data?.choices?.[0]?.message?.content || data?.choices?.[0]?.text || '').trim();
  if (!text) throw new Error('API kết nối được nhưng model không trả nội dung.');
  return { ok:true, model:cfg.model, message:`Kết nối và gọi model ${cfg.model} thành công.` };
}


async function checkRelease(url){
  const u=new URL(url);if(u.protocol!=='https:'||u.username||u.password)throw new Error('Địa chỉ cập nhật phải là HTTPS.');
  if(!await chrome.permissions.contains({origins:[u.origin+'/*']}))throw new Error('Chưa cấp quyền đọc địa chỉ cập nhật.');
  const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),12000);
  try{
    const r=await fetch(u.href,{signal:controller.signal,credentials:'omit',cache:'no-store',redirect:'error'});
    if(!r.ok)throw new Error('Không tải được thông tin cập nhật (HTTP '+r.status+').');
    const reader=r.body.getReader();let bytes=0,parts=[];
    while(true){const {done,value}=await reader.read();if(done)break;bytes+=value.length;if(bytes>65536){await reader.cancel();throw new Error('Tệp cập nhật quá lớn.');}parts.push(value);}
    const joined=new Uint8Array(bytes);let offset=0;for(const part of parts){joined.set(part,offset);offset+=part.length;}
    return IOfficeCore.releaseInfo(JSON.parse(new TextDecoder().decode(joined)),chrome.runtime.getManifest().version);
  }finally{clearTimeout(timer);}
}
async function checkStoreUpdate(){
  const result=await chrome.runtime.requestUpdateCheck();
  return {message:result.status==='update_available'?`Chrome đã tìm thấy bản ${result.version}. Bản cập nhật được Chrome quản lý.`:result.status==='throttled'?'Chrome vừa kiểm tra gần đây. Hãy thử lại sau.':'Chrome chưa tìm thấy bản mới. Nếu đang dùng Load unpacked, hãy tải gói mới và tải lại tiện ích.',status:result.status};
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (sender.id !== chrome.runtime.id) return;
  const url = sender.url || sender.tab?.url || '';
  const isOptions = url.startsWith(chrome.runtime.getURL(''));
  const isOffice = url.startsWith('https://ioffice.vnptdaklak.vn/qlvbdh_dlk/');
  const isGemini = url.startsWith('https://gemini.google.com/');
  const isChatgpt = url.startsWith('https://chatgpt.com/');
  const type = message?.type || '';
  if (iofficeUpdateApplying && ['AI_ANALYZE','WEB_AUTOMATION_START','WEB_AUTOMATION_PREWARM'].includes(type)) { sendResponse({ok:false,error:'Đang cập nhật tiện ích. Vui lòng chờ.'}); return; }
  const fromWebAi = ['WEB_AUTOMATION_RESULT','WEB_AUTOMATION_PROGRESS','WEB_AUTOMATION_ERROR','WEB_AUTOMATION_COMMIT_SEND','WEB_BRIDGE_READY'].includes(type);
  if (fromWebAi ? (!isGemini && !isChatgpt) : (!isOptions && !isOffice)) return;
  if (['AI_LIST_MODELS','AI_TEST_PROVIDER','AI_TEST_API_ROUTE','CHECK_RELEASE','CHECK_STORE_UPDATE'].includes(type) && !isOptions) return;

  if(type==='CHECK_RELEASE'||type==='CHECK_STORE_UPDATE'){(type==='CHECK_RELEASE'?checkRelease(message.url):checkStoreUpdate()).then(data=>sendResponse({ok:true,data})).catch(e=>sendResponse({ok:false,error:e.message}));return true;}
  if (type === 'AI_BUILD_PROMPT') { getSettings().then(settings=>sendResponse({ok:true,prompt:buildPrompt(message.payload || {},'',settings)})).catch(e=>sendResponse({ok:false,error:e.message})); return true; }

  if (type.startsWith('TRACKER_')) {
    IOfficeTrackerClient.handle(message).then(sendResponse).catch(e=>sendResponse({ok:false,error:e.message}));
    return true;
  }
  if (message?.type === 'GET_ROUTING_RULES') {
    getRoutingRules().then((rules) => sendResponse({ ok: true, rules })).catch((error) => sendResponse({ ok: false, error: error?.message || String(error) }));
    return true;
  }
  if(message?.type==='SYSTEM_CPU_INFO'){
    (async()=>{try{const info=await chrome.system.cpu.getInfo();sendResponse({ok:true,data:{modelName:info.modelName||'',archName:info.archName||'',numOfProcessors:Number(info.numOfProcessors||0)}});}catch(e){sendResponse({ok:false,error:e.message});}})();return true;
  }
  if(message?.type==='AI_CANCEL'){const id=sender.tab?.id;apiRequests.get(id)?.abort();sendResponse({ok:true});return;}
  if (message?.type === 'AI_ANALYZE') {
    const tabId=sender.tab?.id;
    apiRequests.get(tabId)?.abort();const c=new AbortController();apiRequests.set(tabId,c);
    analyze(message.payload || {},c.signal).then((data) => sendResponse({ ok: true, data })).catch((error) => sendResponse({ ok: false, error: error?.message || String(error) })).finally(()=>{if(apiRequests.get(tabId)===c)apiRequests.delete(tabId);});
    return true;
  }
  if (message?.type === 'AI_LIST_MODELS') {
    listModels(message.providerId, message.config || {}).then((models) => sendResponse({ ok: true, models })).catch((error) => sendResponse({ ok: false, error: error?.message || String(error) }));
    return true;
  }
  if (message?.type === 'AI_TEST_PROVIDER') {
    testProvider(message.providerId, message.config || {}).then((data) => sendResponse({ ok: true, data })).catch((error) => sendResponse({ ok: false, error: error?.message || String(error) }));
    return true;
  }
  if (message?.type === 'AI_TEST_API_ROUTE') {
    testGeminiOpenAiRoute(message.config || {}).then((data) => sendResponse({ ok: true, data })).catch((error) => sendResponse({ ok: false, error: error?.message || String(error) }));
    return true;
  }
  if (message?.type === 'WEB_BRIDGE_READY') {
    handleWebBridgeReady(sender,message.platform)
      .then(sendResponse)
      .catch((error)=>sendResponse({ok:false,error:error?.message||String(error)}));
    return true;
  }
  if (message?.type === 'WEB_AUTOMATION_PREWARM') {
    const provider=message.provider==='chatgpt'?'chatgpt':'gemini';
    prewarmWebForSession(provider,sender?.tab?.id)
      .then(async ({ tab, reused, firstForeground }) => {
        let health={};
        try { health = await tabMessage(tab.id,{type:'IOFFICE_WEB_BRIDGE_PING'}); } catch (_) {}
        sendResponse({ ok: true, data: { provider, tabId: tab?.id || null, reused, firstForeground, composerFound:!!health?.composerFound, sendFound:!!health?.sendFound, ready:!!health?.ready } });
      })
      .catch((error) => sendResponse({ ok: false, error: error?.message || String(error) }));
    return true;
  }
  if (message?.type === 'WEB_AUTOMATION_START') {
    const provider=message.provider==='chatgpt'?'chatgpt':'gemini';
    startWebAutomation(provider,message.payload || {}, sender?.tab?.id, message.jobId)
      .then((data) => sendResponse({ ok: true, data }))
      .catch((error) => sendResponse({ ok: false, error: error?.message || String(error) }));
    return true;
  }
  if (message?.type === 'WEB_AUTOMATION_COMMIT_SEND') {
    commitWebSend(message, sender).then(sendResponse).catch((error)=>sendResponse({ok:false,error:error?.message||String(error)}));
    return true;
  }
  if (message?.type === 'WEB_AUTOMATION_RESULT') {
    completeWebJob(message, sender).then(sendResponse).catch((error) => sendResponse({ ok: false, error: error?.message || String(error) }));
    return true;
  }
  if (message?.type === 'WEB_AUTOMATION_ERROR') {
    failWebJob(message, sender).then(sendResponse).catch(() => sendResponse({ ok: false }));
    return true;
  }
  if (message?.type === 'WEB_AUTOMATION_PROGRESS') {
    updateWebProgress(message, sender).then(sendResponse).catch(() => sendResponse({ ok: false }));
    return true;
  }
  if (message?.type === 'WEB_AUTOMATION_CANCEL') {
    assertOwner(message.jobId, sender).then(() => cancelWebJob(message.jobId))
      .then(sendResponse).catch(() => sendResponse({ ok: false }));
    return true;
  }
  if (message?.type === 'WEB_AUTOMATION_STATUS') {
    assertOwner(message.jobId, sender).then(() => getWebJobStatus(message.jobId))
      .then((data) => sendResponse({ ok: true, data })).catch((error) => sendResponse({ ok: false, error: error?.message || String(error) }));
    return true;
  }
  if (message?.type === 'WEB_AUTOMATION_CONSUME') {
    assertOwner(message.jobId, sender).then(() => consumeWebJob(message.jobId))
      .then(sendResponse).catch(() => sendResponse({ ok: false }));
    return true;
  }
  if (message?.type === 'OPEN_OPTIONS') {
    chrome.runtime.openOptionsPage(); sendResponse({ ok: true });
  }
});

importScripts('update-manager.js', 'rule-update-manager.js');
