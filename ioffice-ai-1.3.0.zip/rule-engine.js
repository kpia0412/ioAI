/*
 * iOffice AI · Local Rule Pro
 * Phân tích văn bản hành chính hoàn toàn cục bộ, không gửi dữ liệu ra ngoài.
 *
 * Mục tiêu thiết kế:
 *  - Ưu tiên chính xác hơn “đoán đủ”: không đủ bằng chứng => requiresReview=true.
 *  - Xác định CHỦ THỂ trước, sau đó mới xác định HÀNH ĐỘNG/SẢN PHẨM/HẠN/XLC.
 *  - Hạn chỉ được nhận khi có quan hệ ngôn ngữ rõ; ngày văn bản/ngày viện dẫn không phải hạn.
 *  - Phân tích nhiệm vụ trên tài liệu chính; phụ lục/tài liệu kèm chỉ dùng hỗ trợ khi cần.
 *  - Chọn đơn vị theo chính NHIỆM VỤ, không theo toàn văn.
 *
 * Tương thích API cũ:
 *   globalThis.IOfficeRuleEngine.analyze(context, config, availableUnits)
 *   globalThis.IOfficeRuleEngine.extractDeadline(text, documentDate)
 */
(() => {
  'use strict';

  const VERSION = '1.3.0-local-rule-pro';
  const DAY_MS = 86400000;
  const MAX_TASKS = 10;
  const MAX_WINDOW_CHARS = 1800;
  const MAX_WINDOW_LINES = 4;

  const arr = (v) => Array.isArray(v) ? v : [];
  const uniq = (a) => [...new Set((a || []).filter(Boolean))];
  const clean = (v) => String(v || '')
    .replace(/\r/g, '')
    .replace(/[ \t]+/g, ' ')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
  const norm = (v) => String(v || '')
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .replace(/đ/g, 'd').replace(/Đ/g, 'D')
    .toLowerCase().replace(/\s+/g, ' ').trim();
  const cap = (v, n = 260) => {
    const s = clean(v);
    return s.length > n ? s.slice(0, n - 1).trimEnd() + '…' : s;
  };
  const testAny = (text, patterns) => {
    const n = norm(text);
    return patterns.some((r) => r.test(n));
  };
  const matchAny = (text, patterns) => {
    const n = norm(text);
    return patterns.filter((r) => r.test(n));
  };
  const safeNum = (v, d = 0) => Number.isFinite(Number(v)) ? Number(v) : d;

  // ---------------------------------------------------------------------------
  // 1) TỪ ĐIỂN CHỦ THỂ / VAI TRÒ
  // ---------------------------------------------------------------------------

  const EA_DIRECT = [
    /\bubnd\s+xa\s+ea\s*ly\b/i,
    /\buy ban nhan dan\s+xa\s+ea\s*ly\b/i,
    /\bxa\s+ea\s*ly\b/i
  ];

  const LOCAL_GROUP = [
    /\bubnd\s+cac\s+xa(?:,?\s*phuong)?(?:,?\s*dac\s*khu)?\b/i,
    /\buy ban nhan dan\s+cac\s+xa(?:,?\s*phuong)?(?:,?\s*dac\s*khu)?\b/i,
    /\bubnd\s+xa,?\s*phuong(?:,?\s*dac\s*khu)?\b/i,
    /\buy ban nhan dan\s+xa,?\s*phuong(?:,?\s*dac\s*khu)?\b/i,
    /\bcac\s+xa(?:,?\s*phuong)?(?:,?\s*dac\s*khu)?\b/i,
    /\bcac\s+phuong(?:,?\s*xa)?\b/i,
    /\bcac\s+dia\s+phuong\b/i,
    /\bchinh quyen dia phuong\b/i
  ];

  const GENERIC_RECIPIENTS = [
    /\bcac\s+co\s+quan,?\s*don\s+vi,?\s*dia\s+phuong\b/i,
    /\bcac\s+co\s+quan,?\s*don\s+vi\s+va\s+dia\s+phuong\b/i,
    /\bcac\s+don\s+vi,?\s*dia\s+phuong\b/i,
    /\bcac\s+don\s+vi\s+va\s+dia\s+phuong\b/i,
    /\bcac\s+co\s+quan,?\s*don\s+vi\b/i,
    /\bcac\s+don\s+vi\b/i,
    /\bquy\s+co\s+quan,?\s*don\s+vi\b/i
  ];

  const OTHER_AGENCY_START = [
    /^(?:doi voi\s+)?(?:(?:giam doc|thu truong)\s+)?(?:so|bo|ban|cuc|chi cuc|phong|van phong)\s+[a-z0-9]/i,
    /^(?:doi voi\s+)?(?:\d+\s+)?(?:trung tam y te|benh vien|cac benh vien|cac truong|nha truong|co so giao duc)\b/i,
    /^(?:doi voi\s+)?(?:cong an tinh|bo chi huy|ban chi huy|mat tran to quoc|uy ban mat tran)\b/i,
    /^(?:doi voi\s+)?(?:cac so|cac phong|cac trung tam|cac don vi truc thuoc|co quan chuyen mon)\b/i
  ];

  const SUBJECT_LEAD_VERBS = '(?:giao|de nghi|yeu cau|chi dao|phan cong|đề nghị|yêu cầu|chỉ đạo|phân công)';

  // Vai trò hành động. Tất cả pattern chạy trên text đã norm (không dấu).
  const STRONG_ACTION_PATTERNS = [
    /\bbao cao\b/i,
    /\bcung cap\b/i,
    /\bgui\b/i,
    /\bnop\b/i,
    /\bco y kien\b/i,
    /\btham gia y kien\b/i,
    /\bgop y\b/i,
    /\bphan bien\b/i,
    /\bxac nhan\b/i,
    /\bdang ky\b/i,
    /\bke khai\b/i,
    /\bkhao sat\b/i,
    /\bcap nhat\b/i,
    /\bnhap lieu\b/i,
    /\bhoan thien\b/i,
    /\bxay dung\s+(?:bao cao|ke hoach|phuong an|de an|du thao|danh sach|du toan|ho so)\b/i,
    /\blap\s+(?:bao cao|ke hoach|danh sach|du toan|ho so|bien ban)\b/i,
    /\btong hop\s+(?:bao cao|so lieu|danh sach|ket qua|y kien)\b/i,
    /\btham muu\s+(?:bao cao|van ban|ke hoach|quyet dinh|chi dao|xu ly|giai quyet|de xuat)\b/i,
    /\bde xuat\b/i,
    /\btrinh\s+(?:ubnd|chu tich|cap co tham quyen|phe duyet)\b/i,
    /\bban hanh\b/i,
    /\bniem yet\b/i,
    /\bcong khai\b/i,
    /\btra loi\b/i,
    /\bphuc dap\b/i,
    /\bgiai trinh\b/i,
    /\bcam ket\b/i,
    /\bdang tai\b/i,
    /\bcong bo\b/i
  ];

  const OPERATIONAL_ACTION_PATTERNS = [
    /\bra soat\b/i,
    /\bkiem tra\b/i,
    /\bdoi chieu\b/i,
    /\bthong ke\b/i,
    /\bphan loai\b/i,
    /\bkiem dem\b/i,
    /\btrien khai\b/i,
    /\bto chuc thuc hien\b/i,
    /\bthuc hien\b/i,
    /\bkhac phuc\b/i,
    /\bchuan hoa\b/i,
    /\bbo sung\b/i,
    /\bdieu chinh\b/i,
    /\bxu ly\b/i,
    /\bgiai quyet\b/i,
    /\bbo tri\b/i,
    /\bphan cong\b/i,
    /\bcu\s+(?:can bo|cong chuc|vien chuc|dai bieu|nguoi|thanh vien)\b/i,
    /\btham du\b/i,
    /\btham gia\b/i,
    /\bpho bien\b/i,
    /\btuyen truyen\b/i,
    /\bquan triet\b/i,
    /\bhuong dan\b/i,
    /\bdon doc\b/i,
    /\btheo doi\s+tien do\b/i,
    /\bchi dao\b/i,
    /\btiep nhan\b/i,
    /\btra ket qua\b/i,
    /\bthuc hien chi tra\b/i,
    /\bchi tra\b/i,
    /\bho tro\b/i,
    /\bvan dong\b/i,
    /\btap huan\b/i,
    /\bboi duong\b/i,
    /\bkiem ke\b/i,
    /\bchan chinh\b/i,
    /\bxu ly dut diem\b/i,
    /\btang cuong\b/i,
    /\bday nhanh\b/i,
    /\bbao dam\b/i,
    /\bdam bao\b/i,
    /\bthuc hien nghiem(?: tuc)?\b/i,
    /\bto chuc trien khai\b/i,
    /\bchu dong trien khai\b/i,
    /\bchu dong ra soat\b/i,
    /\bkhuyen khich\b/i
  ];

  const PRODUCT_PATTERNS = [
    /\bbao cao\b/i,
    /\bdanh sach\b/i,
    /\bbieu mau\b/i,
    /\bphieu\b/i,
    /\bso lieu\b/i,
    /\bdu lieu\b/i,
    /\bvan ban\b/i,
    /\by kien\b/i,
    /\bke hoach\b/i,
    /\bphuong an\b/i,
    /\bde an\b/i,
    /\bket qua\b/i,
    /\bho so\b/i,
    /\bdu thao\b/i,
    /\bbien ban\b/i,
    /\btai lieu\b/i,
    /\bminh chung\b/i,
    /\bdu toan\b/i,
    /\bquyet toan\b/i,
    /\bphu luc\b/i,
    /\bbao bieu\b/i,
    /\btep tin\b/i,
    /\bfile\b/i,
    /\bxac nhan\b/i,
    /\bho so de nghi\b/i,
    /\bto trinh\b/i,
    /\bbao cao giai trinh\b/i,
    /\bbao cao tong hop\b/i,
    /\bban xac nhan\b/i,
    /\bban dang ky\b/i,
    /\bquyet dinh\b/i,
    /\bket luan\b/i,
    /\bchuong trinh\b/i,
    /\bde cuong\b/i
  ];

  const COORDINATION_PATTERNS = [
    /\bphoi hop\s+(?:chat che\s+)?(?:voi\s+)?/i,
    /\bchu dong phoi hop\b/i,
    /\bphoi hop thuc hien\b/i,
    /\bphoi hop trien khai\b/i,
    /\bphoi hop ra soat\b/i,
    /\bphoi hop cung cap\b/i,
    /\blam viec\s+voi\b/i,
    /\bho tro\s+(?:khi|trong qua trinh|theo de nghi)\b/i,
    /\btao dieu kien\b/i,
    /\bcu dau moi phoi hop\b/i,
    /\bphoi hop khi co yeu cau\b/i,
    /\bkhi co yeu cau\b/i,
    /\btheo de nghi cua\b/i,
    /\btham gia phoi hop\b/i,
    /\bphoi hop xu ly\b/i,
    /\bphoi hop kiem tra\b/i,
    /\bphoi hop tuyen truyen\b/i,
    /\bphoi hop to chuc\b/i,
    /\bphoi hop tong hop\b/i,
    /\bphoi hop bao cao\b/i,
    /\bphoi hop tham muu\b/i
  ];

  const INFORMATION_PATTERNS = [
    /\bde biet\b/i,
    /\bde theo doi\b/i,
    /\bde tham khao\b/i,
    /\bthong tin den\b/i,
    /\bthong bao de biet\b/i,
    /\bpho bien de biet\b/i,
    /\bgui .* de biet\b/i,
    /\bgui .* de tham khao\b/i,
    /\bnghien cuu de biet\b/i,
    /\bnghien cuu,?\s*tham khao\b/i,
    /\bluu y de biet\b/i
  ];

  const CONDITIONAL_PATTERNS = [
    /\bneu\s+/i,
    /\btruong hop\s+/i,
    /\bkhi\s+co\s+(?:yeu cau|phat sinh|vuong mac|kho khan|de nghi)\b/i,
    /\btrong truong hop\b/i,
    /\bneu co phat sinh\b/i,
    /\bkhi can thiet\b/i,
    /\bkhi duoc yeu cau\b/i
  ];

  // ---------------------------------------------------------------------------
  // 2) TỪ ĐIỂN DEADLINE
  // ---------------------------------------------------------------------------

  const REFERENCE_DATE_CONTEXT = [
    /\bcong van\s+(?:so\s*)?[^.;\n]{0,70}\bngay\b/i,
    /\bquyet dinh\s+(?:so\s*)?[^.;\n]{0,70}\bngay\b/i,
    /\bke hoach\s+(?:so\s*)?[^.;\n]{0,70}\bngay\b/i,
    /\bthong bao\s+(?:so\s*)?[^.;\n]{0,70}\bngay\b/i,
    /\bnghi quyet\s+(?:so\s*)?[^.;\n]{0,70}\bngay\b/i,
    /\bnghi dinh\s+(?:so\s*)?[^.;\n]{0,70}\bngay\b/i,
    /\bthong tu\s+(?:so\s*)?[^.;\n]{0,70}\bngay\b/i,
    /\bchi thi\s+(?:so\s*)?[^.;\n]{0,70}\bngay\b/i,
    /\bket luan\s+(?:so\s*)?[^.;\n]{0,70}\bngay\b/i,
    /\btheo\s+(?:cong van|quyet dinh|ke hoach|thong bao|nghi quyet|nghi dinh)[^.;\n]{0,90}\bngay\b/i,
    /\bcan cu\s+[^.;\n]{0,120}\bngay\b/i,
    /\bban hanh\s+ngay\b/i,
    /\bky\s+ngay\b/i,
    /\bngay ban hanh\b/i,
    /\bngay ky\b/i
  ];

  function parseDate(day, month, year, defaultYear = '') {
    let y = year ? Number(year) : Number(String(defaultYear || '').slice(0, 4));
    const m = Number(month), d = Number(day);
    if (!y || !m || !d) return null;
    if (y < 100) y += 2000;
    const dt = new Date(y, m - 1, d);
    if (dt.getFullYear() !== y || dt.getMonth() !== m - 1 || dt.getDate() !== d) return null;
    return `${y}-${String(m).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
  }

  function addDaysIso(iso, count, working = false) {
    const m = String(iso || '').match(/^(\d{4})-(\d{2})-(\d{2})$/);
    if (!m) return '';
    const d = new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3]));
    let left = Math.max(0, Number(count) || 0);
    while (left > 0) {
      d.setDate(d.getDate() + 1);
      if (!working || ![0, 6].includes(d.getDay())) left--;
    }
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  }

  function normalizeTime(hour, minute = '0') {
    const h = Number(hour), m = Number(minute || 0);
    if (h < 0 || h > 23 || m < 0 || m > 59) return '';
    return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
  }

  function evidenceAroundDate(raw, day, month, year, radius = 170) {
    const y = year ? `(?:${String(year).replace(/^20/, '(?:20)?')})` : '(?:\\d{2,4})?';
    const re = new RegExp(`${Number(day)}\\s*[\\/\\-.]\\s*${Number(month)}(?:\\s*[\\/\\-.]\\s*${y})?`, 'i');
    const m = re.exec(raw);
    if (!m) return cap(raw, radius * 2);
    return cap(raw.slice(Math.max(0, m.index - radius), Math.min(raw.length, m.index + m[0].length + radius)), radius * 2 + 80);
  }

  function isReferenceDateEvidence(evidence) {
    return REFERENCE_DATE_CONTEXT.some((r) => r.test(norm(evidence)));
  }

  /**
   * Chỉ nhận deadline khi có cue rõ ràng. Không có fallback “thấy ngày + thấy báo cáo => deadline”.
   */
  function extractDeadline(text, documentDate = '') {
    const raw = clean(text);
    const n = norm(raw);
    const defaultYear = /^\d{4}-\d{2}-\d{2}$/.test(documentDate || '') ? documentDate.slice(0, 4) : '';
    const found = [];

    const push = ({ day, month, year, hour = '', minute = '', index = 0, kind = 'explicit', certainty = 'high', cue = '' }) => {
      const iso = parseDate(day, month, year, defaultYear);
      if (!iso) return;
      const evidence = evidenceAroundDate(raw, day, month, year);
      // Nếu chính evidence thể hiện ngày của văn bản viện dẫn, chỉ loại khi cue deadline không rõ.
      if (kind !== 'explicit-strong' && isReferenceDateEvidence(evidence)) return;
      const time = hour !== '' ? normalizeTime(hour, minute) : '';
      found.push({
        deadline: iso,
        deadlineDate: iso,
        deadlineTime: time,
        deadlineISO: time ? `${iso}T${time}:00+07:00` : '',
        deadlineText: time ? `${time} ${iso}` : iso,
        deadlineEvidence: cap(evidence, 360),
        deadlineSource: kind,
        certainty,
        cue,
        index
      });
    };

    // “trước/chậm nhất/không muộn hơn ... 16h30 ngày 02/10/2026”
    const strongDatePatterns = [
      /(?:truoc|cham nhat|muon nhat|khong muon hon|den het)\s+(?:(?:luc|vao luc|vao)\s+)?(?:(\d{1,2})(?::|h|\s+gio\s*)(\d{1,2})?\s*)?(?:ngay\s+)?(\d{1,2})[\/\-.](\d{1,2})(?:[\/\-.](\d{2,4}))?/gi,
      /(?:hoan thanh|gui|nop|bao cao|phan hoi|co y kien|cung cap|cap nhat|dang ky|tong hop)[^.;\n]{0,120}?(?:truoc|cham nhat|muon nhat|khong muon hon|den het|den)\s+(?:(?:luc|vao luc|vao)\s+)?(?:(\d{1,2})(?::|h|\s+gio\s*)(\d{1,2})?\s*)?(?:ngay\s+)?(\d{1,2})[\/\-.](\d{1,2})(?:[\/\-.](\d{2,4}))?/gi,
      /(?:thoi han|han|thoi diem hoan thanh|thoi gian hoan thanh)\s*[:\-]?\s*(?:(\d{1,2})(?::|h|\s+gio\s*)(\d{1,2})?\s*)?(?:ngay\s+)?(\d{1,2})[\/\-.](\d{1,2})(?:[\/\-.](\d{2,4}))?/gi
    ];

    for (const re of strongDatePatterns) {
      let m;
      while ((m = re.exec(n))) {
        push({ day: m[3], month: m[4], year: m[5], hour: m[1] || '', minute: m[2] || '', index: m.index, kind: 'explicit-strong', certainty: 'high', cue: cap(m[0], 160) });
      }
    }

    // “trước ngày 30 tháng 9 năm 2026”; có thể có “16 giờ 30”.
    const wordDate = /(?:truoc|cham nhat|muon nhat|khong muon hon|den het|hoan thanh truoc)\s+(?:(\d{1,2})\s*(?:gio|h)(?:\s*(\d{1,2}))?\s*)?ngay\s+(\d{1,2})\s+thang\s+(\d{1,2})\s+nam\s+(\d{4})/gi;
    let wm;
    while ((wm = wordDate.exec(n))) {
      push({ day: wm[3], month: wm[4], year: wm[5], hour: wm[1] || '', minute: wm[2] || '', index: wm.index, kind: 'explicit-strong', certainty: 'high', cue: cap(wm[0], 160) });
    }

    if (found.length) {
      found.sort((a, b) => a.index - b.index);
      // Ưu tiên candidate có “trước/chậm nhất/không muộn hơn” hơn “đến” chung chung.
      found.sort((a, b) => {
        const aw = /truoc|cham nhat|khong muon hon|muon nhat/.test(norm(a.cue)) ? 0 : 1;
        const bw = /truoc|cham nhat|khong muon hon|muon nhat/.test(norm(b.cue)) ? 0 : 1;
        return aw - bw || a.index - b.index;
      });
      return { ...found[0], alternatives: found.slice(1, 4) };
    }

    // Hạn tương đối: “trong vòng/trong thời hạn 05 ngày làm việc kể từ ...”
    const rel = n.match(/(?:trong\s+(?:vong|thoi han)\s+|trong\s+)(\d{1,3})\s+ngay(\s+lam\s+viec)?(?:\s+ke\s+tu\s+([^.;\n]{0,150}))?/i);
    if (rel) {
      const count = Number(rel[1]);
      const working = !!rel[2];
      const anchor = clean(rel[3] || '');
      let anchorIso = '';
      const dm = norm(anchor).match(/(\d{1,2})[\/\-.](\d{1,2})(?:[\/\-.](\d{2,4}))?/);
      if (dm) anchorIso = parseDate(dm[1], dm[2], dm[3], defaultYear) || '';
      if (!anchorIso && /ngay ban hanh|ngay ky/.test(norm(anchor)) && /^\d{4}-\d{2}-\d{2}$/.test(documentDate || '')) anchorIso = documentDate;
      const deadline = anchorIso ? addDaysIso(anchorIso, count, working) : '';
      return {
        deadline,
        deadlineDate: deadline,
        deadlineTime: '',
        deadlineISO: '',
        deadlineText: `trong ${count} ngày${working ? ' làm việc' : ''}${anchor ? ` kể từ ${anchor}` : ''}`,
        deadlineEvidence: cap(raw, 360),
        deadlineSource: deadline ? 'derived-explicit-relative' : 'relative',
        certainty: deadline ? 'medium' : 'relative',
        warning: working ? 'Ngày làm việc được tính theo thứ Hai–thứ Sáu; chưa loại trừ ngày nghỉ lễ.' : ''
      };
    }

    // Hạn định kỳ: giữ dạng mô tả, không ép thành một ngày tuyệt đối.
    const recurring = n.match(/(?:truoc|cham nhat|muon nhat)\s+ngay\s+(\d{1,2})\s+(?:hang|hang|hằng)\s+(thang|quy|nam)/i)
      || n.match(/(?:dinh ky|định kỳ)[^.;\n]{0,80}?(?:truoc|cham nhat)\s+ngay\s+(\d{1,2})/i);
    if (recurring) {
      return {
        deadline: '', deadlineDate: '', deadlineTime: '', deadlineISO: '',
        deadlineText: cap(recurring[0], 180), deadlineEvidence: cap(raw, 360),
        deadlineSource: 'recurring', certainty: 'relative'
      };
    }

    // Mốc thời gian định tính/phạm vi kỳ: lưu text để theo dõi, không tự suy thành ngày cụ thể.
    const vague = n.match(/\b(?:ngay sau khi[^.;\n]{0,100}|trong ngay(?:\s+lam viec)?|trong thang\s+\d{1,2}(?:[\/\-]\d{4})?|trong quy\s+(?:i|ii|iii|iv)(?:[\/\-]\d{4})?|dinh ky\s+(?:hang|hằng)\s+(?:tuan|thang|quy|nam)|theo tien do duoc giao)\b/i);
    if (vague) {
      return { deadline:'', deadlineDate:'', deadlineTime:'', deadlineISO:'', deadlineText:cap(vague[0],180), deadlineEvidence:cap(raw,360), deadlineSource:'period-relative', certainty:'relative' };
    }

    // Không bao giờ lấy ngày đứng đơn lẻ làm deadline.
    return {
      deadline: '', deadlineDate: '', deadlineTime: '', deadlineISO: '',
      deadlineText: '', deadlineEvidence: '', deadlineSource: 'none', certainty: 'none'
    };
  }

  // ---------------------------------------------------------------------------
  // 3) CẤU TRÚC VĂN BẢN / TÀI LIỆU
  // ---------------------------------------------------------------------------

  function collectDocuments(context) {
    const b = context?.documentBundle || {};
    const docs = [];
    const seen = new Set();
    const add = (role, name, text, weight) => {
      const s = clean(text);
      if (!s || s.length < 20) return;
      const key = norm(s).slice(0, 800);
      if (seen.has(key)) return;
      seen.add(key);
      docs.push({ role, name: String(name || ''), text: s, weight });
    };

    add('primary', b?.primaryDocument?.name || context?.symbol || 'Văn bản chính', b?.primaryDocument?.text, 1.0);
    for (const x of arr(b?.supportingDocuments)) {
      const name = x?.name || x?.fileName || '';
      const nn = norm(name);
      const role = /phu luc|bieu mau|mau bieu|danh sach|bang/.test(nn) ? 'appendix' : 'supporting';
      add(role, name, x?.text, role === 'appendix' ? 0.55 : 0.30);
    }

    // preview/combined chỉ dùng fallback để tránh nhân đôi nội dung.
    if (!docs.length) add('preview', 'Preview', context?.previewText, 0.8);
    if (!docs.length) add('combined', 'Combined', b?.combinedText, 0.7);
    return docs;
  }

  function bundleText(context) {
    return collectDocuments(context).map((d) => d.text).join('\n');
  }

  function foldLines(text) {
    return clean(text).split(/\n+/).map((raw, index) => ({ raw: clean(raw), n: norm(raw), index })).filter((x) => x.raw);
  }

  function looksHeading(line) {
    const s = clean(line), n = norm(s);
    if (!s || s.length > 240) return false;
    const hasTaskVerb = /\b(?:bao cao|cung cap|gui|nop|ra soat|kiem tra|trien khai|to chuc|thuc hien|xay dung|lap|tong hop|tham muu|cap nhat|niem yet|cong khai|bo tri|tham du|tham gia|phoi hop|de xuat|giai quyet|xu ly)\b/i.test(n);
    if (/^(?:\d+(?:\.\d+)*|[ivxlcdm]+|[a-z])[.)\-:]\s+(?:doi voi|đối với)/iu.test(s)) return true;
    if (/^(?:doi voi)\b/i.test(n)) return true;
    if (/^(?:i|ii|iii|iv|v|vi|vii|viii|ix|x)\.?\s+[A-ZÀ-Ỹ]/u.test(s) && !hasTaskVerb) return true;
    if (/^(?:ubnd|uy ban nhan dan|cac xa|cac phuong|cac so|cac don vi|cac co quan|trung tam|benh vien|cac truong|nha truong|phong\s+)/i.test(n) && !hasTaskVerb && s.length < 170) return true;
    if (/:$/.test(s) && s.length < 170 && !hasTaskVerb) return true;
    return false;
  }

  function stripHeadingPrefix(n) {
    return norm(n)
      .replace(/^(?:\d+(?:\.\d+)*|[ivxlcdm]+|[a-z])[.)\-:]\s*/i, '')
      .replace(/^[-–•]\s*/, '')
      .trim();
  }

  function extractNamedOtherLocality(text) {
    const n = norm(text);
    // Chỉ bắt khi UBND/xã/phường xuất hiện như chủ thể ở đầu hoặc ngay sau “đối với/giao/đề nghị/yêu cầu”.
    const m = n.match(/^(?:(?:doi voi|giao|de nghi|yeu cau)\s+)?(?:(?:chu tich|pho chu tich)\s+)?(?:ubnd|uy ban nhan dan)\s+(xa|phuong)\s+([a-z0-9 '\-]{2,60})/i);
    if (!m) return '';
    const full = `${m[1]} ${m[2]}`.trim();
    if (/^(?:xa|phuong)\s+(?:ra soat|thuc hien|bao cao|cung cap|tong hop|tham muu|trien khai|to chuc|phoi hop|kiem tra|de xuat|xu ly|giai quyet)\b/i.test(full)) return '';
    if (/ea\s*ly\b/.test(full)) return '';
    return cap(full.replace(/[,.;:].*$/, ''), 80);
  }

  function classifyHeadingSubject(line) {
    let n = stripHeadingPrefix(line);
    if (!n) return { scope: 'unknown', label: '' };

    if (/^(?:doi voi\s+)?(?:(?:chu tich|pho chu tich)\s+)?(?:ubnd|uy ban nhan dan)\s+xa\s+ea\s*ly\b/i.test(n) || /^(?:doi voi\s+)?xa\s+ea\s*ly\b/i.test(n)) {
      return { scope: 'ealy-direct', label: 'UBND xã Ea Ly' };
    }
    if (/^(?:doi voi\s+)?(?:(?:chu tich|pho chu tich)\s+)?(?:ubnd|uy ban nhan dan)\s+(?:cac\s+)?xa(?:,?\s*phuong)?(?:,?\s*dac\s*khu)?\b/i.test(n)
        || /^(?:doi voi\s+)?cac\s+(?:xa|phuong|dia phuong)\b/i.test(n)) {
      return { scope: 'local-group', label: 'UBND các xã, phường/địa phương' };
    }
    const otherLocality = extractNamedOtherLocality(n);
    if (otherLocality) return { scope: 'other-locality', label: otherLocality };
    if (OTHER_AGENCY_START.some((r) => r.test(n))) return { scope: 'other-agency', label: cap(line, 120) };
    return { scope: 'unknown', label: '' };
  }

  function splitClauses(line) {
    let raw = clean(line);
    if (!raw) return [];
    // Tách rõ các mệnh đề giao việc sau “trong đó: Giao/Đề nghị/Yêu cầu...”
    // để chủ thể của mệnh đề sau không bị lẫn với phần căn cứ/diễn giải phía trước.
    raw = raw
      .replace(/:\s*(?=(?:Giao|Đề nghị|Yêu cầu|Chỉ đạo|Phân công)\b)/giu, '; ')
      .replace(/\s+(?=(?:Giao|Đề nghị|Yêu cầu|Chỉ đạo|Phân công)\s+(?:UBND|Ủy ban nhân dân|các |Sở |Phòng |Trung tâm |Công an |Ban Chỉ huy))/giu, '; ');
    return raw
      .split(/\s*;\s*|(?<=[.!?])\s+|\s*,\s*(?=(?:đồng thời|trong đó|theo đó|riêng đối với|đối với)\b)/iu)
      .map(clean)
      .filter((x) => x.length >= 8);
  }

  function documentTargetsEa(text) {
    const n = norm(String(text || '').slice(0, 16000));
    if (!n) return false;
    return /kinh gui.{0,1200}(?:ubnd|uy ban nhan dan)\s+(?:(?:cac\s+)?xa(?:,?\s*phuong)?(?:,?\s*dac\s*khu)?|xa\s+ea\s*ly)\b/i.test(n)
      || /kinh gui.{0,1200}cac\s+dia\s+phuong\b/i.test(n);
  }

  function recipientSubjectFromClause(text, addressedToEa, inheritedScope = 'unknown', context = {}) {
    const n = norm(text);
    const prefix = n.slice(0, 260);
    const senderNorm = norm(context?.sender || '');
    const localCommuneParty = /\b(?:dang uy|dang bo)\s+xa\s+ea\s*ly\b/i.test(senderNorm) || /\b(?:dang uy|dang bo)\s+xa\s+ea\s*ly\b/i.test(n);

    const namedInternal = LOCAL_UNIT_DIRECT.find((x) => x.rx.test(n));
    if (namedInternal) return { scope: 'internal-unit', label: namedInternal.id, unitId: namedInternal.id, explicit: true };

    // Chủ thể sau “giao/đề nghị/yêu cầu/chỉ đạo/phân công”. Đây là recipient của nhiệm vụ.
    const lead = new RegExp(`${SUBJECT_LEAD_VERBS}\\s+(.{0,120})`, 'i').exec(prefix);
    if (lead) {
      const r = lead[1];
      if (EA_DIRECT.some((rx) => rx.test(r))) return { scope: 'ealy-direct', label: 'UBND xã Ea Ly', explicit: true };
      // Văn bản của Đảng ủy xã Ea Ly giao “UBND xã” là giao chính UBND xã Ea Ly,
      // không phải Đảng ủy UBND và cũng không phải một địa phương khác.
      if (localCommuneParty && /^ubnd\s+xa\b/i.test(r)) return { scope: 'ealy-direct', label: 'UBND xã Ea Ly', explicit: true };
      const loc = extractNamedOtherLocality(r);
      if (loc) return { scope: 'other-locality', label: loc, explicit: true };
      if (LOCAL_GROUP.some((rx) => rx.test(r))) return { scope: 'local-group', label: 'UBND các xã, phường/địa phương', explicit: true };
      // Nếu recipient bắt đầu bằng Sở/Phòng/Trung tâm... thì đây là chủ thể khác,
      // dù phần sau có nhắc “các đơn vị, địa phương”.
      if (OTHER_AGENCY_START.some((rx) => rx.test(r))) return { scope: 'other-agency', label: cap(r, 100), explicit: true };
      if (GENERIC_RECIPIENTS.some((rx) => rx.test(r))) {
        return { scope: addressedToEa ? 'recipient-group' : 'unknown', label: 'các cơ quan, đơn vị/địa phương', explicit: true };
      }
    }

    // Chủ thể ngay đầu câu.
    const head = classifyHeadingSubject(prefix);
    if (head.scope !== 'unknown') return { ...head, explicit: true };

    // “các cơ quan, đơn vị/địa phương ...” ở đầu câu và văn bản gửi xã.
    if (GENERIC_RECIPIENTS.some((rx) => new RegExp(`^(?:${rx.source})`, 'i').test(prefix))) {
      return { scope: addressedToEa ? 'recipient-group' : 'unknown', label: 'các cơ quan, đơn vị/địa phương', explicit: true };
    }

    return { scope: inheritedScope || 'unknown', label: '', explicit: false };
  }

  function buildScopedLines(text) {
    const lines = foldLines(text);
    let scope = 'unknown';
    let heading = '';
    let headingLabel = '';
    return lines.map((x) => {
      if (looksHeading(x.raw)) {
        const hs = classifyHeadingSubject(x.raw);
        if (hs.scope !== 'unknown') {
          scope = hs.scope;
          heading = x.raw;
          headingLabel = hs.label;
        }
      }
      const explicit = classifyHeadingSubject(x.raw);
      return {
        ...x,
        scope: explicit.scope !== 'unknown' ? explicit.scope : scope,
        explicitScope: explicit.scope,
        heading,
        headingLabel
      };
    });
  }

  function expandTaskWindow(scoped, index, baseScope) {
    const parts = [scoped[index]?.raw || ''];
    let chars = parts[0].length;
    for (let j = index + 1; j < scoped.length && j <= index + MAX_WINDOW_LINES; j++) {
      const next = scoped[j];
      if (!next || looksHeading(next.raw)) break;
      const explicit = classifyHeadingSubject(next.raw).scope;
      if (explicit !== 'unknown' && baseScope !== 'unknown' && explicit !== baseScope) break;
      if (next.scope !== 'unknown' && baseScope !== 'unknown' && next.scope !== baseScope) break;
      if (chars + next.raw.length > MAX_WINDOW_CHARS) break;
      parts.push(next.raw);
      chars += next.raw.length + 1;
      // Không kéo quá xa nếu đã gặp một dấu kết thúc rõ và dòng sau bắt đầu nhiệm vụ mới.
      if (/^(?:giao|de nghi|yeu cau|chi dao)\b/i.test(norm(next.raw)) && j > index + 1) break;
    }
    return clean(parts.join('\n'));
  }

  // ---------------------------------------------------------------------------
  // 4) NHẬN DIỆN NHIỆM VỤ
  // ---------------------------------------------------------------------------

  function appliesToEaScope(scope, addressedToEa) {
    if (scope === 'ealy-direct' || scope === 'local-group' || scope === 'internal-unit') return true;
    if (scope === 'recipient-group') return !!addressedToEa;
    return false;
  }

  function actionProfile(text) {
    const n = norm(text);
    // Các dòng tiêu đề/nơi nhận/căn cứ không phải nhiệm vụ dù có từ “gửi”, “thực hiện”.
    if (/^(?:kinh gui|noi nhan)\b/.test(n)) {
      return { strongCount:0, operationalCount:0, productCount:0, coordinationCount:0, informationCount:0, conditionalCount:0,
        hasStrong:false, hasOperational:false, hasProduct:false, hasCoordination:false, hasInformation:false, hasConditional:false };
    }
    if (/^(?:de co co so|nham co co so|de phuc vu|nham phuc vu)\b/.test(n) && !/\b(?:giao|de nghi|yeu cau|chi dao|phan cong)\b/.test(n)) {
      return { strongCount:0, operationalCount:0, productCount:0, coordinationCount:0, informationCount:0, conditionalCount:0,
        hasStrong:false, hasOperational:false, hasProduct:false, hasCoordination:false, hasInformation:false, hasConditional:false };
    }
    const hasDirectiveInside = /\b(?:giao|de nghi|yeu cau|chi dao|phan cong)\b/.test(n);
    if (/^(?:can cu|thuc hien\s+(?:cong van|quyet dinh|ke hoach|thong bao|nghi quyet))\b/.test(n) && !hasDirectiveInside) {
      return { strongCount:0, operationalCount:0, productCount:0, coordinationCount:0, informationCount:0, conditionalCount:0,
        hasStrong:false, hasOperational:false, hasProduct:false, hasCoordination:false, hasInformation:false, hasConditional:false };
    }

    // “chưa gửi/không gửi/chưa báo cáo...” mô tả trạng thái hoặc hậu quả, không phải động từ giao việc.
    const actionable = n.replace(/\b(?:chua|khong)\s+(?:gui|nop|bao cao|cung cap|hoan thanh|cap nhat|dang ky)\b/g, ' ');
    const strong = STRONG_ACTION_PATTERNS.filter((r) => r.test(actionable));
    const operational = OPERATIONAL_ACTION_PATTERNS.filter((r) => r.test(actionable));
    const product = PRODUCT_PATTERNS.filter((r) => r.test(n));
    const coordination = COORDINATION_PATTERNS.filter((r) => r.test(n));
    const information = INFORMATION_PATTERNS.filter((r) => r.test(n));
    const conditional = CONDITIONAL_PATTERNS.filter((r) => r.test(n));
    return {
      strongCount: strong.length,
      operationalCount: operational.length,
      productCount: product.length,
      coordinationCount: coordination.length,
      informationCount: information.length,
      conditionalCount: conditional.length,
      hasStrong: strong.length > 0,
      hasOperational: operational.length > 0,
      hasProduct: product.length > 0,
      hasCoordination: coordination.length > 0,
      hasInformation: information.length > 0,
      hasConditional: conditional.length > 0
    };
  }

  function hasOptionalResponseBySilence(text) {
    const n = norm(text);
    if (!n) return false;
    const broad = /\b(?:ubnd|uy ban nhan dan)\s+(?:cac\s+)?xa(?:,?\s*phuong)?/.test(n) || /\bcac\s+(?:dia phuong|xa,?\s*phuong)\b/.test(n);
    if (!broad) return false;
    return /khong\s+nhan\s+duoc[^.\n]{0,240}(?:phan hoi|phuc dap|tra loi)[^.\n]{0,260}(?:xem nhu|duoc xem la)[^.\n]{0,220}(?:khong co thong tin|khong phan hoi|chua duoc)/.test(n)
      || /(?:truong hop|neu)[^.\n]{0,180}khong\s+co[^.\n]{0,180}(?:khong can|khong phai)[^.\n]{0,120}(?:phan hoi|tra loi|gui|bao cao)/.test(n)
      || /neu\s+co[^.\n]{0,180}(?:thong tin|so lieu)[^.\n]{0,180}(?:cung cap|phan hoi|tra loi)/.test(n);
  }

  function optionalResponseCandidate(text) {
    const n = norm(text);
    return /\b(?:cung cap thong tin|phan hoi|phuc dap|tra loi|xac nhan thong tin)\b/.test(n);
  }

  function taskLabel(text, subject = '') {
    let s = clean(text).replace(/^[-–•\d.)\s]+/, '');
    // Bỏ động từ giao việc trước, sau đó mới bỏ tên chủ thể/đơn vị để tránh “Đề nghị UBND...” còn sót UBND.
    s = s.replace(/^(?:đề nghị|yêu cầu|giao|chỉ đạo|phân công)\s+/iu, '');
    s = s.replace(/^(?:(?:chủ tịch|phó chủ tịch)\s+)?(?:ubnd|ủy ban nhân dân)\s+(?:các\s+)?xã(?:,?\s*phường)?(?:,?\s*đặc khu)?\s*[:,-]?\s*/iu, '');
    s = s.replace(/^(?:các\s+đơn\s+vị|các\s+cơ\s+quan,?\s*đơn\s+vị(?:,?\s*địa\s+phương)?|các\s+địa\s+phương)\s+/iu, '');
    s = s.replace(/^(?:phòng kinh tế|phòng văn hóa\s*[-–]?\s*xã hội|văn phòng hdnd(?:\s+và|\s*&)?\s*ubnd|trung tâm phục vụ hành chính công|bộ phận một cửa|công an xã|ban chỉ huy quân sự xã|trạm y tế(?: xã)? ea ly|trường thcs ea ly|trường tiểu học ea ly|trường mẫu giáo ea ly)\s*[:,-]?\s*/iu, '');
    if (s.length < 18) s = clean(subject) || s;
    return s;
  }

  function candidateConfidence({ subject, profile, deadline, sourceRole, inheritedOnly, ambiguous }) {
    let score = 0;
    if (subject.explicit) score += 25;
    else if (!inheritedOnly && subject.scope !== 'unknown') score += 18;
    else if (subject.scope !== 'unknown') score += 10;
    if (subject.scope === 'ealy-direct' || subject.scope === 'local-group') score += 8;
    if (subject.scope === 'recipient-group') score += 3;
    if (profile.hasStrong) score += 22;
    else if (profile.hasOperational) score += 12;
    if (profile.hasProduct) score += 12;
    if (subject.explicit && profile.hasOperational && profile.hasProduct) score += 10;
    if (deadline?.certainty === 'high') score += 12;
    else if (deadline?.certainty === 'medium' || deadline?.certainty === 'relative') score += 6;
    if (profile.hasCoordination && !profile.hasStrong) score -= 10;
    if (profile.hasInformation && !profile.hasStrong && !profile.hasOperational) score -= 18;
    if (profile.hasConditional && !profile.hasStrong) score -= 10;
    if (sourceRole !== 'primary') score -= 20;
    if (ambiguous) score -= 25;
    return Math.max(0, Math.min(100, score));
  }

  function mentionsEaAsCoordinationObject(text, addressedToEa) {
    const n = norm(text);
    if (!/\b(?:phoi hop|lam viec|ho tro|tao dieu kien)\b/.test(n)) return false;
    if (/\b(?:phoi hop|lam viec|ho tro|tao dieu kien)[^.;\n]{0,140}?(?:(?:chu tich|pho chu tich)\s+)?(?:ubnd|uy ban nhan dan)\s+(?:xa\s+ea\s*ly|(?:cac\s+|tung\s+)?xa(?:,?\s*phuong)?(?:,?\s*dac\s*khu)?)\b/.test(n)) return true;
    if (addressedToEa && /\b(?:phoi hop|lam viec)[^.;\n]{0,100}?(?:cac\s+don\s+vi,?\s*dia\s+phuong|cac\s+dia\s+phuong)\b/.test(n)) return true;
    return false;
  }

  function findTaskCandidatesInDocument(context, doc) {
    const scoped = buildScopedLines(doc.text);
    const addressedToEa = documentTargetsEa(doc.text);
    const optionalBySilence = hasOptionalResponseBySilence(doc.text);
    const candidates = [];

    for (let i = 0; i < scoped.length; i++) {
      const x = scoped[i];
      if (looksHeading(x.raw)) continue;

      const clauses = splitClauses(x.raw);
      for (const clause of clauses.length ? clauses : [x.raw]) {
        const profile = actionProfile(clause);
        if (!profile.hasStrong && !profile.hasOperational && !profile.hasCoordination && !profile.hasInformation) continue;

        const subject = recipientSubjectFromClause(clause, addressedToEa, x.scope, context);
        const applies = appliesToEaScope(subject.scope, addressedToEa);
        const otherLocality = subject.scope === 'other-locality';
        const otherAgency = subject.scope === 'other-agency';

        // Nếu câu rõ chủ thể khác thì không biến cụm “phối hợp với UBND” thành task của xã.
        if (otherAgency || otherLocality) {
          // Chủ thể khác chủ trì nhưng yêu cầu phối hợp/làm việc với UBND xã: Ea Ly chỉ là phối hợp,
          // không nhận deadline/sản phẩm của chủ thể kia.
          if (otherAgency && mentionsEaAsCoordinationObject(clause, addressedToEa)) {
            candidates.push({
              raw: cap(clause, 520), window: cap(clause, 700), scope: 'coordination',
              subject: { scope: addressedToEa ? 'recipient-group' : 'local-group', label: 'UBND xã (vai trò phối hợp)', explicit: false },
              foreignLead: subject, profile, deadline: { deadline:'', deadlineDate:'', deadlineTime:'', deadlineText:'', deadlineEvidence:'', deadlineSource:'foreign-owner', certainty:'none' },
              heading: x.heading, sourceRole: doc.role, sourceName: doc.name, lineIndex: i, confidence: 84
            });
          } else {
            candidates.push({
              raw: cap(clause, 520), window: cap(clause, 700), scope: otherLocality ? 'other-locality' : 'foreign',
              subject, profile, deadline: extractDeadline(clause, context?.documentDate || ''), heading: x.heading,
              sourceRole: doc.role, sourceName: doc.name, lineIndex: i, confidence: 90
            });
          }
          continue;
        }

        const window = expandTaskWindow(scoped, i, x.scope);
        const deadline = extractDeadline(window, context?.documentDate || '');
        const nClause = norm(clause);
        const infoDominant = profile.hasInformation && !/\b(?:giao|de nghi|yeu cau|chi dao|phan cong)\b[^.;\n]{0,180}\b(?:bao cao|cung cap|nop|xac nhan|gop y|dang ky|cap nhat|ra soat)\b/i.test(nClause);
        const infoOnly = infoDominant || (profile.hasInformation && !profile.hasStrong && !profile.hasOperational);
        const coordinationOnly = profile.hasCoordination && !profile.hasStrong;
        const conditionalOnly = profile.hasConditional && !profile.hasStrong && !profile.hasOperational;

        let scope = 'ambiguous';
        if (infoOnly) {
          scope = 'information';
        } else if (!applies) {
          // Có hành động nhưng không chứng minh được giao cho Ea Ly: tuyệt đối không tự tạo task.
          scope = addressedToEa && (profile.hasStrong || profile.hasOperational) ? 'ambiguous' : 'information';
        } else if (conditionalOnly) {
          scope = 'information';
        } else if (coordinationOnly) {
          scope = 'coordination';
        } else if (profile.hasStrong || profile.hasOperational) {
          scope = 'direct';
        }

        // Công văn gửi chung “nếu có thì phản hồi, không phản hồi = không có thông tin”
        // là yêu cầu rà soát có điều kiện, không phải sản phẩm bắt buộc của Ea Ly.
        if (scope === 'direct' && optionalBySilence && ['local-group','recipient-group'].includes(subject.scope) && optionalResponseCandidate(`${clause} ${window}`)) {
          scope = 'coordination';
          deadline.deadline = ''; deadline.deadlineDate = ''; deadline.deadlineTime = ''; deadline.deadlineISO = '';
          deadline.deadlineText = ''; deadline.deadlineEvidence = ''; deadline.deadlineSource = 'conditional-optional'; deadline.certainty = 'none';
        }

        const confidence = candidateConfidence({
          subject, profile, deadline, sourceRole: doc.role,
          inheritedOnly: !subject.explicit, ambiguous: scope === 'ambiguous'
        });

        candidates.push({
          raw: cap(clause, 520), window: cap(window, 1200), scope, subject, profile, deadline,
          optionalResponse: optionalBySilence && scope === 'coordination' && optionalResponseCandidate(`${clause} ${window}`),
          heading: x.heading, sourceRole: doc.role, sourceName: doc.name, lineIndex: i, confidence
        });
      }
    }

    return candidates;
  }

  function dedupeCandidates(candidates) {
    const out = [];
    const seen = new Set();
    for (const c of candidates) {
      const k = `${c.scope}|${norm(c.raw).replace(/\d+/g, '#').slice(0, 180)}`;
      if (!k || seen.has(k)) continue;
      seen.add(k);
      out.push(c);
    }
    return out.slice(0, MAX_TASKS + 8);
  }

  function findTaskCandidates(context, docs) {
    const primary = docs.find((d) => d.role === 'primary') || docs[0];
    let candidates = primary ? findTaskCandidatesInDocument(context, primary) : [];

    // Không tự tạo nhiệm vụ từ tài liệu tham khảo thông thường.
    // Nhưng nếu văn bản chính dẫn chiếu Phụ lục/Danh sách/Biểu để xác định đối tượng, phạm vi hoặc hạn,
    // phụ lục là dữ liệu bắt buộc và phải được đọc cùng văn bản chính.
    const primaryNorm = norm(primary?.text || '');
    const needsAppendix = /\b(?:theo|tai|kem theo)[^.\n]{0,120}(?:phu luc|danh sach|bieu(?: mau)?)[^.\n]{0,160}(?:don vi|doi tuong|thoi han|han|noi dung|kem theo)?/.test(primaryNorm)
      || /\b(?:phu luc|danh sach|bieu(?: mau)?)\s+(?:kem theo|dinh kem)\b/.test(primaryNorm);
    if ((!primary || primary.text.length < 180 || needsAppendix) && docs.length > 1) {
      for (const d of docs.filter((x) => x !== primary)) {
        if (needsAppendix && !/(phu luc|danh sach|bieu|appendix)/.test(norm(d.name || '')) && d.role !== 'support') continue;
        candidates.push(...findTaskCandidatesInDocument(context, d));
      }
    }
    return dedupeCandidates(candidates);
  }

  // ---------------------------------------------------------------------------
  // 5) ROUTING: LĨNH VỰC -> ĐƠN VỊ
  // ---------------------------------------------------------------------------

  const DOMAIN_RULES = [
    // U140 - Văn phòng HĐND & UBND
    { id: 'general_administration', unit: 'U140', w: 44, rx: /\b(chuong trinh cong tac|lich cong tac|lich lam viec|lich hop|thong bao ket luan|ket luan cuoc hop|tham muu tong hop|cong tac van phong|hanh chinh quan tri|le tan|hau can|hoi nghi|phien hop)\b/i },
    { id: 'citizen_legal', unit: 'U140', w: 54, rx: /\b(tiep cong dan|khieu nai|to cao|kien nghi phan anh|don thu|phap che|pho bien giao duc phap luat|pbgdpl|hoa giai o co so|tiep can phap luat|boi thuong nha nuoc|xu ly vi pham hanh chinh)\b/i },
    { id: 'civil_status', unit: 'U140', w: 48, rx: /\b(ho tich|khai sinh|khai tu|ket hon|chung thuc|nuoi con nuoi|quoc tich)\b/i },
    { id: 'foreign_affairs', unit: 'U140', w: 52, rx: /\b(doi ngoai|ngoai vu|doan ra|doan vao|le tan doi ngoai|hop tac quoc te|nguoi nuoc ngoai)\b/i },
    { id: 'anti_corruption', unit: 'U140', w: 50, rx: /\b(phong chong tham nhung|tham nhung tieu cuc|ke khai tai san|kiem soat tai san thu nhap|thuc hanh tiet kiem chong lang phi)\b/i },

    // U141 - Phòng Kinh tế
    { id: 'finance_budget', unit: 'U141', w: 58, rx: /\b(tai chinh|ngan sach|nsnn|du toan|quyet toan|thu ngan sach|chi ngan sach|phan bo ngan sach|kinh phi|nguon von|kho bac|thue|phi le phi|gia ca|quan ly gia|tham dinh gia|bang gia|don gia|tai san cong|mua sam cong)\b/i },
    { id: 'public_investment', unit: 'U141', w: 64, rx: /\b(dau tu cong|ke hoach von|giai ngan|chu truong dau tu|du an dau tu|von dau tu|chu dau tu|dau thau|giai phong mat bang|boi thuong ho tro tai dinh cu)\b/i },
    { id: 'land_natural_resources', unit: 'U141', w: 62, rx: /\b(dat dai|quyen su dung dat|giay chung nhan quyen su dung dat|gcnqsd|dia chinh|thua dat|to ban do|han muc dat|chuyen muc dich su dung dat|thu hoi dat|giao dat|cho thue dat|tai nguyen|khoang san)\b/i },
    { id: 'environment', unit: 'U141', w: 50, rx: /\b(moi truong|rac thai|chat thai|nuoc thai|o nhiem|ve sinh moi truong|bao ve moi truong|bien doi khi hau)\b/i },
    { id: 'agriculture', unit: 'U141', w: 58, rx: /\b(nong nghiep|nong thon|trong trot|chan nuoi|thu y|bao ve thuc vat|lam nghiep|rung|thuy san|khuyen nong|hop tac xa|htx|oc?op|nong thon moi)\b/i },
    { id: 'irrigation_disaster', unit: 'U141', w: 64, rx: /\b(thuy loi|ho dap|kenh muong|phong chong thien tai|pctt|mua lon|bao so|con bao|bao manh|bao lut|ap thap nhiet doi|lu|ngap lut|han han|sat lo|ung pho su co thien tai|cap nuoc|nuoc sinh hoat)\b/i },
    { id: 'construction_planning', unit: 'U141', w: 60, rx: /\b(linh vuc xay dung|quan ly xay dung|cong trinh xay dung|du an xay dung|giay phep xay dung|cap phep xay dung|trat tu xay dung|quy hoach|kien truc|nha o|ha tang ky thuat|do thi|cong trinh|vat lieu xay dung|vlxd)\b/i },
    { id: 'transport', unit: 'U141', w: 54, rx: /\b(giao thong|duong bo|duong giao thong|hanh lang an toan duong bo|ket cau ha tang giao thong|ben bai|phuong tien van tai)\b/i },
    { id: 'industry_trade', unit: 'U141', w: 58, rx: /\b(cong thuong|thuong mai|cong nghiep|tieu thu cong nghiep|cum cong nghiep|ccn|cho dan sinh|cho truyen thong|cho dau moi|quan ly cho|kinh doanh|doanh nghiep|ho kinh doanh|dien luc|an toan dien|xang dau|hang hoa|quan ly thi truong)\b/i },

    // U142 - Phòng Văn hóa - Xã hội
    { id: 'internal_affairs', unit: 'U142', w: 60, rx: /\b(noi vu|to chuc bo may|bien che|can bo cong chuc|vien chuc|vi tri viec lam|tuyen dung|bo nhiem|dieu dong|luan chuyen|thi dua khen thuong|ky luat|tien luong|che do chinh sach can bo)\b/i },
    { id: 'admin_reform', unit: 'U142', w: 62, rx: /\b(cai cach hanh chinh|cchc|chi so cchc|par index|sipas|ky luat ky cuong hanh chinh|kiem soat thu tuc hanh chinh)\b/i },
    { id: 'records_archives', unit: 'U142', w: 60, rx: /\b(van thu|luu tru|lap ho so cong viec|chinh ly tai lieu|nop luu|ho so dien tu|tai lieu luu tru|con dau)\b/i },
    { id: 'digital_science', unit: 'U142', w: 60, rx: /\b(chuyen doi so|cong nghe thong tin|cntt|khoa hoc cong nghe|doi moi sang tao|ha tang so|nen tang so|du lieu so|co so du lieu|an toan thong tin|chu ky so)\b/i },
    { id: 'education', unit: 'U142', w: 64, rx: /\b(giao duc|dao tao|truong hoc|hoc sinh|giao vien|mam non|tieu hoc|thcs|pho cap giao duc|xoa mu chu|y te hoc duong|nam hoc|tuyen sinh)\b/i },
    { id: 'health', unit: 'U142', w: 62, rx: /\b(y te|suc khoe|kham chua benh|dich benh|tiem chung|dan so|an toan thuc pham|attp|bao hiem y te|bhyt|duoc|benh truyen nhiem|ve sinh an toan thuc pham)\b/i },
    { id: 'labor_social', unit: 'U142', w: 62, rx: /\b(lao dong|viec lam|bao hiem xa hoi|bhxh|nguoi co cong|bao tro xa hoi|an sinh xa hoi|giam ngheo|ho ngheo|ho can ngheo|tre em|binh dang gioi|phong chong te nan xa hoi|nguoi cao tuoi|nguoi khuyet tat)\b/i },
    { id: 'culture_sports_tourism', unit: 'U142', w: 58, rx: /\b(van hoa|gia dinh|the thao|du lich|di san|le hoi|quang cao|thong tin co so|truyen thanh|phong trao toan dan doan ket|doi song van hoa)\b/i },
    { id: 'religion_ethnicity_youth', unit: 'U142', w: 54, rx: /\b(tin nguong|ton giao|dan toc|thanh nien|cong tac thanh nien|hoi quan chung|to chuc hoi)\b/i },

    // U120 - Trung tâm PVHCC: chỉ ưu tiên khi đúng nhiệm vụ một cửa/TTHC tác nghiệp trực tiếp.
    { id: 'one_stop', unit: 'U120', w: 78, rx: /\b(trung tam phuc vu hanh chinh cong|bo phan mot cua|mot cua|mot cua lien thong|tiep nhan ho so|tra ket qua|giai quyet thu tuc hanh chinh|dich vu cong truc tuyen|ho so thu tuc hanh chinh|so hoa ho so|so hoa ket qua|thanh toan truc tuyen)\b/i },

    // U340 - Công an xã
    { id: 'security_police', unit: 'U340', w: 72, rx: /\b(an ninh trat tu|antt|toi pham|ma tuy|hinh su|quan ly cu tru|cu tru|can cuoc|dinh danh dien tu|vneid|de an 06|du lieu dan cu|phong chay chua chay|pccc|cuu nan cuu ho|cnch|an toan giao thong|atgt|trat tu an toan giao thong|vu khi vat lieu no)\b/i },

    // U360 - BCHQS xã
    { id: 'military_defense', unit: 'U360', w: 72, rx: /\b(quoc phong|quan su|nghia vu quan su|nvqs|dan quan tu ve|du bi dong vien|tuyen quan|giao quan|san sang chien dau|phong thu dan su|dong vien|luc luong vu trang)\b/i },

    // U260 - HĐND xã
    { id: 'people_council', unit: 'U260', w: 74, rx: /\b(hoi dong nhan dan|hdnd|thuong truc hdnd|ban kinh te ngan sach hdnd|ban van hoa xa hoi hdnd|ky hop hdnd|nghi quyet hdnd|giam sat cua hdnd|tiep xuc cu tri)\b/i }
  ];

  const LOCAL_UNIT_DIRECT = [
    { id: 'U140', rx: /(?:giao|de nghi|yeu cau|phan cong)\s+(?:van phong hdnd(?:\s+va|\s*&)?\s*ubnd|van phong hdnd va ubnd|van phong)\b/i },
    { id: 'U141', rx: /(?:giao|de nghi|yeu cau|phan cong)\s+phong kinh te\b/i },
    { id: 'U142', rx: /(?:giao|de nghi|yeu cau|phan cong)\s+(?:phong van hoa\s*[-–]?\s*xa hoi|tram y te(?:\s+xa)?(?:\s+ea\s*ly)?|(?:truong\s+)?(?:thcs|trung hoc co so|tieu hoc|mau giao|mam non)(?:\s+ea\s*ly)?)\b/i },
    { id: 'U120', rx: /(?:giao|de nghi|yeu cau|phan cong)\s+(?:trung tam phuc vu hanh chinh cong|bo phan mot cua)\b/i },
    { id: 'U183', rx: /(?:giao|de nghi|yeu cau|phan cong)\s+trung tam cung ung\b/i },
    { id: 'U340', rx: /(?:giao|de nghi|yeu cau|phan cong)\s+cong an(?:\s+xa)?\b/i },
    { id: 'U360', rx: /(?:giao|de nghi|yeu cau|phan cong)\s+(?:ban chi huy quan su|bchqs)(?:\s+xa)?\b/i },
    { id: 'U260', rx: /(?:giao|de nghi|yeu cau|phan cong)\s+(?:thuong truc\s+)?hdnd(?:\s+xa)?\b/i },
    { id: 'DUUBND', rx: /(?:giao|de nghi|yeu cau|phan cong)\s+(?:(?:dang uy|dang bo)\s+(?:ubnd|uy ban nhan dan))(?:\s+xa)?\b/i }
  ];

  function cleanRule(rule) {
    const weights = rule?.weights || {};
    return {
      ...rule,
      enabled: rule?.enabled !== false,
      priority: safeNum(rule?.priority, 0),
      minScore: Math.max(0, safeNum(rule?.minScore, 0)),
      match: {
        senderAny: arr(rule?.match?.senderAny),
        subjectAny: arr(rule?.match?.subjectAny),
        contentAny: arr(rule?.match?.contentAny),
        attachmentAny: arr(rule?.match?.attachmentAny),
        excludeAny: arr(rule?.match?.excludeAny)
      },
      weights: {
        sender: safeNum(weights.sender, 8),
        subject: safeNum(weights.subject, 12),
        content: safeNum(weights.content, 18),
        attachment: safeNum(weights.attachment, 4)
      }
    };
  }

  function phraseMatches(haystack, phrases) {
    const h = norm(haystack);
    if (!h) return [];
    return uniq(arr(phrases).filter((raw) => {
      const p = norm(raw);
      return p && h.includes(p);
    }).map(String));
  }

  function allowedUnitSet(config, availableUnits) {
    const allowed = new Set(arr(availableUnits).map((u) => u?.value || u?.id).filter((x) => /^(?:U\d+|DUUBND)$/.test(x || '')));
    for (const u of arr(config?.units)) if (/^(?:U\d+|DUUBND)$/.test(u?.id || '')) allowed.add(u.id);
    return allowed;
  }

  function scoreUnits(context, config, availableUnits, taskText, evidenceText = '') {
    const allowed = allowedUnitSet(config, availableUnits);
    const scores = new Map();
    const reasons = new Map();
    const add = (id, points, reason) => {
      if (!allowed.has(id) || !points) return;
      scores.set(id, (scores.get(id) || 0) + points);
      if (!reasons.has(id)) reasons.set(id, []);
      reasons.get(id).push({ points, reason });
    };

    const t = norm(`${taskText}\n${evidenceText}`);
    const subject = norm(context?.trichYeu || '');
    const sender = norm(context?.sender || '');
    const attachmentText = arr(context?.attachmentNames).join(' | ');

    // 1. Giao đích danh đơn vị nội bộ: hard evidence.
    for (const x of LOCAL_UNIT_DIRECT) if (x.rx.test(t)) add(x.id, 220, 'Văn bản giao/đề nghị trực tiếp đơn vị này.');
    // Đảng ủy UBND là tổ chức riêng với Đảng ủy xã. Không suy từ cụm “Đảng ủy xã” sang DUUBND.
    const mentionsPartyUbnd = /\b(?:dang uy|dang bo)\s+(?:ubnd|uy ban nhan dan)\b/i.test(t);
    const onlyCommuneParty = /\bdang uy\s+xa\b/i.test(t) && !mentionsPartyUbnd;
    if (onlyCommuneParty) { scores.delete('DUUBND'); reasons.delete('DUUBND'); }

    // 2. Lĩnh vực của chính nhiệm vụ.
    for (const d of DOMAIN_RULES) {
      if (d.rx.test(t)) add(d.unit, d.w, `Lĩnh vực nhiệm vụ: ${d.id}.`);
      // Trích yếu chỉ là prior yếu.
      if (d.rx.test(subject)) add(d.unit, Math.round(d.w * 0.22), `Trích yếu liên quan: ${d.id}.`);
    }

    // 3. Cơ quan gửi là prior rất yếu, không được lật ngược nội dung nhiệm vụ.
    if (/so tai chinh|kho bac|thue/.test(sender)) add('U141', 8, 'Cơ quan gửi thuộc khối tài chính.');
    if (/so noi vu/.test(sender)) add('U142', 7, 'Cơ quan gửi thuộc khối nội vụ.');
    if (/so giao duc/.test(sender)) add('U142', 7, 'Cơ quan gửi thuộc khối giáo dục.');
    if (/so y te/.test(sender)) add('U142', 7, 'Cơ quan gửi thuộc khối y tế.');
    if (/so khoa hoc|so van hoa/.test(sender)) add('U142', 6, 'Cơ quan gửi thuộc khối văn hóa/KHCN.');
    if (/cong an/.test(sender)) add('U340', 8, 'Cơ quan gửi là Công an.');
    if (/bo chi huy quan su|quan su/.test(sender)) add('U360', 8, 'Cơ quan gửi thuộc quân sự.');

    // 4. Rule cấu hình của người dùng: ưu tiên taskText, toàn văn chỉ hỗ trợ rất nhẹ.
    const legacyRules = arr(config?.rules).map(cleanRule).filter((r) => r.enabled && /^(?:U\d+|DUUBND)$/.test(r.mainUnit || ''));
    const wholeWeak = `${context?.trichYeu || ''}\n${context?.sender || ''}\n${evidenceText || ''}`;
    const coordination = new Map();
    const view = new Map();
    const matched = [];

    for (const rule of legacyRules) {
      if (!allowed.has(rule.mainUnit)) continue;
      if (phraseMatches(`${taskText}\n${wholeWeak}`, rule.match.excludeAny).length) continue;

      const taskBody = phraseMatches(taskText, rule.match.contentAny);
      const sub = phraseMatches(context?.trichYeu, rule.match.subjectAny);
      const snd = phraseMatches(context?.sender, rule.match.senderAny);
      const att = phraseMatches(attachmentText, rule.match.attachmentAny);
      const any = rule.match.senderAny.length || rule.match.subjectAny.length || rule.match.contentAny.length || rule.match.attachmentAny.length;
      if (any && !(taskBody.length || sub.length || snd.length || att.length)) continue;

      let points = 0;
      points += Math.min(taskBody.length, 5) * Math.max(0, rule.weights.content);
      points += Math.min(sub.length, 3) * Math.max(0, rule.weights.subject);
      points += Math.min(snd.length, 2) * Math.max(0, rule.weights.sender);
      points += Math.min(att.length, 2) * Math.max(0, rule.weights.attachment);
      points += Math.max(0, Math.min(8, rule.priority / 25));
      if (points < rule.minScore) continue;

      add(rule.mainUnit, points, `Rule cấu hình: ${rule.name || rule.id || rule.mainUnit}.`);
      for (const id of arr(rule.coordinationUnits)) if (allowed.has(id) && id !== rule.mainUnit) coordination.set(id, (coordination.get(id) || 0) + points);
      for (const id of arr(rule.viewUnits)) if (allowed.has(id) && id !== rule.mainUnit) view.set(id, (view.get(id) || 0) + points);
      matched.push({ rule, score: points });
    }
    if (onlyCommuneParty) { scores.delete('DUUBND'); reasons.delete('DUUBND'); }

    const ranking = [...scores.entries()].sort((a, b) => b[1] - a[1]);
    const top = ranking[0]?.[1] || 0;
    const second = ranking[1]?.[1] || 0;
    const hardDirect = ranking.some(([id]) => (reasons.get(id) || []).some((r) => r.points >= 200));

    // Không fallback U140. Không đủ căn cứ => null.
    let mainUnit = null;
    if (ranking.length && (top >= 35 || hardDirect)) mainUnit = ranking[0][0];

    const gap = top - second;
    const routingAmbiguous = !!mainUnit && second > 0 && gap < Math.max(10, top * 0.18);
    if (routingAmbiguous && !hardDirect) mainUnit = null;

    const coord = [...coordination.entries()]
      .filter(([id]) => id !== mainUnit)
      .sort((a, b) => b[1] - a[1])
      .filter(([, s]) => s >= Math.max(18, top * 0.22))
      .slice(0, 4).map(([id]) => id);
    const views = [...view.entries()]
      .filter(([id]) => id !== mainUnit && !coord.includes(id))
      .sort((a, b) => b[1] - a[1])
      .slice(0, 4).map(([id]) => id);

    return {
      mainUnit,
      coordinationUnits: uniq(coord),
      viewUnits: uniq(views),
      ranking,
      top,
      second,
      gap,
      routingAmbiguous,
      reasons: Object.fromEntries([...reasons.entries()]),
      matched: matched.sort((a, b) => b.score - a.score)
    };
  }

  function rawHasDeadlineCue(text) {
    return /\b(?:truoc|cham nhat|muon nhat|khong muon hon|den het|thoi han|han|thoi gian hoan thanh|thoi diem hoan thanh)\b/i.test(norm(text));
  }

  function productFamily(text) {
    const n = norm(text);
    const f = [];
    if (/\b(thong tin|so lieu|du lieu|tai lieu)\b/.test(n)) f.push('data');
    if (/\bbao cao\b/.test(n)) f.push('report');
    if (/\b(y kien|gop y|phan bien)\b/.test(n)) f.push('opinion');
    if (/\b(danh sach|bieu mau|bao bieu)\b/.test(n)) f.push('list-form');
    if (/\b(ke hoach|phuong an|de an)\b/.test(n)) f.push('plan');
    if (/\b(ho so|van ban|du thao)\b/.test(n)) f.push('document');
    if (/\b(dang ky|ke khai)\b/.test(n)) f.push('registration');
    return f;
  }

  function collapseDirectCandidates(list) {
    const src = [...list].sort((a, b) => (a.lineIndex || 0) - (b.lineIndex || 0));
    const out = [];
    for (const c of src) {
      const prev = out[out.length - 1];
      if (prev) {
        const sameSubject = (prev.subject?.scope || '') === (c.subject?.scope || '');
        const adjacent = Math.abs((prev.lineIndex || 0) - (c.lineIndex || 0)) <= 1;
        const pd = prev.deadline?.deadline || prev.deadline?.deadlineText || '';
        const cd = c.deadline?.deadline || c.deadline?.deadlineText || '';
        const sameDeadline = !!pd && pd === cd;
        const pCue = rawHasDeadlineCue(prev.raw), cCue = rawHasDeadlineCue(c.raw);
        const pf = productFamily(prev.raw), cf = productFamily(c.raw);
        const sharedFamily = pf.some((x) => cf.includes(x));
        // Mệnh đề trước nêu “cung cấp ...”, mệnh đề ngay sau chỉ rõ “gửi ... trước ngày ...”
        // thường là một nhiệm vụ, không nên tạo 2 task trùng nhau.
        if (sameSubject && adjacent && sameDeadline && sharedFamily && pCue !== cCue) {
          const keep = cCue ? c : prev;
          const extra = cCue ? prev : c;
          keep.mergedEvidence = uniq([...(keep.mergedEvidence || []), extra.raw]);
          out[out.length - 1] = keep;
          continue;
        }
      }
      out.push(c);
    }
    return out;
  }

  // ---------------------------------------------------------------------------
  // 6) TỔNG HỢP KẾT QUẢ
  // ---------------------------------------------------------------------------

  function confidenceLabel(score) {
    if (score >= 85) return 'high';
    if (score >= 70) return 'medium-high';
    if (score >= 50) return 'review';
    return 'low';
  }

  function taskScopeFromCandidates(candidates) {
    if (candidates.some((x) => x.scope === 'direct')) return 'direct';
    if (candidates.some((x) => x.scope === 'coordination')) return 'coordination';
    if (candidates.some((x) => x.scope === 'ambiguous')) return 'ambiguous';
    if (candidates.some((x) => x.scope === 'other-locality')) return 'other-locality';
    return 'information';
  }

  function summaryFrom(context, candidates, scope) {
    const direct = candidates.filter((x) => x.scope === 'direct');
    if (direct.length) {
      const withDeadline = direct.filter((x) => x.deadline?.deadline || x.deadline?.deadlineText).length;
      return `Phát hiện ${direct.length} nội dung giao trực tiếp áp dụng cho UBND xã${withDeadline ? `; ${withDeadline} nội dung có thông tin thời hạn` : ''}.`;
    }
    if (scope === 'coordination') return 'UBND xã được xác định ở vai trò phối hợp; chưa phát hiện sản phẩm độc lập phải nộp.';
    if (scope === 'other-locality') return 'Nội dung nhiệm vụ phát hiện được giao cho địa phương khác, không phải UBND xã Ea Ly.';
    if (scope === 'ambiguous') return 'Có câu mang tính giao việc nhưng chưa đủ bằng chứng xác định chắc chắn chủ thể áp dụng cho UBND xã Ea Ly.';
    return cap(context?.trichYeu || 'Không phát hiện nhiệm vụ bắt buộc áp dụng trực tiếp cho UBND xã trong phần văn bản đã đọc.', 300);
  }

  function instructionFor(mainName, directCandidates, scope, bestDeadline) {
    if (scope === 'direct') {
      const parts = [];
      for (const c of (directCandidates || []).slice(0, MAX_TASKS)) {
        const t = taskLabel(c?.raw || '');
        if (!t) continue;
        const d = c?.deadline || {};
        const dueDate = d.deadlineDate ? d.deadlineDate.split('-').reverse().join('/') : '';
        let part = t.replace(/[.;]+$/,'').trim();
        const folded = norm(part);
        if (dueDate && !folded.includes(norm(dueDate)) && !/hoàn thành|trước ngày|hạn/.test(folded)) part += ` (hoàn thành trước ${dueDate}${d.deadlineTime ? ` lúc ${d.deadlineTime}` : ''})`;
        if (part && !parts.some(x => norm(x) === norm(part))) parts.push(part);
      }
      const body = parts.length ? parts.join('; ') : 'thực hiện nội dung văn bản';
      if (!mainName) return `Chưa đủ căn cứ chọn đơn vị xử lý chính. Nội dung cần thực hiện: ${body}.`.replace(/\.\s*\./g, '.').trim();
      return `Giao ${mainName} chủ trì ${body.charAt(0).toLowerCase() + body.slice(1)}.`.replace(/\.\s*\./g, '.').trim();
    }
    if (scope === 'coordination') return `${mainName ? `Giao ${mainName} ` : ''}tiếp nhận, theo dõi và phối hợp theo nội dung văn bản; chưa phát sinh sản phẩm độc lập của UBND xã.`.trim();
    if (scope === 'ambiguous') return 'Chưa tự áp dụng: cần kiểm tra lại chủ thể/nhiệm vụ trước khi chuyển xử lý.';
    if (scope === 'other-locality') return 'Văn bản có nội dung giao địa phương khác; không tự tạo nhiệm vụ cho UBND xã Ea Ly.';
    return `${mainName ? `Giao ${mainName} ` : ''}tiếp nhận, nghiên cứu để biết; chưa phát hiện nhiệm vụ bắt buộc.`.trim();
  }

  function analyzeIncoming(context, config, availableUnits) {
    const docs = collectDocuments(context);
    const primaryText = docs.find((d) => d.role === 'primary')?.text || docs[0]?.text || '';
    const candidates = findTaskCandidates(context, docs);
    const detectedDirect = collapseDirectCandidates(candidates.filter((x) => x.scope === 'direct')).sort((a, b) => b.confidence - a.confidence);
    const appendixMissing = context?.documentBundle?.appendixRequiredMissing === true;
    const direct = appendixMissing ? [] : detectedDirect;
    const coord = candidates.filter((x) => x.scope === 'coordination');
    const ambiguous = candidates.filter((x) => x.scope === 'ambiguous');
    const otherLocality = candidates.filter((x) => x.scope === 'other-locality');
    const taskScope = appendixMissing ? 'ambiguous' : taskScopeFromCandidates(candidates);
    const optionalResponse = candidates.some((x) => x.optionalResponse === true);

    const taskText = direct.map((x) => x.raw).join('\n');
    const evidenceText = direct.map((x) => x.window).join('\n');
    const routing = scoreUnits(context, config, availableUnits, taskText, evidenceText);
    const units = new Map(arr(config?.units).map((u) => [u.id, u.name]));
    const mainUnit = taskScope === 'direct' ? routing.mainUnit : (taskScope === 'coordination' ? routing.mainUnit : null);
    const mainName = mainUnit ? (units.get(mainUnit) || mainUnit) : '';

    const tasks = direct.slice(0, MAX_TASKS).map((c, index) => {
      const d = c.deadline || {};
      return {
        task: taskLabel(c.raw, context?.trichYeu),
        action: '',
        product: c.profile?.hasProduct ? 'Có sản phẩm/đầu ra được nhận diện trong câu nhiệm vụ.' : '',
        deadline: d.deadline || '',
        deadlineDate: d.deadlineDate || d.deadline || '',
        deadlineTime: d.deadlineTime || '',
        deadlineISO: d.deadlineISO || '',
        deadlineText: d.deadlineText || '',
        deadlineEvidence: d.deadlineEvidence || '',
        deadlineSource: d.deadlineSource || 'none',
        deadlineCertainty: d.certainty || 'none',
        responsibleUnit: mainUnit,
        scope: 'direct',
        subjectScope: c.subject?.scope || '',
        subjectLabel: c.subject?.label || '',
        evidence: c.mergedEvidence?.length ? `${c.mergedEvidence.join(' | ')} | ${c.raw}` : c.raw,
        sourceDocument: c.sourceName || '',
        sourceRole: c.sourceRole || '',
        ruleConfidence: c.confidence,
        trackRecommended: true,
        index: index + 1
      };
    });

    const bestTask = direct[0] || null;
    const bestDeadlineTask = direct.find((x) => x.deadline?.deadline || x.deadline?.deadlineText) || null;
    const bestDeadline = bestDeadlineTask?.deadline || null;
    const unreadable = Number(context?.documentBundle?.stats?.unreadableCount || 0);
    const scan = Number(context?.documentBundle?.stats?.scanSkippedCount || 0);

    let score = 0;
    if (taskScope === 'direct') {
      score = bestTask?.confidence || 55;
      if (routing.mainUnit) score += 8;
      if (routing.routingAmbiguous) score -= 18;
      if (!routing.mainUnit) score -= 12;
    } else if (taskScope === 'coordination') score = 78;
    else if (taskScope === 'other-locality') score = 88;
    else if (taskScope === 'ambiguous') score = 48;
    else {
      const explicitInfo = candidates.some((x) => x.scope === 'information' && x.profile?.hasInformation);
      score = explicitInfo ? 82 : (primaryText.length >= 250 ? 72 : 62);
    }

    if (unreadable || scan) score -= 18;
    if (!primaryText) score = Math.min(score, 45);
    else if (primaryText.length < 180 && !candidates.length) score = Math.min(score, 52);
    score = Math.max(0, Math.min(96, Math.round(score)));

    const requiresReview = score < 70
      || unreadable > 0
      || scan > 0
      || taskScope === 'ambiguous'
      || appendixMissing
      || (taskScope === 'direct' && !routing.mainUnit)
      || routing.routingAmbiguous;

    const signals = [];
    if (direct.length) signals.push(`Phát hiện ${direct.length} nhiệm vụ trực tiếp áp dụng cho UBND xã.`);
    else if (coord.length) signals.push('UBND xã được xác định ở vai trò phối hợp; không tự gán hạn của đơn vị chủ trì khác.');
    else if (otherLocality.length) signals.push('Phát hiện nhiệm vụ của địa phương khác; không tạo task cho Ea Ly.');
    else if (ambiguous.length) signals.push('Có câu giao việc nhưng chủ thể áp dụng chưa đủ chắc chắn.');
    else signals.push('Không phát hiện sản phẩm/nhiệm vụ độc lập bắt buộc cho UBND xã trong tài liệu chính.');

    if (bestDeadline?.deadlineDate || bestDeadline?.deadlineText) {
      signals.push(`Hạn: ${bestDeadline.deadlineDate || bestDeadline.deadlineText}${bestDeadline.deadlineTime ? ` ${bestDeadline.deadlineTime}` : ''}.`);
    }
    if ((taskScope === 'direct' || taskScope === 'coordination') && routing.mainUnit) {
      const rr = routing.reasons?.[routing.mainUnit]?.[0]?.reason;
      signals.push(`XLC: ${units.get(routing.mainUnit) || routing.mainUnit}${rr ? ` · ${rr}` : ''}`);
    }
    if (routing.routingAmbiguous) signals.push('Điểm routing giữa hai đơn vị đứng đầu quá sát; yêu cầu chọn thủ công.');
    if (appendixMissing) signals.push('Văn bản dẫn chiếu Phụ lục/Danh sách/Biểu bắt buộc nhưng chưa đọc đủ; không tự xác định nhiệm vụ hoặc hạn của Ea Ly.');
    if (unreadable || scan) signals.push('Có tệp/scan chưa đọc được text đầy đủ; phải kiểm tra lại trước khi áp dụng.');

    return {
      workflow: 'leader-incoming',
      actionRequired: direct.length > 0,
      mainUnit,
      coordinationUnits: taskScope === 'direct' ? routing.coordinationUnits.filter((x) => x !== mainUnit) : [],
      viewUnits: [],
      instruction: optionalResponse && taskScope === 'coordination'
        ? `${mainName ? `Giao ${mainName} ` : ''}rà soát; chỉ tham mưu phản hồi khi có thông tin liên quan theo đề nghị của văn bản.`.trim()
        : instructionFor(mainName, direct, taskScope, bestDeadline),
      tasks,
      taskScope,
      trackRecommended: direct.length > 0,
      trackingReason: direct.length
        ? 'UBND xã có nhiệm vụ/sản phẩm trực tiếp cần theo dõi.'
        : taskScope === 'coordination'
          ? (optionalResponse ? 'Yêu cầu phản hồi có điều kiện; không phản hồi được hiểu là không có thông tin nên không tự tạo nhiệm vụ theo dõi.' : 'UBND xã chỉ phối hợp; chưa có sản phẩm độc lập phải nộp.')
          : taskScope === 'other-locality'
            ? 'Nhiệm vụ thuộc địa phương khác.'
            : taskScope === 'ambiguous'
              ? 'Chủ thể/nhiệm vụ chưa đủ chắc chắn; không tự thêm Sổ theo dõi.'
              : 'Không phát hiện nhiệm vụ bắt buộc; có thể tạo thủ công nếu lãnh đạo cần theo dõi.',
      reason: optionalResponse && taskScope === 'coordination' ? 'Văn bản đề nghị rà soát/cung cấp thông tin nhưng quy định không phản hồi được hiểu là không có thông tin; Ea Ly không có sản phẩm bắt buộc nếu không phát sinh dữ liệu.' : summaryFrom(context, candidates, taskScope),
      confidence: Number((score / 100).toFixed(2)),
      confidenceScore: score,
      confidenceLabel: confidenceLabel(score),
      requiresReview,
      signals: signals.slice(0, 7),
      recipientNames: [],
      reviewSummary: requiresReview ? 'Rule bảo thủ: có điểm chưa đủ chắc chắn, cần người dùng kiểm tra trước khi áp dụng.' : '',
      reviewIssues: [
        ...(routing.routingAmbiguous ? [{ severity: 'medium', category: 'Routing', detail: 'Hai đơn vị có điểm gần nhau; không tự chọn XLC.' }] : []),
        ...((taskScope === 'direct' && !routing.mainUnit) ? [{ severity: 'medium', category: 'XLC', detail: 'Có nhiệm vụ trực tiếp nhưng chưa đủ căn cứ xác định đơn vị xử lý chính.' }] : []),
        ...(appendixMissing ? [{ severity: 'high', category: 'Phụ lục', detail: 'Văn bản dẫn chiếu Phụ lục/Danh sách/Biểu bắt buộc nhưng chưa đọc đủ; không tự tạo nhiệm vụ/hạn.' }] : []),
        ...((unreadable || scan) ? [{ severity: 'high', category: 'Dữ liệu', detail: 'Có tệp/scan chưa đọc được đầy đủ.' }] : [])
      ],
      provider: 'local-rule-pro',
      providerLabel: 'Local Rule Pro',
      model: `Rule Engine ${VERSION}`,
      localRuleMeta: {
        version: VERSION,
        documentCount: docs.length,
        primaryLength: primaryText.length,
        ranking: routing.ranking.slice(0, 6).map(([unit, s]) => ({ unit, score: Number(s.toFixed(1)), reasons: (routing.reasons?.[unit] || []).slice(0, 4) })),
        candidates: candidates.slice(0, 12).map((x) => ({
          scope: x.scope,
          subjectScope: x.subject?.scope || '',
          subjectLabel: x.subject?.label || '',
          text: x.raw,
          deadline: x.deadline?.deadline || '',
          deadlineTime: x.deadline?.deadlineTime || '',
          deadlineText: x.deadline?.deadlineText || '',
          deadlineEvidence: x.deadline?.deadlineEvidence || '',
          sourceRole: x.sourceRole,
          sourceName: x.sourceName,
          confidence: x.confidence
        }))
      }
    };
  }

  // ---------------------------------------------------------------------------
  // 7) VĂN BẢN ĐI / FILE TRÌNH KÝ - kiểm tra text nhanh
  // ---------------------------------------------------------------------------

  function analyzeOutgoing(context) {
    const text = bundleText(context);
    const n = norm(text);
    const issues = [];
    const add = (severity, category, detail, evidence = '') => issues.push({ severity, category, detail, evidence: cap(evidence, 240) });
    const ext = String(context?.documentBundle?.primaryDocument?.ext || '').toLowerCase();
    const isWordDraft = ['doc','docx'].includes(ext);

    // Với bản Word trình ký, không coi số/ký hiệu, ngày ký, chữ ký, con dấu chưa có là lỗi.
    // Tập trung vào câu chữ, lặp, sai nghĩa và tính nhất quán nội dung.
    const raw = clean(text);
    const duplicateWord = raw.match(/\b([A-Za-zÀ-ỹĐđ]{3,})\s+\1\b/iu);
    if (duplicateWord) add('medium','Từ lặp',`Phát hiện từ lặp liên tiếp “${duplicateWord[0]}”.`,duplicateWord[0]);
    const sentences = raw.split(/(?<=[.!?;])\s+|\n+/).map(x=>clean(x)).filter(x=>x.length>=35);
    const seen = new Map();
    for (const sentence of sentences) {
      const key = norm(sentence).replace(/\d+/g,'#').slice(0,220);
      if (!key) continue;
      if (seen.has(key)) { add('medium','Câu/đoạn lặp','Có câu hoặc đoạn nội dung lặp lại gần như nguyên văn.',cap(sentence,180)); break; }
      seen.set(key,true);
    }
    if (/\b(?:ngay|ngày)\s+(\d{1,2})[\/-](\d{1,2})[\/-](\d{4})\b/i.test(raw) && /\b(?:ngày|ngay)\s+\d{1,2}\s+tháng\s+\d{1,2}\s+năm\s+\d{4}\b/i.test(raw)) {
      // Có nhiều kiểu biểu diễn ngày không phải lỗi; AI sẽ kiểm tra mâu thuẫn ngữ nghĩa nếu có.
    }

    if (!isWordDraft) {
      if (!/cong hoa xa hoi chu nghia viet nam/.test(n)) add('low', 'Quốc hiệu', 'Chưa phát hiện Quốc hiệu trong text đọc được.');
      if (!/doc lap\s*[-–]\s*tu do\s*[-–]\s*hanh phuc/.test(n)) add('low', 'Tiêu ngữ', 'Chưa phát hiện Tiêu ngữ trong text đọc được.');
      if (!/(kinh gui|kính gửi|noi nhan|nơi nhận)/i.test(text)) add('low', 'Nơi nhận', 'Chưa phát hiện “Kính gửi” hoặc “Nơi nhận” trong text đọc được.');
    }

    const unreadable = Number(context?.documentBundle?.stats?.unreadableCount || 0);
    const scan = Number(context?.documentBundle?.stats?.scanSkippedCount || 0);
    if (unreadable || scan) add('high', 'Dữ liệu', 'FILE TRÌNH KÝ chưa đọc đủ; không thể kiểm tra toàn bộ câu chữ/nội dung.');

    const confidence = Math.max(0.48, Math.min(0.94, 0.92 - issues.filter((x) => x.severity === 'high').length * 0.22 - issues.filter((x) => x.severity === 'medium').length * 0.06));
    return {
      workflow: 'leader-outgoing', actionRequired: false, mainUnit: null,
      coordinationUnits: [], viewUnits: [], instruction: '', tasks: [],
      taskScope: 'information', trackRecommended: false, trackingReason: '', recipientNames: [],
      reviewSummary: issues.length
        ? `Local Rule Pro phát hiện ${issues.length} điểm cần kiểm tra trong câu chữ/nội dung${isWordDraft ? ' của bản Word trình ký' : ''}.`
        : `Không phát hiện lỗi câu chữ/lặp nội dung đáng chú ý${isWordDraft ? ' trong bản Word trình ký' : ''}.`,
      reviewIssues: issues,
      reason: isWordDraft ? 'Đã kiểm tra bản Word trình ký, ưu tiên câu chữ và tính nhất quán nội dung.' : 'Đã kiểm tra FILE TRÌNH KÝ bằng quy tắc cục bộ.',
      confidence: Number(confidence.toFixed(2)),
      confidenceScore: Math.round(confidence * 100),
      confidenceLabel: confidenceLabel(Math.round(confidence * 100)),
      requiresReview: issues.some((x) => x.severity === 'high') || confidence < 0.72,
      signals: issues.slice(0, 6).map((x) => `${x.category}: ${x.detail}`),
      provider: 'local-rule-pro', providerLabel: 'Local Rule Pro', model: `Rule Engine ${VERSION}`
    };
  }

  function analyze(context, config, availableUnits = []) {
    const workflow = String(context?.workflow || context?.analysisWorkflow || '');
    return workflow === 'leader-outgoing'
      ? analyzeOutgoing(context)
      : analyzeIncoming(context, config || {}, availableUnits || []);
  }

  globalThis.IOfficeRuleEngine = Object.freeze({
    VERSION,
    analyze,
    analyzeIncoming,
    analyzeOutgoing,
    extractDeadline,
    collectDocuments,
    findTaskCandidates,
    scoreUnits
  });
})();
