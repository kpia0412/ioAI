Tracker 1.3.0 tương thích iOffice AI 1.3.0.
Rule Pack vẫn 1.0.0.
