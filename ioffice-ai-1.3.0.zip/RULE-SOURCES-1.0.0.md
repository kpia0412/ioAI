# Nguồn tham chiếu Rule Pack 1.0.0

Rule Pack chỉ dùng nguồn để xây dựng ma trận nghiệp vụ; URL nguồn không được gửi vào prompt AI. Quy tắc phân luồng là trợ lý tham mưu, không thay quyết định phân công cụ thể của Ea Ly.

- Nghị định 150/2025/NĐ-CP, sửa đổi bởi Nghị định 370/2025/NĐ-CP — khung cơ quan chuyên môn cấp xã: Văn phòng HĐND và UBND; Phòng Kinh tế; Phòng Văn hóa - Xã hội. https://vanban.chinhphu.vn/?classid=1&docid=216396&pageid=27160&typegroupid=4
- Thông tư 09/2025/TT-BTP — Văn phòng HĐND và UBND trong lĩnh vực tư pháp. https://vanban.chinhphu.vn/?classid=0&docid=214030&pageid=27160
- Thông tư 09/2025/TT-BNG — công tác đối ngoại cấp xã. https://vanban.chinhphu.vn/?classid=1&docid=214529&pageid=27160&typegroupid=6
- Thông tư 10/2025/TT-BNV — lĩnh vực nội vụ cấp xã. https://vanban.chinhphu.vn/?docid=214182&pageid=27160
- Giải đáp Bộ Nội vụ về văn thư/lưu trữ cấp xã — Phòng VH-XH tham mưu quản lý nhà nước về văn thư/lưu trữ; nghiệp vụ hồ sơ hiện hành do từng phòng thực hiện. https://baochinhphu.vn/ubnd-xa-phong-chuyen-mon-tu-luu-tru-ho-so-tai-lieu-10225102710534721.htm
- Thông tư 57/2025/TT-BTC — Tài chính - Kế hoạch cấp xã. https://vanban.chinhphu.vn/?classid=1&docid=214406&pageid=27160&typegroupid=6
- Thông tư 15/2025/TT-BGDĐT và Thông tư 45/2026/TT-BGDĐT — giáo dục cấp xã/Phòng VH-XH. https://vanban.chinhphu.vn/?docid=218411&pageid=27160
- Thông tư 20/2025/TT-BYT — cơ quan chuyên môn y tế cấp xã/Phòng VH-XH. https://vanban.chinhphu.vn/?classid=1&docid=214190&pageid=27160&typegroupid=6
- Thông tư 10/2025/TT-BVHTTDL — văn hóa, gia đình, thể thao, du lịch, thông tin cấp xã. https://vanban.chinhphu.vn/?docid=214183&pageid=27160
- Nghị định 118/2025/NĐ-CP, sửa đổi bởi Nghị định 367/2025/NĐ-CP — một cửa, một cửa liên thông/Trung tâm PVHCC. https://vanban.chinhphu.vn/?classid=1&docid=216407&pageid=27160&typegroupid=4
- Nghị quyết 66.12/2026/NQ-CP — Ban CHQS cấp xã; nguồn nêu hiệu lực đến hết 28/02/2027. https://xaydungchinhsach.chinhphu.vn/quy-dinh-moi-nhat-ve-vi-tri-chuc-nang-nhiem-vu-cua-ban-chi-huy-quan-su-cap-xa-119260127110139737.htm
- Luật 72/2025/QH15 — phân biệt HĐND, UBND, Chủ tịch UBND. https://xaydungchinhsach.chinhphu.vn/toan-van-luat-so-72-2025-qh15-to-chuc-chinh-quyen-dia-phuong-119250618161434371.htm
- Trang thông tin điện tử Ea Ly — xác nhận thực tế địa phương có Đảng ủy UBND xã Ea Ly; không dùng tin hoạt động để suy toàn bộ thẩm quyền. https://ealy.daklak.gov.vn/

## Chủ ý tối ưu
- Không chép toàn văn pháp luật vào Rule Pack.
- Giữ ranh giới nghiệp vụ có ảnh hưởng trực tiếp đến XLC/PH, actionRequired, deadline và Tracker.
- Trung tâm Cung ứng dịch vụ sự nghiệp công giữ mô tả bảo thủ: chỉ phân luồng tác nghiệp/dịch vụ khi có quyết định hoặc phân công Ea Ly; không suy chức năng mở rộng từ trung tâm nơi khác.
- Nguồn pháp luật/tham chiếu chỉ cập nhật Master Rule; compiler runtime không gửi danh sách nguồn cho AI.
