(() => {
  'use strict';
  const IDS=['U140','U141','U142','U120','U183','U340','U360','U260','DUUBND'];
  const primaryText='UBND các xã, phường rà soát và gửi báo cáo trước ngày 05/10/2026. Giao Phòng Kinh tế chủ trì thực hiện.';
  const ctx={documentBundle:{primaryDocument:{text:primaryText},supportingDocuments:[],requiresReviewForUnreadable:false,appendixRequiredMissing:false}};
  const base={workflow:'leader-incoming',actionRequired:true,mainUnit:'U141',coordinationUnits:[],viewUnits:[],instruction:'Giao Phòng Kinh tế rà soát và báo cáo.',tasks:[{task:'Rà soát và gửi báo cáo.',deadline:'2026-10-05',deadlineText:'trước ngày 05/10/2026',deadlineEvidence:'UBND các xã, phường rà soát và gửi báo cáo trước ngày 05/10/2026.',deadlineSource:'document',responsibleUnit:'U141',scope:'direct',trackRecommended:true}],recipientNames:[],reviewSummary:'',reviewIssues:[],taskScope:'direct',trackRecommended:true,trackingReason:'Có nhiệm vụ trực tiếp có hạn.',reason:'',confidence:.9,requiresReview:false,signals:[]};
  const clone=v=>JSON.parse(JSON.stringify(v));
  const cases=[];
  const add=(name,mutate,check)=>cases.push({name,mutate,check});

  add('01 giữ actionRequired',x=>x,r=>r.actionRequired===true);
  add('02 giữ taskScope',x=>x,r=>r.taskScope==='direct');
  add('03 giữ trackRecommended',x=>x,r=>r.trackRecommended===true);
  add('04 giữ trackingReason',x=>x,r=>/nhiệm vụ/i.test(r.trackingReason));
  add('05 giữ task.scope',x=>x,r=>r.tasks[0]?.scope==='direct');
  add('06 giữ task.trackRecommended',x=>x,r=>r.tasks[0]?.trackRecommended===true);
  add('07 deadline đúng bằng chứng',x=>x,r=>r.tasks[0]?.deadline==='2026-10-05');
  add('08 thiếu actionRequired không suy từ XLC',x=>{delete x.actionRequired;return x},r=>r.actionRequired===false&&r.requiresReview);
  add('09 thiếu taskScope thành ambiguous',x=>{delete x.taskScope;return x},r=>r.taskScope==='ambiguous'&&r.requiresReview);
  add('10 thiếu evidence loại deadline',x=>{x.tasks[0].deadlineEvidence='';return x},r=>!r.tasks[0]?.deadline&&r.deadlineEvidenceRejected);
  add('11 evidence sai loại deadline',x=>{x.tasks[0].deadlineEvidence='một câu không tồn tại trong văn bản nguồn';return x},r=>!r.tasks[0]?.deadline);
  add('12 coordination không theo dõi',x=>{x.taskScope='coordination';x.actionRequired=false;return x},r=>!r.trackRecommended&&!r.actionRequired);
  add('13 information không theo dõi',x=>{x.taskScope='information';x.actionRequired=false;return x},r=>!r.trackRecommended);
  add('14 other-locality không theo dõi',x=>{x.taskScope='other-locality';x.actionRequired=false;return x},r=>!r.trackRecommended);
  add('15 ambiguous không theo dõi',x=>{x.taskScope='ambiguous';x.actionRequired=false;return x},r=>!r.trackRecommended&&r.requiresReview);
  add('16 viewUnits bị bỏ ở incoming',x=>{x.viewUnits=['U142'];return x},r=>r.viewUnits.length===0);
  add('17 phối hợp không trùng XLC',x=>{x.coordinationUnits=['U141','U142'];return x},r=>r.coordinationUnits.length===1&&r.coordinationUnits[0]==='U142');
  add('18 confidence giữ trong khoảng',x=>{x.confidence=.81;return x},r=>Math.abs(r.confidence-.81)<.001);
  add('19 confidence giảm khi tài liệu thiếu',x=>x,r=>true);
  add('20 recipientNames giữ dữ liệu',x=>{x.recipientNames=['A','B'];return x},r=>r.recipientNames.length===2);
  add('21 reviewIssues giữ dữ liệu',x=>{x.reviewIssues=[{severity:'high',category:'Test',detail:'Lỗi',evidence:'x'}];return x},r=>r.reviewIssues.length===1);
  add('22 signals giữ dữ liệu',x=>{x.signals=['Một'];return x},r=>r.signals.includes('Một'));
  add('23 deadline format sai bị loại',x=>{x.tasks[0].deadline='05/10/2026';return x},r=>!r.tasks[0]?.deadline);
  add('24 task responsibleUnit giữ nguyên',x=>x,r=>r.tasks[0]?.responsibleUnit==='U141');
  add('25 direct thiếu mainUnit cần review',x=>{x.mainUnit=null;x.tasks[0].responsibleUnit=null;return x},r=>r.requiresReview);
  add('26 task scope coordination hủy deadline',x=>{x.tasks[0].scope='coordination';return x},r=>!r.tasks[0]?.deadline);
  add('27 track false được giữ',x=>{x.trackRecommended=false;x.tasks[0].trackRecommended=false;return x},r=>r.trackRecommended===false);
  add('28 instruction giữ nguyên',x=>x,r=>/Phòng Kinh tế/.test(r.instruction));
  add('29 reason giữ nguyên',x=>{x.reason='Lý do';return x},r=>r.reason==='Lý do');
  add('30 reviewSummary giữ nguyên',x=>{x.reviewSummary='Tóm tắt';return x},r=>r.reviewSummary==='Tóm tắt');
  add('31 deadlineText giữ khi deadline bị loại',x=>{x.tasks[0].deadlineEvidence='';return x},r=>/05\/10\/2026/.test(r.tasks[0]?.deadlineText||''));
  add('32 deadlineEvidence giữ để rà soát',x=>{x.tasks[0].deadlineEvidence='câu sai';return x},r=>r.tasks[0]?.deadlineEvidence==='câu sai');
  add('33 multiple tasks giữ đủ',x=>{x.tasks.push({...x.tasks[0],task:'Nhiệm vụ 2'});return x},r=>r.tasks.length===2);
  add('34 không tự tạo unit lạ',x=>x,r=>IDS.includes(r.mainUnit));
  add('35 taskScope information action false',x=>{x.taskScope='information';x.actionRequired=true;return x},r=>r.actionRequired===false);
  add('36 trackingReason không bị mất',x=>{x.trackingReason='Theo dõi do có sản phẩm bắt buộc';return x},r=>r.trackingReason==='Theo dõi do có sản phẩm bắt buộc');

  function run(pack){
    const unitIds=(pack?.units||[]).map(u=>u.id);
    const missing=IDS.filter(id=>!unitIds.includes(id));
    const extra=unitIds.filter(id=>!IDS.includes(id));
    const failures=[];
    if(missing.length||extra.length) failures.push(`Unit set sai · thiếu ${missing.join(',')||'0'} · dư ${extra.join(',')||'0'}`);
    for(const c of cases){
      try{
        const input=c.mutate(clone(base))||clone(base);
        const localCtx=clone(ctx);
        if(c.name.startsWith('19 ')) localCtx.documentBundle.requiresReviewForUnreadable=true;
        const r=globalThis.IOfficeResultValidator.validate(input,{workflow:'leader-incoming',allowedUnitIds:IDS,context:localCtx});
        if(!c.check(r)) failures.push(c.name);
      }catch(e){ failures.push(`${c.name}: ${e.message}`); }
    }
    const examples=Array.isArray(pack?.examples)?pack.examples:[];
    examples.forEach((ex,i)=>{
      try{
        const e=ex?.expected||{};
        if(!['direct','coordination','information','other-locality','ambiguous'].includes(String(e.taskScope||''))) throw new Error('taskScope không hợp lệ');
        if(typeof e.actionRequired!=='boolean'||typeof e.trackRecommended!=='boolean') throw new Error('thiếu actionRequired/trackRecommended');
        if(e.mainUnit&&!IDS.includes(e.mainUnit)) throw new Error('mainUnit lạ');
        if(e.taskScope!=='direct'&&(e.actionRequired||e.trackRecommended)) throw new Error('scope không trực tiếp nhưng bật action/tracking');
      }catch(err){failures.push(`Example ${i+1} ${ex?.name||''}: ${err.message}`);}
    });
    const compilerChecks=[];
    const addCompiler=(name,text,check)=>compilerChecks.push({name,text,check});
    addCompiler('C01 đất đai chọn U141 và giữ phản hồi điều kiện','UBND các xã rà soát thông tin đất đai; nếu có thông tin thì gửi trước ngày 05/10/2026; không phản hồi xem như không có.',p=>p.includes('U141')&&p.includes('Phản hồi có điều kiện'));
    addCompiler('C02 y tế chọn U142 và tình huống TTYT','Đối với Trung tâm Y tế: phối hợp UBND các xã rà soát nhu cầu; TTYT báo cáo Sở trước 05/10/2026.',p=>p.includes('U142')&&p.includes('Trung tâm Y tế'));
    addCompiler('C03 giấy mời chọn quy tắc lịch/hạn','Mời dự hội nghị ngày 01/10/2026; đăng ký đại biểu trước 28/09/2026.',p=>p.includes('Ngày họp/sự kiện')||p.includes('Mời họp'));
    addCompiler('C04 một cửa chọn U120','Rà soát thủ tục hành chính, hồ sơ trễ hạn tại Trung tâm Phục vụ hành chính công và Cổng Dịch vụ công.',p=>p.includes('U120'));
    addCompiler('C05 công an chọn U340','Công an xã rà soát PCCC, cư trú, định danh điện tử và bảo đảm trật tự an toàn giao thông.',p=>p.includes('U340'));
    addCompiler('C06 quân sự chọn U360','Ban CHQS xã triển khai tuyển quân, nghĩa vụ quân sự và huấn luyện dân quân.',p=>p.includes('U360'));
    addCompiler('C07 HĐND chọn U260','Thường trực HĐND yêu cầu báo cáo phục vụ kỳ họp và giám sát.',p=>p.includes('U260'));
    addCompiler('C08 Đảng ủy UBND chọn DUUBND','Đảng ủy UBND xã tổ chức sinh hoạt chi bộ và kiểm tra đảng viên.',p=>p.includes('DUUBND'));
    addCompiler('C09 nguồn pháp lý không chèn vào prompt','Rà soát dự toán ngân sách xã.',p=>!p.includes('vanban.chinhphu.vn')&&!p.includes('sourceReferences'));
    addCompiler('C10 runtime prompt trong ngân sách','UBND các xã rà soát, tổng hợp báo cáo trước ngày 05/10/2026; chi tiết tại Phụ lục 1.',p=>p.length<=Number(pack?.runtimePolicy?.maxPromptChars||13500));
    for(const c of compilerChecks){
      try{
        const payload={context:{trichYeu:c.text,documentBundle:{primaryDocument:{text:c.text},supportingDocuments:[],appendixReferenced:/phụ lục/i.test(c.text)}}};
        const prompt=globalThis.IOfficeRulePack.compilePrompt(pack,payload);
        if(!c.check(prompt)) failures.push(c.name);
      }catch(e){failures.push(`${c.name}: ${e.message}`);}
    }
    const total=cases.length+examples.length+compilerChecks.length;
    return {ok:failures.length===0,total,passed:total-failures.length,failures};
  }
  globalThis.IOfficeGoldenTests=Object.freeze({run,count:cases.length});
})();
