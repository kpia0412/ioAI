Tracker 1.0.0 tương thích iOffice AI 1.0.0.

Nâng từ Tracker 7.0.17: thay Code.gs, Save, Deploy > Manage deployments > Edit > New version > Deploy. Giữ deployment để giữ URL /exec. KHÔNG chạy setupFreshV7() nếu đang có dữ liệu.

Web quản lý mở được không đồng nghĩa API tiện ích đã kết nối: API còn cần TOKEN đúng và POST /exec. iOffice AI 1.0 có nút Kiểm tra kết nối Sổ để xác minh đúng giao thức.
