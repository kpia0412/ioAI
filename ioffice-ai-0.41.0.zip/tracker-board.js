(() => {
  'use strict';

  const CACHE_KEY = 'trackerClientCacheV4';
  const STATUS_ORDER = ['PROCESSING','WAITING_PUBLISH','PUBLISHED','COMPLETED'];
  const STATUS_LABEL = {
    PROCESSING: 'Đang xử lý',
    WAITING_PUBLISH: 'Chờ ban hành',
    PUBLISHED: 'Đã ban hành',
    COMPLETED: 'Hoàn thành',
    STOPPED: 'Đã xóa'
  };

  const state = {
    root: null,
    container: null,
    matchContainer: null,
    role: () => 'leader',
    getContext: () => ({}),
    getPreparedText: () => '',
    notify: () => {},
    loaded: false,
    loading: false,
    tasks: [],
    filter: 'active',
    selectedId: '',
    detail: null,
    addOpen: false,
    message: '',
    messageKind: 'info'
  };

  const norm = v => String(v ?? '').replace(/\u00a0/g,' ').replace(/\s+/g,' ').trim();
  const fold = v => norm(v).normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/đ/g,'d').replace(/Đ/g,'D').toLowerCase();
  const esc = v => String(v ?? '').replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;').replaceAll("'",'&#039;');

  function runtime(message) {
    return new Promise(resolve => {
      try {
        chrome.runtime.sendMessage(message, response => {
          const err = chrome.runtime.lastError;
          resolve(err ? {ok:false,error:err.message} : (response || {ok:false,error:'Không có phản hồi'}));
        });
      } catch (e) { resolve({ok:false,error:e.message}); }
    });
  }


  function notice(text, kind='info') {
    state.message = norm(text);
    state.messageKind = kind || 'info';
    try { state.notify(state.message, state.messageKind); } catch (_) {}
    if (state.container && !state.container.classList.contains('hidden')) renderBoard();
  }
  function statusCode(v) {
    const raw = norm(v).toUpperCase();
    if (STATUS_LABEL[raw]) return raw;
    const f = fold(v);
    if (/cho ban hanh|cho phat hanh|da xu ly.*ban hanh/.test(f)) return 'WAITING_PUBLISH';
    if (/da ban hanh|da phat hanh/.test(f)) return 'PUBLISHED';
    if (/hoan thanh|da hoan thanh|completed/.test(f)) return 'COMPLETED';
    if (/dung|xoa|stopped|deleted/.test(f)) return 'STOPPED';
    return 'PROCESSING';
  }

  function deadlineOf(t) { return norm(t?.deadline || t?.hanXuLy || t?.dueDate || ''); }
  function titleOf(t) { return norm(t?.taskText || t?.nhiemVu || t?.title || t?.sourceSubject || t?.trichYeu || 'Nhiệm vụ chưa đặt tên'); }
  function detailsOf(t) { return norm(t?.details || t?.detail || t?.nhiemVuChiTiet || t?.description || t?.nhiemVu || t?.taskText || ''); }
  function noteOf(t) { return norm(t?.note || t?.ghiChu || t?.manualNote || ''); }
  function symbolOf(t) { return norm(t?.sourceSymbol || t?.soKyHieu || ''); }
  function taskIdOf(t) { return norm(t?.taskId || t?.id || ''); }

  function viDate(v) {
    const m = norm(v).match(/^(\d{4})-(\d{2})-(\d{2})$/);
    return m ? `${m[3]}/${m[2]}/${m[1]}` : norm(v) || 'Không hạn';
  }

  function dueRank(t) {
    const d = deadlineOf(t);
    if (!/^\d{4}-\d{2}-\d{2}$/.test(d)) return Number.MAX_SAFE_INTEGER;
    const n = Date.parse(`${d}T00:00:00`);
    return Number.isFinite(n) ? n : Number.MAX_SAFE_INTEGER;
  }

  function normalizedTask(t) {
    return {
      ...t,
      taskId: taskIdOf(t),
      taskText: titleOf(t),
      deadline: deadlineOf(t),
      businessStatus: statusCode(t?.businessStatus || t?.trangThai || t?.status),
      sourceSymbol: symbolOf(t),
      details: detailsOf(t),
      note: noteOf(t)
    };
  }

  function isActive(t) { return !['COMPLETED','STOPPED'].includes(statusCode(t.businessStatus)); }
  function filteredTasks() {
    const f = state.filter;
    return state.tasks.filter(t => {
      const s = statusCode(t.businessStatus);
      if (s === 'STOPPED') return false;
      if (f === 'active') return isActive(t);
      if (f === 'all') return true;
      return s === f;
    }).sort((a,b) => {
      const sa = statusCode(a.businessStatus), sb = statusCode(b.businessStatus);
      const activeA = isActive(a) ? 0 : 1, activeB = isActive(b) ? 0 : 1;
      if (activeA !== activeB) return activeA - activeB;
      const da = dueRank(a), db = dueRank(b);
      if (da !== db) return da - db;
      return titleOf(a).localeCompare(titleOf(b), 'vi');
    });
  }

  function todayIso() {
    const d = new Date(), z = n => String(n).padStart(2,'0');
    return `${d.getFullYear()}-${z(d.getMonth()+1)}-${z(d.getDate())}`;
  }

  function dueClass(t) {
    const d = deadlineOf(t);
    if (!/^\d{4}-\d{2}-\d{2}$/.test(d)) return '';
    const today = todayIso();
    if (d < today) return 'overdue';
    const days = Math.round((Date.parse(`${d}T00:00:00`) - Date.parse(`${today}T00:00:00`))/86400000);
    return days <= 2 ? 'soon' : '';
  }

  function ensureStyle() {
    if (!state.root || state.root.getElementById('trackerBoardStyle')) return;
    const style = document.createElement('style');
    style.id = 'trackerBoardStyle';
    style.textContent = `
      .tracker-board{font-family:Arial,Helvetica,sans-serif}.tb-head{display:flex;align-items:center;justify-content:space-between;gap:7px;margin-bottom:8px}.tb-title{font-size:13px;font-weight:900;color:#19324c}.tb-tools{display:flex;gap:5px}.tb-btn{border:1px solid #d5dee9;border-radius:8px;background:#fff;color:#31516f;padding:6px 8px;font-size:10px;font-weight:800;cursor:pointer}.tb-btn.primary{background:#0866cf;color:#fff;border-color:#0866cf}.tb-btn.danger{color:#b42318;border-color:#fecaca;background:#fff7f7}.tb-btn:disabled{opacity:.55;cursor:not-allowed}.tb-filter{width:100%;min-height:34px;padding:6px 8px;border:1px solid #d5dee9;border-radius:9px;background:#fff;font-size:10.5px;margin-bottom:8px}.tb-list{display:grid;gap:6px}.tb-row{border:1px solid #e0e7ef;border-radius:10px;padding:8px 9px;background:#fff;cursor:pointer}.tb-row:hover{background:#f8fbff}.tb-row.overdue{border-left:5px solid #dc2626}.tb-row.soon{border-left:5px solid #f59e0b}.tb-row-title{font-size:11px;font-weight:850;color:#1f344b;line-height:1.35}.tb-row-meta{margin-top:4px;font-size:9.5px;color:#64748b;display:flex;gap:6px;flex-wrap:wrap}.tb-status{font-weight:850;color:#155e75}.tb-empty{padding:20px 10px;text-align:center;color:#64748b;font-size:10.5px;border:1px dashed #d6dee8;border-radius:10px}.tb-detail,.tb-add{margin-top:8px;border:1px solid #d7e1ec;border-radius:11px;background:#f9fbfd;padding:9px}.tb-detail h4,.tb-add h4{margin:0 0 8px;font-size:11.5px;color:#223c56}.tb-grid{display:grid;grid-template-columns:1fr 1fr;gap:7px}.tb-field{display:grid;gap:4px}.tb-field.full{grid-column:1/-1}.tb-field label{font-size:9px;font-weight:800;color:#64748b}.tb-field input,.tb-field textarea,.tb-field select{width:100%;border:1px solid #ced9e4;border-radius:8px;padding:7px 8px;background:#fff;font:10.5px Arial;color:#172033}.tb-field textarea{min-height:66px;resize:vertical}.tb-actions{display:flex;gap:6px;flex-wrap:wrap;margin-top:8px}.tb-note{font-size:9.5px;color:#64748b;margin-top:6px;line-height:1.4}.tb-loading{padding:18px;text-align:center;color:#64748b;font-size:10px}.tb-message{margin:0 0 8px;padding:7px 8px;border-radius:8px;font-size:9.8px;line-height:1.4;background:#eef5ff;color:#285e9d}.tb-message.success{background:#eaf8f0;color:#166534}.tb-message.error{background:#fff0f0;color:#a23535}.tb-confirm{position:absolute;inset:0;z-index:20;background:rgba(15,23,42,.38);display:flex;align-items:center;justify-content:center;padding:18px}.tb-confirm-box{width:min(330px,100%);background:#fff;border-radius:12px;padding:13px;box-shadow:0 15px 40px rgba(0,0,0,.25)}.tb-confirm-title{font-size:12px;font-weight:900;color:#1f2937}.tb-confirm-text{margin-top:6px;font-size:10.5px;line-height:1.45;color:#475569}.tb-confirm-actions{display:flex;justify-content:flex-end;gap:6px;margin-top:11px}.tracker-match{margin-top:8px;padding:9px 10px;border:1px solid #cfe0ef;border-left:5px solid #0f766e;border-radius:10px;background:#f2fbfa;font-size:10px;line-height:1.45;color:#31544f}.tracker-match.hidden{display:none!important}.tracker-match .tm-title{font-weight:900}.tracker-match .tm-meta{margin-top:3px;color:#64748b}.tracker-match .tm-actions{display:flex;gap:6px;flex-wrap:wrap;margin-top:7px}.tracker-match button{border:1px solid #b9d7d2;border-radius:8px;background:#fff;color:#0f5f58;padding:6px 8px;font-size:9.5px;font-weight:850;cursor:pointer}.tracker-match button.primary{background:#0f766e;color:#fff;border-color:#0f766e}
      @media(max-width:520px){.tb-grid{grid-template-columns:1fr}.tb-field.full{grid-column:auto}}
    `;
    state.root.appendChild(style);
  }

  async function loadIndex(force=false) {
    if (state.loading) return;
    state.loading = true;
    renderBoard();
    const r = await runtime({type:'TRACKER_CACHE_REFRESH',data:{force}});
    state.loading = false;
    if (!r?.ok) {
      state.tasks = [];
      renderBoard(r?.error || 'Không tải được Sổ theo dõi.');
      return;
    }
    state.tasks = (r.cache?.tasks || []).map(normalizedTask);
    state.loaded = true;
    renderBoard();
  }

  function renderBoard(error='') {
    const c = state.container;
    if (!c) return;
    if (state.loading) { c.innerHTML = '<div class="tb-loading">Đang tải Sổ theo dõi…</div>'; return; }
    if (error) { c.innerHTML = `<div class="tb-empty">⚠ ${esc(error)}<div class="tb-actions" style="justify-content:center"><button class="tb-btn" data-tb="refresh">Thử lại</button></div></div>`; bindBoardEvents(); return; }
    const tasks = filteredTasks();
    const rows = tasks.map(t => `<div class="tb-row ${dueClass(t)}" data-task-id="${esc(t.taskId)}"><div class="tb-row-title">${esc(titleOf(t))}</div><div class="tb-row-meta"><span>${esc(viDate(deadlineOf(t)))}</span><span class="tb-status">${esc(STATUS_LABEL[statusCode(t.businessStatus)] || statusCode(t.businessStatus))}</span>${symbolOf(t)?`<span>${esc(symbolOf(t))}</span>`:''}</div></div>`).join('');
    c.innerHTML = `
      <div class="tb-head"><div class="tb-title">📒 Sổ theo dõi</div><div class="tb-tools"><button class="tb-btn" data-tb="refresh">↻</button><button class="tb-btn primary" data-tb="add">＋ Thêm</button></div></div>
      ${state.message ? `<div class="tb-message ${esc(state.messageKind)}">${esc(state.message)}</div>` : ''}
      <select class="tb-filter" id="tbFilter">
        <option value="active" ${state.filter==='active'?'selected':''}>Nhiệm vụ đang theo dõi</option>
        <option value="PROCESSING" ${state.filter==='PROCESSING'?'selected':''}>Đang xử lý</option>
        <option value="WAITING_PUBLISH" ${state.filter==='WAITING_PUBLISH'?'selected':''}>Chờ ban hành</option>
        <option value="PUBLISHED" ${state.filter==='PUBLISHED'?'selected':''}>Đã ban hành</option>
        <option value="COMPLETED" ${state.filter==='COMPLETED'?'selected':''}>✓ Nhiệm vụ hoàn thành</option>
        <option value="all" ${state.filter==='all'?'selected':''}>Tất cả</option>
      </select>
      ${state.addOpen ? addFormHtml() : ''}
      <div class="tb-list">${rows || '<div class="tb-empty">Không có nhiệm vụ trong bộ lọc này.</div>'}</div>
      ${state.selectedId ? detailHtml() : ''}`;
    bindBoardEvents();
  }

  function addFormHtml() {
    return `<div class="tb-add"><h4>Thêm nhiệm vụ</h4><div class="tb-grid"><div class="tb-field full"><label>Tên công việc *</label><input id="tbAddTitle" maxlength="220" placeholder="Tên công việc ngắn gọn"></div><div class="tb-field"><label>Hạn</label><input id="tbAddDeadline" type="date"></div><div class="tb-field"><label>Trạng thái</label><select id="tbAddStatus">${STATUS_ORDER.map(s=>`<option value="${s}">${STATUS_LABEL[s]}</option>`).join('')}</select></div><div class="tb-field full"><label>Nội dung thêm</label><textarea id="tbAddDetail" maxlength="1200" placeholder="Có thể để trống"></textarea></div></div><div class="tb-actions"><button class="tb-btn primary" data-tb="create">Thêm nhiệm vụ</button><button class="tb-btn" data-tb="cancel-add">Hủy</button></div></div>`;
  }

  function detailHtml() {
    const t = normalizedTask(state.detail || state.tasks.find(x=>x.taskId===state.selectedId) || {});
    if (!t.taskId) return '';
    const status = statusCode(t.businessStatus);
    return `<div class="tb-detail"><h4>Chi tiết nhiệm vụ</h4><div class="tb-grid">
      <div class="tb-field full"><label>Tên công việc</label><input id="tbEditTitle" maxlength="220" value="${esc(titleOf(t))}"></div>
      <div class="tb-field"><label>Hạn</label><input id="tbEditDeadline" type="date" value="${esc(deadlineOf(t))}"></div>
      <div class="tb-field"><label>Trạng thái</label><select id="tbEditStatus">${STATUS_ORDER.map(s=>`<option value="${s}" ${s===status?'selected':''}>${STATUS_LABEL[s]}</option>`).join('')}</select></div>
      <div class="tb-field full"><label>Nội dung</label><textarea id="tbEditDetail" maxlength="1800">${esc(detailsOf(t))}</textarea></div>
      <div class="tb-field"><label>Số/Ký hiệu nguồn</label><input id="tbEditSymbol" maxlength="120" value="${esc(symbolOf(t))}"></div>
      <div class="tb-field"><label>Ghi chú</label><input id="tbEditNote" maxlength="500" value="${esc(noteOf(t))}"></div>
    </div><div class="tb-actions"><button class="tb-btn primary" data-tb="save">Lưu thông tin</button><button class="tb-btn" data-tb="status">Đổi trạng thái</button><button class="tb-btn danger" data-tb="delete">Xóa</button><button class="tb-btn" data-tb="close-detail">Đóng</button></div><div class="tb-note">Đổi trạng thái và Xóa luôn yêu cầu xác nhận trước khi ghi dữ liệu.</div></div>`;
  }

  function bindBoardEvents() {
    const c=state.container; if(!c) return;
    c.querySelector('#tbFilter')?.addEventListener('change',e=>{state.filter=e.target.value;state.selectedId='';state.detail=null;renderBoard();});
    c.querySelectorAll('.tb-row[data-task-id]').forEach(row=>row.addEventListener('click',()=>void openTask(row.dataset.taskId)));
    c.querySelectorAll('[data-tb]').forEach(btn=>btn.addEventListener('click',ev=>{ev.stopPropagation();void handleBoardAction(btn.dataset.tb);}));
  }

  async function openTask(id) {
    state.selectedId = norm(id); state.detail = state.tasks.find(x=>x.taskId===state.selectedId) || null; renderBoard();
    const r = await runtime({type:'TRACKER_GET',data:{taskId:state.selectedId}});
    if (state.selectedId !== norm(id)) return;
    if (r?.ok) state.detail = normalizedTask(r.data?.task || r.data || state.detail || {});
    renderBoard();
  }

  function confirmAction(title,text,confirmLabel='Xác nhận',danger=false) {
    return new Promise(resolve=>{
      const host=state.root?.host; if(!host){resolve(false);return;}
      const overlay=document.createElement('div'); overlay.className='tb-confirm';
      overlay.innerHTML=`<div class="tb-confirm-box"><div class="tb-confirm-title">${esc(title)}</div><div class="tb-confirm-text">${esc(text)}</div><div class="tb-confirm-actions"><button class="tb-btn" data-cancel>Hủy</button><button class="tb-btn ${danger?'danger':'primary'}" data-ok>${esc(confirmLabel)}</button></div></div>`;
      const card=state.root.querySelector('.card'); if(card){card.style.position='relative';card.appendChild(overlay);} else host.appendChild(overlay);
      const done=v=>{overlay.remove();resolve(v);}; overlay.querySelector('[data-cancel]').onclick=()=>done(false);overlay.querySelector('[data-ok]').onclick=()=>done(true);overlay.addEventListener('click',e=>{if(e.target===overlay)done(false);});
    });
  }

  async function createTask() {
    const title=norm(state.container.querySelector('#tbAddTitle')?.value); if(!title){notice('Nhập tên công việc.','error');return;}
    const deadline=norm(state.container.querySelector('#tbAddDeadline')?.value); const detail=norm(state.container.querySelector('#tbAddDetail')?.value); const businessStatus=statusCode(state.container.querySelector('#tbAddStatus')?.value);
    const key=`manual-${Date.now()}-${Math.random().toString(36).slice(2,8)}`;
    const payload={syncKey:key,nhiemVu:title,taskText:title,hanXuLy:deadline,deadline,ghiChu:detail,details:detail,trangThai:STATUS_LABEL[businessStatus],businessStatus,ngayGiao:todayIso(),updateSource:'MANUAL',manualNote:'Tạo trực tiếp từ Sổ theo dõi trong tiện ích.',documentId:'',soKyHieu:'',trichYeu:'',linkIOfficeNguon:''};
    const r=await runtime({type:'TRACKER_UPSERT',data:payload}); if(!r?.ok){notice(r?.error||'Không thêm được nhiệm vụ.','error');return;}
    state.addOpen=false; notice(r.queued?'Đã lưu hàng chờ đồng bộ nhiệm vụ.':'Đã thêm nhiệm vụ.','success'); await loadIndex(true);
  }

  function readEditPayload() {
    return {
      taskId:state.selectedId,
      taskText:norm(state.container.querySelector('#tbEditTitle')?.value),
      nhiemVu:norm(state.container.querySelector('#tbEditTitle')?.value),
      deadline:norm(state.container.querySelector('#tbEditDeadline')?.value),
      hanXuLy:norm(state.container.querySelector('#tbEditDeadline')?.value),
      details:norm(state.container.querySelector('#tbEditDetail')?.value),
      nhiemVuChiTiet:norm(state.container.querySelector('#tbEditDetail')?.value),
      sourceSymbol:norm(state.container.querySelector('#tbEditSymbol')?.value),
      soKyHieu:norm(state.container.querySelector('#tbEditSymbol')?.value),
      note:norm(state.container.querySelector('#tbEditNote')?.value),
      ghiChu:norm(state.container.querySelector('#tbEditNote')?.value),
      updateSource:'MANUAL'
    };
  }

  async function saveTask() {
    const p=readEditPayload(); if(!p.taskText){notice('Tên công việc không được để trống.','error');return;}
    const r=await runtime({type:'TRACKER_MANUAL_UPDATE',data:p}); if(!r?.ok){notice(r?.error||'Không lưu được nhiệm vụ.','error');return;}
    notice(r.queued?'Đã lưu thay đổi vào hàng chờ đồng bộ.':'Đã lưu thông tin nhiệm vụ.','success'); await loadIndex(true); if(state.selectedId) await openTask(state.selectedId);
  }

  async function changeStatus(target=null, task=null) {
    const t=normalizedTask(task || state.detail || state.tasks.find(x=>x.taskId===state.selectedId) || {}); if(!t.taskId)return false;
    const next=statusCode(target || state.container?.querySelector('#tbEditStatus')?.value); const prev=statusCode(t.businessStatus); if(next===prev){notice('Trạng thái chưa thay đổi.','info');return false;}
    const ok=await confirmAction('Xác nhận thay đổi trạng thái',`“${titleOf(t)}”\n${STATUS_LABEL[prev]} → ${STATUS_LABEL[next]}`,'Xác nhận'); if(!ok)return false;
    const r=await runtime({type:'TRACKER_MANUAL_UPDATE',data:{taskId:t.taskId,businessStatus:next,status:next,trangThai:STATUS_LABEL[next],updateSource:'MANUAL',manualNote:`Xác nhận đổi trạng thái ${STATUS_LABEL[prev]} → ${STATUS_LABEL[next]}`}});
    if(!r?.ok){notice(r?.error||'Không đổi được trạng thái.','error');return false;}
    notice(r.queued?'Đã lưu thay đổi trạng thái vào hàng chờ đồng bộ.':`Đã chuyển sang “${STATUS_LABEL[next]}”.`,'success'); await loadIndex(true); if(state.selectedId===t.taskId)await openTask(t.taskId); return true;
  }

  async function deleteTask() {
    const t=normalizedTask(state.detail || state.tasks.find(x=>x.taskId===state.selectedId) || {}); if(!t.taskId)return;
    const ok=await confirmAction('Xóa nhiệm vụ?',`“${titleOf(t)}” sẽ bị xóa khỏi Sổ theo dõi. Thao tác chỉ thực hiện sau khi bấm Xóa nhiệm vụ.`,'Xóa nhiệm vụ',true); if(!ok)return;
    const r=await runtime({type:'TRACKER_DELETE',data:{taskId:t.taskId,deletedAt:new Date().toISOString(),updateSource:'MANUAL'}}); if(!r?.ok){notice(r?.error||'Không xóa được nhiệm vụ.','error');return;}
    state.selectedId='';state.detail=null;notice('Đã xóa nhiệm vụ khỏi Sổ theo dõi.','success');await loadIndex(true);
  }

  async function handleBoardAction(action) {
    if(action==='refresh')return loadIndex(true);
    if(action==='add'){state.addOpen=!state.addOpen;renderBoard();return;}
    if(action==='cancel-add'){state.addOpen=false;renderBoard();return;}
    if(action==='create')return createTask();
    if(action==='save')return saveTask();
    if(action==='status')return changeStatus();
    if(action==='delete')return deleteTask();
    if(action==='close-detail'){state.selectedId='';state.detail=null;renderBoard();}
  }

  function lightRelatedText() {
    const root=document.querySelector('#thongtinvb');
    if(!root)return '';
    return norm(root.textContent||'').slice(0,18000);
  }

  function taskMatchScore(t, evidence) {
    const hay=fold(evidence); if(!hay)return 0;
    let score=0; const symbol=fold(symbolOf(t)); if(symbol && symbol.length>=5 && hay.includes(symbol))score+=0.78;
    const words=[...new Set(fold(`${titleOf(t)} ${t.sourceSubject||t.trichYeu||''}`).split(' ').filter(w=>w.length>=4))].slice(0,28);
    if(words.length){const hit=words.filter(w=>hay.includes(w)).length;score+=Math.min(.22,(hit/words.length)*.22);}
    return Math.min(1,score);
  }

  function renderMatch(task=null,message='') {
    const box=state.matchContainer;if(!box)return;
    if(message){box.classList.remove('hidden');box.innerHTML=`<div class="tm-title">📒 Sổ theo dõi</div><div class="tm-meta">${esc(message)}</div>`;return;}
    if(!task){box.classList.add('hidden');box.innerHTML='';return;}
    const t=normalizedTask(task), role=state.role(), s=statusCode(t.businessStatus);
    let action='';
    if(role==='leader'&&s==='PROCESSING')action='<button class="primary" data-tm-status="WAITING_PUBLISH">✓ Chờ ban hành</button>';
    if(role==='clerk'&&s==='WAITING_PUBLISH')action='<button class="primary" data-tm-status="PUBLISHED">✓ Đã ban hành</button>';
    box.classList.remove('hidden');box.innerHTML=`<div class="tm-title">🔗 Nhiệm vụ phù hợp trong Sổ</div><div>${esc(titleOf(t))}</div><div class="tm-meta">${esc(viDate(deadlineOf(t)))} · ${esc(STATUS_LABEL[s])}${symbolOf(t)?` · ${esc(symbolOf(t))}`:''}</div>${action?`<div class="tm-actions">${action}<button data-tm-open>Mở Sổ theo dõi</button></div>`:'<div class="tm-meta">Có thể mở Sổ theo dõi để chỉnh sửa hoặc đổi trạng thái.</div>'}`;
    box.querySelector('[data-tm-open]')?.addEventListener('click',()=>{try{const sel=state.root.getElementById('roleSelect');if(sel){sel.value='tracker';sel.dispatchEvent(new Event('change',{bubbles:true}));setTimeout(()=>openTask(t.taskId),80);}}catch(_){}});
    box.querySelector('[data-tm-status]')?.addEventListener('click',()=>void changeStatus(box.querySelector('[data-tm-status]').dataset.tmStatus,t));
  }

  async function matchCurrentOutgoing() {
    const role=state.role(); if(!['leader','clerk'].includes(role))return null;
    const r=await runtime({type:'TRACKER_CACHE_REFRESH',data:{force:false}}); if(!r?.ok){renderMatch(null,r?.error||'Không tải được Sổ.');return null;}
    state.tasks=(r.cache?.tasks||[]).map(normalizedTask);
    const ctx=state.getContext()||{};
    const evidence=norm(`${ctx.trichYeu||''} ${state.getPreparedText()||''} ${lightRelatedText()}`);
    const ranked=state.tasks.filter(t=>statusCode(t.businessStatus)!=='STOPPED').map(t=>({t,score:taskMatchScore(t,evidence)})).filter(x=>x.score>=0.62).sort((a,b)=>b.score-a.score);
    if(!ranked.length){renderMatch(null,'Chưa tìm thấy nhiệm vụ khớp chắc chắn. Có thể mở Sổ theo dõi để chọn và cập nhật thủ công.');return null;}
    if(ranked.length>1 && ranked[0].score-ranked[1].score<0.08){renderMatch(null,'Có nhiều nhiệm vụ gần giống nhau. Mở Sổ theo dõi để chọn đúng nhiệm vụ trước khi đổi trạng thái.');return null;}
    renderMatch(ranked[0].t); return ranked[0].t;
  }

  async function createFromPayload(payload) {
    const r=await runtime({type:'TRACKER_UPSERT',data:payload});
    if(r?.ok && state.loaded)await loadIndex(true);
    return r;
  }

  function init(opts={}) {
    state.root=opts.root||state.root;state.container=opts.container||state.container;state.matchContainer=opts.matchContainer||state.matchContainer;state.role=typeof opts.getRole==='function'?opts.getRole:state.role;state.getContext=typeof opts.getContext==='function'?opts.getContext:state.getContext;state.getPreparedText=typeof opts.getPreparedText==='function'?opts.getPreparedText:state.getPreparedText;state.notify=typeof opts.notify==='function'?opts.notify:state.notify;ensureStyle();
  }
  function activate(){if(!state.container)return;state.container.classList.remove('hidden');if(!state.loaded)void loadIndex(false);else renderBoard();}
  function deactivate(){state.container?.classList.add('hidden');}

  globalThis.IOfficeTrackerBoard={init,activate,deactivate,refresh:()=>loadIndex(true),openTask,matchCurrentOutgoing,createFromPayload,changeStatus};
})();
