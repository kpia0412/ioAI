'use strict';
const $=id=>document.getElementById(id);
const CATALOG=globalThis.IOFFICE_PROVIDER_CATALOG||{};
const defaults={
  userRole:'leader',
  analysisMode:'gemini-web',
  fallbackAnalysisMode:'chatgpt-web',
  aiRequireCompleteFiles:true,
  webAiEnabled:true,
  webGeminiMaxTurns:3, webChatgptMaxTurns:3,
  webGeminiTimeoutMs:150000, webChatgptTimeoutMs:150000,
  readerMode:'primary',
  readerTimeoutMs:5000,
  readerMaxFileSizeMb:10,
  readerIncludeRelated:false,
  trackerEnabled:false,
  trackerApiUrl:'',
  trackerToken:'',
  trackerReminderDays:3,
  clerkIncomingMainRecipient:'',
  clerkIncomingCoordRecipients:[],
  clerkIncomingViewRecipients:[],
  clerkIncomingMainRecipientId:'',
  clerkIncomingCoordRecipientIds:[],
  clerkIncomingViewRecipientIds:[],
  clerkRecipientDirectory:[],
  instructionPrefixEnabled:false,
  instructionPrefixText:'VP đề xuất:',
  providerOrder:['gemini','openai','none','none'],
  providerConfigs:{},
  requestTimeoutMs:45000,
  retriesPerProvider:1
};
let current={};

function deepMerge(base,extra){
  const out={...base};
  for(const [k,v] of Object.entries(extra||{})){
    out[k]=(v&&typeof v==='object'&&!Array.isArray(v)&&base?.[k]&&typeof base[k]==='object'&&!Array.isArray(base[k]))?deepMerge(base[k],v):v;
  }
  return out;
}
function defaultProviderConfigs(){
  const out={};
  for(const [id,p] of Object.entries(CATALOG))out[id]={apiKey:'',model:p.defaultModel||'',baseUrl:p.baseUrl||'',authMode:'bearer',customHeaderName:'',customHeaderValue:'',deployment:'',apiVersion:'2025-04-01-preview'};
  return out;
}
function msg(t,ok=true){$('msg').textContent=t;$('msg').className='msg '+(ok?'ok':'err');}
function runtime(message){return new Promise(resolve=>{try{chrome.runtime.sendMessage(message,r=>resolve(chrome.runtime.lastError?{ok:false,error:chrome.runtime.lastError.message}:r));}catch(e){resolve({ok:false,error:e.message});}});}
function selectedValues(el){return [...el.selectedOptions].map(o=>o.value).filter(Boolean);}
function esc(v){return String(v||'').replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('"','&quot;');}

function fillDirectory(list){
  const clean=(Array.isArray(list)?list:[]).filter(x=>x&&x.key&&x.name);
  const main=$('clerkMain'),coord=$('clerkCoord'),view=$('clerkView');

  const units=clean.filter(x=>x.type==='unit');
  const people=clean.filter(x=>x.type==='person');
  const groups=new Map();
  for(const x of people){
    const g=String(x.parentName||x.parentUnit||'Cá nhân khác').trim()||'Cá nhân khác';
    if(!groups.has(g))groups.set(g,[]);
    groups.get(g).push(x);
  }
  const opt=x=>`<option value="${esc(x.key)}">${esc(x.name)}</option>`;
  let options='';
  if(units.length)options+=`<optgroup label="Đơn vị">${units.map(opt).join('')}</optgroup>`;
  for(const [group,items] of groups)options+=`<optgroup label="${esc(group)}">${items.map(opt).join('')}</optgroup>`;
  if(!options)options=clean.map(opt).join('');

  main.innerHTML='<option value="">— Chưa chọn —</option>'+options;
  coord.innerHTML=options; view.innerHTML=options;

  main.value=current.clerkIncomingMainRecipientId||'';
  const c=new Set(current.clerkIncomingCoordRecipientIds||[]);
  const v=new Set(current.clerkIncomingViewRecipientIds||[]);
  [...coord.options].forEach(o=>o.selected=c.has(o.value));
  [...view.options].forEach(o=>o.selected=v.has(o.value));

  const ds=$('directoryStatus'); if(ds){ds.textContent=clean.length ? `Đã ghi nhận ${clean.length} người/đơn vị từ cây nhận trực tiếp của iOffice.` : 'Chưa có danh bạ.'; ds.className='status '+(clean.length?'ok':'');}
}

function syncRoleUi(){
  const role=$('userRole').value;
  const clerk=role==='clerk', tracker=role==='tracker';
  document.querySelectorAll('.aiSetting').forEach(el=>el.classList.toggle('hidden',clerk||tracker));
  $('prefixCard')?.classList.toggle('hidden',clerk||tracker);
  $('clerkCard')?.classList.toggle('hidden',!clerk);
  if($('roleCardTitle')) $('roleCardTitle').textContent=tracker?'Chế độ mặc định':clerk?'Vai trò & chuyển văn bản':'Vai trò & trợ lý AI';
  if($('roleHint')) $('roleHint').innerHTML=tracker
    ? '<b>Sổ theo dõi:</b> chỉ tải dữ liệu khi mở chế độ này; không quét nền iOffice.'
    : clerk
      ? '<b>Chế độ Văn thư:</b> không gọi AI và không đọc tệp khi bấm Xử lý. “Áp dụng” chỉ tick người nhận; “Áp dụng & Chuyển xử lý” mới chuyển.'
      : '<b>Chế độ Lãnh đạo:</b> văn bản đến dùng Phân tích; văn bản đi dùng Kiểm tra văn bản. Sổ nhiệm vụ chỉ được đối chiếu khi người dùng chủ động.';
}

function loadApiProvider(id){
  const cfg=current.providerConfigs?.[id]||{};
  $('apiProvider').value=id;
  $('apiModel').value=cfg.model||'';
  $('apiBaseUrl').value=cfg.baseUrl||CATALOG[id]?.baseUrl||'';
  $('apiKey').value=cfg.apiKey||'';
}

async function load(){
  const raw=await chrome.storage.local.get(null);
  current={...defaults,...raw,providerConfigs:deepMerge(defaultProviderConfigs(),raw.providerConfigs||{})};
  $('version').textContent='v'+chrome.runtime.getManifest().version;
  $('userRole').value=['leader','clerk','tracker'].includes(current.userRole)?current.userRole:'leader';
  $('analysisMode').value=['gemini-web','chatgpt-web','api'].includes(current.analysisMode)?current.analysisMode:'gemini-web';
  $('fallbackAnalysisMode').value=['gemini-web','chatgpt-web','api','none'].includes(current.fallbackAnalysisMode)?current.fallbackAnalysisMode:'chatgpt-web';
  $('aiRequireCompleteFiles').checked=current.aiRequireCompleteFiles!==false;
  $('webAiEnabled').checked=current.webAiEnabled!==false;
  $('webAiMaxTurns').value=String(Math.max(2,Math.min(5,Number(current.webGeminiMaxTurns||current.webChatgptMaxTurns)||3)));
  $('webAiTimeoutSec').value=String(Math.round((Number(current.webGeminiTimeoutMs||current.webChatgptTimeoutMs)||150000)/1000));

  $('readerMode').value=current.readerMode==='all'?'all':'primary';
  $('readerTimeoutSec').value=String(Math.round((Number(current.readerTimeoutMs)||5000)/1000));
  $('readerMaxFileSizeMb').value=String(Number(current.readerMaxFileSizeMb)||10);
  $('readerIncludeRelated').checked=current.readerIncludeRelated===true;

  $('trackerEnabled').checked=current.trackerEnabled===true;
  $('trackerApiUrl').value=current.trackerApiUrl||'';
  $('trackerToken').value=current.trackerToken||'';
  $('trackerReminderDays').value=String(Number(current.trackerReminderDays)||3);

  if($('instructionPrefixEnabled')) $('instructionPrefixEnabled').checked=current.instructionPrefixEnabled===true;
  if($('instructionPrefixText')) $('instructionPrefixText').value=String(current.instructionPrefixText ?? 'VP đề xuất:');
  fillDirectory(current.clerkRecipientDirectory);
  syncRoleUi();

  const api=(current.providerOrder||[]).find(x=>['gemini','openai','gateway','custom'].includes(x))||'gemini';
  current._editingApi=api;
  loadApiProvider(api);
}

$('userRole').addEventListener('change',syncRoleUi);

$('apiProvider').addEventListener('change',()=>{
  const prev=current._editingApi||((current.providerOrder||[]).find(x=>['gemini','openai','gateway','custom'].includes(x))||'gemini');
  current.providerConfigs[prev]={...(current.providerConfigs[prev]||{}),model:$('apiModel').value.trim(),baseUrl:$('apiBaseUrl').value.trim(),apiKey:$('apiKey').value.trim()};
  current._editingApi=$('apiProvider').value;
  loadApiProvider(current._editingApi);
});

$('refreshClerkDirectory')?.addEventListener('click',async()=>{
  const r=await chrome.storage.local.get({clerkRecipientDirectory:[]});
  current.clerkRecipientDirectory=r.clerkRecipientDirectory||[];
  fillDirectory(current.clerkRecipientDirectory);
  msg(current.clerkRecipientDirectory.length?'Đã tải lại danh bạ Văn thư từ iOffice.':'Chưa có danh bạ. Hãy mở văn bản đến và bấm Xử lý trên iOffice trước.',Boolean(current.clerkRecipientDirectory.length));
});


async function testWebAi(provider){
  const el=$('webAiHealth');
  const label=provider==='chatgpt'?'ChatGPT Web':'Gemini Web';
  el.textContent=`Đang kiểm tra ${label}…`; el.className='status';
  const r=await runtime({type:'WEB_AUTOMATION_PREWARM',provider});
  if(!r?.ok){el.textContent=`✕ ${label}: ${r?.error||'không sẵn sàng'}`;el.className='status err';return;}
  el.textContent=`✓ ${label}: ô nhập ${r.data?.composerFound?'OK':'chưa thấy'} · nút gửi ${r.data?.sendFound?'OK':'chưa sẵn sàng'}${r.data?.reused?' · dùng lại tab ấm':' · đã mở tab nền'}.`;
  el.className='status ok';
}
$('testGeminiWeb')?.addEventListener('click',()=>void testWebAi('gemini'));
$('testChatgptWeb')?.addEventListener('click',()=>void testWebAi('chatgpt'));

async function ensureTrackerPermission(url){
  if(!url)return false;
  const u=new URL(url);
  if(u.protocol!=='https:')throw new Error('URL Apps Script phải dùng HTTPS.');
  const origins=[`${u.protocol}//${u.hostname}/*`,'https://script.googleusercontent.com/*'];
  const miss=[];
  for(const origin of origins)if(!(await chrome.permissions.contains({origins:[origin]})))miss.push(origin);
  return !miss.length||await chrome.permissions.request({origins:miss});
}

$('testTracker').addEventListener('click',async()=>{
  const el=$('trackerStatus');el.textContent='Đang kiểm tra…';el.className='status';
  try{
    const url=$('trackerApiUrl').value.trim(),token=$('trackerToken').value.trim();
    if(!url||!token)throw new Error('Nhập URL Web App và mã truy cập trước.');
    if(!(await ensureTrackerPermission(url)))throw new Error('Chưa cấp quyền Apps Script.');
    await chrome.storage.local.set({trackerEnabled:true,trackerApiUrl:url,trackerToken:token});
    const r=await runtime({type:'TRACKER_TEST'});
    if(!r?.ok)throw new Error(r?.error||'Không kết nối được Sổ.');
    el.textContent='✓ Đã kết nối Tracker '+(r.data?.version||'');
    el.className='status ok';
  }catch(e){el.textContent=e.message;el.className='status err';}
});

async function reloadOfficeTabs(){
  try{
    const tabs=await chrome.tabs.query({url:['https://ioffice.vnptdaklak.vn/qlvbdh_dlk/*']});
    await Promise.allSettled(tabs.map(t=>chrome.tabs.reload(t.id)));
  }catch(_){}
}

$('save').addEventListener('click',async()=>{
  try{
    const oldRole=current.userRole;
    const api=$('apiProvider').value;
    current.providerConfigs[api]={...(current.providerConfigs[api]||{}),model:$('apiModel').value.trim(),baseUrl:$('apiBaseUrl').value.trim()||CATALOG[api]?.baseUrl||'',apiKey:$('apiKey').value.trim()};

    const dir=new Map((current.clerkRecipientDirectory||[]).map(x=>[x.key,x.name]));
    const mainId=$('clerkMain').value;
    const coordIds=selectedValues($('clerkCoord')).filter(x=>x!==mainId);
    const coordSet=new Set(coordIds);
    const viewIds=selectedValues($('clerkView')).filter(x=>x!==mainId&&!coordSet.has(x));

    const settings={
      userRole:$('userRole').value,
      analysisMode:$('analysisMode').value,
      fallbackAnalysisMode:$('fallbackAnalysisMode').value,
      webAiEnabled:$('webAiEnabled').checked,
      webGeminiForeground:false,
      webGeminiFirstForeground:false,
      webChatgptForeground:false,
      webChatgptFirstForeground:false,
      webGeminiMaxTurns:Math.max(2,Math.min(5,Number($('webAiMaxTurns').value)||3)),
      webChatgptMaxTurns:Math.max(2,Math.min(5,Number($('webAiMaxTurns').value)||3)),
      webGeminiTimeoutMs:Math.max(60000,Math.min(240000,Number($('webAiTimeoutSec').value||150)*1000)),
      webChatgptTimeoutMs:Math.max(60000,Math.min(240000,Number($('webAiTimeoutSec').value||150)*1000)),
      aiRequireCompleteFiles:$('aiRequireCompleteFiles').checked,

      readerMode:$('readerMode').value,
      readerTimeoutMs:Math.max(2000,Math.min(60000,Number($('readerTimeoutSec').value||5)*1000)),
      readerMaxFileSizeMb:Math.max(1,Math.min(50,Number($('readerMaxFileSizeMb').value||10))),
      readerIncludeRelated:$('readerIncludeRelated').checked,
      readerConcurrency:0,
      readerDeduplicateContent:true,
      readerScanEnabled:false,

      trackerEnabled:$('trackerEnabled').checked,
      trackerApiUrl:$('trackerApiUrl').value.trim(),
      trackerToken:$('trackerToken').value.trim(),
      trackerReminderDays:Number($('trackerReminderDays').value||3),

      clerkIncomingMainRecipientId:mainId,
      clerkIncomingCoordRecipientIds:coordIds,
      clerkIncomingViewRecipientIds:viewIds,
      clerkIncomingMainRecipient:dir.get(mainId)||'',
      clerkIncomingCoordRecipients:coordIds.map(x=>dir.get(x)||'').filter(Boolean),
      clerkIncomingViewRecipients:viewIds.map(x=>dir.get(x)||'').filter(Boolean),
      instructionPrefixEnabled:$('instructionPrefixEnabled')?.checked === true,
      instructionPrefixText:String($('instructionPrefixText')?.value || 'VP đề xuất:').trim(),

      providerOrder:[api,'none','none','none'],
      providerConfigs:current.providerConfigs,
      retriesPerProvider:1,
      requestTimeoutMs:45000
    };

    if(settings.trackerEnabled){
      if(!settings.trackerApiUrl||!settings.trackerToken)throw new Error('Đã bật Sổ theo dõi nhưng chưa nhập URL/token.');
      if(!(await ensureTrackerPermission(settings.trackerApiUrl)))throw new Error('Chưa cấp quyền Apps Script.');
    }
    if(settings.analysisMode==='api'||settings.fallbackAnalysisMode==='api'){
      const u=new URL(settings.providerConfigs[api].baseUrl);
      const origin=`${u.protocol}//${u.hostname}/*`;
      if(!(await chrome.permissions.contains({origins:[origin]})))await chrome.permissions.request({origins:[origin]});
    }

    await chrome.storage.local.set(settings);
    current={...current,...settings};
    const roleChanged=oldRole!==settings.userRole;
    msg(roleChanged?'Đã lưu. Đang tải lại các tab iOffice theo vai trò mới…':'Đã lưu cấu hình.',true);
    if(roleChanged)await reloadOfficeTabs();
  }catch(e){msg(e.message,false);}
});

load().catch(e=>msg('Không tải được cấu hình: '+e.message,false));
