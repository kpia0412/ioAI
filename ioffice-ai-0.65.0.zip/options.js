'use strict';
const $=id=>document.getElementById(id);
const API_PROVIDER='gemini-openai';
const API_BASE_URL='https://generativelanguage.googleapis.com/v1beta/openai/';
const API_MODELS=['gemini-3.5-flash-lite','gemini-3.1-flash-lite','gemini-3.8-flash'];
const defaults={
  analysisMode:'api',fallbackAnalysisMode:'gemini-web',aiRequireCompleteFiles:true,webAiEnabled:true,
  webGeminiMaxTurns:3,webChatgptMaxTurns:3,webGeminiTimeoutMs:150000,webChatgptTimeoutMs:150000,
  readerMode:'primary',readerTimeoutMs:5000,readerMaxFileSizeMb:10,readerIncludeRelated:false,
  trackerEnabled:false,trackerApiUrl:'',trackerToken:'',trackerReminderDays:3,
  instructionPrefixEnabled:false,instructionPrefixText:'VP đề xuất:',providerOrder:[API_PROVIDER,'none','none','none'],providerConfigs:{}
};
let current={...defaults};
function msg(t,ok=true){$('msg').textContent=t;$('msg').className='msg '+(ok?'ok':'err');}
function runtime(m){return new Promise(resolve=>{try{chrome.runtime.sendMessage(m,r=>resolve(chrome.runtime.lastError?{ok:false,error:chrome.runtime.lastError.message}:(r||{ok:false})));}catch(e){resolve({ok:false,error:e.message});}});}
function geminiCfg(){
  const cfg=current.providerConfigs?.[API_PROVIDER]||{};
  const legacyCustom=current.providerConfigs?.custom||{};
  const legacyGemini=current.providerConfigs?.gemini||{};
  const googleCustom=/generativelanguage\.googleapis\.com\/v1beta\/openai/i.test(String(legacyCustom.baseUrl||''));
  return {
    model: API_MODELS.includes(cfg.model)?cfg.model:(googleCustom&&API_MODELS.includes(legacyCustom.model)?legacyCustom.model:'gemini-3.5-flash-lite'),
    baseUrl: API_BASE_URL,
    apiKey: cfg.apiKey || (googleCustom?legacyCustom.apiKey:'') || legacyGemini.apiKey || ''
  };
}
async function load(){
  current=await chrome.storage.local.get(defaults);
  $('version').textContent='v'+chrome.runtime.getManifest().version;
  $('analysisMode').value=['api','gemini-web','chatgpt-web'].includes(current.analysisMode)?current.analysisMode:'api';
  $('fallbackAnalysisMode').value=['gemini-web','chatgpt-web','none'].includes(current.fallbackAnalysisMode)?current.fallbackAnalysisMode:'gemini-web';
  $('aiRequireCompleteFiles').checked=current.aiRequireCompleteFiles!==false;
  $('instructionPrefixEnabled').checked=current.instructionPrefixEnabled===true;$('instructionPrefixText').value=current.instructionPrefixText||'VP đề xuất:';
  $('trackerApiUrl').value=current.trackerApiUrl||'';$('trackerToken').value=current.trackerToken||'';$('trackerReminderDays').value=String(current.trackerReminderDays||3);
  $('readerTimeoutSec').value=String(Math.round((current.readerTimeoutMs||5000)/1000));$('readerMaxFileSizeMb').value=String(current.readerMaxFileSizeMb||10);
  const cfg=geminiCfg();$('apiPreset').value=cfg.model;$('apiBaseUrl').value=API_BASE_URL;$('apiKey').value=cfg.apiKey;
}
async function ensureOriginPermission(url){const u=new URL(url);const origin=`${u.protocol}//${u.hostname}/*`;return (await chrome.permissions.contains({origins:[origin]}))||await chrome.permissions.request({origins:[origin]});}
async function ensureTrackerPermission(url){if(!url)return false;const u=new URL(url);if(u.protocol!=='https:'||u.hostname!=='script.google.com'||!/^\/macros\/s\/[^/]+\/exec$/.test(u.pathname)||u.username||u.password)throw new Error('Nhập URL Apps Script dạng https://script.google.com/macros/s/.../exec.');const origins=[`${u.protocol}//${u.hostname}/*`,'https://script.googleusercontent.com/*'];const miss=[];for(const origin of origins)if(!(await chrome.permissions.contains({origins:[origin]})))miss.push(origin);return !miss.length||await chrome.permissions.request({origins:miss});}
$('testApi')?.addEventListener('click',async()=>{const el=$('apiStatus');el.textContent='Đang kiểm tra API…';el.className='status';try{const apiKey=$('apiKey').value.trim();const model=$('apiPreset').value;if(!apiKey)throw new Error('Nhập API key trước.');if(!(await ensureOriginPermission(API_BASE_URL)))throw new Error('Chưa cấp quyền truy cập máy chủ API.');const r=await runtime({type:'AI_TEST_PROVIDER',providerId:API_PROVIDER,config:{apiKey,model,baseUrl:API_BASE_URL,authMode:'bearer'}});if(!r?.ok)throw new Error(r?.error||'Không kết nối được API.');const models=Array.isArray(r.data?.models)?r.data.models:[];const exists=models.some(x=>String(x?.id||x)===model);el.textContent=exists?`✓ Kết nối API thành công · ${model}`:`✓ Kết nối API thành công${models.length?` · thấy ${models.length} model`:''}.`;el.className='status ok';}catch(e){el.textContent='✕ '+e.message;el.className='status err';}});
$('testTracker')?.addEventListener('click',async()=>{const el=$('trackerStatus');el.textContent='Đang kiểm tra…';el.className='status';try{const url=$('trackerApiUrl').value.trim(),token=$('trackerToken').value.trim();if(!url||!token)throw new Error('Nhập URL Web App và TOKEN trước.');if(!(await ensureTrackerPermission(url)))throw new Error('Chưa cấp quyền Apps Script.');await chrome.storage.local.set({trackerEnabled:true,trackerApiUrl:url,trackerToken:token});const r=await runtime({type:'TRACKER_TEST'});if(!r?.ok)throw new Error(r?.error||'Không kết nối được Sổ.');el.textContent=`✓ Đã kết nối Tracker ${r.data?.version||''}`;el.className='status ok';}catch(e){el.textContent='✕ '+e.message;el.className='status err';}});
$('save')?.addEventListener('click',async()=>{try{
  const model=$('apiPreset').value,apiKey=$('apiKey').value.trim();
  const providerConfigs={...(current.providerConfigs||{})};providerConfigs[API_PROVIDER]={...(providerConfigs[API_PROVIDER]||{}),model,baseUrl:API_BASE_URL,apiKey,authMode:'bearer'};
  const trackerApiUrl=$('trackerApiUrl').value.trim(),trackerToken=$('trackerToken').value.trim();
  const trackerEnabled=Boolean(trackerApiUrl&&trackerToken);
  if((trackerApiUrl&&!trackerToken)||(!trackerApiUrl&&trackerToken))throw new Error('Sổ theo dõi cần nhập đủ cả URL Web App và TOKEN.');
  if(trackerEnabled&&!(await ensureTrackerPermission(trackerApiUrl)))throw new Error('Chưa cấp quyền Apps Script.');
  if($('analysisMode').value==='api'){if(!apiKey)throw new Error('Phân tích mặc định là API nhưng chưa nhập API key.');if(!(await ensureOriginPermission(API_BASE_URL)))throw new Error('Chưa cấp quyền máy chủ API.');}
  const settings={userRole:'leader',analysisMode:$('analysisMode').value,fallbackAnalysisMode:$('fallbackAnalysisMode').value,webAiEnabled:true,webGeminiForeground:false,webGeminiFirstForeground:false,webChatgptForeground:false,webChatgptFirstForeground:false,webGeminiMaxTurns:3,webChatgptMaxTurns:3,webGeminiTimeoutMs:150000,webChatgptTimeoutMs:150000,aiRequireCompleteFiles:$('aiRequireCompleteFiles').checked,readerMode:'primary',readerTimeoutMs:Math.max(2000,Math.min(60000,Number($('readerTimeoutSec').value||5)*1000)),readerMaxFileSizeMb:Math.max(1,Math.min(50,Number($('readerMaxFileSizeMb').value||10))),readerIncludeRelated:false,readerConcurrency:0,readerDeduplicateContent:true,readerScanEnabled:false,trackerEnabled,trackerApiUrl,trackerToken,trackerReminderDays:Number($('trackerReminderDays').value||3),instructionPrefixEnabled:$('instructionPrefixEnabled').checked,instructionPrefixText:String($('instructionPrefixText').value||'VP đề xuất:').trim(),providerOrder:[API_PROVIDER,'none','none','none'],providerConfigs,retriesPerProvider:1,requestTimeoutMs:45000};
  await chrome.storage.local.set(settings);current={...current,...settings};msg('Đã lưu cấu hình.',true);
}catch(e){msg(e.message,false);}});
load().catch(e=>msg('Không tải được cấu hình: '+e.message,false));
