(() => {
  'use strict';

  const VERSION = `${globalThis.chrome?.runtime?.getManifest?.().version || '2.0.0'}-reader`;
  const MAX_FILE_CHARS = 40000;
  const MAX_PRIMARY_CHARS = 18000;
  const MAX_SUPPORT_CHARS = 5000;
  const MAX_TOTAL_AI_CHARS = 28000;
  const MAX_PDF_PAGES = 80;
  const MAX_SCAN_FILE_BYTES = 8 * 1024 * 1024;
  const MAX_SCAN_TOTAL_BYTES = 12 * 1024 * 1024;
  const MAX_SCAN_ATTACHMENTS = 3;
  const MIN_TEXT_CHARS = 40;
  const NETWORK_CHANNEL = 'ioffice-file-network-v1';
  const observedNetwork = [];
  const capturedFiles = [];
  const pendingViewerResolvers = new Map();
  const capturedCopyTexts = [];
  const MAX_CAPTURE_CACHE_BYTES = 60 * 1024 * 1024;

  function trimCapturedFiles() {
    let total = capturedFiles.reduce((n, x) => n + Number(x.bytes?.byteLength || 0), 0);
    while (capturedFiles.length > 40 || total > MAX_CAPTURE_CACHE_BYTES) {
      const removed = capturedFiles.shift();
      total -= Number(removed?.bytes?.byteLength || 0);
    }
  }

  window.addEventListener('message', (event) => {
    if (event.origin !== location.origin || event.data?.channel !== NETWORK_CHANNEL) return;
    const type = String(event.data?.type || '');

    if (type === 'resolved-viewer') {
      const requestId = String(event.data?.requestId || '');
      const pending = pendingViewerResolvers.get(requestId);
      if (!pending) return;
      pendingViewerResolvers.delete(requestId);
      pending.resolve({
        ok: Boolean(event.data?.ok),
        url: String(event.data?.url || ''),
        error: String(event.data?.error || '')
      });
      return;
    }

    if (type === 'copy-text') {
      const text = cleanText(String(event.data?.text || ''));
      if (text.length >= MIN_TEXT_CHARS) {
        capturedCopyTexts.push({ text: text.slice(0, MAX_FILE_CHARS), frameUrl: String(event.data?.frameUrl || ''), ts: Date.now() });
        while (capturedCopyTexts.length > 30) capturedCopyTexts.shift();
      }
      return;
    }

    const url = String(event.data?.url || '');
    const frameUrl = String(event.data?.frameUrl || '');
    if (!url || !url.startsWith(location.origin + '/')) return;

    if (type === 'resource') {
      observedNetwork.push({
        url,
        frameUrl,
        initiatorType: String(event.data.initiatorType || ''),
        method: String(event.data.method || 'GET'),
        contentLength: Number(event.data.contentLength || 0),
        contentType: String(event.data.contentType || ''),
        disposition: String(event.data.disposition || ''),
        ts: Date.now()
      });
      while (observedNetwork.length > 900) observedNetwork.shift();
      return;
    }

    if (type === 'file-bytes' && event.data?.bytes != null) {
      try {
        const raw = event.data.bytes;
        let bytes = null;
        if (raw instanceof ArrayBuffer) bytes = new Uint8Array(raw);
        else if (ArrayBuffer.isView(raw)) bytes = new Uint8Array(raw.buffer, raw.byteOffset, raw.byteLength);
        else if (typeof raw?.byteLength === 'number') bytes = new Uint8Array(raw);
        if (!bytes?.byteLength) return;
        capturedFiles.push({
          url,
          frameUrl,
          filename: String(event.data.filename || ''),
          contentType: String(event.data.contentType || ''),
          disposition: String(event.data.disposition || ''),
          signature: String(event.data.signature || ''),
          initiatorType: String(event.data.initiatorType || ''),
          bytes,
          ts: Date.now()
        });
        trimCapturedFiles();
      } catch (_) {}
    }
  });

  function abortError() {
    try { return new DOMException('Đã dừng phân tích.', 'AbortError'); }
    catch (_) { const e = new Error('Đã dừng phân tích.'); e.name = 'AbortError'; return e; }
  }

  function assertNotAborted(signal) {
    if (signal?.aborted) throw abortError();
  }

  async function sleepAbortable(ms, signal) {
    assertNotAborted(signal);
    await new Promise((resolve, reject) => {
      const t = setTimeout(() => { signal?.removeEventListener('abort', onAbort); resolve(); }, ms);
      const onAbort = () => {
        clearTimeout(t);
        signal.removeEventListener('abort', onAbort);
        reject(abortError());
      };
      signal?.addEventListener('abort', onAbort, { once: true });
    });
    assertNotAborted(signal);
  }

  const normalizeInline = (value) => String(value || '')
    .replace(/\u00a0/g, ' ')
    .replace(/[ \t]+/g, ' ')
    .trim();

  const cleanText = (value) => String(value || '')
    .replace(/\u00a0/g, ' ')
    .replace(/\r/g, '')
    .split('\n')
    .map((line) => line.replace(/[ \t]+/g, ' ').trim())
    .filter(Boolean)
    .join('\n')
    .replace(/\n{3,}/g, '\n\n')
    .trim();

  function wordCount(value) {
    const text = cleanText(value);
    if (!text) return 0;
    return (text.match(/[\p{L}\p{N}]+(?:['’._-][\p{L}\p{N}]+)*/gu) || []).length;
  }

  const fold = (value) => normalizeInline(value)
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/đ/g, 'd')
    .replace(/Đ/g, 'D')
    .toLowerCase();

  const STOP = new Set([
    'cong','van','ve','viec','theo','cua','va','cac','cho','tai','tren','den','tu','so','ngay','nam','thang',
    'ubnd','hdnd','tinh','xa','signed','final','copy','ban','ky','da','file','dinh','kem'
  ]);

  function tokens(value) {
    return fold(value)
      .replace(/[^a-z0-9]+/g, ' ')
      .split(/\s+/)
      .filter((x) => x.length >= 3 && !STOP.has(x));
  }

  function jaccard(a, b) {
    const A = new Set(a);
    const B = new Set(b);
    if (!A.size || !B.size) return 0;
    let inter = 0;
    for (const x of A) if (B.has(x)) inter += 1;
    return inter / (A.size + B.size - inter);
  }

  function extensionOf(name) {
    const m = String(name || '').toLowerCase().match(/\.([a-z0-9]{2,5})$/);
    return m ? m[1] : '';
  }

  function canonicalStem(name) {
    return fold(String(name || '')
      .replace(/\.[a-z0-9]{2,5}$/i, '')
      .replace(/(?:\.signed)+/ig, '')
      .replace(/\bsigned\b/ig, '')
      .replace(/\bfinal\b/ig, '')
      .replace(/\bcopy\b/ig, '')
      .replace(/\bban\s*ky\b/ig, '')
      .replace(/\bda\s*ky\b/ig, '')
      .replace(/\bky\s*so\b/ig, '')
      .replace(/\(\s*\d+\s*\)$/g, ''))
      .replace(/[^a-z0-9]+/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
  }

  function fileNameSimilarity(a, b) {
    const sa = canonicalStem(a);
    const sb = canonicalStem(b);
    if (!sa || !sb) return 0;
    if (sa === sb) return 1;
    if (sa.includes(sb) || sb.includes(sa)) return Math.min(sa.length, sb.length) / Math.max(sa.length, sb.length);
    return jaccard(tokens(sa), tokens(sb));
  }

  function textSimilarity(a, b) {
    const ta = tokens(String(a || '').slice(0, 16000));
    const tb = tokens(String(b || '').slice(0, 16000));
    return jaccard(ta, tb);
  }


  // Stable 1.3.2: văn bản hành chính thường nhận diện được ngay ở trang đầu qua
  // cơ quan ban hành + số/ký hiệu (nếu đã ký) + tên loại/trích yếu. Bản Word trước ký
  // có thể chưa có số, vì vậy không được bắt buộc số/ký hiệu nếu phần tên loại/trích yếu
  // và nội dung trang đầu đã khớp mạnh với văn bản hiện tại.
  function tokenCoverage(needleValue, haystackValue) {
    const a=[...new Set(tokens(needleValue))];
    if(!a.length)return 0;
    const B=new Set(tokens(haystackValue));
    let hit=0; for(const x of a) if(B.has(x)) hit+=1;
    return hit/a.length;
  }

  function administrativeIdentityEvidence(desc, item, meta={}) {
    const text=String(item?.text||'');
    const head=text.slice(0,8500);
    const subject=meta?.trichYeu||'';
    const sender=meta?.sender||meta?.issuer||meta?.donViBanHanh||'';
    const symbol=meta?.symbol||meta?.soKyHieu||meta?.soHieu||'';
    const subjectCoverage=tokenCoverage(subject, head);
    const nameCoverage=tokenCoverage(subject, desc?.name||'');
    const senderCoverage=sender ? tokenCoverage(sender, head) : 0;
    const exactSymbol=exactSymbolInText(symbol,head);
    const currentNo=primaryNumber(symbol);
    const numberHit=!!(currentNo && new RegExp(`(?:^|[^0-9])${currentNo}(?=[^0-9]|$)`).test(fold(head)));
    const familyNameStrong=nameCoverage>=0.28 || subjectSimilarity(subject,desc?.name||'','')>=0.22;
    const accepted = exactSymbol || numberHit
      || subjectCoverage>=0.42
      || (subjectCoverage>=0.28 && (senderCoverage>=0.20 || familyNameStrong || desc?.isMain===true))
      || (familyNameStrong && subjectCoverage>=0.16);
    const strong = exactSymbol || numberHit
      || subjectCoverage>=0.62
      || (subjectCoverage>=0.45 && (senderCoverage>=0.22 || familyNameStrong));
    return {subjectCoverage,nameCoverage,senderCoverage,exactSymbol,numberHit,accepted,strong};
  }

  function samePrimaryFamily(a,b){
    if(!a||!b)return false;
    const sa=canonicalStem(a.name||''), sb=canonicalStem(b.name||'');
    if(sa&&sb&&sa===sb)return true;
    return fileNameSimilarity(a.name||'',b.name||'')>=0.62;
  }

  function bytesToBase64(bytes) {
    if (!bytes?.length) return '';
    const chunk = 0x8000;
    let binary = '';
    for (let i = 0; i < bytes.length; i += chunk) {
      const slice = bytes.subarray(i, Math.min(bytes.length, i + chunk));
      binary += String.fromCharCode(...slice);
    }
    return btoa(binary);
  }

  function parseQuotedArgs(text) {
    const values = [];
    const re = /'((?:\\.|[^'])*)'|"((?:\\.|[^"])*)"/g;
    let m;
    while ((m = re.exec(text || ''))) {
      values.push((m[1] ?? m[2] ?? '').replace(/\\'/g, "'").replace(/\\"/g, '"'));
    }
    return values;
  }

  function stripActionWords(value) {
    let text = normalizeInline(value)
      .replace(/[|•·]+/g, ' ')
      .trim();
    // iOffice đôi khi ghép text nút trực tiếp vào tên tệp, ví dụ
    // "Xoá Đổi tên XemSố KH....docx". Chỉ bóc các nhãn hành động ở đầu chuỗi.
    const prefix = /^(?:(?:Xoá|Xóa)\s*|Đổi\s*tên\s*|Xem\s*tab\s*mới\s*|Xem\s*|Tải\s*tệp\s*tin\s*|Tải\s*file\s*|Tải\s*xuống\s*|Tải\s*về\s*|Ký\s*số\s*token\s*|Ký\s*SmartCA\s*|Ký\s*số\s*VGCA\s*|Ký\s*số\s*)+/i;
    for (let i = 0; i < 4; i++) {
      const next = text.replace(prefix, '').trim();
      if (next === text) break;
      text = next;
    }
    return text.replace(/\s+/g, ' ').trim();
  }

  function extractFilenameCandidate(value) {
    const text = stripActionWords(value);
    if (!text) return '';
    const matches = [];
    const re = /(?:^|[\s(])([^|<>]{1,240}?\.(?:pdf|docx?|xlsx?|xls|rtf|txt|zip|rar|7z))(?:$|[\s)|])/gi;
    let m;
    while ((m = re.exec(` ${text} `))) {
      const name = normalizeInline(m[1] || '').replace(/^[\-–—:;,\s]+|[\-–—:;,\s]+$/g, '');
      if (name) matches.push(name);
    }
    if (!matches.length) return '';
    return matches.sort((a, b) => {
      const aa = /(?:signed|ký|ky)/i.test(a) ? 1 : 0;
      const bb = /(?:signed|ký|ky)/i.test(b) ? 1 : 0;
      return bb - aa || b.length - a.length;
    })[0];
  }

  function cleanFilenameFromNode(node) {
    if (!node) return '';

    try {
      const elements = node.matches?.('[onclick*="showFileNewTab"]')
        ? [node]
        : [...(node.querySelectorAll?.('[onclick*="showFileNewTab"]') || [])];
      for (const el of elements) {
        const args = parseQuotedArgs(el.getAttribute('onclick') || '');
        const fromArgs = extractFilenameCandidate(args[2] || '');
        if (fromArgs) return fromArgs;
      }
    } catch (_) {}

    try {
      for (const el of node.querySelectorAll?.('[data-file-name], [download], a[href], [title]') || []) {
        const candidates = [
          el.getAttribute('data-file-name'),
          el.getAttribute('download'),
          el.getAttribute('title'),
          (() => {
            try {
              const href = el.getAttribute('href') || '';
              const pathname = new URL(href, location.href).pathname;
              return decodeURIComponent(pathname.split('/').pop() || '');
            } catch (_) { return ''; }
          })(),
          el.childElementCount === 0 ? (el.textContent || '') : ''
        ];
        for (const value of candidates) {
          const name = extractFilenameCandidate(value || '');
          if (name) return name;
        }
      }
    } catch (_) {}

    return extractFilenameCandidate(node.innerText || node.textContent || '');
  }

  function looksLikeAttachmentName(text) {
    return /\.(?:pdf|docx?|xlsx?|xls|rtf|txt|zip|rar|7z)(?:\s|$)/i.test(normalizeInline(text));
  }

  function sameDescriptorIdentity(a, b) {
    const aToken = String(a.viewerToken || '').trim();
    const bToken = String(b.viewerToken || '').trim();
    if (aToken && bToken && aToken === bToken) return true;

    const aFile = String(a.fileId || '').trim();
    const bFile = String(b.fileId || '').trim();
    if (aFile && bFile && aFile === bFile) return true;

    // Cùng đúng tên file thì chỉ là một tệp, dù iOffice render nó ở nhiều node/link khác nhau.
    const aName = fold(a.name || '');
    const bName = fold(b.name || '');
    // iOffice thường render cùng một tệp ở card + action/viewer khác token/id.
    // Tên file đầy đủ trùng nhau được xem là cùng một tệp để không bị 4 -> 8.
    if (aName && bName && aName === bName) return true;
    return false;
  }

  function exactIdElements(id) {
    if (!id) return [];
    try { return [...document.querySelectorAll(`#${CSS.escape(String(id))}`)]; }
    catch (_) { return [...document.querySelectorAll('[id]')].filter(el => el.id === String(id)); }
  }

  function exactIdValue(id, within = null) {
    const local = (() => { try { return within?.querySelector?.(`#${CSS.escape(String(id))}`); } catch (_) { return null; } })();
    if (local && 'value' in local && String(local.value || '').trim()) return String(local.value).trim();
    for (const el of exactIdElements(id)) {
      if ('value' in el && String(el.value || '').trim()) return String(el.value).trim();
    }
    return '';
  }

  function elementVisible(el) {
    if (!el?.isConnected) return false;
    try {
      const cs = getComputedStyle(el);
      if (cs.display === 'none' || cs.visibility === 'hidden' || Number(cs.opacity || 1) === 0) return false;
      return el.getClientRects().length > 0;
    } catch (_) { return true; }
  }

  function isPrimaryRedColor(value) {
    const m = String(value || '').match(/rgba?\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)/i);
    if (!m) return false;
    const r=Number(m[1]), g=Number(m[2]), b=Number(m[3]);
    return r >= 180 && g <= 115 && b <= 115 && r >= g * 1.65 && r >= b * 1.65;
  }

  function filenameElementMatches(el, name) {
    const target = fold(name || '');
    if (!target || !el) return false;
    const text = fold(normalizeInline(el.textContent || el.getAttribute?.('title') || ''));
    if (!text) return false;
    return text === target || fold(stripActionWords(text)) === target || (text.endsWith(target) && text.length <= target.length + 42);
  }

  // iOffice Đắk Lắk render cùng một file ở nhiều node #file_<id>. Một node quản trị có thể màu đen,
  // trong khi node chuyển xử lý của CHÍNH FILE đó hiển thị tên đỏ và có action signDocumentOnlineVbDen.
  // Không dùng document.getElementById vì duplicate id là hợp lệ trên DOM iOffice thực tế.
  function inspectDomPrimarySignal({ fileId='', viewerToken='', name='' } = {}, seedNode = null) {
    const nodes=[];
    const push=n=>{ if(n && !nodes.includes(n)) nodes.push(n); };
    push(seedNode);
    if (fileId) for (const n of exactIdElements(`file_${fileId}`)) push(n);

    // Nếu card gốc thiếu fileId, tìm node có action đúng token/tên. Chỉ dùng làm tín hiệu, không tạo descriptor mới.
    if ((!fileId || nodes.length <= 1) && (viewerToken || name)) {
      try {
        for (const el of document.querySelectorAll('[onclick*="showFileDinhKem"],[onclick*="showFileNewTab"],[onclick*="signDocumentOnlineVbDen"]')) {
          const onclick=String(el.getAttribute('onclick')||'');
          if ((viewerToken && onclick.includes(viewerToken)) || (name && onclick.includes(name))) push(el.closest('[id^="file_"]') || el.parentElement);
        }
      } catch (_) {}
    }

    let redName=false, incomingSign=false, transferContext=false, visibleReplica=false, visibleNameNode=false;
    for (const node of nodes) {
      if (!node) continue;
      if (elementVisible(node)) visibleReplica=true;
      const actionText=[node.getAttribute?.('onclick')||'', ...[...(node.querySelectorAll?.('[onclick]')||[])].map(el=>el.getAttribute('onclick')||'')].join(' ');
      if (/signDocumentOnlineVbDen/i.test(actionText) || node.querySelector?.('.btnKyToken')) incomingSign=true;
      if (/dinhkem_chuyenxuly|dukiennhan/i.test(actionText) || node.closest?.('[id*="dinhkem_chuyenxuly"],[id*="dukiennhan"]')) transferContext=true;
      const els=[node, ...[...(node.querySelectorAll?.('span,a,div,label')||[])]];
      for (const el of els) {
        if (!filenameElementMatches(el,name) || !elementVisible(el)) continue;
        visibleNameNode=true;
        try {
          const color=getComputedStyle(el).color || el.getAttribute?.('style') || '';
          if (isPrimaryRedColor(color) || /color\s*:\s*(?:#f5?1?7?07|red|rgb\(\s*245\s*,\s*23\s*,\s*7\s*\))/i.test(el.getAttribute?.('style')||'')) redName=true;
        } catch (_) {}
      }
    }
    let score=0;
    const reasons=[];
    if (redName) { score += 2.0; reasons.push('tên file đỏ'); }
    if (incomingSign) { score += 1.65; reasons.push('action ký VB đến'); }
    if (transferContext) { score += 0.65; reasons.push('vùng chuyển xử lý'); }
    if (visibleNameNode) score += 0.10;
    if (visibleReplica && nodes.length > 1) { score += 0.15; reasons.push('file render lặp đúng ID'); }
    return { score:Number(score.toFixed(2)), strong:score>=2.45, redName, incomingSign, transferContext, replicaCount:nodes.length, reasons };
  }

  function addDescriptor(map, raw = {}) {
    const rawName = normalizeInline(raw.name || '');
    const name = extractFilenameCandidate(rawName) || rawName;
    if (!name || !looksLikeAttachmentName(name)) return;

    const item = {
      nodeId: raw.nodeId || '',
      fileId: raw.fileId || '',
      viewerToken: raw.viewerToken || '',
      viewerUrl: raw.viewerUrl || '',
      candidateUrls: Array.isArray(raw.candidateUrls) ? raw.candidateUrls : [],
      actionArgs: Array.isArray(raw.actionArgs) ? raw.actionArgs.map(x => String(x ?? '')) : [],
      name,
      date: raw.date || '',
      scopeKind: raw.scopeKind || 'attachment',
      sourceSection: raw.sourceSection || '',
      isMain: raw.isMain === true,
      domPrimaryScore: Number(raw.domPrimaryScore || 0),
      domPrimaryStrong: raw.domPrimaryStrong === true,
      domPrimaryRed: raw.domPrimaryRed === true,
      domPrimaryReasons: Array.isArray(raw.domPrimaryReasons) ? raw.domPrimaryReasons : [],
      ext: extensionOf(name),
      canonicalStem: canonicalStem(name)
    };

    for (const [key, existing] of map.entries()) {
      if (!sameDescriptorIdentity(existing, item)) continue;
      map.set(key, {
        ...existing,
        nodeId: existing.nodeId || item.nodeId,
        fileId: existing.fileId || item.fileId,
        viewerToken: existing.viewerToken || item.viewerToken,
        viewerUrl: existing.viewerUrl || item.viewerUrl,
        candidateUrls: [...new Set([...(existing.candidateUrls || []), ...(item.candidateUrls || [])])],
        actionArgs: (existing.actionArgs?.length ? existing.actionArgs : item.actionArgs),
        date: existing.date || item.date,
        sourceSection: existing.sourceSection || item.sourceSection,
        isMain: existing.isMain || item.isMain,
        domPrimaryScore: Math.max(Number(existing.domPrimaryScore||0), Number(item.domPrimaryScore||0)),
        domPrimaryStrong: existing.domPrimaryStrong === true || item.domPrimaryStrong === true,
        domPrimaryRed: existing.domPrimaryRed === true || item.domPrimaryRed === true,
        domPrimaryReasons: [...new Set([...(existing.domPrimaryReasons||[]), ...(item.domPrimaryReasons||[])])],
        scopeKind: existing.scopeKind === 'attachment' || item.scopeKind === 'attachment'
          ? 'attachment'
          : (existing.scopeKind === 'signing' || item.scopeKind === 'signing' ? 'signing' : 'related')
      });
      return;
    }

    const key = item.viewerToken || item.fileId || `${item.scopeKind}|${fold(item.name)}`;
    map.set(key, item);
  }

  function collectUrlCandidates(node, args = []) {
    const values = [];
    const push = (value) => {
      value = String(value || '').trim();
      if (!value || /^(?:javascript:|#)/i.test(value)) return;
      // Tên tệp thuần trong argument không phải URL tải. Trước đây biến "abc.pdf" thành
      // URL tương đối của trang và tạo request rác/nhầm nguồn.
      if (/^[^/?#\\]+\.(?:pdf|docx?|xlsx?|xls|rtf|txt|zip|rar|7z)$/i.test(value)) return;
      if (!/(?:https?:\/\/|^\/|^\.\.?\/|download|attachment|getfile|viewfile|viewer|filedownload|[?&](?:file|id)=)/i.test(value)) return;
      try { values.push(new URL(value, location.href).href); } catch (_) {}
    };
    for (const value of args) push(value);
    try {
      const elements = [node, ...(node?.querySelectorAll?.('a,button,[onclick],[href],[data-url],[data-href],[data-file-url],[data-download-url],[data-src]') || [])];
      for (const el of elements) {
        for (const attr of ['href','src','data-url','data-href','data-file-url','data-download-url','data-src']) push(el?.getAttribute?.(attr));
        const onclick = el?.getAttribute?.('onclick') || '';
        for (const value of parseQuotedArgs(onclick)) push(value);
        for (const match of onclick.matchAll(/(?:https?:\/\/|\/)[^'"\s)]+/g)) push(match[0]);
      }
    } catch (_) {}
    return [...new Set(values)];
  }

  function descriptorFromCard(node, scopeKind = 'attachment') {
    if (!node) return null;
    const actions = [];
    try {
      if (node.matches?.('[onclick*="showFileDinhKem"], [onclick*="showFileNewTab"]')) actions.push(node);
      actions.push(...(node.querySelectorAll?.('[onclick*="showFileDinhKem"], [onclick*="showFileNewTab"]') || []));
    } catch (_) {}

    let best = null;
    for (const el of actions) {
      const onclick = el?.getAttribute?.('onclick') || '';
      const args = parseQuotedArgs(onclick);
      const name = extractFilenameCandidate(args[2] || '');
      if (!name) continue;
      const score = (/showFileDinhKem/i.test(onclick) ? 20 : 10) + (args[0] ? 4 : 0) + (args[1] ? 4 : 0);
      if (!best || score > best.score) best = { el, onclick, args, name, score };
    }

    const hrefEl = node.querySelector?.('a[href*="viewer" i], iframe[src*="viewer" i]');
    const href = hrefEl?.getAttribute?.('href') || hrefEl?.getAttribute?.('src') || '';
    const domId = String(node.id || '').replace(/^file_/, '');
    const hiddenFileId = exactIdValue(`txt_file_${domId}`, node);
    const hiddenToken = exactIdValue(`txt_file_hdd_${domId}`, node);
    const hiddenName = exactIdValue(`txt_file_name_${domId}`, node);
    const args = best?.args || [];
    const name = best?.name || extractFilenameCandidate(hiddenName) || normalizeInline(hiddenName) || cleanFilenameFromNode(node);
    if (!name || !looksLikeAttachmentName(name)) return null;
    const fileId = args[0] || hiddenFileId || domId || '';
    const viewerToken = args[1] || hiddenToken || '';
    const effectiveArgs = [fileId, viewerToken, name, args[3] || ''];
    const candidateUrls = collectUrlCandidates(node, [...args, ...effectiveArgs]);
    const mainToggle = node.querySelector?.('.btn_file_chinh,[onclick*="vbdi_toggleFileChinh"]');
    const mainToggleText = normalizeInline(mainToggle?.innerText || mainToggle?.textContent || '');
    const mainCheckbox = node.querySelector?.('input.chk_file_send,input[id^="chk_file_send"]');
    const isMain = Boolean(mainCheckbox?.checked)
      || /(?:bỏ|hủy)\s*file\s*chính/i.test(mainToggleText)
      || /file[_-]?main|file[_-]?chinh|primary/i.test(String(node.className || ''));
    const domPrimary = inspectDomPrimarySignal({ fileId, viewerToken, name:stripActionWords(name) }, node);
    return {
      nodeId: node.id || '',
      fileId,
      viewerToken,
      viewerUrl: /viewer|pdf|file/i.test(href) ? href : '',
      candidateUrls,
      actionArgs: effectiveArgs,
      name: stripActionWords(name),
      date: args[3] || '',
      scopeKind,
      sourceSection: scopeKind === 'signing' ? 'FILE_TRINH_KY' : '',
      isMain,
      domPrimaryScore:domPrimary.score,
      domPrimaryStrong:domPrimary.strong,
      domPrimaryRed:domPrimary.redName,
      domPrimaryReasons:domPrimary.reasons
    };
  }

  function smallestFileContainerFromHeading(heading, maxDepth = 5) {
    if (!heading) return null;
    let best = null;
    let cur = heading.parentElement;
    for (let depth = 0; cur && depth < maxDepth; depth++, cur = cur.parentElement) {
      if (cur === document.body || cur === document.documentElement) break;
      const directCards = (() => {
        try { return [...cur.querySelectorAll(':scope > [id^="file_"]')]; } catch (_) { return []; }
      })();
      const anyCards = [...(cur.querySelectorAll?.('[id^="file_"]') || [])];
      const actions = [...(cur.querySelectorAll?.('[onclick*="showFileNewTab"]') || [])];
      const count = directCards.length || anyCards.length || actions.length;
      if (!count || count > 60) continue;
      // The nearest file section is authoritative; do not widen into neighboring documents.
      return cur;
    }
    return best;
  }

  function findExactSectionHeading(pattern) {
    for (const el of document.querySelectorAll('div,span,b,strong,h1,h2,h3,h4,h5,legend,th,td,label')) {
      if(el.childElementCount>2)continue;
      const text = normalizeInline(el.textContent || '');
      if (pattern.test(text)) return el;
    }
    return null;
  }

  function getDeclaredAttachmentCount() {
    let declared = 0;
    // Tiêu đề iOffice có thể kèm icon/khoảng trắng hoặc node con, nên không phụ thuộc tuyệt đối vào exact heading.
    for (const el of document.querySelectorAll('div,span,b,strong,h1,h2,h3,h4,h5,legend,th,td,label')) {
      if (el.childElementCount > 4) continue;
      const text = normalizeInline(el.textContent || '');
      const m = text.match(/(?:FILE|TỆP)\s+ĐÍNH\s+KÈM\s*\((\d+)\)/i);
      if (m) declared = Math.max(declared, Number(m[1]) || 0);
    }
    // Fallback từ vùng chi tiết.
    const detailRoot = document.querySelector('#div_thongtin_chitiet, #rightContentDLK, #div_doc_detail');
    const detailText = normalizeInline(detailRoot?.innerText || '');
    const dm = detailText.match(/(?:FILE|TỆP)\s+ĐÍNH\s+KÈM\s*\((\d+)\)/i);
    if (dm) declared = Math.max(declared, Number(dm[1]) || 0);

    // Quan trọng: số card thật đang hiển thị là cận dưới đáng tin cậy. Trước đây declared=0/1 tạm thời
    // khiến resolver trả về quá sớm và bỏ sót Word/PDF cùng văn bản.
    const root = document.querySelector('#div_file_attach_dsvb, #div_file_list');
    if (root) {
      const names = new Set();
      let cards = [];
      try { cards = [...root.querySelectorAll(':scope > [id^="file_"], :scope > .x_file')]; } catch (_) { cards = [...root.querySelectorAll('[id^="file_"], .x_file')]; }
      for (const card of cards) {
        const name = cleanFilenameFromNode(card);
        if (name && looksLikeAttachmentName(name)) names.add(fold(name));
      }
      declared = Math.max(declared, names.size);
    }
    return Math.max(0, declared);
  }

  function getMainAttachmentRoot() {
    // Diagnostic iOffice Đắk Lắk xác nhận danh sách tệp chi tiết nằm ở #div_file_attach_dsvb.
    // Ưu tiên vùng này để tránh quét nhầm bản sao tệp trong modal/chuyển xử lý.
    for (const selector of ['#div_file_attach_dsvb', '#div_file_list']) {
      const direct = document.querySelector(selector);
      if (direct?.querySelector?.('[id^="file_"], [onclick*="showFileDinhKem"], [onclick*="showFileNewTab"]')) return direct;
    }

    // Một số màn hình không dùng các id trên: chỉ fallback theo đúng tiêu đề FILE/TỆP ĐÍNH KÈM.
    const heading = findExactSectionHeading(/^(?:FILE|TỆP)\s+ĐÍNH\s+KÈM(?:\s*\(\d+\))?$/i);
    return smallestFileContainerFromHeading(heading);
  }

  function getRelatedRoots() {
    // TUYỆT ĐỐI không dò theo id/class chứa "lienquan" vì iOffice có nhiều vùng nghiệp vụ
    // không phải danh sách tệp. Chỉ nhận vùng có tiêu đề hiển thị đúng "Văn bản liên quan".
    const roots = [];
    const headingPattern = /^VĂN\s+BẢN\s+LIÊN\s+QUAN(?:\s*\(\d+\))?$/i;
    for (const heading of document.querySelectorAll('div,span,b,strong,h1,h2,h3,h4,h5,legend,th,td,label')) {
      if(heading.childElementCount>2)continue;
      const text = normalizeInline(heading.textContent || '');
      if (!headingPattern.test(text)) continue;
      const root = smallestFileContainerFromHeading(heading);
      if (!root) continue;
      const main = getMainAttachmentRoot();
      if (main && (root === main || root.contains(main) || main.contains(root))) continue;
      if (!roots.some((x) => x === root || x.contains(root) || root.contains(x))) roots.push(root);
    }
    return roots;
  }

  function collectStrictRootDescriptors(root, scopeKind, found) {
    if (!root?.querySelectorAll) return;

    // iOffice thật đang render mỗi tệp thành một direct card #file_XXXXX bên trong #div_file_list.
    // Nếu đã có card direct thì chỉ đọc đúng các card này, TUYỆT ĐỐI không quét các link/action con lần nữa.
    let cards = [];
    try { cards = [...root.querySelectorAll(':scope > [id^="file_"]')]; } catch (_) {}
    if (root.id?.startsWith?.('file_')) cards.unshift(root);

    if (cards.length) {
      for (const card of cards) {
        const desc = descriptorFromCard(card, scopeKind);
        if (desc) addDescriptor(found, desc);
      }
      return;
    }

    // Với vùng "Văn bản liên quan" có thể không dùng #file_*. Khi đó mỗi showFileNewTab là một tệp.
    for (const el of root.querySelectorAll('[onclick*="showFileNewTab"], [onclick*="showFileDinhKem"]')) {
      const args = parseQuotedArgs(el.getAttribute('onclick') || '');
      const name = extractFilenameCandidate(args[2] || '');
      if (!name) continue;
      addDescriptor(found, {
        nodeId: el.closest('[id]')?.id || '',
        fileId: args[0] || '',
        viewerToken: args[1] || '',
        candidateUrls: collectUrlCandidates(el, args),
        actionArgs: args,
        name,
        date: args[3] || '',
        scopeKind
      });
    }
  }


  function signingSectionActive() {
    const label = document.querySelector('#phatHanhUploadLabel');
    const text = normalizeInline(label?.textContent || label?.innerText || '');
    return /^File\s+trình\s+ký/i.test(text);
  }

  function descriptorFromSigningPreProcess(root) {
    if (!root) return null;
    const actions = [...root.querySelectorAll('[onclick*="showFileDinhKem"],[onclick*="showFileNewTab"]')];
    let best = null;
    for (const el of actions) {
      const onclick = el.getAttribute('onclick') || '';
      const args = parseQuotedArgs(onclick);
      let fileId = '', viewerToken = '', name = '', date = '';
      if (/showFileDinhKem/i.test(onclick) || /showFileNewTab/i.test(onclick)) {
        fileId = args[0] || '';
        viewerToken = args[1] || '';
        name = extractFilenameCandidate(args[2] || '') || normalizeInline(args[2] || '');
        date = args[3] || '';
      }
      if (!name || !looksLikeAttachmentName(name)) continue;
      const score = (/showFileDinhKem/i.test(onclick) ? 30 : 20) + (fileId ? 5 : 0) + (viewerToken ? 5 : 0);
      if (!best || score > best.score) best = { el, args, fileId, viewerToken, name, date, score };
    }

    if (!best) {
      const dl = root.querySelector('[onclick*="filedownload"]');
      if (dl) {
        const args = parseQuotedArgs(dl.getAttribute('onclick') || '');
        const name = extractFilenameCandidate(args[1] || '') || normalizeInline(args[1] || '');
        if (name && looksLikeAttachmentName(name)) {
          best = { el: dl, args, fileId: '', viewerToken: args[0] || '', name, date: '', score: 10 };
        }
      }
    }
    if (!best) return null;

    return {
      nodeId: best.el.closest?.('[id]')?.id || root.id || '',
      fileId: best.fileId || '',
      viewerToken: best.viewerToken || '',
      viewerUrl: '',
      candidateUrls: collectUrlCandidates(root, best.args || []),
      actionArgs: best.args || [],
      name: stripActionWords(best.name),
      date: best.date || '',
      scopeKind: 'signing',
      sourceSection: 'FILE_TRINH_KY',
      isMain: true
    };
  }

  function getSigningFileDescriptors() {
    const found = new Map();

    // Sau khi bấm Xử lý: iOffice dựng đúng section FILE TRÌNH KÝ tại #div_file_list.
    if (signingSectionActive()) {
      const root = document.querySelector('#div_file_list');
      if (root) {
        let cards = [];
        try { cards = [...root.querySelectorAll(':scope > .x_file,:scope > [id^="file_"]')]; }
        catch (_) { cards = [...root.querySelectorAll('.x_file,[id^="file_"]')]; }
        const unique = [...new Set(cards)].filter(x => x && !/^txt_file_/i.test(x.id || ''));
        for (const card of unique) {
          const desc = descriptorFromCard(card, 'signing');
          if (desc) addDescriptor(found, { ...desc, sourceSection: 'FILE_TRINH_KY' });
        }
      }
    }

    // Trước khi bấm Xử lý: DOM thật của Lãnh đạo nằm tại #id_file_dinhkem.
    if (!found.size) {
      const desc = descriptorFromSigningPreProcess(document.querySelector('#id_file_dinhkem'));
      if (desc) addDescriptor(found, desc);
    }

    let list = dedupeDescriptorList([...found.values()]);
    // Văn bản đi: ưu tiên bản Word/DOCX để kiểm tra câu chữ. PDF chỉ là fallback.
    const signingRank = (x) => ['docx','doc'].includes(String(x.ext||'').toLowerCase()) ? 100 : String(x.ext||'').toLowerCase()==='pdf' ? 70 : 40;
    list.sort((a,b)=>(signingRank(b)-signingRank(a)) + ((b.isMain?1:0)-(a.isMain?1:0))*3);
    return list;
  }

  function chooseSigningDescriptor(list) {
    const arr = [...(list || [])];
    if (!arr.length) return null;
    const rank = (x) => ['docx','doc'].includes(String(x.ext||'').toLowerCase()) ? 100 : String(x.ext||'').toLowerCase()==='pdf' ? 70 : 40;
    return arr.sort((a,b)=>(rank(b)-rank(a)) + ((b.isMain?1:0)-(a.isMain?1:0))*3)[0] || null;
  }

  function policyKeywords(policy,key,fallback=[]) {
    const v=policy&&Array.isArray(policy[key])?policy[key]:fallback;
    return v.map(x=>fold(x||'')).filter(Boolean);
  }
  function containsAnyKeyword(text,keywords){const n=fold(text||'');return keywords.some(k=>k&&n.includes(k));}

  function referencesRequiredAppendix(text, policy=null) {
    const n=fold(text||''); if(!n)return false;
    const appendixK=policyKeywords(policy,'appendixNameKeywords',['phụ lục','danh sách','biểu','mẫu biểu','appendix']);
    if(!containsAnyKeyword(n,appendixK))return false;
    // Chỉ mạnh khi phụ lục quyết định đối tượng/nhiệm vụ/chỉ tiêu/biểu mẫu/hạn; nhắc “chi tiết tại phụ lục” đơn thuần không đủ.
    const target=/(?:don vi|co quan|dia phuong|doi tuong|co ten|nhiem vu|chi tieu|so lieu|bieu mau|mau bieu|bao cao|thoi han|han gui|han nop|deadline)/i;
    const lines=n.split(/\n|\.|;/).filter(Boolean);
    return lines.some(line=>containsAnyKeyword(line,appendixK)&&target.test(line)&&/(?:theo|tai|trong|kem theo|dinh kem|gui kem)/i.test(line));
  }

  function isLikelyRequiredAppendix(desc, policy=null) {
    return containsAnyKeyword(desc?.name||'',policyKeywords(policy,'appendixNameKeywords',['phụ lục','danh sách','biểu','appendix']));
  }

  function hasExplicitDeadlineCue(text, policy=null) {
    const raw=String(text||'');
    const n=fold(raw);
    if(!n)return false;
    // Mốc ngày/giờ hoặc thời hạn tương đối rõ ràng.
    if(/\b(?:0?[1-9]|[12]\d|3[01])[\/\-.](?:0?[1-9]|1[0-2])(?:[\/\-.](?:20)?\d{2,4})?\b/.test(raw))return true;
    if(/\b(?:\d{1,2})\s*(?:gio|h)\s*(?:\d{1,2})?\b/i.test(n))return true;
    if(/\b(?:trong vong|trong)\s+\d+\s+(?:ngay|ngay lam viec|gio)\b/i.test(n))return true;
    const dueK=policyKeywords(policy,'deadlineKeywords',['trước ngày','chậm nhất','hoàn thành trước','gửi trước','hạn','thời hạn','trong ngày','trong vòng','kể từ','ngày làm việc','định kỳ','hằng tháng','hàng tháng','hằng quý','hàng quý','theo tiến độ','gia hạn','điều chỉnh']);
    return containsAnyKeyword(n,dueK);
  }

  function hasLikelyTaskDeadlineCue(text, policy=null) {
    const taskK=policyKeywords(policy,'taskKeywords',['giao','đề nghị','yêu cầu','thực hiện','rà soát','báo cáo','cung cấp','xác nhận','có ý kiến','triển khai','xây dựng kế hoạch','gửi kết quả']);
    return containsAnyKeyword(text,taskK)&&hasExplicitDeadlineCue(text,policy);
  }

  function getAttachmentDescriptors() {
    const found = new Map();
    const main = getMainAttachmentRoot();

    // Nguồn 1: chỉ đúng FILE/TỆP ĐÍNH KÈM của văn bản hiện tại.
    if (main) collectStrictRootDescriptors(main, 'attachment', found);

    // Nguồn 2: chỉ đúng VĂN BẢN LIÊN QUAN nếu thực sự có vùng này.
    for (const root of getRelatedRoots()) collectStrictRootDescriptors(root, 'related', found);

    // Enrich lại sau dedupe: cùng fileId có thể còn một node đỏ/btn ký ở vùng chuyển xử lý nằm ngoài root chính.
    // Đây là tín hiệu của chính iOffice; chỉ tăng ưu tiên, không thay thế bước xác minh nội dung.
    return dedupeDescriptorList([...found.values()]).map(desc=>{
      if(desc.scopeKind==='related')return desc;
      const sig=inspectDomPrimarySignal(desc,null);
      return {
        ...desc,
        domPrimaryScore:Math.max(Number(desc.domPrimaryScore||0),Number(sig.score||0)),
        domPrimaryStrong:desc.domPrimaryStrong===true||sig.strong===true,
        domPrimaryRed:desc.domPrimaryRed===true||sig.redName===true,
        domPrimaryReasons:[...new Set([...(desc.domPrimaryReasons||[]),...(sig.reasons||[])])]
      };
    });
  }

  function descriptorIdentityKey(desc) {
    const fileId = String(desc?.fileId || '').trim();
    const token = String(desc?.viewerToken || '').trim();
    const name = fold(stripActionWords(desc?.name || ''));
    if (fileId) return `id:${fileId}`;
    if (token) return `token:${token}`;
    return `name:${desc?.scopeKind || 'attachment'}:${name}`;
  }

  function mergeDescriptor(a, b) {
    return {
      ...a,
      nodeId: a.nodeId || b.nodeId,
      fileId: a.fileId || b.fileId,
      viewerToken: a.viewerToken || b.viewerToken,
      viewerUrl: a.viewerUrl || b.viewerUrl,
      candidateUrls: [...new Set([...(a.candidateUrls || []), ...(b.candidateUrls || [])])],
      actionArgs: a.actionArgs?.length ? a.actionArgs : (b.actionArgs || []),
      date: a.date || b.date,
      name: stripActionWords(a.name || b.name),
      isMain: a.isMain === true || b.isMain === true,
      domPrimaryScore: Math.max(Number(a.domPrimaryScore||0), Number(b.domPrimaryScore||0)),
      domPrimaryStrong: a.domPrimaryStrong === true || b.domPrimaryStrong === true,
      domPrimaryRed: a.domPrimaryRed === true || b.domPrimaryRed === true,
      domPrimaryReasons: [...new Set([...(a.domPrimaryReasons||[]), ...(b.domPrimaryReasons||[])])],
      sourceSection: a.sourceSection || b.sourceSection,
      scopeKind: a.scopeKind === 'attachment' || b.scopeKind === 'attachment' ? 'attachment' : 'related',
      ext: a.ext || b.ext,
      canonicalStem: a.canonicalStem || b.canonicalStem
    };
  }

  function dedupeDescriptorList(items) {
    const out = [];
    for (const raw of items || []) {
      const item = { ...raw, name: stripActionWords(raw?.name || '') };
      let index = out.findIndex((x) => sameDescriptorIdentity(x, item));
      if (index < 0) {
        const nk = fold(item.name || '');
        if (nk) index = out.findIndex((x) => fold(x.name || '') === nk);
      }
      if (index >= 0) out[index] = mergeDescriptor(out[index], item);
      else out.push(item);
    }
    return out;
  }

  function constrainDescriptorsToDeclared(items, declaredCount) {
    const list = dedupeDescriptorList(items || []);
    const declared = Math.max(0, Number(declaredCount) || 0);
    if (!declared) return list;
    const attachments = list.filter(x => x.scopeKind !== 'related');
    const related = list.filter(x => x.scopeKind === 'related');
    if (attachments.length <= declared) return list;
    // Stable 1.3.1: KHÔNG cắt cứng theo con số tiêu đề. DOM iOffice tải bất đồng bộ, số đếm có thể
    // xuất hiện chậm hoặc sai tạm thời; cắt ở đây từng làm mất bản Word/PDF cùng văn bản. Vùng FILE ĐÍNH KÈM
    // đã được giới hạn nghiêm ngặt và dedupe theo id/token/tên nên giữ toàn bộ descriptor thật an toàn hơn.
    return [...attachments, ...related];
  }

  function getAttachmentNames() {
    return [...new Set(dedupeDescriptorList(getAttachmentDescriptors()).map((x) => x.name))];
  }

  const readMemory = new Map();
  const cacheKey = d => `${location.href}|${d.viewerToken||d.fileId}|${d.name}|${d.date}`;
  async function readCache(desc) {
    const item=readMemory.get(cacheKey(desc));
    return item && Date.now()-item.ts<300000 ? {...item,cached:true} : null;
  }
  async function writeCache(desc,value) {
    if(!value?.text || (!desc.viewerToken&&!desc.fileId))return;
    const key=cacheKey(desc);readMemory.delete(key);readMemory.set(key,{...value,ts:Date.now()});
    while(readMemory.size>30)readMemory.delete(readMemory.keys().next().value);
  }

  function makeViewerUrl(desc) {
    const direct = String(desc.viewerUrl || '').trim();
    if (direct) {
      try { return new URL(direct, location.href).href; } catch (_) {}
    }
    const token = String(desc.viewerToken || '').trim();
    if (!token) return '';
    if (/^https?:\/\//i.test(token)) return token;
    if (/viewer\.jsp\?/i.test(token)) return new URL(token, location.origin).href;
    // iOffice đang truyền chuỗi file-token vào showFileNewTab; giữ nguyên dấu & nếu token chứa tham số phụ.
    return `${location.origin}/qlvbdh_dlk/web/viewer.jsp?file=${token}`;
  }

  const MAX_ORIGINAL_FILE_BYTES = 50 * 1024 * 1024;

  function maxFileBytesFromOptions(options = {}) {
    const mb = Math.max(1, Math.min(50, Number(options.readerMaxFileSizeMb || 10)));
    return Math.round(mb * 1024 * 1024);
  }

  function tooLargeResult(desc, sizeBytes, options = {}, source = 'size-limit') {
    const mb = Math.max(1, Math.min(50, Number(options.readerMaxFileSizeMb || 10)));
    return { ...desc, text:'', chars:0, words:0, status:'file-too-large-skipped', source, sizeLimitSkipped:true, originalSizeBytes:Number(sizeBytes || 0), error:`Tệp vượt giới hạn ${mb} MB nên được bỏ qua.` };
  }

  function mimeForExt(ext) {
    return ({
      pdf:'application/pdf', doc:'application/msword', docx:'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      xls:'application/vnd.ms-excel', xlsx:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      rtf:'application/rtf', txt:'text/plain'
    })[String(ext || '').toLowerCase()] || 'application/octet-stream';
  }

  function observedCandidatesForDescriptor(desc, recentMs = 45000) {
    const now = Date.now();
    const token = String(desc.viewerToken || '').trim();
    const fileId = String(desc.fileId || '').trim();
    const foldedName = fold(desc.name || '');
    const stem = canonicalStem(desc.name || '');
    const scored = [];
    for (const item of observedNetwork) {
      if (now - item.ts > recentMs) continue;
      let decoded = '';
      try { decoded = decodeURIComponent(`${item.url} ${item.frameUrl}`); } catch (_) { decoded = `${item.url} ${item.frameUrl}`; }
      const f = fold(decoded);
      let score = 0;
      if (token && decoded.includes(token)) score += 8;
      if (fileId && new RegExp(`(?:[?&=/_-]|^)${fileId.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')}(?:[&#/_-]|$)`).test(decoded)) score += 7;
      if (foldedName && f.includes(foldedName)) score += 8;
      if (stem && stem.length >= 6 && f.includes(stem)) score += 5;
      let path = '';
      try { path = new URL(item.url, location.href).pathname.toLowerCase(); } catch (_) {}
      // CSS/JS/icon/locale của PDF.js không phải tài liệu. Không bao giờ đưa chúng
      // vào hàng đợi fetchOriginalFile, dù frameUrl có trùng viewer của tệp.
      if (/\/qlvbdh_dlk\/web\//i.test(path) && !/\/qlvbdh_dlk\/web\/viewer\.jsp$/i.test(path)) continue;
      if (/\/viewfile$|download|attachment|getfile|filedownload|document/i.test(path)) score += 2;
      if (score > 0) scored.push({ ...item, score });
    }
    return [...new Map(scored.sort((a,b)=>b.score-a.score||b.ts-a.ts).map(x=>[x.url,x])).values()].map(x=>x.url).slice(0,24);
  }


  function observedOversizeForDescriptor(desc, viewerUrl, maxBytes, notBefore = 0) {
    const now = Date.now();
    const token = String(desc.viewerToken || '').trim();
    const fileId = String(desc.fileId || '').trim();
    const nameFold = fold(desc.name || '');
    const stem = canonicalStem(desc.name || '');
    let viewerToken = '';
    try { viewerToken = viewerUrl ? (new URL(viewerUrl, location.href).searchParams.get('file') || '') : ''; } catch (_) {}
    let best = null;
    for (const item of observedNetwork) {
      const size = Number(item.contentLength || 0);
      if (!size || size <= maxBytes || now - item.ts > 180000 || (notBefore && item.ts < notBefore)) continue;
      let decoded = '';
      try { decoded = decodeURIComponent(`${item.url} ${item.frameUrl}`); } catch (_) { decoded = `${item.url} ${item.frameUrl}`; }
      const f = fold(decoded);
      let score = 0;
      if (viewerUrl && item.frameUrl === viewerUrl) score += 24;
      if (viewerToken) { try { if ((new URL(item.frameUrl || item.url, location.href).searchParams.get('file') || '') === viewerToken) score += 24; } catch (_) {} }
      if (token && decoded.includes(token)) score += 18;
      if (fileId && decoded.includes(fileId)) score += 14;
      if (nameFold && f.includes(nameFold)) score += 10;
      if (stem && stem.length >= 6 && f.includes(stem)) score += 5;
      if (/\/viewfile(?:[?#]|$)|download|attachment|getfile|filedownload/i.test(item.url || '')) score += 2;
      if (score >= 12 && (!best || score > best.score)) best = { sizeBytes:size, score, url:item.url };
    }
    return best;
  }

  function urlCandidatesForDescriptor(desc) {
    const out = [];
    const push = (value) => {
      value = String(value || '').trim();
      if (!value || /^(?:javascript:|#)/i.test(value)) return;
      try {
        const u = new URL(value, location.href);
        const path = u.pathname.toLowerCase();
        if (/\/qlvbdh_dlk\/web\//i.test(path) && !/\/qlvbdh_dlk\/web\/viewer\.jsp$/i.test(path)) return;
        out.push(u.href);
      } catch (_) {}
    };
    for (const u of desc.candidateUrls || []) push(u);
    for (const u of observedCandidatesForDescriptor(desc)) push(u);
    push(desc.viewerUrl);
    const token = String(desc.viewerToken || '').trim();
    if (/^(?:https?:\/\/|\/|\.\/|\.\.\/)/i.test(token) || /\.(?:pdf|docx?|xlsx?|xls|rtf|txt)(?:$|[?#])/i.test(token)) push(token);
    return [...new Set(out)];
  }

  function signatureKind(bytes) {
    if (!bytes?.length) return '';
    if (bytes.length >= 5 && String.fromCharCode(...bytes.slice(0,5)) === '%PDF-') return 'pdf';
    if (bytes.length >= 4 && bytes[0]===0x50 && bytes[1]===0x4b && [0x03,0x05,0x07].includes(bytes[2]) && [0x04,0x06,0x08].includes(bytes[3])) return 'zip';
    if (bytes.length >= 8 && bytes[0]===0xd0 && bytes[1]===0xcf && bytes[2]===0x11 && bytes[3]===0xe0 && bytes[4]===0xa1 && bytes[5]===0xb1 && bytes[6]===0x1a && bytes[7]===0xe1) return 'ole';
    const prefix = new TextDecoder('utf-8', {fatal:false}).decode(bytes.slice(0, Math.min(bytes.length, 500))).trimStart().toLowerCase();
    if (/^(?:<!doctype\s+html|<html|<head|<body)/.test(prefix)) return 'html';
    if (/^\{\\rtf/.test(prefix)) return 'rtf';
    return 'other';
  }

  function bytesCompatibleWithExt(bytes, ext, contentType = '') {
    const kind = signatureKind(bytes);
    ext = String(ext || '').toLowerCase();
    if (kind === 'html') return false;
    if (ext === 'pdf') return kind === 'pdf';
    if (ext === 'docx' || ext === 'xlsx') return kind === 'zip';
    if (ext === 'doc' || ext === 'xls') return kind === 'ole';
    if (ext === 'rtf') return kind === 'rtf' || /rtf/i.test(contentType);
    if (ext === 'txt') return kind !== 'pdf' && kind !== 'zip' && kind !== 'ole';
    return true;
  }

  async function readResponseLimited(response, maxBytes = MAX_ORIGINAL_FILE_BYTES, signal = null) {
    const len = Number(response.headers.get('content-length') || 0);
    if (len > maxBytes) throw new Error(`Tệp gốc lớn hơn ${(maxBytes/1024/1024).toFixed(0)} MB`);
    if (!response.body) {
      const buf = new Uint8Array(await response.arrayBuffer());
      if (buf.byteLength > maxBytes) throw new Error('Tệp gốc vượt giới hạn đọc');
      return buf;
    }
    const reader = response.body.getReader();
    const parts = []; let total = 0;
    try {
      while (true) {
        assertNotAborted(signal);
        const {done, value} = await reader.read();
        if (done) break;
        total += value.byteLength;
        if (total > maxBytes) { await reader.cancel(); throw new Error('Tệp gốc vượt giới hạn đọc'); }
        parts.push(value);
      }
    } finally { try { reader.releaseLock(); } catch (_) {} }
    const out = new Uint8Array(total); let off = 0;
    for (const part of parts) { out.set(part, off); off += part.byteLength; }
    return out;
  }

  function discoverFileUrlsFromHtml(html, baseUrl, fileName = '') {
    const values = [];
    const push = (value) => {
      value = String(value || '').replace(/&amp;/g,'&').trim();
      if (!value || /^(?:javascript:|#|data:)/i.test(value)) return;
      if (!/(?:download|file|document|attachment|view|\.pdf|\.docx?|\.xlsx?|\.xls|\.rtf|\.txt)/i.test(value)) return;
      try { values.push(new URL(value, baseUrl).href); } catch (_) {}
    };
    try {
      const doc = new DOMParser().parseFromString(html, 'text/html');
      for (const el of doc.querySelectorAll('[href],[src],[data-url],[data-file],[data-src],[data-download-url]')) {
        for (const attr of ['href','src','data-url','data-file','data-src','data-download-url']) push(el.getAttribute(attr));
      }
    } catch (_) {}
    for (const m of String(html || '').matchAll(/['\"]((?:https?:\/\/|\/|\.\/|\.\.\/)[^'\"]{3,500})['\"]/g)) push(m[1]);
    for (const m of String(html || '').matchAll(/['\"]([^'\"]{1,500}\.(?:pdf|docx?|xlsx?|xls|rtf|txt)(?:\?[^'\"]*)?)['\"]/gi)) push(m[1]);
    if (fileName) {
      const foldedName = fold(fileName);
      values.sort((a,b) => Number(fold(decodeURIComponent(b)).includes(foldedName)) - Number(fold(decodeURIComponent(a)).includes(foldedName)));
    }
    return [...new Set(values)].slice(0, 20);
  }

  function capturedFileForDescriptor(desc, options = {}) {
    const recentMs = Number(options.recentMs || 120000);
    const notBefore = Number(options.notBefore || 0);
    const allowConvertedPdf = options.allowConvertedPdf !== false;
    const viewerUrl = String(options.viewerUrl || desc.viewerUrl || '').trim();
    const now = Date.now();
    const token = String(desc.viewerToken || '').trim();
    const fileId = String(desc.fileId || '').trim();
    const nameFold = fold(desc.name || '');
    const stem = canonicalStem(desc.name || '');
    const ext = desc.ext || extensionOf(desc.name);
    const officeCanBecomePdf = ['doc','docx','xls','xlsx','rtf'].includes(ext);
    let viewerFileToken = '';
    try { viewerFileToken = viewerUrl ? (new URL(viewerUrl, location.href).searchParams.get('file') || '') : ''; } catch (_) {}
    const ranked = [];

    for (const item of capturedFiles) {
      if (!item?.bytes?.length || now - item.ts > recentMs || (notBefore && item.ts < notBefore)) continue;
      const kind = signatureKind(item.bytes);
      const originalCompatible = bytesCompatibleWithExt(item.bytes, ext, item.contentType);
      const convertedPdf = allowConvertedPdf && officeCanBecomePdf && kind === 'pdf';
      if (!originalCompatible && !convertedPdf) continue;

      let decoded = '';
      try { decoded = decodeURIComponent(`${item.url} ${item.frameUrl} ${item.filename}`); }
      catch (_) { decoded = `${item.url} ${item.frameUrl} ${item.filename}`; }
      const f = fold(decoded);
      let score = 0;

      let strongIdentity = false;
      if (viewerUrl) {
        try {
          const itemFrame = item.frameUrl ? new URL(item.frameUrl, location.href) : null;
          const wanted = new URL(viewerUrl, location.href);
          if (itemFrame && itemFrame.href === wanted.href && (wanted.searchParams.get('file') || wanted.search.length > 3)) { score += 40; strongIdentity = true; }
        } catch (_) {}
      }
      if (viewerFileToken && item.frameUrl) {
        try {
          const frameToken = new URL(item.frameUrl, location.href).searchParams.get('file') || '';
          if (frameToken && frameToken === viewerFileToken) { score += 32; strongIdentity = true; }
        } catch (_) {}
      }
      if (item.filename && fold(stripActionWords(item.filename)) === nameFold) { score += 20; strongIdentity = true; }
      else if (nameFold && f.includes(nameFold)) score += 6;
      if (stem && stem.length >= 6 && f.includes(stem)) score += 3;
      if (token && decoded.includes(token)) { score += 18; strongIdentity = true; }
      if (fileId && decoded.includes(fileId)) { score += 14; strongIdentity = true; }
      if (kind === 'pdf' && (ext === 'pdf' || convertedPdf)) score += 3;
      if (originalCompatible) score += 2;
      if (/\/viewfile(?:[?#]|$)/i.test(item.url || '')) score += 2;

      // Không bao giờ nhận bytes chỉ vì cùng stem/tên gần giống: đây là nguồn gây gán nhầm 1 PDF cho nhiều tệp.
      if (strongIdentity && score > 0) ranked.push({ item, score, kind, convertedPdf });
    }

    ranked.sort((a, b) => b.score - a.score || b.item.ts - a.item.ts);
    const best = ranked[0];
    if (!best || best.score < 12) return null;
    return {
      bytes: best.item.bytes,
      url: best.item.url,
      frameUrl: best.item.frameUrl,
      contentType: best.item.contentType,
      disposition: best.item.disposition,
      signature: best.kind,
      convertedPdf: best.convertedPdf,
      source: best.convertedPdf ? 'ioffice-viewer-pdf' : 'captured-original',
      capturedScore: best.score
    };
  }

  let viewerResolverBusy = false;
  async function withViewerResolverLock(signal, task) {
    while (viewerResolverBusy) await sleepAbortable(30, signal);
    assertNotAborted(signal);
    viewerResolverBusy = true;
    try {
      const result = await task();
      // Cho iOffice hoàn tất việc gán src/token cho viewer trước khi tạo viewer kế tiếp.
      await sleepAbortable(180, signal);
      return result;
    } finally {
      viewerResolverBusy = false;
    }
  }

  async function waitForCapturedFile(desc, viewerUrl, options = {}) {
    const signal = options.signal || null;
    const timeoutMs = Math.max(100, Math.min(8000, Number(options.timeoutMs || 1800)));
    const until = performance.now() + timeoutMs;
    do {
      assertNotAborted(signal);
      const found = capturedFileForDescriptor(desc, { viewerUrl, allowConvertedPdf: true, recentMs: 180000, notBefore:options.notBefore || 0 });
      if (found?.bytes?.length) return found;
      await sleepAbortable(70, signal);
    } while (performance.now() < until);
    return capturedFileForDescriptor(desc, { viewerUrl, allowConvertedPdf: true, recentMs: 180000, notBefore:options.notBefore || 0 });
  }

  async function resolveViewerUrlViaPage(desc, signal) {
    const args = Array.isArray(desc?.actionArgs) ? desc.actionArgs.map(x => String(x ?? '')) : [];
    if (!args.length) return '';
    assertNotAborted(signal);
    const requestId = `iof-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 9)}`;
    const result = await new Promise((resolve, reject) => {
      let done = false;
      const finish = (value) => {
        if (done) return;
        done = true;
        clearTimeout(timer);
        signal?.removeEventListener?.('abort', onAbort);
        pendingViewerResolvers.delete(requestId);
        resolve(value);
      };
      const onAbort = () => {
        if (done) return;
        done = true;
        clearTimeout(timer);
        pendingViewerResolvers.delete(requestId);
        reject(abortError());
      };
      const timer = setTimeout(() => finish({ ok:false, url:'', error:'resolve-timeout' }), 1100);
      pendingViewerResolvers.set(requestId, { resolve: finish });
      signal?.addEventListener?.('abort', onAbort, { once:true });
      try {
        window.postMessage({ channel: NETWORK_CHANNEL, type:'resolve-show-file', requestId, args, nodeId:String(desc?.nodeId || '') }, location.origin);
      } catch (_) { finish({ ok:false, url:'', error:'post-message-failed' }); }
    });
    assertNotAborted(signal);
    if (!result?.ok || !result.url) return '';
    try {
      const absolute = new URL(result.url, location.href);
      if (absolute.origin !== location.origin) return '';
      return absolute.href;
    } catch (_) { return ''; }
  }

  async function fetchOriginalFile(desc, options = {}) {
    const signal = options.signal || null;
    assertNotAborted(signal);
    const ext = desc.ext || extensionOf(desc.name);
    const maxFileBytes = maxFileBytesFromOptions(options);
    const capturedFirst = capturedFileForDescriptor(desc, { allowConvertedPdf:false, notBefore:options.notBefore || 0 });
    if (capturedFirst?.bytes?.length) {
      if (capturedFirst.bytes.byteLength > maxFileBytes) return { tooLarge:true, sizeBytes:capturedFirst.bytes.byteLength, url:capturedFirst.url || '', contentType:capturedFirst.contentType || '' };
      return capturedFirst;
    }
    const seen = new Set();
    const queue = urlCandidatesForDescriptor(desc).map(url => ({url, depth:0}));
    const diagnostics = [];
    while (queue.length) {
      assertNotAborted(signal);
      const {url, depth} = queue.shift();
      if (!url || seen.has(url) || seen.size > 28) continue;
      seen.add(url);
      let u;
      try { u = new URL(url, location.href); } catch (_) { continue; }
      if (u.origin !== location.origin) continue;
      // /viewfile chỉ hợp lệ khi chính viewer của iOffice đã tạo đủ query. Không tự gọi endpoint trần/thiếu tham số vì server trả HTTP500.
      if (/\/viewfile$/i.test(u.pathname)) {
        const keys = [...u.searchParams.keys()];
        if (!u.searchParams.has('file') || keys.length < 2) {
          diagnostics.push(`${u.pathname}:skip-incomplete-query`);
          continue;
        }
      }
      try {
        const response = await fetch(u.href, {credentials:'include', cache:'no-store', redirect:'follow', signal, headers:{'Accept':'*/*'}});
        if (!response.ok) { diagnostics.push(`${u.pathname}:HTTP${response.status}`); continue; }
        const contentType = response.headers.get('content-type') || '';
        const disposition = response.headers.get('content-disposition') || '';
        if (/text\/html|application\/xhtml/i.test(contentType)) {
          if (depth >= 1) continue;
          const htmlBytes = await readResponseLimited(response, 2 * 1024 * 1024, signal);
          const html = new TextDecoder('utf-8', {fatal:false}).decode(htmlBytes);
          for (const inner of discoverFileUrlsFromHtml(html, response.url || u.href, desc.name)) {
            if (!seen.has(inner)) queue.push({url:inner, depth:depth+1});
          }
          continue;
        }
        const len = Number(response.headers.get('content-length') || 0);
        if (len > maxFileBytes) return { tooLarge:true, sizeBytes:len, url:response.url || u.href, contentType, disposition };
        const bytes = await readResponseLimited(response, maxFileBytes, signal);
        if (!bytesCompatibleWithExt(bytes, ext, contentType)) {
          diagnostics.push(`${u.pathname}:signature-${signatureKind(bytes)}`);
          if (signatureKind(bytes) === 'html' && depth < 1) {
            const html = new TextDecoder().decode(bytes);
            for (const inner of discoverFileUrlsFromHtml(html, response.url || u.href, desc.name)) queue.push({url:inner, depth:depth+1});
          }
          continue;
        }
        return {bytes, url:response.url || u.href, contentType, disposition, source:'original-file'};
      } catch (error) {
        if (error?.name === 'AbortError') throw error;
        const message = String(error?.message || 'fetch-error');
        if (/vượt giới hạn đọc|lớn hơn\s+\d+\s*MB/i.test(message)) {
          return { tooLarge:true, sizeBytes:maxFileBytes + 1, url:u.href, contentType:'', disposition:'' };
        }
        diagnostics.push(`${u.pathname}:${message}`);
      }
    }
    const capturedLast = capturedFileForDescriptor(desc, { allowConvertedPdf:false, notBefore:options.notBefore || 0 });
    if (capturedLast?.bytes?.length) {
      if (capturedLast.bytes.byteLength > maxFileBytes) return { tooLarge:true, sizeBytes:capturedLast.bytes.byteLength, url:capturedLast.url || '', contentType:capturedLast.contentType || '' };
      return capturedLast;
    }
    return {bytes:null, url:'', contentType:'', source:'none', diagnostics};
  }

  function findEocd(bytes) {
    const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    const min = Math.max(0, bytes.length - 0x10000 - 22);
    for (let i = bytes.length - 22; i >= min; i--) if (view.getUint32(i, true) === 0x06054b50) return i;
    return -1;
  }

  function zipEntries(bytes) {
    const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    const eocd = findEocd(bytes);
    if (eocd < 0) throw new Error('ZIP không có central directory');
    const count = view.getUint16(eocd + 10, true);
    const cdOffset = view.getUint32(eocd + 16, true);
    const decoder = new TextDecoder('utf-8', {fatal:false});
    const entries = new Map(); let pos = cdOffset;
    for (let i=0; i<count && pos+46<=bytes.length; i++) {
      if (view.getUint32(pos,true)!==0x02014b50) break;
      const method=view.getUint16(pos+10,true), compSize=view.getUint32(pos+20,true), uncompSize=view.getUint32(pos+24,true);
      const nameLen=view.getUint16(pos+28,true), extraLen=view.getUint16(pos+30,true), commentLen=view.getUint16(pos+32,true), localOffset=view.getUint32(pos+42,true);
      const name=decoder.decode(bytes.slice(pos+46,pos+46+nameLen));
      entries.set(name,{name,method,compSize,uncompSize,localOffset});
      pos += 46+nameLen+extraLen+commentLen;
    }
    return entries;
  }

  async function unzipEntry(bytes, entry, maxBytes = 6 * 1024 * 1024) {
    if (!entry) return null;
    if (entry.uncompSize > maxBytes) throw new Error(`Mục ZIP ${entry.name} quá lớn`);
    const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    const off = entry.localOffset;
    if (off+30>bytes.length || view.getUint32(off,true)!==0x04034b50) throw new Error('ZIP local header lỗi');
    const nameLen=view.getUint16(off+26,true), extraLen=view.getUint16(off+28,true);
    const start=off+30+nameLen+extraLen, end=start+entry.compSize;
    if (end>bytes.length) throw new Error('ZIP data vượt kích thước');
    const raw=bytes.slice(start,end);
    if (entry.method===0) return raw;
    if (entry.method!==8) throw new Error(`ZIP compression ${entry.method} chưa hỗ trợ`);
    if (typeof DecompressionStream !== 'function') throw new Error('Chrome không hỗ trợ giải nén DOCX/XLSX');
    const ds = new DecompressionStream('deflate-raw');
    const stream = new Blob([raw]).stream().pipeThrough(ds);
    const out = new Uint8Array(await new Response(stream).arrayBuffer());
    if (out.byteLength > maxBytes) throw new Error('Dữ liệu giải nén vượt giới hạn');
    return out;
  }

  async function zipText(bytes, entries, name, maxBytes) {
    const part = await unzipEntry(bytes, entries.get(name), maxBytes);
    return part ? new TextDecoder('utf-8', {fatal:false}).decode(part) : '';
  }

  function xmlDoc(xml) {
    if (!xml) return null;
    const doc = new DOMParser().parseFromString(xml, 'application/xml');
    if (doc.querySelector('parsererror')) return null;
    return doc;
  }

  function docxXmlToText(xml) {
    const doc = xmlDoc(xml); if (!doc) return '';
    const out=[];
    const walk=(node)=>{
      if (node.nodeType!==1) return;
      const local=node.localName;
      if (local==='t') out.push(node.textContent || '');
      else if (local==='tab') out.push('\t');
      else if (local==='br' || local==='cr') out.push('\n');
      else {
        for (const child of node.children || []) walk(child);
        if (local==='p' || local==='tr') out.push('\n');
        else if (local==='tc') out.push('\t');
      }
    };
    walk(doc.documentElement);
    return cleanText(out.join('').replace(/\t+\n/g,'\n').replace(/\n{3,}/g,'\n\n'));
  }

  async function parseDocx(bytes, maxChars = MAX_FILE_CHARS) {
    const entries=zipEntries(bytes);
    if (!entries.has('word/document.xml')) throw new Error('Không thấy word/document.xml');
    const names=['word/document.xml', ...[...entries.keys()].filter(n=>/^word\/(?:header|footer)\d+\.xml$/i.test(n)).slice(0,8)];
    const texts=[];
    for (const name of names) {
      const xml=await zipText(bytes,entries,name,6*1024*1024);
      const text=docxXmlToText(xml); if(text)texts.push(text);
      if (texts.join('\n').length>=maxChars) break;
    }
    return cleanText(texts.join('\n\n')).slice(0,maxChars);
  }

  function colNumber(ref) {
    const m=String(ref||'').match(/^([A-Z]+)/i); if(!m)return 0;
    let n=0; for(const c of m[1].toUpperCase()) n=n*26+(c.charCodeAt(0)-64); return n;
  }

  async function parseXlsx(bytes, maxChars = MAX_FILE_CHARS) {
    const entries=zipEntries(bytes);
    let shared=[];
    if(entries.has('xl/sharedStrings.xml')){
      const doc=xmlDoc(await zipText(bytes,entries,'xl/sharedStrings.xml',8*1024*1024));
      if(doc) shared=[...doc.getElementsByTagNameNS('*','si')].map(si=>[...si.getElementsByTagNameNS('*','t')].map(t=>t.textContent||'').join(''));
    }
    const workbook=xmlDoc(await zipText(bytes,entries,'xl/workbook.xml',3*1024*1024));
    const rels=xmlDoc(await zipText(bytes,entries,'xl/_rels/workbook.xml.rels',3*1024*1024));
    const relMap=new Map();
    if(rels) for(const r of rels.getElementsByTagNameNS('*','Relationship')) relMap.set(r.getAttribute('Id'),r.getAttribute('Target'));
    const sheets=[];
    if(workbook){
      for(const s of workbook.getElementsByTagNameNS('*','sheet')){
        const rid=s.getAttributeNS('http://schemas.openxmlformats.org/officeDocument/2006/relationships','id') || s.getAttribute('r:id') || '';
        let target=relMap.get(rid)||''; if(target) target=target.replace(/^\//,'').replace(/^\.\.\//,'');
        if(target && !target.startsWith('xl/')) target='xl/'+target;
        sheets.push({name:s.getAttribute('name')||'Sheet',target});
      }
    }
    if(!sheets.length) for(const name of [...entries.keys()].filter(n=>/^xl\/worksheets\/sheet\d+\.xml$/i.test(n)).slice(0,20)) sheets.push({name:name.split('/').pop(),target:name});
    const out=[];
    for(const sheet of sheets.slice(0,20)){
      if(!entries.has(sheet.target))continue;
      const doc=xmlDoc(await zipText(bytes,entries,sheet.target,10*1024*1024)); if(!doc)continue;
      out.push(`Sheet: ${sheet.name}`);
      for(const row of doc.getElementsByTagNameNS('*','row')){
        const vals=[]; let lastCol=0;
        for(const c of row.getElementsByTagNameNS('*','c')){
          const col=colNumber(c.getAttribute('r')); while(lastCol && col>lastCol+1 && vals.length<40){vals.push('');lastCol++;}
          const type=c.getAttribute('t')||''; let value='';
          if(type==='inlineStr') value=[...c.getElementsByTagNameNS('*','t')].map(t=>t.textContent||'').join('');
          else {
            const v=c.getElementsByTagNameNS('*','v')[0]?.textContent || '';
            value=type==='s' ? (shared[Number(v)] ?? v) : v;
          }
          vals.push(value); lastCol=col||lastCol+1;
        }
        const line=vals.join('\t').trim(); if(line)out.push(line);
        if(out.join('\n').length>=maxChars)break;
      }
      if(out.join('\n').length>=maxChars)break;
    }
    return cleanText(out.join('\n')).slice(0,maxChars);
  }

  function decodeTextBytes(bytes) {
    let text=new TextDecoder('utf-8',{fatal:false}).decode(bytes);
    const bad=(text.match(/�/g)||[]).length;
    if(bad > Math.max(2,text.length/150)){
      try{text=new TextDecoder('windows-1258',{fatal:false}).decode(bytes);}catch(_){}
    }
    return cleanText(text);
  }

  function parseRtf(text) {
    return cleanText(String(text||'')
      .replace(/\\'([0-9a-fA-F]{2})/g,(_,h)=>String.fromCharCode(parseInt(h,16)))
      .replace(/\\u(-?\d+)\??/g,(_,n)=>String.fromCharCode((Number(n)+65536)%65536))
      .replace(/\\(?:par|line)\b/g,'\n')
      .replace(/\\tab\b/g,'\t')
      .replace(/\\[a-zA-Z]+-?\d* ?/g,'')
      .replace(/[{}]/g,' '));
  }

  async function parseOriginalText(desc, original, options = {}) {
    if(!original?.bytes?.length)return null;
    const ext=String(desc.ext||extensionOf(desc.name)).toLowerCase();
    const maxChars=Math.max(500,Math.min(MAX_FILE_CHARS,Number(options.maxChars||MAX_FILE_CHARS)));
    let text='';
    if(ext==='docx') text=await parseDocx(original.bytes,maxChars);
    else if(ext==='xlsx') text=await parseXlsx(original.bytes,maxChars);
    else if(ext==='txt') text=decodeTextBytes(original.bytes).slice(0,maxChars);
    else if(ext==='rtf') text=parseRtf(decodeTextBytes(original.bytes)).slice(0,maxChars);
    else return null;
    return {text,source:`original-${ext}`,status:text.length>=20?'text':'original-no-text',originalBytes:original.bytes,originalSizeBytes:original.bytes.byteLength,originalUrl:original.url,originalMimeType:original.contentType||mimeForExt(ext)};
  }


  function collectTextLayersFromRoot(root, out, depth = 0) {
    if (!root || depth > 5) return;
    const selectors = [
      '.textLayer', '.text-layer', '[class*="textLayer"]', '[class*="text-layer"]',
      '[data-testid*="text-layer" i]', '[data-test-id*="text-layer" i]',
      '[data-ioffice-ocr-text]'
    ];
    for (const selector of selectors) {
      try {
        for (const el of root.querySelectorAll(selector)) {
          const text = cleanText(el.innerText || el.textContent || '');
          if (text.length >= 20) out.push(text);
        }
      } catch (_) {}
    }
    // PDF/OCR viewer có thể để text layer trong Shadow DOM hoặc iframe lồng cùng origin.
    try {
      for (const el of root.querySelectorAll('*')) {
        if (el.shadowRoot) collectTextLayersFromRoot(el.shadowRoot, out, depth + 1);
        if (el.tagName === 'IFRAME') {
          try { if (el.contentDocument) collectTextLayersFromRoot(el.contentDocument, out, depth + 1); } catch (_) {}
        }
      }
    } catch (_) {}
  }

  function cleanViewerBodyText(text) {
    return cleanText(text)
      .replace(/^Bật\/Tắt thanh lề[\s\S]{0,1200}?(?=\b1\b\s|UBND|CỘNG HÒA|SỞ |BỘ |ỦY BAN|HỘI ĐỒNG)/i, '')
      .replace(/^(?:viewfile|tự động chọn kích thước|về xem mặc định|trên\s+\d+)[\s\S]{0,500}?(?=UBND|CỘNG HÒA|SỞ |BỘ |ỦY BAN|HỘI ĐỒNG)/i, '')
      .slice(0, MAX_FILE_CHARS);
  }

  function extractRenderedTextFromDocument(doc, allowBodyFallback = true) {
    if (!doc) return '';
    const layers = [];
    collectTextLayersFromRoot(doc, layers);
    const unique = [...new Set(layers.map(cleanText).filter((x) => x.length >= 20))];
    const layerText = cleanText(unique.join('\n\n'));
    if (layerText.length >= 80) return layerText.slice(0, MAX_FILE_CHARS);

    // Viewer same-origin đôi khi không dùng class textLayer nhưng body vẫn chứa OCR/copy text.
    if (allowBodyFallback) {
      const body = cleanViewerBodyText(doc.body?.innerText || '');
      if (body.length >= 120 && /(?:UBND|CỘNG HÒA|SỞ |BỘ |ỦY BAN|HỘI ĐỒNG|BÁO CÁO|Kính gửi|Số:)/i.test(body)) {
        return body;
      }
    }
    return '';
  }

  function extractRenderedText(frame) {
    try {
      const doc = frame.contentDocument;
      return extractRenderedTextFromDocument(doc);
    } catch (_) {
      return '';
    }
  }

  function readFrameMain(frame, options={}) {
    const signal=options.signal,id=crypto.randomUUID();
    assertNotAborted(signal);
    return new Promise((resolve,reject)=>{
      let settled=false;
      // Parent phải sống lâu hơn job trong viewer-main. Bản 1.3.1 gửi timeout ~6s nhưng
      // viewer-main lại tự ép tối thiểu 12s, khiến parent hủy trước khi PDF.js đọc xong.
      const childTimeoutMs=Math.max(2200,Number(options.appTimeoutMs)||4800);
      const timeoutMs=childTimeoutMs+500;
      let retryTimer=null;
      const finish=(error,value)=>{
        if(settled)return;settled=true;clearTimeout(timer);clearInterval(retryTimer);
        window.removeEventListener('message',onMessage);signal?.removeEventListener('abort',onAbort);
        error?reject(error):resolve(value);
      };
      const send=type=>{try{frame.contentWindow.postMessage({channel:'ioffice-reader-v2',type,id,maxChars:options.maxChars,maxPages:options.maxPages,captureScanBinary:options.captureScanBinary!==false,tryIofficeOcr:options.tryIofficeOcr!==false,timeoutMs:childTimeoutMs},location.origin);}catch(_){} };
      const onAbort=()=>{send('cancel');finish(abortError());};
      const onMessage=event=>{
        if(event.source!==frame.contentWindow||event.origin!==location.origin||event.data?.channel!=='ioffice-reader-v2'||event.data?.id!==id)return;
        const r=event.data;finish(null,r.ok?r.data:null);
      };
      const timer=setTimeout(()=>{send('cancel');finish(null,null);},timeoutMs);
      window.addEventListener('message',onMessage);signal?.addEventListener('abort',onAbort,{once:true});
      send('read');
      // viewer-main có thể được inject sau khi iframe load; gửi lại cùng id để không bỏ lỡ lệnh đầu.
      retryTimer=setInterval(()=>{if(!settled)send('read');},700);
    });
  }

  function recentCopiedTextForFrame(frame) {
    const now = Date.now();
    let src = '';
    try { src = String(frame?.src || frame?.contentWindow?.location?.href || ''); } catch (_) {}
    let fileKey = '';
    try { fileKey = new URL(src, location.href).searchParams.get('file') || ''; } catch (_) {}
    for (let i = capturedCopyTexts.length - 1; i >= 0; i--) {
      const item = capturedCopyTexts[i];
      if (now - item.ts > 90000) break;
      if (!item.text || item.text.length < 120) continue;
      if (!src) return item.text;
      if (item.frameUrl === src) return item.text;
      try {
        const k = new URL(item.frameUrl, location.href).searchParams.get('file') || '';
        if (fileKey && k && fileKey === k) return item.text;
      } catch (_) {}
    }
    return '';
  }

  async function extractFromFrame(frame, sourceLabel, options={}) {
    // Stable 1.3.1: DOM textLayer của PDF.js chỉ chứa các trang đang render (virtualized).
    // Trả ngay DOM text từng làm PDF 6 trang chỉ còn ~1 trang/1.000 từ và bị đánh giá "không khớp".
    // Chỉ dùng DOM fast-path khi chắc chắn tài liệu một trang; tài liệu nhiều trang phải đọc pdfDocument qua viewer-main.
    const renderedFirst=extractRenderedText(frame);
    let totalPagesHint=0;
    try { totalPagesHint=Number(frame.contentWindow?.PDFViewerApplication?.pdfDocument?.numPages||0); } catch (_) {}
    if(renderedFirst.length>=120 && totalPagesHint===1){
      return{text:renderedFirst,source:/\.docx?$/i.test(options.fileName||'')?'word-viewer-dom':'viewer-text-layer',status:'text',pagesRead:1,totalPages:1,truncated:false};
    }
    const data=await readFrameMain(frame,options);
    assertNotAborted(options.signal);
    if(data?.text?.length>=120)return data;
    if (options.tryIofficeOcr !== false) {
      const copied = recentCopiedTextForFrame(frame);
      if (copied.length >= 120) return { ...data, text: copied, source:'ioffice-copy-captured', status:'ocr-text' };
    }
    if(data?.scanBytes?.length||data?.status==='scan-too-large')return data;
    // Bridge/PDF.js chưa sẵn sàng: DOM text vẫn là fallback cuối cùng, nhưng đánh dấu có thể chưa đủ trang.
    const text=renderedFirst || extractRenderedText(frame);
    return {text,source:/\.docx?$/i.test(options.fileName||'')?'word-viewer-dom-fallback':sourceLabel,status:text.length>=120?'viewer-partial-text':'viewer-not-ready',pagesRead:data?.pagesRead||0,totalPages:data?.totalPages||totalPagesHint||0,truncated:Boolean(totalPagesHint>1)};
  }

  function currentViewerFrames() {
    const out = [];
    for (const frame of document.querySelectorAll('iframe')) {
      const src = frame.getAttribute('src') || '';
      let readable = false;
      try { readable = Boolean(frame.contentDocument?.body); } catch (_) {}
      if (/viewer|viewfile|pdf|document|file/i.test(src) || readable) out.push(frame);
    }
    return out;
  }

  function primaryNumber(value) {
    const text=normalizeInline(value||'');
    const m=text.match(/(?:^|\b)(\d{2,6})(?=\s*\/|\s*-\s*[A-ZĐ]|\b)/i);
    if(!m)return '';
    const n=m[1];
    if(/^20\d{2}$/.test(n))return '';
    return n;
  }

  function filenameDocumentNumbers(value) {
    // Chỉ lấy số có hình thái "số văn bản" trong tên file. Không lấy mọi con số vì tên chính văn
    // thường chứa số thửa/địa chỉ/năm (ví dụ "TB NIEM YET THUA 93" của TB số 198).
    const raw=fold(String(value||'').replace(/\.[a-z0-9]{2,5}$/i,''));
    let text=raw.replace(/[^a-z0-9]+/g,' ').replace(/\s+/g,' ').trim();
    // Bỏ tiền tố ngày/tháng hoặc ngày/tháng/năm thường dùng làm tên file dự thảo: 25.9.BC..., 30_09_2026_...
    text=text.replace(/^\d{1,2}\s+\d{1,2}\s+(?:20\d{2}\s+)?(?=(?:cv|qd|kh|bc|tb|gm|ttr|bb)\b)/,'');
    const nums=[];
    const add=n=>{n=String(n||'');if(!n||/^20\d{2}$/.test(n)||nums.includes(n))return;nums.push(n);};
    const type='(?:cv|qd|kh|bc|tb|gm|ttr|bb|cong van|quyet dinh|ke hoach|bao cao|thong bao|giay moi|to trinh|bien ban)';
    for(const m of text.matchAll(new RegExp(`(?:^|\\s)(\\d{1,6})\\s+${type}(?=\\s|$)`,'g')))add(m[1]);
    for(const m of text.matchAll(new RegExp(`(?:^|\\s)${type}\\s+(\\d{1,6})(?=\\s|$)`,'g')))add(m[1]);
    // Tên do iOffice sinh thường bắt đầu bằng đúng số văn bản: 10688_STC..., 1523_TB...
    // nhưng loại chuỗi ngày kiểu 25.9.BC... / 30_09_2026....
    const lead=raw.match(/^(\d{2,6})(?:[_ -]+)(?!\d{1,2}(?:[_ .-]|$))/);
    if(lead)add(lead[1]);
    return nums.slice(0,4);
  }

  function exactSymbolInText(symbol,text) {
    const compact=v=>fold(v||'').replace(/[^a-z0-9]+/g,'');
    const key=compact(symbol);
    const body=compact(String(text||'').slice(0,9000));
    return key.length>=5 && body.includes(key);
  }

  function primaryContentScore(desc,item,meta) {
    if(!item || (item.text?.length||0)<MIN_TEXT_CHARS)return -999;
    const text=String(item.text||'');
    const subject=meta?.trichYeu||'';
    const symbol=meta?.symbol||meta?.soKyHieu||meta?.soHieu||'';
    const sender=meta?.sender||meta?.issuer||meta?.donViBanHanh||'';
    let score=descriptorPriority(desc,meta);
    const exactSymbol=exactSymbolInText(symbol,text);
    if(exactSymbol)score+=4.2;
    const subjectScore=textSimilarity(subject,text.slice(0,9000));
    score+=subjectScore*2.8;
    if(sender){
      const senderScore=textSimilarity(sender,text.slice(0,5000));
      score+=Math.min(.85,senderScore*1.4);
    }
    // Nếu nội dung tự ghi đúng số hiện tại, đây gần như chắc chắn là chính văn.
    const currentNo=primaryNumber(symbol);
    if(currentNo && new RegExp(`(?:^|[^0-9])${currentNo}(?=[^0-9]|$)`).test(fold(text.slice(0,5000))))score+=1.2;
    if(['doc','docx'].includes(String(desc?.ext||'').toLowerCase()))score+=0.12;
    return score;
  }

  function primaryMetadataEvidence(desc, meta={}) {
    const symbol=meta?.symbol||meta?.soKyHieu||meta?.soHieu||'';
    const currentNo=primaryNumber(symbol);
    const fileNos=filenameDocumentNumbers(desc?.name||'');
    const nameSubject=subjectSimilarity(meta?.trichYeu||'',desc?.name||'','');
    const priority=descriptorPriority(desc,meta);
    const exactNo=!!(currentNo&&fileNos.includes(currentNo));
    const strong=desc?.isMain===true||domPrimaryPreference(desc,meta)>=1.35||exactNo||nameSubject>=0.38||priority>=1.45;
    return {currentNo,fileNos,nameSubject,priority,exactNo,strong};
  }

  function buildPrimaryVerifyCandidates(ranked, meta) {
    if(!ranked?.length)return [];
    if(ranked.length===1)return [ranked[0]];
    const out=[];
    const push=d=>{if(d&&!out.includes(d))out.push(d);};
    const top=ranked[0];
    const topScore=descriptorPriority(top,meta);
    push(top);

    // Luôn xác minh các bản cùng "họ" văn bản trước: signed PDF <-> Word gốc. Đây là lớp fallback
    // bắt buộc, không phụ thuộc ngưỡng điểm. Ví dụ DakLak...NQ37.signed.signed.pdf + DakLak...NQ37.docx.
    const topStem=canonicalStem(top.name||'');
    const familyPeers=ranked.filter(d=>d!==top && ['pdf','doc','docx'].includes(String(d.ext||'').toLowerCase()) && (
      (topStem && canonicalStem(d.name||'')===topStem) || fileNameSimilarity(d.name,top.name)>=0.55
    ));
    for(const d of familyPeers.slice(0,2))push(d);

    // Luôn giữ một Word/DOCX có liên hệ với trích yếu làm fallback sớm, kể cả tên file không chứa số hiện tại.
    const wordPeer=ranked.find(d=>d!==top && !out.includes(d) && ['doc','docx'].includes(String(d.ext||'').toLowerCase())
      && (fileNameSimilarity(d.name,top.name)>=0.38 || primaryMetadataEvidence(d,meta).nameSubject>=0.10 || primaryMetadataEvidence(d,meta).priority>=0.20));
    push(wordPeer);

    const distinct=ranked.find(d=>!out.includes(d)
      && out.every(x=>fileNameSimilarity(d.name,x.name)<0.68)
      && descriptorPriority(d,meta)>=topScore-0.75);
    push(distinct);

    const secondScore=ranked[1]?descriptorPriority(ranked[1],meta):-999;
    const uncertain=topScore<1.15 || (topScore-secondScore)<0.35;
    const target=Math.max(out.length, uncertain?Math.min(4,ranked.length):Math.min(3,ranked.length));
    for(const d of ranked){
      if(out.length>=target)break;
      if(descriptorPriority(d,meta)<topScore-0.75)continue;
      push(d);
    }
    return out.slice(0,Math.min(4,ranked.length));
  }

  function documentTypeHint(value) {
    const n=fold(value||'');
    const defs=[
      ['thong bao',/\b(?:tb|thong bao)\b/],['cong van',/\b(?:cv|cong van)\b/],['quyet dinh',/\b(?:qd|quyet dinh)\b/],
      ['ke hoach',/\b(?:kh|ke hoach)\b/],['bao cao',/\b(?:bc|bao cao)\b/],['to trinh',/\b(?:ttr|to trinh)\b/],
      ['giay moi',/\b(?:gm|giay moi)\b/],['bien ban',/\b(?:bb|bien ban)\b/]
    ];
    for(const [label,rx] of defs) if(n.includes(label)||rx.test(n)) return label;
    return '';
  }

  // Tên đỏ là tín hiệu DOM rất mạnh nhưng KHÔNG tuyệt đối: iOffice có thể render sai/màu trạng thái.
  // Nếu file đỏ mang số văn bản khác, tên kiểu phụ lục/danh sách hoặc loại văn bản xung đột rõ,
  // giảm ưu tiên và vẫn xác minh bằng nội dung + một ứng viên metadata mạnh nhất.
  function domPrimaryPreference(desc, meta={}) {
    let score=Number(desc?.domPrimaryScore||0);
    if(score<=0)return 0;
    const subject=meta?.trichYeu||'';
    const subjectFold=fold(subject);
    const name=desc?.name||'';
    const nameFold=fold(name);
    const currentNo=primaryNumber(meta?.symbol||meta?.soKyHieu||meta?.soHieu||'');
    const fileNos=filenameDocumentNumbers(name);
    const subjectName=subjectSimilarity(subject,name,'');
    let penalty=0;
    if(currentNo && fileNos.length && !fileNos.includes(currentNo) && subjectName<0.20) penalty+=1.65;
    if(looksSupporting(name) && !/(?:phu luc|danh sach|bieu mau|ho so|minh chung)/i.test(subjectFold)) penalty+=1.25;
    const st=documentTypeHint(subject), nt=documentTypeHint(name);
    if(st && nt && st!==nt && subjectName<0.22) penalty+=0.75;
    if(desc?.scopeKind==='related') penalty+=2.5;
    return Math.max(0, Number((score-penalty).toFixed(2)));
  }

  function descriptorPriority(desc, meta) {
    const subject = meta?.trichYeu || '';
    const subjectFold = fold(subject);
    const symbol = fold(meta?.symbol || meta?.soKyHieu || meta?.soHieu || '');
    const nameFold = fold(desc?.name || '');
    const compact = (v) => fold(v).replace(/[^a-z0-9]+/g, '');
    const symbolKey = compact(symbol), nameKey = compact(nameFold);
    let score = subjectSimilarity(subject, desc?.name || '', '');

    // Nếu iOffice đánh dấu file chính thì luôn ưu tiên mạnh nhất.
    if (desc?.isMain === true) score += 3.0;
    const domPref=domPrimaryPreference(desc,meta);
    if(domPref>0) score += Math.min(3.1, domPref);

    // Số/ký hiệu là tín hiệu mạnh, nhưng không được lấn át loại văn bản/trích yếu.
    if (symbolKey.length >= 5 && nameKey.includes(symbolKey)) score += 1.15;
    else if (symbol) {
      const symbolTokens = symbol.replace(/[^a-z0-9]+/g, ' ').split(/\s+/).filter(x => x.length >= 3);
      const hit = symbolTokens.filter(x => nameFold.includes(x)).length;
      if (symbolTokens.length && hit >= Math.ceil(symbolTokens.length * 0.6)) score += 0.5;
    }

    // Loại văn bản trong trích yếu phải khớp tên file chính (Thông báo/Công văn/QĐ/KH/BC/TTr/GM...).
    const docTypes = [
      ['thong bao', /\bthong bao\b/], ['cong van', /\bcong van\b/], ['quyet dinh', /\bquyet dinh\b/],
      ['ke hoach', /\bke hoach\b/], ['bao cao', /\bbao cao\b/], ['to trinh', /\bto trinh\b/],
      ['giay moi', /\bgiay moi\b/], ['bien ban', /\bbien ban\b/]
    ];
    for (const [label, rx] of docTypes) {
      if (subjectFold.includes(label) && rx.test(nameFold)) { score += 0.75; break; }
    }

    // Nếu tên file mang một số công văn khác rõ ràng với số hiện tại, trừ điểm mạnh.
    // Ví dụ văn bản hiện tại 10688/... nhưng file tên "CV 6713-....pdf" thường là văn bản dẫn chiếu/kèm theo.
    const currentNo=primaryNumber(symbol);
    const fileNos=filenameDocumentNumbers(desc?.name||'');
    if(currentNo && fileNos.length){
      if(fileNos.includes(currentNo)) score += 0.95;
      else if(/\b(?:cv|qd|kh|bc|tb|gm|ttr|cong van|quyet dinh|ke hoach|bao cao|thong bao)\b/i.test(nameFold)) score -= 0.95;
      else score -= 0.35;
    }

    // File đầu tiên trong khu FILE ĐÍNH KÈM thường là văn bản chính; chỉ cộng nhẹ, không tuyệt đối.
    if (Number(desc?.discoveryIndex) === 0 && desc?.scopeKind !== 'related') score += 0.22;

    if (['doc', 'docx'].includes(desc?.ext)) score += 0.10;
    if (desc?.ext === 'pdf') score += 0.06;
    if (isLikelySignedPdf(desc)) score += 0.08;

    const supportWords = ['phu luc','danh sach','ho so','bieu mau','tai lieu kem','tap '];
    const subjectHasSupport = supportWords.some(x => subjectFold.includes(x));
    if (looksSupporting(desc?.name || '') && !subjectHasSupport) score -= 0.65;
    if (/\bho so\b/i.test(nameFold) && !/\bho so\b/i.test(subjectFold)) score -= 0.75;
    if (/\bdanh sach\b/i.test(nameFold) && !/\bdanh sach\b/i.test(subjectFold)) score -= 0.45;
    if (desc?.scopeKind === 'related') score -= 0.45;
    return score;
  }

  function isLikelySignedPdf(desc) {
    return desc?.ext === 'pdf' && /(?:signed|ký|ky|ban\s*ky|da\s*ky)/i.test(fold(desc?.name || ''));
  }

  // Tracker không nhất thiết dùng cùng tệp mà AI đọc. AI có thể đọc DOCX nhanh/đủ text,
  // còn tệp giao nhiệm vụ phải ưu tiên PDF chính thức đã ký/đóng dấu của CÙNG văn bản.
  function officialAttachmentScore(desc, meta = {}, analysisPrimaryName = '') {
    if (!desc || String(desc.ext || extensionOf(desc.name)).toLowerCase() !== 'pdf') return -999;
    if (desc.scopeKind === 'related') return -999;
    let score = descriptorPriority(desc, meta);
    const primaryName = String(analysisPrimaryName || '').trim();
    const sim = primaryName ? fileNameSimilarity(desc.name || '', primaryName) : 0;
    const sameStem = primaryName && canonicalStem(desc.name || '') && canonicalStem(desc.name || '') === canonicalStem(primaryName);
    if (sameStem) score += 5.5;
    else if (sim >= 0.82) score += 4.7;
    else if (sim >= 0.68) score += 3.6;
    else if (sim >= 0.50) score += 1.5;
    else if (primaryName) score -= 1.4;
    if (desc.isMain === true) score += 4.0;
    const domPref=domPrimaryPreference(desc,meta);
    if(domPref>0) score += Math.min(4.2, domPref*1.35);
    if (isLikelySignedPdf(desc)) score += 0.9;

    const symbol = meta?.symbol || meta?.soKyHieu || meta?.soHieu || '';
    const currentNo = primaryNumber(symbol);
    const fileNos = filenameDocumentNumbers(desc.name || '');
    if (currentNo && fileNos.length) {
      if (fileNos.includes(currentNo)) score += 1.8;
      else if (sim < 0.68 && !sameStem) score -= 3.2;
    }
    return score;
  }

  function pickOfficialPrimaryPdf(descriptors = [], meta = {}, analysisPrimaryName = '') {
    const pdfs = (descriptors || []).filter(d => d && d.scopeKind !== 'related' && String(d.ext || extensionOf(d.name)).toLowerCase() === 'pdf');
    if (!pdfs.length) return null;
    const ranked = pdfs.map(d => ({...d, officialScore:officialAttachmentScore(d, meta, analysisPrimaryName)}))
      .sort((a,b) => b.officialScore - a.officialScore || Number(b.isMain===true)-Number(a.isMain===true));
    const best = ranked[0];
    if (!best) return null;
    const sim = analysisPrimaryName ? fileNameSimilarity(best.name || '', analysisPrimaryName) : 0;
    const strong = best.isMain === true || domPrimaryPreference(best,meta)>=1.35 || sim >= 0.60 || best.officialScore >= 1.05;
    if (!strong) return null;
    return best;
  }

  function buildReadGroups(descriptors, meta) {
    const byStem = new Map();
    for (const desc of descriptors) {
      const key = desc.canonicalStem || `__${desc.scopeKind}|${fold(desc.name)}`;
      if (!byStem.has(key)) byStem.set(key, []);
      byStem.get(key).push(desc);
    }
    return [...byStem.values()]
      .map((items) => ({
        items: items.sort((a, b) => descriptorPriority(b, meta) - descriptorPriority(a, meta)),
        priority: Math.max(...items.map((x) => descriptorPriority(x, meta)))
      }))
      .sort((a, b) => b.priority - a.priority);
  }

  async function runBounded(items, limit, mapper) {
    const results = new Array(items.length);
    let cursor = 0;
    const workers = Array.from({ length: Math.max(1, Math.min(limit, items.length || 1)) }, async (_, workerIndex) => {
      while (true) {
        const index = cursor++;
        if (index >= items.length) break;
        results[index] = await mapper(items[index], index, workerIndex + 1);
      }
    });
    await Promise.all(workers);
    return results;
  }

  async function readDescriptorTimed(desc, readOptions, parentSignal, timeoutMs) {
    const controller = new AbortController();
    let timedOut = false;
    const relayAbort = () => controller.abort();
    if (parentSignal) {
      if (parentSignal.aborted) throw abortError();
      parentSignal.addEventListener('abort', relayAbort, { once: true });
    }
    const timer = setTimeout(() => { timedOut = true; controller.abort(); }, timeoutMs);
    try {
      return await extractDescriptor(desc, { ...readOptions, signal: controller.signal });
    } catch (error) {
      if (parentSignal?.aborted) throw abortError();
      if (timedOut || error?.name === 'AbortError') {
        return { ...desc, text: '', chars: 0, status: 'timeout', source: 'timeout', error: `Timeout ${Math.round(timeoutMs / 1000)}s` };
      }
      return { ...desc, text: '', chars: 0, status: 'reader-error', source: 'none', error: error?.message || String(error) };
    } finally {
      clearTimeout(timer);
      parentSignal?.removeEventListener?.('abort', relayAbort);
    }
  }

  let activeHiddenViewers = 0;
  function adaptiveHiddenViewerConcurrency() {
    const cpu=Math.max(1,Number(navigator.hardwareConcurrency||4));
    const mem=Number(navigator.deviceMemory||0);
    if(navigator.connection?.saveData)return 1;
    // Viewer là nút thắt cổ chai; dùng khoảng nửa số luồng CPU nhưng giới hạn 8 iframe để giữ ổn định.
    let n=Math.max(1,Math.min(8,Math.ceil(cpu/2)));
    if(mem&&mem<4)n=Math.min(n,2); else if(mem&&mem<8)n=Math.min(n,4);
    return n;
  }
  async function withHiddenViewerSlot(signal, task) {
    const maxHidden = adaptiveHiddenViewerConcurrency();
    while (activeHiddenViewers >= maxHidden) await sleepAbortable(35, signal);
    assertNotAborted(signal);
    activeHiddenViewers += 1;
    try { return await task(); }
    finally { activeHiddenViewers = Math.max(0, activeHiddenViewers - 1); }
  }

  async function extractDescriptor(desc, options = {}) {
    const signal = options.signal || null;
    assertNotAborted(signal);
    const partial = Boolean(options.partial);
    const forceFresh = Boolean(options.forceFresh);
    const captureNotBefore = forceFresh ? Date.now() - 25 : Number(options.notBefore || 0);
    const cached = (partial || forceFresh) ? null : await readCache(desc);
    assertNotAborted(signal);
    if (cached?.text) return { ...desc, ...cached, chars: cached.text.length };

    const ext = String(desc.ext || extensionOf(desc.name)).toLowerCase();
    const maxFileBytes = maxFileBytesFromOptions(options);
    const supported = ['pdf','doc','docx','xls','xlsx','rtf','txt'].includes(ext);
    if (!supported) {
      return { ...desc, text:'', chars:0, words:0, status:'unsupported-file', source:'unsupported', unsupported:true, error:`Định dạng .${ext || '?'} không đọc tự động.` };
    }
    let original = null;
    let originalFailure = '';
    let viewerUrl = String(desc.viewerUrl || '').trim();

    // 0) Fast path file Office mở được trực tiếp: ưu tiên lấy bytes gốc và parse trước viewer.
    // Đây là đường nhanh/ổn định nhất cho DOCX/XLSX/TXT/RTF và không làm thay đổi trạng thái iOffice.
    if (!forceFresh && ['docx','xlsx','txt','rtf'].includes(ext)) {
      try {
        const directOriginal = await fetchOriginalFile(desc, { ...options, signal, notBefore:captureNotBefore });
        if (directOriginal?.tooLarge) return tooLargeResult(desc, directOriginal.sizeBytes, options, 'original-size-limit');
        if (directOriginal?.bytes?.length) {
          const parsed = await parseOriginalText(desc, directOriginal, options);
          if (parsed?.text?.length >= 20) {
            const result = { ...desc, ...parsed, chars:parsed.text.length, words:wordCount(parsed.text), source:`direct-${ext}` };
            if (!partial) await writeCache(desc, result);
            return result;
          }
        }
      } catch (error) {
        if (error?.name === 'AbortError') throw error;
        originalFailure ||= error?.message || String(error);
      }
    }

    // 1) Luôn hỏi chính iOffice để lấy URL viewer thật. Không tự dựng /viewfile.
    if (Array.isArray(desc.actionArgs) && desc.actionArgs.length) {
      try {
        const actualViewer = await withViewerResolverLock(signal, () => resolveViewerUrlViaPage(desc, signal));
        if (actualViewer) {
          viewerUrl = actualViewer;
          desc = { ...desc, viewerUrl: actualViewer, candidateUrls: [...new Set([actualViewer, ...(desc.candidateUrls || [])])] };
        }
      } catch (error) {
        if (error?.name === 'AbortError') throw error;
        originalFailure = error?.message || String(error);
      }
    }

    // Nếu người dùng vừa mở đúng file, network-tap có thể đã bắt được file gốc hoặc PDF iOffice chuyển đổi.
    const preCaptured = capturedFileForDescriptor(desc, { viewerUrl, allowConvertedPdf:true, recentMs:180000, notBefore:captureNotBefore });
    if (preCaptured?.bytes?.length > maxFileBytes) return tooLargeResult(desc, preCaptured.bytes.byteLength, options, 'captured-size-limit');
    if (preCaptured?.bytes?.length && !preCaptured.convertedPdf && ['docx','xlsx','txt','rtf'].includes(ext)) {
      try {
        const parsed = await parseOriginalText(desc, preCaptured, options);
        if (parsed?.text?.length >= 20) {
          const result = { ...desc, ...parsed, source:`captured-${ext}`, chars:parsed.text.length, words:wordCount(parsed.text) };
          if (!partial) await writeCache(desc, result);
          return result;
        }
      } catch (error) { originalFailure ||= error?.message || String(error); }
    }

    const resolvedViewer = (() => {
      try { return viewerUrl || (makeViewerUrl(desc) ? new URL(makeViewerUrl(desc), location.href).href : ''); }
      catch (_) { return viewerUrl || ''; }
    })();

    const observedOversize = observedOversizeForDescriptor(desc, resolvedViewer, maxFileBytes, captureNotBefore);
    if (observedOversize) return tooLargeResult(desc, observedOversize.sizeBytes, options, 'network-size-limit');

    const frameMatchesDescriptor = (frame) => {
      const src = frame.getAttribute('src') || '';
      const token = String(desc.viewerToken || '').trim();
      const fileId = String(desc.fileId || '').trim();
      let absolute = '', activeToken = '', decoded = '';
      try {
        absolute = new URL(src, location.href).href;
        activeToken = new URL(absolute).searchParams.get('file') || '';
        decoded = decodeURIComponent(absolute);
      } catch (_) {}
      if (resolvedViewer && absolute === resolvedViewer) {
        try { const u = new URL(absolute); if (u.searchParams.get('file') || u.search.length > 3) return true; } catch (_) {}
      }
      if (token && (activeToken === token || decoded.includes(token))) return true;
      if (fileId && decoded && new RegExp(`(?:[?&=/]|^)${fileId.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')}(?:[&#/]|$)`).test(decoded)) return true;
      return false;
    };

    const finishViewerResult = async (data, usedViewerUrl, sourceLabel) => {
      assertNotAborted(signal);
      const text = data?.text || '';
      if (text.length >= 20) {
        const result = { ...desc, ...data, text, chars:text.length, words:wordCount(text), source:data?.source || sourceLabel };
        if (!partial) await writeCache(desc, result);
        return result;
      }
      // v0.15.1: tạm bỏ qua PDF scan. Không OCR và không giữ bytes để upload AI.
      const pdfPagesRead=Number(data?.pagesRead||0), pdfTotalPages=Number(data?.totalPages||0);
      const pdfTextInspectionCompleted=pdfPagesRead>0 && pdfTotalPages>0;
      if (ext === 'pdf' && options.tryIofficeOcr === false && options.captureScanBinary === false &&
          pdfTextInspectionCompleted && /scan-no-text|scan-no-ocr-text|scan-ready-for-ai|scan-too-large/i.test(String(data?.status || ''))) {
        return { ...desc, text:'', chars:0, words:0, status:'pdf-scan-skipped', source:data?.source || sourceLabel, scanSkipped:true, scanConfirmed:true, pagesRead:pdfPagesRead, totalPages:pdfTotalPages };
      }
      if (data?.scanBytes?.length || data?.status === 'scan-too-large') {
        return { ...desc, ...data, text:'', chars:0, words:0, source:data?.source || sourceLabel };
      }

      // iOffice có thể chuyển DOC/DOCX/XLS/XLSX thành PDF trước khi viewer đọc. Bắt chính bytes PDF đó làm fallback cho AI/OCR.
      const converted = await waitForCapturedFile(desc, usedViewerUrl, { signal, timeoutMs:['doc','docx','xls','xlsx'].includes(ext) ? 1800 : 900, notBefore:captureNotBefore });
      if (converted?.bytes?.length && converted.signature === 'pdf') {
        if (ext === 'pdf' && options.captureScanBinary === false) {
          return { ...desc, text:'', chars:0, words:0, status:'pdf-read-unverified', source:converted.convertedPdf ? 'ioffice-converted-pdf' : 'captured-pdf', scanSkipped:false, scanConfirmed:false, originalUrl:converted.url, viewerUrl:usedViewerUrl, error:'Đã lấy được PDF nhưng PDF.js chưa xác minh được lớp chữ; không kết luận là file scan.' };
        }
        const sizeBytes = converted.bytes.byteLength;
        if (sizeBytes <= MAX_SCAN_FILE_BYTES) {
          return { ...desc, text:'', chars:0, words:0, status:'scan-ready-for-ai', source:converted.convertedPdf ? 'ioffice-converted-pdf' : 'captured-pdf', scanBytes:converted.bytes, scanSizeBytes:sizeBytes, originalUrl:converted.url, viewerUrl:usedViewerUrl };
        }
        return { ...desc, text:'', chars:0, words:0, status:'scan-too-large', source:converted.convertedPdf ? 'ioffice-converted-pdf' : 'captured-pdf', scanSizeBytes:sizeBytes, originalUrl:converted.url, viewerUrl:usedViewerUrl };
      }
      return null;
    };

    // 2) Ưu tiên viewer đang mở của đúng tệp.
    const viewerFrames = forceFresh ? [] : currentViewerFrames();
    const existing = forceFresh ? null : (viewerFrames.find(frameMatchesDescriptor) || (options.allowCurrentViewerFallback === true && viewerFrames.length === 1 ? viewerFrames[0] : null));
    if (existing) {
      try {
        const data = await extractFromFrame(existing, 'current-viewer', { ...options, signal, fileName:desc.name, tryIofficeOcr:options.tryIofficeOcr!==false, appTimeoutMs:Math.max(1800, Math.min(6500, Number(options.appTimeoutMs || 5200))) });
        const result = await finishViewerResult(data, existing.src || resolvedViewer, 'current-viewer');
        if (result) return result;
      } catch (error) {
        if (error?.name === 'AbortError') throw error;
        originalFailure ||= error?.message || String(error);
      }
    }

    // 3) Mở viewer ẩn đúng URL do iOffice tạo. Đây là đường chính cho PDF và Office cũ do iOffice tự chuyển sang PDF.
    const url = resolvedViewer || makeViewerUrl(desc);
    if (url && supported) {
      const viewerResult = await withHiddenViewerSlot(signal, async () => {
        let frame = null;
        try {
          if (new URL(url, location.href).origin !== location.origin) return null;
          frame = document.createElement('iframe');
          frame.setAttribute('aria-hidden', 'true');
          frame.style.cssText = 'position:fixed;left:-12000px;top:0;width:900px;height:700px;opacity:.01;pointer-events:none;z-index:-1;border:0';
          const loaded = new Promise(resolve => frame.addEventListener('load', resolve, { once:true }));
          frame.src = url;
          document.documentElement.appendChild(frame);
          await Promise.race([loaded, sleepAbortable(Math.max(1100,Math.min(3200,Number(options.appTimeoutMs||5200)*0.48)), signal)]);
          assertNotAborted(signal);

          // network-tap chạy trong chính viewer.jsp và bắt GET /viewfile cùng bytes thật.
          const captured = await waitForCapturedFile(desc, url, { signal, timeoutMs:['doc','docx','xls','xlsx'].includes(ext) ? 2200 : 1100, notBefore:captureNotBefore });
          if (captured?.bytes?.length > maxFileBytes) return tooLargeResult(desc, captured.bytes.byteLength, options, 'viewer-size-limit');
          const lateOversize = observedOversizeForDescriptor(desc, url, maxFileBytes, captureNotBefore);
          if (lateOversize) return tooLargeResult(desc, lateOversize.sizeBytes, options, 'network-size-limit');
          if (captured?.bytes?.length && !captured.convertedPdf && ['docx','xlsx','txt','rtf'].includes(ext)) {
            try {
              const parsed = await parseOriginalText(desc, captured, options);
              if (parsed?.text?.length >= 20) return { ...desc, ...parsed, source:`captured-${ext}`, chars:parsed.text.length, words:wordCount(parsed.text) };
            } catch (error) { originalFailure ||= error?.message || String(error); }
          }

          const data = await extractFromFrame(frame, 'hidden-viewer', { ...options, signal, fileName:desc.name, tryIofficeOcr:options.tryIofficeOcr!==false, appTimeoutMs:Math.max(1800, Math.min(6500, Number(options.appTimeoutMs || 5200))) });
          return await finishViewerResult(data, url, 'hidden-viewer');
        } catch (error) {
          if (error?.name === 'AbortError') throw error;
          originalFailure ||= error?.message || String(error);
          return null;
        } finally {
          try { frame?.remove(); } catch (_) {}
        }
      });
      if (viewerResult) {
        if (!partial && viewerResult.text) await writeCache(desc, viewerResult);
        return viewerResult;
      }
    }

    // 4) Fallback file gốc. Chỉ chạy sau viewer để tận dụng các request thật mà iOffice vừa làm lộ.
    if (['docx','xlsx','txt','rtf','doc','xls','pdf'].includes(ext)) {
      try {
        original = await fetchOriginalFile(desc, { ...options, signal, notBefore:captureNotBefore });
        assertNotAborted(signal);
        if (original?.tooLarge) return tooLargeResult(desc, original.sizeBytes, options, 'original-size-limit');
        if (original?.bytes?.length && ['docx','xlsx','txt','rtf'].includes(ext)) {
          const parsed = await parseOriginalText(desc, original, options);
          if (parsed?.text?.length >= 20) {
            const result = { ...desc, ...parsed, chars:parsed.text.length, words:wordCount(parsed.text) };
            if (!partial) await writeCache(desc, result);
            return result;
          }
        }
      } catch (error) {
        if (error?.name === 'AbortError') throw error;
        originalFailure ||= error?.message || String(error);
      }
    }

    // 5) Nếu đã có PDF (gốc hoặc iOffice chuyển đổi) nhưng không có text, chuyển nguyên PDF cho AI/OCR.
    const capturedPdf = capturedFileForDescriptor(desc, { viewerUrl:url, allowConvertedPdf:true, recentMs:180000, notBefore:captureNotBefore });
    const pdfBytes = capturedPdf?.signature === 'pdf' ? capturedPdf : (original?.bytes?.length && signatureKind(original.bytes)==='pdf' ? original : null);
    if (pdfBytes?.bytes?.length && options.captureScanBinary === false && ext === 'pdf') {
      return { ...desc, text:'', chars:0, words:0, status:'pdf-read-unverified', source:capturedPdf?.convertedPdf ? 'ioffice-converted-pdf' : 'original-pdf', scanSkipped:false, scanConfirmed:false, originalUrl:pdfBytes.url, error:'Đã lấy được bytes PDF nhưng chưa đọc được PDF.js; chưa đủ căn cứ xác định PDF scan.' };
    }
    if (pdfBytes?.bytes?.length && options.captureScanBinary !== false) {
      const sizeBytes = pdfBytes.bytes.byteLength;
      if (sizeBytes <= MAX_SCAN_FILE_BYTES) {
        return { ...desc, text:'', chars:0, words:0, status:'scan-ready-for-ai', source:capturedPdf?.convertedPdf ? 'ioffice-converted-pdf' : 'original-pdf', scanBytes:pdfBytes.bytes, scanSizeBytes:sizeBytes, originalUrl:pdfBytes.url };
      }
      return { ...desc, text:'', chars:0, words:0, status:'scan-too-large', source:capturedPdf?.convertedPdf ? 'ioffice-converted-pdf' : 'original-pdf', scanSizeBytes:sizeBytes, originalUrl:pdfBytes.url };
    }

    if (original?.bytes?.length && ['doc','xls'].includes(ext)) {
      return { ...desc, text:'', chars:0, words:0, status:'legacy-binary-unparsed', source:'original-file', originalSizeBytes:original.bytes.byteLength, error:'Đã lấy file gốc Office đời cũ nhưng iOffice viewer không tạo được text/PDF chuyển đổi.' };
    }
    const diagnostics = Array.isArray(original?.diagnostics) ? original.diagnostics.slice(-4).join(' · ') : '';
    return {
      ...desc,
      text:'', chars:0, words:0,
      status: url ? 'viewer-no-text' : 'no-file-source',
      source:'none',
      error: originalFailure || (diagnostics ? `Đã thử viewer thật và nguồn file nhưng chưa lấy được dữ liệu (${diagnostics}).` : 'Không lấy được nội dung từ viewer thật của iOffice hoặc file gốc.')
    };
  }

  function subjectSimilarity(subject, name, text) {
    const subjectTokens = tokens(subject);
    const nameScore = jaccard(subjectTokens, tokens(name));
    const textScore = jaccard(subjectTokens, tokens(String(text || '').slice(0, 6000)));
    return Math.max(0, Math.min(1, nameScore * 0.65 + textScore * 0.35));
  }

  function looksSupporting(name) {
    const n=fold(name||'');
    // Chỉ dùng các nhãn phụ lục/tệp kèm có tính đặc hiệu cao.
    // "hướng dẫn", "tài liệu", "kế hoạch"... có thể chính là trích yếu của công văn nên tuyệt đối không loại trước.
    return /\b(phu luc|danh sach|mau bieu|bieu mau|bang ke|appendix|tai lieu kem|tai lieu tham khao|tap\s*\d+)\b/i.test(n);
  }

  function chooseRepresentative(group, subject, symbol) {
    const scored = group.map((doc) => {
      const rel = subjectSimilarity(subject, doc.name, doc.text);
      const symbolHit = symbol && fold(`${doc.name} ${doc.text.slice(0, 3000)}`).includes(fold(symbol)) ? 0.12 : 0;
      const extBonus = ['docx', 'doc'].includes(doc.ext) ? 0.06 : doc.ext === 'pdf' ? 0.03 : 0;
      const textBonus = doc.text.length >= 500 ? 0.08 : 0;
      const supportPenalty = looksSupporting(doc.name) ? 0.06 : 0;
      const score = rel + symbolHit + extBonus + textBonus - supportPenalty;
      return { doc, rel, score };
    }).sort((a, b) => b.score - a.score || b.doc.text.length - a.doc.text.length);

    // Nếu DOC/DOCX và PDF gần như trùng nội dung, ưu tiên bản Word làm nguồn text sạch.
    const word = scored.find((x) => ['docx', 'doc'].includes(x.doc.ext) && x.doc.text.length >= 300);
    const pdf = scored.find((x) => x.doc.ext === 'pdf' && x.doc.text.length >= 300);
    if (word && pdf && textSimilarity(word.doc.text, pdf.doc.text) >= 0.84 && pdf.doc.text.length < word.doc.text.length * 1.2) {
      return { ...word, duplicateVerifiedByPdf: true };
    }
    return scored[0] || { doc: group[0], rel: 0, score: 0 };
  }

  function groupDuplicates(docs) {
    const parent = docs.map((_, i) => i);
    const find = (x) => parent[x] === x ? x : (parent[x] = find(parent[x]));
    const join = (a, b) => {
      a = find(a); b = find(b);
      if (a !== b) parent[b] = a;
    };

    for (let i = 0; i < docs.length; i++) {
      for (let j = i + 1; j < docs.length; j++) {
        if (docs[i].forcedDuplicateOf === docs[j].name || docs[j].forcedDuplicateOf === docs[i].name) {
          join(i, j);
          continue;
        }
        const aText = cleanText(docs[i].text || '');
        const bText = cleanText(docs[j].text || '');
        const bothText = aText.length >= 200 && bText.length >= 200;
        if (!bothText) continue;
        const exactSame = aText === bText;
        const shorter = Math.min(aText.length, bText.length);
        const longer = Math.max(aText.length, bText.length);
        const lengthRatio = longer ? shorter / longer : 0;
        const sim = exactSame ? 1 : textSimilarity(aText, bText);
        const nameSim = fileNameSimilarity(docs[i].name, docs[j].name);
        // Văn bản hành chính thường có DOCX chưa ký + PDF đã ký, hoặc nhiều PDF ký số cùng nội dung.
        // - Nội dung gần như tuyệt đối giống nhau: gộp dù tên khác.
        // - Tên cùng họ (bản Word/PDF, _1/_2, signed): cho phép chênh nhẹ do chữ ký/header/footer.
        const sameContent = exactSame
          || (lengthRatio >= 0.90 && sim >= 0.975)
          || (nameSim >= 0.72 && lengthRatio >= 0.80 && sim >= 0.90);
        if (!docs[i].truncated && !docs[j].truncated && sameContent) join(i, j);
      }
    }

    const groups = new Map();
    docs.forEach((doc, i) => {
      const root = find(i);
      if (!groups.has(root)) groups.set(root, []);
      groups.get(root).push(doc);
    });
    return [...groups.values()];
  }

  function chunks(text, size = 1200) {
    const clean = cleanText(text);
    const paras = clean.split(/\n{2,}/).filter(Boolean);
    if (paras.length > 1) return paras;
    const out = [];
    for (let i = 0; i < clean.length; i += size) out.push(clean.slice(i, i + size));
    return out;
  }

  function relevantExcerpt(text, subject, limit) {
    const clean = cleanText(text);
    if (clean.length <= limit) return clean;
    const subjectTokens = tokens(subject);
    const pieces = chunks(clean);
    const ranked = pieces.map((part, idx) => ({
      idx,
      part,
      score: jaccard(subjectTokens, tokens(part)) + (idx === 0 ? 0.22 : idx === 1 ? 0.08 : 0)
    })).sort((a, b) => b.score - a.score || a.idx - b.idx);

    const selected = [];
    let used = 0;
    for (const item of ranked) {
      if (used >= limit) break;
      const take = item.part.slice(0, Math.max(0, limit - used));
      if (take) {
        selected.push({ idx: item.idx, text: take });
        used += take.length + 2;
      }
    }
    return selected.sort((a, b) => a.idx - b.idx).map((x) => x.text).join('\n\n').slice(0, limit);
  }

  function normalizedTextKey(text) {
    const clean = cleanText(text || '');
    if (clean.length < 300) return '';
    return `${clean.length}|${fold(clean.slice(0, 12000))}`;
  }

  function dedupeDocsByIdentity(docs) {
    const map = new Map();
    for (const doc of docs || []) {
      const key = descriptorIdentityKey(doc);
      const prev = map.get(key);
      if (!prev) { map.set(key, doc); continue; }
      const score = (x) => ((x.text?.length || 0) >= MIN_TEXT_CHARS ? 1000000 : 0) + (x.text?.length || 0) + (x.status === 'pdf-scan-skipped' ? 50 : 0);
      if (score(doc) > score(prev)) map.set(key, doc);
    }
    return [...map.values()];
  }

  async function repairViewerCollisions(docs, descriptors, signal, onProgress = () => {}) {
    const current = dedupeDocsByIdentity(docs);
    const groups = new Map();
    for (const doc of current) {
      const key = normalizedTextKey(doc.text);
      if (!key) continue;
      if (!groups.has(key)) groups.set(key, []);
      groups.get(key).push(doc);
    }
    const descMap = new Map((descriptors || []).map(d => [descriptorIdentityKey(d), d]));

    // v0.16.4: nội dung giống nhau không còn mặc định bị coi là lỗi.
    // Chỉ xác minh lại tuần tự khi nhiều descriptor thật sự đang dùng cùng một viewer URL.
    // Sau khi xác minh, nếu nội dung vẫn giống nhau thì coi là bản sao hợp lệ và để prepareBundle gộp token.
    for (const same of groups.values()) {
      if (same.length < 2) continue;
      const sameViewer = same.some((a, i) => same.some((b, j) => i < j && a.viewerUrl && b.viewerUrl && a.viewerUrl === b.viewerUrl));
      if (!sameViewer) continue;

      onProgress({ phase:'collision', message:`Phát hiện ${same.length} tệp đang dùng cùng viewer · xác minh lại tuần tự. Nếu nội dung thật sự trùng sẽ gộp và chỉ gửi AI một bản.` });
      for (let i = 0; i < same.length; i++) {
        assertNotAborted(signal);
        const doc = same[i];
        const desc = descMap.get(descriptorIdentityKey(doc));
        if (!desc) continue;
        try {
          const reread = await readDescriptorTimed(desc, { partial:false, forceFresh:true, maxChars:24000, maxPages:24, tryIofficeOcr:false, captureScanBinary:false, fileName:desc.name }, signal, 18000);
          const idx = current.findIndex(x => descriptorIdentityKey(x) === descriptorIdentityKey(doc));
          if (idx >= 0 && reread) current[idx] = reread;
        } catch (error) {
          if (error?.name === 'AbortError') throw error;
          // Giữ kết quả cũ nếu xác minh lại lỗi tạm thời; không biến file đã đọc được thành "chưa đọc được".
        }
      }
    }
    return current;
  }

  function prepareBundle(meta, docs, expectedAttachmentCount = null, options = {}) {
    docs = dedupeDocsByIdentity(docs);
    const groups = options.readerDeduplicateContent === false ? docs.map((doc) => [doc]) : groupDuplicates(docs);
    const representatives = [];
    const duplicates = [];

    for (const group of groups) {
      const chosen = chooseRepresentative(group, meta.trichYeu || '', meta.symbol || '');
      const rep = chosen.doc;
      const rel = chosen.rel;
      representatives.push({ ...rep, relevance: rel, duplicateVerifiedByPdf: !!chosen.duplicateVerifiedByPdf });
      for (const item of group) {
        if (item === rep) continue;
        duplicates.push({
          name: item.name,
          duplicateOf: rep.name,
          nameSimilarity: Number(fileNameSimilarity(item.name, rep.name).toFixed(3)),
          textSimilarity: item.text && rep.text ? Number(textSimilarity(item.text, rep.text).toFixed(3)) : null,
          status: item.text ? 'duplicate-not-sent' : 'duplicate-skipped'
        });
      }
    }

    representatives.sort((a, b) => {
      const aPrimary = looksSupporting(a.name) ? 0 : 1;
      const bPrimary = looksSupporting(b.name) ? 0 : 1;
      return bPrimary - aPrimary || b.relevance - a.relevance || (b.text?.length || 0) - (a.text?.length || 0);
    });

    const primary = representatives.find((x) => (x.text?.length || 0) >= MIN_TEXT_CHARS) || representatives[0] || null;
    const support = representatives.filter((x) => x !== primary).sort((a, b) => b.relevance - a.relevance);

    // v0.15.1: PDF scan không có text được tạm bỏ qua. Không OCR, không base64 và không upload Gemini.
    const scanAttachments = [];
    const scanBytesUsed = 0;
    const scanNames = new Set();
    const skippedScans = representatives
      .filter((x) => x.status === 'pdf-scan-skipped')
      .map((x) => ({ name:x.name, status:'pdf-scan-skipped', scopeKind:x.scopeKind, ext:x.ext, source:x.source || '', scanConfirmed:x.scanConfirmed===true, pagesRead:Number(x.pagesRead||0), totalPages:Number(x.totalPages||0) }));
    const skippedLargeFiles = representatives
      .filter((x) => x.status === 'file-too-large-skipped')
      .map((x) => ({ name:x.name, status:'file-too-large-skipped', scopeKind:x.scopeKind, ext:x.ext, source:x.source || '', sizeBytes:Number(x.originalSizeBytes || 0), error:x.error || '' }));

    const unreadable = representatives
      .filter((x) => (!x.text || x.text.length < MIN_TEXT_CHARS) && !scanNames.has(x.name) && x.status !== 'pdf-scan-skipped' && x.status !== 'file-too-large-skipped')
      .map((x) => ({ name: x.name, status: x.status, scopeKind: x.scopeKind, ext:x.ext, sizeBytes: x.originalSizeBytes || x.scanSizeBytes || 0, error:x.error || '' }));

    const primaryText = primary?.text ? relevantExcerpt(primary.text, meta.trichYeu || '', MAX_PRIMARY_CHARS) : '';
    let remaining = Math.max(0, MAX_TOTAL_AI_CHARS - primaryText.length);
    const supportingDocuments = [];
    for (const doc of support) {
      if (remaining < 300 || !doc.text) continue;
      const max = Math.min(MAX_SUPPORT_CHARS, remaining);
      const excerpt = relevantExcerpt(doc.text, meta.trichYeu || '', max);
      if (!excerpt) continue;
      supportingDocuments.push({
        name: doc.name, ext: doc.ext, relevance: Number(doc.relevance.toFixed(3)), source: doc.source,
        charsOriginal: doc.text.length, wordsOriginal: wordCount(doc.text),
        charsSent: excerpt.length, wordsSent: wordCount(excerpt), text: excerpt
      });
      remaining -= excerpt.length;
    }

    const primaryDocument = primary ? {
      name: primary.name, ext: primary.ext, relevance: Number((primary.relevance || 0).toFixed(3)), source: primary.source,
      status: primary.status, charsOriginal: primary.text?.length || 0, wordsOriginal: wordCount(primary.text || ''),
      charsSent: primaryText.length, wordsSent: wordCount(primaryText), pagesRead: primary.pagesRead || 0, totalPages: primary.totalPages || 0,
      scanConfirmed: primary.scanConfirmed === true, domPrimaryRed: primary.domPrimaryRed === true, domPrimaryScore:Number(primary.domPrimaryScore||0),
      truncated: !!primary.truncated || (primary.text?.length || 0) > primaryText.length,
      duplicateVerifiedByPdf: !!primary.duplicateVerifiedByPdf, scanAttachedForAi: scanNames.has(primary.name), text: primaryText
    } : null;

    const combinedText = cleanText([primaryDocument?.text || '', ...supportingDocuments.map((x) => x.text)].filter(Boolean).join('\n\n')).slice(0, MAX_TOTAL_AI_CHARS);
    // Kiểm tra độ đầy đủ theo từng tệp thật đã phát hiện, không theo nhóm nội dung đã gộp.
    // Nhờ vậy 4 tệp thật vẫn được báo 4/4, dù Word + PDF có nội dung trùng và chỉ gửi một bản cho AI.
    const requiredDocs = docs.filter((x) => x.scopeKind !== 'related');
    const expectedRequired = Number(expectedAttachmentCount) > 0 ? Number(expectedAttachmentCount) : requiredDocs.length;
    const missingDescriptors = Math.max(0, expectedRequired - requiredDocs.length);
    const requiredScanSkipped = requiredDocs.filter((x) => x.status === 'pdf-scan-skipped');
    const requiredLargeSkipped = requiredDocs.filter((x) => x.status === 'file-too-large-skipped');
    const requiredUnsupported = requiredDocs.filter((x) => x.status === 'unsupported-file');
    const requiredUnreadable = requiredDocs.filter((x) => (!x.text || x.text.length < MIN_TEXT_CHARS) && !scanNames.has(x.name) && x.status !== 'pdf-scan-skipped' && x.status !== 'file-too-large-skipped' && x.status !== 'unsupported-file');
    const requiredTextReady = requiredDocs.filter((x) => (x.text?.length || 0) >= MIN_TEXT_CHARS).length;
    const readableExpected = Math.max(0, expectedRequired - requiredUnsupported.length);
    const blockedByScanOnly = readableExpected > 0 && missingDescriptors === 0 && requiredUnreadable.length === 0 && requiredTextReady === 0 && (requiredScanSkipped.length + requiredLargeSkipped.length) > 0;
    // ZIP/RAR/7z là tệp có thật nhưng không phải định dạng văn bản mà Reader phải parse. Không coi chúng là lỗi
    // "chưa nhận diện" và không chặn AI nếu chính văn PDF/Word đã đọc được.
    const aiReady = expectedRequired === 0 ? true : (!blockedByScanOnly && requiredUnreadable.length === 0 && missingDescriptors === 0 && requiredTextReady > 0);

    const duplicateByName = new Map(duplicates.map((d) => [fold(d.name), d]));
    const fileResults = docs.map((doc) => {
      const textReady = (doc.text?.length || 0) >= MIN_TEXT_CHARS;
      const duplicateInfo = duplicateByName.get(fold(doc.name)) || null;
      const scanReady = scanNames.has(doc.name);
      const scanSkipped = doc.status === 'pdf-scan-skipped';
      const sizeLimitSkipped = doc.status === 'file-too-large-skipped';
      return {
        name:doc.name, ext:doc.ext, scopeKind:doc.scopeKind, role:doc.name===primary?.name?'primary':'support',
        status: duplicateInfo && textReady ? 'duplicate-not-sent' : textReady ? 'text-ready' : scanSkipped ? 'scan-skipped' : sizeLimitSkipped ? 'size-limit-skipped' : doc.status === 'unsupported-file' ? 'unsupported-file' : scanReady ? 'scan-attached' : (doc.status || 'unreadable'),
        source:doc.source || '', chars:Number(doc.text?.length || 0), words:wordCount(doc.text || ''),
        readyForAi:textReady || scanReady, sentAsScan:scanReady, scanSkipped, sizeLimitSkipped, sizeBytes:Number(doc.originalSizeBytes || 0),
        duplicateOf: duplicateInfo?.duplicateOf || '', duplicateSimilarity: duplicateInfo?.textSimilarity ?? null, error:doc.error || ''
      };
    });

    for (let i = 0; i < missingDescriptors; i++) {
      fileResults.push({
        name: `Tệp chưa nhận diện #${requiredDocs.length + i + 1}`, ext:'', scopeKind:'attachment', role:'unknown',
        status:'descriptor-missing', source:'none', chars:0, words:0, readyForAi:false, sentAsScan:false,
        error:'iOffice báo có tệp nhưng tiện ích chưa lấy được định danh/link của tệp.'
      });
      unreadable.push({ name:`Tệp chưa nhận diện #${requiredDocs.length + i + 1}`, status:'descriptor-missing', scopeKind:'attachment', ext:'', sizeBytes:0, error:'Chưa lấy được định danh/link tệp từ iOffice.' });
    }

    return {
      version: VERSION,
      readMode: options.readerMode === 'all' ? 'all' : 'primary',
      primaryDocument, supportingDocuments, scanAttachments, skippedScans, skippedLargeFiles, duplicates, unreadable, fileResults,
      stats: {
        filesDetected: expectedRequired,
        relatedFilesDetected: representatives.filter(x=>x.scopeKind==='related').length,
        filesWithText: docs.filter((x) => (x.text?.length || 0) >= MIN_TEXT_CHARS).length,
        filesReadyForAi: requiredTextReady,
        scanSkippedCount: requiredScanSkipped.length,
        oversizedSkippedCount: requiredLargeSkipped.length,
        unsupportedCount: requiredUnsupported.length,
        uniqueGroups: groups.length, duplicatesSkipped: duplicates.length, duplicateCount: duplicates.length,
        scanAttachmentsPrepared: 0, scanBytesPrepared: 0,
        unreadableCount: unreadable.length, requiredUnreadableCount: requiredUnreadable.length + missingDescriptors, missingDescriptorCount: missingDescriptors,
        extractedTextChars: docs.reduce((n,x)=>n+(x.text?.length||0),0),
        extractedWords: docs.reduce((n,x)=>n+wordCount(x.text||''),0),
        aiTextChars: combinedText.length, aiTextWords: wordCount(combinedText)
      },
      aiReady,
      blockedByScanOnly,
      aiBlockedReason: aiReady
        ? ''
        : blockedByScanOnly
          ? (requiredLargeSkipped.length && !requiredScanSkipped.length
              ? (expectedRequired === 1
                  ? `Văn bản chỉ có 1 tệp vượt giới hạn dung lượng nên không còn nội dung để phân tích.`
                  : `Cả ${expectedRequired} tệp đính kèm đều vượt giới hạn dung lượng nên không còn nội dung để phân tích.`)
              : requiredScanSkipped.length && !requiredLargeSkipped.length
                ? (expectedRequired === 1
                    ? 'Văn bản chỉ có 1 PDF scan, chưa thể trích xuất nội dung nên không phân tích được.'
                    : `Cả ${expectedRequired} tệp đính kèm đều là PDF scan, chưa thể trích xuất nội dung nên không phân tích được.`)
                : 'Các tệp đính kèm đều bị bỏ qua (PDF scan hoặc vượt giới hạn dung lượng), nên không còn nội dung để phân tích.')
          : `Chưa đủ dữ liệu: ${requiredUnreadable.length + missingDescriptors}/${expectedRequired} tệp bắt buộc chưa sẵn sàng.`,
      requiresReviewForUnreadable: !aiReady || requiredScanSkipped.length > 0 || requiredLargeSkipped.length > 0 || !!primary?.truncated,
      combinedText
    };
  }



  async function getStableAttachmentDescriptors(options = {}, signal = null, onProgress = () => {}) {
    const includeRelated = options.readerIncludeRelated !== false;
    const startedAt = Date.now();
    const deadline = startedAt + 1800;
    let best = [];
    let lastSig = '';
    let stableRounds = 0;
    let declared = getDeclaredAttachmentCount();
    while (Date.now() < deadline) {
      assertNotAborted(signal);
      const current = getAttachmentDescriptors().filter(d => includeRelated || d.scopeKind !== 'related');
      declared = Math.max(declared, getDeclaredAttachmentCount());
      if (current.length > best.length) best = current;
      else if (current.length === best.length && current.some((d,i)=>d.viewerToken && !best[i]?.viewerToken)) best = current;
      const sig = current.map(d => `${d.scopeKind}|${d.fileId}|${d.viewerToken}|${fold(d.name)}`).sort().join('||');
      stableRounds = sig && sig === lastSig ? stableRounds + 1 : 0;
      lastSig = sig;
      const attachmentCount = current.filter(x => x.scopeKind !== 'related').length;
      // Không trả quá sớm khi iOffice mới render PDF đầu tiên. Chờ tối thiểu ~650 ms và chỉ kết thúc sớm
      // khi đã thấy đủ số card công bố; nếu chưa có declared count thì cần ổn định lâu hơn.
      const settledMs = Date.now() - startedAt;
      if (settledMs >= 650 && stableRounds >= (declared>0?2:4) && (declared === 0 ? current.length>0 : attachmentCount >= declared)) return current;
      await sleepAbortable(stableRounds ? 120 : 160, signal);
    }
    const count = best.filter(x => x.scopeKind !== 'related').length;
    if (declared > count) onProgress({ phase:'discover-wait', message:`Danh sách tệp tải chậm: mới nhận diện ${count}/${declared}; tiếp tục đọc các tệp đã có và sẽ kiểm tra lại.` });
    return best;
  }

  function adaptiveReaderConcurrency(groupCount = 1, cpuHint = 0) {
    const hw=Math.max(1,Number(cpuHint||navigator.hardwareConcurrency||4));
    if(navigator.connection?.saveData)return Math.max(1,Math.min(2,groupCount));
    // Auto-max: worker dùng tối đa số luồng logic trình duyệt công bố; viewer vẫn có semaphore riêng để tránh quá tải DOM.
    return Math.max(1,Math.min(hw,Math.max(1,Number(groupCount)||1)));
  }


  async function collectAndPrepare(meta, onProgress = () => {}, options = {}) {
    const signal = options.signal || null;
    assertNotAborted(signal);

    const scanEnabled = false; // Stable 1.1: không OCR PDF scan; Primary Resolver v2 sẽ thử bản Word/PDF khác trước khi kết luận file chính là scan.
    const signingFileOnly = options.signingFileOnly === true;
    const discovered = signingFileOnly
      ? dedupeDescriptorList(getSigningFileDescriptors())
      : dedupeDescriptorList(await getStableAttachmentDescriptors(options, signal, onProgress));
    const declaredAttachmentCount = signingFileOnly ? discovered.length : getDeclaredAttachmentCount();
    let descriptors = signingFileOnly
      ? (discovered.length ? [chooseSigningDescriptor(discovered)] : [])
      : constrainDescriptorsToDeclared(discovered, declaredAttachmentCount);
    if (declaredAttachmentCount > 0 && discovered.filter(x=>x.scopeKind!=='related').length > descriptors.filter(x=>x.scopeKind!=='related').length) {
      onProgress({ phase:'dedupe', message:`Loại bản sao giao diện: ${discovered.filter(x=>x.scopeKind!=='related').length} → ${descriptors.filter(x=>x.scopeKind!=='related').length} tệp theo số lượng iOffice công bố.` });
    }
    descriptors = descriptors.map((d,i)=>({ ...d, discoveryIndex:i }));
    let attachmentCount = descriptors.filter((x) => x.scopeKind !== 'related').length;
    const expectedAttachmentCount = declaredAttachmentCount > 0 ? declaredAttachmentCount : attachmentCount;
    const relatedCount = descriptors.filter((x) => x.scopeKind === 'related').length;
    onProgress({
      phase: 'discover',
      message: descriptors.length
        ? (signingFileOnly
            ? `Đã nhận diện FILE TRÌNH KÝ: ${descriptors[0]?.name || 'không rõ tên'} · chuẩn bị đọc để kiểm tra văn bản.`
            : `Phát hiện ${attachmentCount}/${expectedAttachmentCount} tệp đính kèm${relatedCount ? ` + ${relatedCount} văn bản liên quan` : ''}.`)
        : (signingFileOnly
            ? 'Không nhận diện được FILE TRÌNH KÝ của văn bản hiện tại.'
            : 'Không thấy danh sách tệp hợp lệ; thử lấy text của viewer đang mở.'),
      total: descriptors.length,
      files: descriptors.map((x) => ({ name: x.name, scopeKind: x.scopeKind, ext: x.ext }))
    });

    const docs = [];
    const prefilled = new Map();
    const readMode = options.readerMode === 'all' ? 'all' : 'primary';
    const allDiscoveredDescriptors = [...descriptors];

    // File chính: chọn theo Số/Ký hiệu + Trích yếu. Nếu hai ứng viên quá gần nhau,
    // đọc tối đa 2 tệp để kiểm chứng bằng chính nội dung rồi mới chọn nguồn gửi AI.
    if (readMode === 'primary' && descriptors.length) {
      const attachmentPool=descriptors.filter(d=>d.scopeKind!=='related');
      const textCapablePool=attachmentPool.filter(d=>['pdf','doc','docx','xls','xlsx','rtf','txt'].includes(String(d.ext||'').toLowerCase()));
      const primaryPool=(textCapablePool.length?textCapablePool:(attachmentPool.length?attachmentPool:descriptors));
      // Primary Resolver v2: không loại cứng ứng viên chỉ vì tên có từ dễ gây nhầm.
      // Tất cả tệp đính kèm đều được xếp hạng; nội dung thực tế mới quyết định cuối cùng.
      const ranked=[...primaryPool].sort((a,b)=>descriptorPriority(b,meta)-descriptorPriority(a,meta));
      let candidates;
      let domAnchor=null;
      if(signingFileOnly){
        candidates=[chooseSigningDescriptor(ranked)];
      }else{
        const domRanked=[...ranked]
          .map(d=>({d,pref:domPrimaryPreference(d,meta)}))
          .filter(x=>x.pref>=1.15)
          .sort((a,b)=>b.pref-a.pref || descriptorPriority(b.d,meta)-descriptorPriority(a.d,meta));
        domAnchor=domRanked[0]?.d || null;
        if(domAnchor){
          const family=ranked.filter(d=>samePrimaryFamily(domAnchor,d));
          // AI chỉ cần một nguồn text tốt. Nếu có Word cùng họ với PDF chính thức DOM, đọc Word trước để nhanh;
          // PDF đỏ vẫn được giữ là officialPrimaryFile để giao Tracker.
          family.sort((a,b)=>{
            const ea=String(a.ext||'').toLowerCase(), eb=String(b.ext||'').toLowerCase();
            const da=['docx','doc'].includes(ea)?0:(a===domAnchor?1:ea==='pdf'?2:3);
            const db=['docx','doc'].includes(eb)?0:(b===domAnchor?1:eb==='pdf'?2:3);
            return da-db || domPrimaryPreference(b,meta)-domPrimaryPreference(a,meta) || descriptorPriority(b,meta)-descriptorPriority(a,meta);
          });
          const outsidePool=ranked.filter(d=>!family.includes(d));
          const outsideStrong=outsidePool.find(d=>{
            const e=primaryMetadataEvidence(d,meta);
            return e.exactNo || e.nameSubject>=0.30 || descriptorPriority(d,meta)>=descriptorPriority(domAnchor,meta)-0.35;
          }) || outsidePool[0] || null;
          // Ngoại lệ an toàn: luôn giữ đúng 1 ứng viên ngoài họ DOM. Nếu màu đỏ bị iOffice dùng cho trạng thái
          // khác hoặc người dùng đổi tên sai, Reader vẫn còn một đường thoát nhưng không đọc lan 4-5 hồ sơ.
          candidates=[...family.slice(0,2),outsideStrong].filter(Boolean);
        }else{
          candidates=buildPrimaryVerifyCandidates(ranked,meta);
        }
      }
      // Không có tín hiệu DOM: vẫn giữ fallback Word/PDF cùng họ như bản 1.3.2.
      if(!signingFileOnly && !domAnchor && candidates.length){
        const top=candidates[0];
        const family=candidates.filter(d=>samePrimaryFamily(top,d));
        const rest=candidates.filter(d=>!family.includes(d));
        family.sort((a,b)=>{
          const ea=String(a.ext||'').toLowerCase(), eb=String(b.ext||'').toLowerCase();
          const da=ea==='docx'?0:ea==='pdf'?1:2, db=eb==='docx'?0:eb==='pdf'?1:2;
          return da-db || descriptorPriority(b,meta)-descriptorPriority(a,meta);
        });
        candidates=[...family,...rest];
      }
      const configuredTimeoutMs = domAnchor
        ? Math.max(6500, Math.min(10000, Number(options.readerTimeoutMs) || 7000))
        : Math.max(9000, Math.min(18000, Number(options.readerTimeoutMs) || 9000));
      const attempts = [];
      const tried = new Set();
      onProgress({ phase:'primary-select', message: signingFileOnly
        ? `Kiểm tra văn bản: ưu tiên ${['doc','docx'].includes(candidates[0]?.ext)?'Word':'PDF'} trong FILE TRÌNH KÝ “${candidates[0]?.name || ''}”.`
        : domAnchor
          ? `iOffice có tín hiệu DOM file chính “${domAnchor.name}”${domAnchor.domPrimaryRed?' (tên đỏ)':''} · ưu tiên họ Word/PDF này, vẫn xác minh nội dung để tránh ngoại lệ chọn nhầm.`
          : `Đang xác minh file chính bằng Số/Ký hiệu + Trích yếu + nội dung (${candidates.length}/${ranked.length} ứng viên ưu tiên).`,
        files:ranked.map(x=>({name:x.name,score:Number(descriptorPriority(x,meta).toFixed(3)),scopeKind:x.scopeKind})) });

      const readPrimaryCandidates = async (items,label='ứng viên file chính') => {
        const list=(items||[]).filter(Boolean).filter(d=>!tried.has(descriptorIdentityKey(d)));
        if(!list.length)return;
        // Primary file resolver chạy tuần tự theo thứ tự tin cậy. iOffice viewer dùng trạng thái trang chung;
        // mở nhiều viewer chính song song dễ làm token/frame va nhau, chậm hơn và sinh timeout giả.
        for(let i=0;i<list.length;i++){
          const desc=list[i];
          tried.add(descriptorIdentityKey(desc));
          assertNotAborted(signal);
          onProgress({ phase:'read', message:`Đọc ${signingFileOnly?'FILE TRÌNH KÝ':label} ${i+1}/${list.length} · ${desc.name}`, index:i+1,total:list.length,name:desc.name,worker:1 });
          const startedAt = performance.now();
          let item = await readDescriptorTimed(desc, { maxChars:32000, maxPages:50, tryIofficeOcr:false, captureScanBinary:false, fileName:desc.name, allowCurrentViewerFallback:(attempts.length===0 && i===0 && tried.size===1 && (!domAnchor || desc===domAnchor)), appTimeoutMs:Math.max(4200,configuredTimeoutMs-900) }, signal, configuredTimeoutMs);
          let ok = (item.text?.length || 0) >= MIN_TEXT_CHARS;

          // Cold-viewer retry: lần mở Word/PDF đầu tiên của iOffice đôi khi chỉ kịp dựng viewer rồi hết timeout.
          // Trước đây bấm “Đọc tất cả” lần hai mới thành công vì viewer đã ấm. Tự retry ngắn ngay trong lượt hiện tại.
          if(!ok && ['timeout','viewer-no-text','viewer-not-ready','reader-error','no-file-source','scan-no-text','pdf-read-unverified'].includes(String(item.status||'')) && ['pdf','doc','docx'].includes(String(desc.ext||'').toLowerCase())){
            onProgress({phase:'reader-warm-retry',message:`Tệp chưa sẵn sàng · tự thử lại ngay ${desc.name}`,name:desc.name});
            await sleepAbortable(320,signal);
            const retryTimeout=domAnchor ? Math.max(3500,Math.min(5200,configuredTimeoutMs-1200)) : Math.max(5000,Math.min(8000,configuredTimeoutMs));
            const refreshed=getAttachmentDescriptors().find(d=>fold(d.name||'')===fold(desc.name||'') && d.scopeKind===desc.scopeKind) || desc;
            const retry=await readDescriptorTimed(refreshed,{maxChars:32000,maxPages:50,tryIofficeOcr:false,captureScanBinary:false,fileName:refreshed.name,allowCurrentViewerFallback:true,forceFresh:true,appTimeoutMs:Math.max(4200,retryTimeout-900)},signal,retryTimeout);
            if((retry.text?.length||0)>=(item.text?.length||0) || (retry.text?.length||0)>=MIN_TEXT_CHARS)item=retry;
            ok=(item.text?.length||0)>=MIN_TEXT_CHARS;
          }

          const tookMs = Math.round(performance.now()-startedAt);
          if (ok) {
            const verifiedScore=primaryContentScore(desc,item,meta);
            const identity=administrativeIdentityEvidence(desc,item,meta);
            const metaEvidence=primaryMetadataEvidence(desc,meta);
            const familyPeer=candidates.some(d=>d!==desc && samePrimaryFamily(desc,d));
            const domPref=domPrimaryPreference(desc,meta);
            const domFamilyPeer=domAnchor && samePrimaryFamily(desc,domAnchor);
            // NĐ 30: số/ký hiệu là một thành phần nhận diện, nhưng bản Word trước ký có thể chưa có số.
            // Khi trang đầu khớp mạnh tên loại/trích yếu, hoặc Word/PDF thuộc cùng họ văn bản, vẫn chấp nhận nguồn text.
            const accepted=signingFileOnly || ranked.length===1 || identity.accepted
              || (domFamilyPeer && domPrimaryPreference(domAnchor,meta)>=1.15 && identity.subjectCoverage>=0.10)
              || (familyPeer && identity.subjectCoverage>=0.14)
              || (metaEvidence.strong && identity.subjectCoverage>=0.10);
            const contentComplete = item.truncated !== true && (!Number(item.totalPages||0) || Number(item.pagesRead||0) >= Number(item.totalPages||0));
            const strongAccepted=accepted && contentComplete && (identity.strong || (familyPeer && identity.subjectCoverage>=0.34));
            const wordsNow=wordCount(item.text||'');
            const selectionQuality=(identity.exactSymbol?5:0)+(identity.numberHit?3:0)+(identity.subjectCoverage*7)+(identity.nameCoverage*1.8)+(identity.senderCoverage*1.1)+(contentComplete?0.8:0)+Math.min(0.8,Math.log10(Math.max(10,wordsNow))/4)+(metaEvidence.exactNo?0.6:0)+(familyPeer?0.45:0)+(desc?.isMain===true?0.25:0)+Math.min(0.8,domPref*0.22);
            attempts.push({desc,item,score:accepted?verifiedScore:verifiedScore-3.5,selectionQuality,verified:true,accepted,strongAccepted,exact:identity.exactSymbol,subjectEvidence:identity.subjectCoverage,nameEvidence:identity.nameCoverage,metaEvidence,contentComplete,identity});
            onProgress({ phase:'file-result', message:`${accepted?'✓':'⚠'} Đã đọc ${item.name} · ${wordCount(item.text||'').toLocaleString('vi-VN')} từ${identity.exactSymbol||identity.numberHit||metaEvidence.exactNo?' · khớp Số/Ký hiệu':accepted?' · khớp nội dung/trích yếu':' · chưa khớp văn bản hiện tại'} · ${(tookMs/1000).toFixed(1)}s`, name:item.name, chars:item.text.length,status:item.status,source:item.source,tookMs,score:verifiedScore });
            if(strongAccepted) break;
          } else {
            const why = item.status === 'timeout' ? `quá thời gian ${Math.round(configuredTimeoutMs/1000)}s` : item.status === 'pdf-scan-skipped' ? 'PDF scan đã xác nhận: PDF.js đã kiểm tra trang nhưng không có lớp chữ' : item.status === 'pdf-read-unverified' ? 'PDF chưa sẵn sàng/không đọc được PDF.js; chưa kết luận là scan' : item.error || item.status || 'không có text';
            attempts.push({desc,item,score:-999,verified:false,accepted:false,strongAccepted:false});
            onProgress({ phase:item.status==='timeout'?'timeout':'file-result', message:`⚠ AI chưa đọc được tệp ${item.name} · ${why}`, name:item.name,chars:0,status:item.status,tookMs });
          }
        }
      };

      await readPrimaryCandidates(candidates);

      // Fallback mạnh: nếu vòng đầu chưa có tệp text đủ tin cậy (đặc biệt ứng viên đầu là PDF scan),
      // tiếp tục thử các tệp đính kèm còn lại theo thứ tự điểm, tối đa 6 tệp tổng cộng.
      attempts.sort((a,b)=>b.score-a.score);
      let firstBest=attempts.find(a=>a.verified && a.score>-900) || null;
      const needFallback=!attempts.some(a=>a.accepted===true && (a.item?.text?.length||0)>=MIN_TEXT_CHARS);
      if(!signingFileOnly && needFallback){
        const fallbackLimit=domAnchor?1:Math.max(0,5-tried.size);
        const remaining=ranked.filter(d=>!tried.has(descriptorIdentityKey(d))).slice(0,fallbackLimit);
        if(remaining.length){
          onProgress({phase:'primary-fallback',message:`Chưa xác minh chắc file chính${firstBest?'':' hoặc ứng viên đầu không đọc được'} · thử thêm ${remaining.length} tệp để tránh chọn nhầm.`});
          await readPrimaryCandidates(remaining,'ứng viên dự phòng');
        }
      }

      // Self-heal ngay trong chế độ file chính: nếu vẫn chưa có ứng viên được chấp nhận, quét lại DOM một lần
      // để bắt Word/PDF vừa render muộn. Trước đây người dùng phải bấm "Đọc tất cả" mới vô tình kích hoạt bước này.
      let acceptedNow = attempts.some(a=>a.accepted===true && (a.item?.text?.length||0)>=MIN_TEXT_CHARS);
      if(!signingFileOnly && !acceptedNow){
        await sleepAbortable(220, signal);
        const latePrimary=dedupeDescriptorList(getAttachmentDescriptors()).filter(d=>d.scopeKind!=='related' && ['pdf','doc','docx','xls','xlsx','rtf','txt'].includes(String(d.ext||'').toLowerCase()));
        const lateRanked=[...latePrimary].sort((a,b)=>descriptorPriority(b,meta)-descriptorPriority(a,meta));
        const lateRemaining=lateRanked.filter(d=>!tried.has(descriptorIdentityKey(d))).slice(0,domAnchor?1:4);
        if(lateRemaining.length){
          onProgress({phase:'primary-late-fallback',message:`Phát hiện thêm ${lateRemaining.length} ứng viên file chính tải muộn · tự đọc tiếp, không cần bấm Đọc tất cả.`});
          await readPrimaryCandidates(lateRemaining,'ứng viên tải muộn');
        }
      }

      attempts.sort((a,b)=>b.score-a.score);
      const bestAttempt = attempts[0] || null;
      const bestAccepted = attempts.filter(a=>a.accepted===true && (a.item?.text?.length||0)>=MIN_TEXT_CHARS)
        .sort((a,b)=>(Number(b.selectionQuality||0)-Number(a.selectionQuality||0)) || (b.score-a.score) || ((b.item?.text?.length||0)-(a.item?.text?.length||0)))[0] || null;
      const selected = bestAccepted?.item || null;
      const selectedDesc = bestAccepted?.desc || bestAttempt?.desc || candidates[0] || null;
      let chosen = selected;
      if (!chosen && bestAttempt?.item) {
        // Không gửi text của một tệp đọc được nhưng không chứng minh là văn bản hiện tại.
        // Nếu tất cả ứng viên là scan/unreadable, giữ trạng thái đó để phía trên báo lỗi đúng thay vì chọn nhầm file khác.
        chosen = bestAttempt.item.status === 'pdf-scan-skipped'
          ? bestAttempt.item
          : { ...bestAttempt.item, text:'', chars:0, words:0, status:'primary-unverified', error:'Đã đọc tệp nhưng không khớp đủ Số/Ký hiệu/Trích yếu của văn bản hiện tại.' };
      }
      const docs = [];
      if (chosen) docs.push(chosen);

      // v0.68: chỉ tự đọc Phụ lục/Danh sách/Biểu khi chính văn vừa có dẫn chiếu phù hợp
      // vừa có dấu hiệu nhiệm vụ + thời hạn. Nhắc “chi tiết tại Phụ lục” chung chung không còn chặn AI.
      const appendixReferenced = !signingFileOnly && !!selected && referencesRequiredAppendix(selected.text || '', options.readerPolicy);
      const likelyTaskDeadline = !signingFileOnly && !!selected && hasLikelyTaskDeadlineCue(selected.text || '', options.readerPolicy);
      const readTaskAppendices = options.readTaskAppendices === true || (options.readTaskAppendices !== false && appendixReferenced && likelyTaskDeadline);
      const appendixRequired = !!readTaskAppendices;
      let appendixRequiredMissing = false;
      if (appendixRequired) {
        const maxAdditional=Math.max(1,Math.min(8,Number(options.maxAdditionalTaskFiles)||6));
        let appendixDescs = allDiscoveredDescriptors
          .filter(d => d !== selectedDesc && d.scopeKind !== 'related' && isLikelyRequiredAppendix(d, options.readerPolicy))
          .sort((a,b)=>descriptorPriority(b,meta)-descriptorPriority(a,meta))
          .slice(0,maxAdditional);
        // Nếu tên tệp không ghi rõ “Phụ lục/Danh sách/Biểu”, lấy một số tệp đính kèm có điểm liên quan cao nhất
        // thay vì đọc toàn bộ hàng chục tệp.
        if (!appendixDescs.length && (appendixReferenced || options.readTaskAppendices === true)) {
          appendixDescs = allDiscoveredDescriptors
            .filter(d => d !== selectedDesc && d.scopeKind !== 'related')
            .sort((a,b)=>descriptorPriority(b,meta)-descriptorPriority(a,meta))
            .slice(0,Math.min(options.readTaskAppendices === true ? maxAdditional : 4,maxAdditional));
        }
        if (!appendixDescs.length) {
          appendixRequiredMissing = true;
          onProgress({phase:'appendix-required',message:'⚠ Chính văn có dấu hiệu nhiệm vụ/hạn gắn với Phụ lục nhưng chưa nhận diện được tệp phù hợp; vẫn gửi file chính đã đọc được cho AI.'});
        } else {
          onProgress({phase:'appendix-required',message:`Phát hiện khả năng nhiệm vụ/hạn phụ thuộc tệp kèm · đọc thêm ${appendixDescs.length} tệp liên quan để xác minh.`});
          const appendixWorkers=Math.max(1,Math.min(appendixDescs.length,adaptiveReaderConcurrency(appendixDescs.length,options.readerCpuLogical)));
          const appendixResults=await runBounded(appendixDescs,appendixWorkers,async(desc,_i,workerId)=>{
            assertNotAborted(signal);
            onProgress({phase:'read',message:`Đọc tệp bổ sung · ${desc.name}`,name:desc.name,worker:workerId});
            return await readDescriptorTimed(desc,{maxChars:18000,maxPages:36,tryIofficeOcr:scanEnabled,captureScanBinary:false,fileName:desc.name,appTimeoutMs:configuredTimeoutMs},signal,configuredTimeoutMs);
          });
          for(const item of appendixResults.flat().filter(Boolean)){
            if ((item.text?.length||0)>=MIN_TEXT_CHARS) docs.push(item);
            else appendixRequiredMissing = true;
          }
        }
      }

      const expectedForBundle = docs.length || (chosen ? 1 : 0);
      const bundle = prepareBundle(meta, docs, expectedForBundle, { ...options, readerMode:'primary' });
      const chosenNames = new Set(docs.map(x=>fold(x.name||'')));
      bundle.otherFiles = allDiscoveredDescriptors.filter(d => !chosenNames.has(fold(d.name||''))).map(d => ({ name:d.name, ext:d.ext, scopeKind:d.scopeKind, priority:Number(descriptorPriority(d,meta).toFixed(3)), status:'not-read-primary-mode' }));
      bundle.stats.filesDiscovered = allDiscoveredDescriptors.filter(x=>x.scopeKind!=='related').length;
      bundle.stats.relatedFilesDiscovered = allDiscoveredDescriptors.filter(x=>x.scopeKind==='related').length;
      bundle.stats.timeoutSkippedCount = attempts.filter(x=>x.item?.status==='timeout').length;
      bundle.sourceSection = signingFileOnly ? 'FILE_TRINH_KY' : 'ATTACHMENTS';
      bundle.signingFileName = signingFileOnly ? (chosen?.name || candidates[0]?.name || '') : '';
      bundle.readMode = 'primary';
      bundle.appendixReferenced = appendixReferenced;
      bundle.likelyTaskDeadline = likelyTaskDeadline;
      bundle.appendixRequired = appendixRequired;
      bundle.appendixRequiredMissing = appendixRequiredMissing;
      bundle.additionalReadSuggested = !signingFileOnly && !!selected && likelyTaskDeadline && bundle.otherFiles.length > 0;
      if (selected) {
        bundle.aiReady = true; // luôn cho phép gửi file chính đã đọc được
        bundle.requiresReviewForUnreadable = !!appendixRequiredMissing;
        bundle.aiBlockedReason = appendixRequiredMissing
          ? 'Chưa đọc đủ tệp phụ cần để xác minh nhiệm vụ/hạn; AI vẫn nhận file chính và phải đánh dấu cần kiểm tra.'
          : '';
      }
      onProgress({ phase:'bundle', message: signingFileOnly
        ? (selected
            ? `✓ Đã đọc ${['doc','docx'].includes(selected.ext)?'Word':'PDF'} FILE TRÌNH KÝ “${selected.name}” · ${Number(bundle.stats.aiTextWords||0).toLocaleString('vi-VN')} từ để kiểm tra văn bản.`
            : `⚠ Đã nhận diện FILE TRÌNH KÝ “${candidates[0]?.name || ''}” nhưng chưa lấy được nội dung trong ${Math.round(configuredTimeoutMs/1000)} giây.`)
        : (selected
            ? `${appendixRequired ? (appendixRequiredMissing?'⚠':'✓')+' Đã đọc tệp bổ sung theo dấu hiệu nhiệm vụ/hạn · ' : ''}File chính: ${selected.name} · ${Number(bundle.stats.aiTextWords||0).toLocaleString('vi-VN')} từ gửi AI.`
            : `⚠ AI chưa đọc được tệp chính sau khi đã tự thử PDF/Word cùng văn bản; chưa gửi AI để tránh phân tích sai.`), stats:bundle.stats, primaryDocument:bundle.primaryDocument?.name||'' });
      return {
        descriptors: allDiscoveredDescriptors.map(({ viewerToken, candidateUrls, actionArgs, ...safe }) => safe),
        docs: docs.map(({ viewerToken, candidateUrls, actionArgs, scanBytes, originalBytes, ...safe }) => safe),
        bundle,
        combinedText: bundle.combinedText,
        stats: bundle.stats
      };
    }

    if (!descriptors.length) {
      onProgress({phase:'viewer',message:'Không có tệp thuộc văn bản hiện tại; cần kiểm tra kết quả theo trích yếu.'});
    } else {
      const groups = buildReadGroups(descriptors, meta);
      const requestedConcurrency = Number(options.readerConcurrency);
      const autoConcurrency = adaptiveReaderConcurrency(groups.length || 1,options.readerCpuLogical);
      const concurrency = requestedConcurrency > 0
        ? Math.max(1, Math.min(64, requestedConcurrency, groups.length || 1))
        : autoConcurrency;
      onProgress({
        phase: 'parallel',
        message: `${requestedConcurrency > 0 ? 'Đọc song song' : 'Tự tối ưu theo máy'}: tối đa ${concurrency} luồng · ${groups.length} nhóm tài liệu${requestedConcurrency > 0 ? '' : ` · CPU ${options.readerCpuLogical || navigator.hardwareConcurrency || '?'} luồng logic · dùng ${concurrency} worker${navigator.deviceMemory ? ` · RAM ~${navigator.deviceMemory} GB` : ''}`}.`,
        total: descriptors.length,
        concurrency
      });

      let startedCount = 0;
      let finishedCount = 0;

      const groupResults = await runBounded(groups, concurrency, async (group, groupIndex, workerId) => {
        assertNotAborted(signal);
        const out = [];
        const items = [...group.items];
        const wordDesc = items.find((x) => ['doc', 'docx'].includes(x.ext));
        const pdfPeers = wordDesc ? items.filter((x) => x.ext === 'pdf' && x.canonicalStem === wordDesc.canonicalStem) : [];

        const readOne = async (desc, forceDeep = false) => {
          assertNotAborted(signal);
          const already = prefilled.get(desc.name);
          if (already) {
            finishedCount += 1;
            return { ...already };
          }

          const ordinal = ++startedCount;
          const priority = descriptorPriority(desc, meta);
          const supporting = looksSupporting(desc.name) || desc.scopeKind === 'related';
          const deep = forceDeep || (!supporting && priority >= 0.12) || groupIndex < 2;
          const readOptions = deep
            ? { maxChars: 24000, maxPages: 24 }
            : { partial: true, maxChars: 5000, maxPages: 4 };
          const configuredTimeoutMs = Math.max(2000, Math.min(45000, Number(options.readerTimeoutMs)||5000));
          const timeoutMs = ['doc','docx'].includes(desc.ext) ? Math.min(configuredTimeoutMs, 18000) : configuredTimeoutMs;
          const startedAt = performance.now();

          onProgress({
            phase: 'read',
            message: `Luồng ${workerId}: đọc ${ordinal}/${descriptors.length} · ${desc.name}`,
            index: ordinal,
            total: descriptors.length,
            name: desc.name,
            worker: workerId
          });

          const selectiveOcr=scanEnabled && (desc.isMain===true || !supporting || isLikelyRequiredAppendix(desc,options.readerPolicy));
          let item = await readDescriptorTimed(desc, { ...readOptions, tryIofficeOcr:selectiveOcr, captureScanBinary:false, fileName: desc.name }, signal, timeoutMs);
          // Tệp iOffice có thể chỉ lộ request/viewer sau nhịp AJAX đầu tiên. Với lỗi tạm thời,
          // chờ ngắn và đọc lại ngay trong cùng lần Phân tích thay vì bắt người dùng bấm lần hai.
          const transient = (item.text?.length || 0) < MIN_TEXT_CHARS && !['scan-ready-for-ai','scan-too-large','legacy-binary-unparsed','pdf-scan-skipped','file-too-large-skipped'].includes(item.status || '');
          if (transient && configuredTimeoutMs > 6000) {
            onProgress({ phase:'retry', message:`Chưa đủ dữ liệu · thử lại ${desc.name} trong cùng phiên`, name:desc.name, worker:workerId });
            await sleepAbortable(450, signal);
            const refreshed = getAttachmentDescriptors().find((d) => fold(d.name) === fold(desc.name) && d.scopeKind === desc.scopeKind) || desc;
            const retry = await readDescriptorTimed(refreshed, { ...readOptions, partial:false, maxChars:Math.max(12000, readOptions.maxChars || 0), maxPages:Math.max(12, readOptions.maxPages || 0), tryIofficeOcr:selectiveOcr, captureScanBinary:false, fileName: refreshed.name }, signal, Math.min(30000, Math.max(timeoutMs, Math.round(timeoutMs * 1.1))));
            const score = (x) => ((x.text?.length || 0) >= MIN_TEXT_CHARS ? 1000000 : 0) + (x.scanSizeBytes || 0) + (x.text?.length || 0);
            if (score(retry) > score(item)) item = retry;
          }
          const tookMs = Math.round(performance.now() - startedAt);
          finishedCount += 1;
          const ok = (item.text?.length || 0) >= MIN_TEXT_CHARS;
          const scanReady = item.status === 'scan-ready-for-ai' && Number(item.scanSizeBytes || 0) > 0;
          const scanSkipped = item.status === 'pdf-scan-skipped';
          const sizeLimitSkipped = item.status === 'file-too-large-skipped';
          const label = ok
            ? 'Đã đọc'
            : sizeLimitSkipped
              ? 'Tệp quá dung lượng · tạm bỏ qua'
            : scanSkipped
              ? 'PDF scan · tạm bỏ qua'
              : scanReady
                ? 'PDF scan · trạng thái cũ'
              : item.status === 'scan-too-large'
                ? 'PDF scan quá lớn để đính kèm tự động'
                : item.status === 'timeout'
                  ? 'Hết thời gian'
                  : 'Chưa lấy được text';
          const detail = sizeLimitSkipped
            ? `Vượt giới hạn ${Math.max(1,Math.min(50,Number(options.readerMaxFileSizeMb||10)))} MB · tạm bỏ qua`
            : scanSkipped
            ? 'không OCR · không gửi file'
            : scanReady
              ? `${(Number(item.scanSizeBytes || 0) / 1024 / 1024).toFixed(1)} MB`
              : `${wordCount(item.text || '').toLocaleString('vi-VN')} từ · ${Number(item.text?.length || 0).toLocaleString('vi-VN')} ký tự`;
          onProgress({
            phase: sizeLimitSkipped ? 'size-limit-skipped' : (scanSkipped ? 'scan-skipped' : (scanReady ? 'scan-ready' : 'file-result')),
            message: `${label}: ${item.name} · ${detail} · ${(tookMs / 1000).toFixed(1)}s`,
            name: item.name,
            chars: item.text?.length || 0,
            source: item.source || '',
            status: item.status || '',
            scanSizeBytes: item.scanSizeBytes || 0,
            worker: workerId,
            tookMs,
            finished: finishedCount
          });
          return item;
        };

        // Cặp Word + PDF cùng stem: đọc Word trước trong nhóm. Các nhóm khác vẫn chạy song song.
        if (wordDesc && pdfPeers.length) {
          const word = await readOne(wordDesc, true);
          out.push(word);

          for (const pdfDesc of pdfPeers) out.push(await readOne(pdfDesc, true));

          for (const desc of items) {
            if (desc === wordDesc || pdfPeers.includes(desc)) continue;
            out.push(await readOne(desc, false));
          }
          return out;
        }

        // Nhóm thường: đọc tuần tự bên trong một worker để không tạo quá nhiều iframe,
        // trong khi các nhóm khác vẫn chạy song song ở worker khác.
        for (const desc of items) out.push(await readOne(desc, false));
        return out;
      });

      for (const groupDocs of groupResults) docs.push(...(groupDocs || []));

      // Readiness barrier lần cuối: iOffice đôi khi render thêm attachment sau khi các viewer đầu đã mở.
      await sleepAbortable(260, signal);
      const freshDescriptors = signingFileOnly
        ? dedupeDescriptorList(getSigningFileDescriptors())
        : dedupeDescriptorList(getAttachmentDescriptors()).filter(d => options.readerIncludeRelated !== false || d.scopeKind !== 'related');
      const known = new Set(descriptors.map(descriptorIdentityKey));
      const late = freshDescriptors.filter(d => !known.has(descriptorIdentityKey(d)));
      if (late.length) {
        const merged = constrainDescriptorsToDeclared([...descriptors, ...late], getDeclaredAttachmentCount());
        const accepted = new Set(merged.map(descriptorIdentityKey));
        const lateAccepted = late.filter(d => accepted.has(descriptorIdentityKey(d)));
        descriptors = merged;
        attachmentCount = descriptors.filter(x => x.scopeKind !== 'related').length;
        if (lateAccepted.length) {
          onProgress({ phase:'late-files', message:`Phát hiện thêm ${lateAccepted.length} tệp tải muộn · đọc ngay trong phiên hiện tại.`, total:lateAccepted.length });
          const lateResults = await runBounded(lateAccepted, Math.min(2, lateAccepted.length), async (desc, index) => {
            const baseTimeoutMs = Math.max(2000, Math.min(45000, Number(options.readerTimeoutMs)||5000));
            const timeoutMs = baseTimeoutMs;
            onProgress({phase:'read', message:`Đọc tệp tải muộn ${index+1}/${lateAccepted.length} · ${desc.name}`, name:desc.name});
            return readDescriptorTimed(desc, { partial:false, maxChars:24000, maxPages:24, tryIofficeOcr:scanEnabled, captureScanBinary:false, fileName:desc.name }, signal, timeoutMs);
          });
          docs.push(...lateResults);
        }
      }
    }

    assertNotAborted(signal);
    const repairedDocs = await repairViewerCollisions(docs, descriptors, signal, onProgress);
    docs.length = 0; docs.push(...repairedDocs);
    const declaredFinal = signingFileOnly ? descriptors.length : getDeclaredAttachmentCount();
    const finalExpectedAttachmentCount = declaredFinal > 0 ? declaredFinal : descriptors.filter(x => x.scopeKind !== 'related').length;
    const bundle = prepareBundle(meta, docs, finalExpectedAttachmentCount, { ...options, readerMode:'all' });
    bundle.stats.filesDiscovered = descriptors.filter(x=>x.scopeKind!=='related').length;
    bundle.stats.relatedFilesDiscovered = descriptors.filter(x=>x.scopeKind==='related').length;
    bundle.sourceSection = signingFileOnly ? 'FILE_TRINH_KY' : 'ATTACHMENTS';
    bundle.signingFileName = signingFileOnly ? (descriptors[0]?.name || '') : '';
    bundle.readMode = signingFileOnly ? 'primary' : 'all';
    onProgress({
      phase: 'bundle',
      message: signingFileOnly
        ? `Kiểm tra văn bản: ${bundle.stats.filesReadyForAi ? 'đã đọc' : 'chưa đọc được'} FILE TRÌNH KÝ “${bundle.signingFileName || descriptors[0]?.name || ''}” · ${Number(bundle.stats.extractedWords || 0).toLocaleString('vi-VN')} từ.`
        : `Hoàn tất: ${bundle.stats.filesReadyForAi}/${bundle.stats.filesDetected} tệp đã đọc${bundle.stats.scanSkippedCount ? ` · bỏ qua ${bundle.stats.scanSkippedCount} PDF scan` : ''}${bundle.stats.oversizedSkippedCount ? ` · bỏ qua ${bundle.stats.oversizedSkippedCount} tệp quá dung lượng` : ''}${bundle.stats.duplicatesSkipped ? ` · gộp ${bundle.stats.duplicatesSkipped} tệp trùng` : ''} · lấy ${Number(bundle.stats.extractedWords || 0).toLocaleString('vi-VN')} từ · dự kiến gửi ${Number(bundle.stats.aiTextWords || 0).toLocaleString('vi-VN')} từ.`,
      stats: bundle.stats,
      primaryDocument: bundle.primaryDocument?.name || ''
    });
    return {
      descriptors: descriptors.map(({ viewerToken, candidateUrls, actionArgs, ...safe }) => safe),
      docs: docs.map(({ viewerToken, candidateUrls, actionArgs, scanBytes, originalBytes, ...safe }) => safe),
      bundle,
      combinedText: bundle.combinedText,
      stats: bundle.stats
    };
  }

  async function getOfficialPrimaryAttachment(meta = {}, analysisPrimaryName = '', options = {}) {
    const maxMb = Math.max(1, Math.min(30, Number(options.maxMb || 20)));
    const signal = options.signal || null;
    assertNotAborted(signal);
    const declared = getDeclaredAttachmentCount();
    const descriptors = constrainDescriptorsToDeclared(
      dedupeDescriptorList(getAttachmentDescriptors()).filter(d => d.scopeKind !== 'related'),
      declared
    ).map((d,i)=>({...d,discoveryIndex:i}));
    const chosen = pickOfficialPrimaryPdf(descriptors, meta, analysisPrimaryName);
    if (!chosen) {
      return {ok:false, reason:'no-trusted-primary-pdf', message:'Không xác định chắc chắn PDF chính thức của văn bản hiện tại.'};
    }

    // Tái sử dụng bytes đã bắt khi AI đọc/xác minh PDF nếu có. Chỉ nhận PDF GỐC,
    // không nhận PDF mà iOffice chuyển đổi tạm từ DOC/DOCX.
    let file = capturedFileForDescriptor(chosen, {allowConvertedPdf:false, recentMs:300000});
    if (!file?.bytes?.length) {
      file = await fetchOriginalFile(chosen, {readerMaxFileSizeMb:maxMb, signal});
    }
    if (file?.tooLarge) {
      return {ok:false, reason:'too-large', name:chosen.name, sizeBytes:Number(file.sizeBytes||0), maxMb, message:`PDF chính vượt ${maxMb} MB nên chưa tự đính kèm.`};
    }
    const bytes = file?.bytes;
    if (!bytes?.length || signatureKind(bytes) !== 'pdf') {
      return {ok:false, reason:'unreadable-official-pdf', name:chosen.name, message:'Đã xác định PDF chính nhưng chưa lấy được dữ liệu PDF gốc để giao kèm.'};
    }
    if (bytes.byteLength > maxMb * 1024 * 1024) {
      return {ok:false, reason:'too-large', name:chosen.name, sizeBytes:bytes.byteLength, maxMb, message:`PDF chính vượt ${maxMb} MB nên chưa tự đính kèm.`};
    }
    return {
      ok:true,
      name:chosen.name || 'van-ban-chinh.pdf',
      mimeType:'application/pdf',
      size:Number(bytes.byteLength || 0),
      base64:bytesToBase64(bytes),
      source:file.source || 'ioffice-original-pdf',
      officialScore:Number((chosen.officialScore || 0).toFixed(3)),
      matchedTo:analysisPrimaryName || '',
      reusedCaptured:Boolean(file?.source && /captured/i.test(file.source))
    };
  }

  globalThis.IOfficeDocumentReader = {
    version: VERSION,
    getAttachmentDescriptors,
    getSigningFileDescriptors,
    getAttachmentNames,
    getDeclaredAttachmentCount,
    collectAndPrepare,
    getOfficialPrimaryAttachment,
    pickOfficialPrimaryPdf,
    officialAttachmentScore,
    fileNameSimilarity,
    textSimilarity,
    samePrimaryFamily,
    administrativeIdentityEvidence,
    adaptiveReaderConcurrency,
    adaptiveHiddenViewerConcurrency
  };
})();
