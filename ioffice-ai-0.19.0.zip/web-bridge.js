(() => {
  'use strict';
  if (globalThis.__iofficeBridge090) return;
  globalThis.__iofficeBridge090 = true;
  const core = globalThis.IOfficeCore;
  const platform = location.hostname === 'gemini.google.com' ? 'gemini' : 'chatgpt';
  const RESPONSE = 'model-response,[data-message-author-role="model"],[data-author="assistant"],.model-response-text';
  let active = null;
  const visible = el => !!el && el.getClientRects().length > 0 && getComputedStyle(el).visibility !== 'hidden';
  const pick = selectors => selectors.flatMap(s => [...document.querySelectorAll(s)]).find(visible);
  const message = m => chrome.runtime.sendMessage(m);
  const cancelled = () => new DOMException('Đã dừng phân tích.', 'AbortError');
  const assert = signal => { if(signal?.aborted) throw cancelled(); };
  function waitFor(check, timeout, signal, error) {
    assert(signal);
    return new Promise((resolve,reject) => {
      let observer, interval, deadline, done=false;
      const finish=(err,value)=>{if(done)return;done=true;observer?.disconnect();clearInterval(interval);clearTimeout(deadline);signal?.removeEventListener('abort',abort);err?reject(err):resolve(value);};
      const abort=()=>finish(cancelled());
      const scan=()=>{try{assert(signal);const v=check();if(v)finish(null,v);}catch(e){finish(e);}};
      observer=new MutationObserver(scan);
      observer.observe(document.body || document.documentElement,{subtree:true,childList:true,characterData:true,attributes:true,attributeFilter:['disabled','aria-disabled','aria-busy']});
      interval=setInterval(scan,1000);
      deadline=setTimeout(()=>finish(new Error(error)),timeout);
      signal?.addEventListener('abort',abort,{once:true});
      scan();
    });
  }
  function composer() {
    return platform==='gemini' ? pick(['rich-textarea [contenteditable="true"]','.ql-editor[contenteditable="true"]','div[contenteditable="true"][aria-label*="prompt" i]','div[contenteditable="true"][aria-label*="message" i]','[contenteditable="true"][role="textbox"]','textarea']) : pick(['#prompt-textarea','textarea[data-testid="prompt-textarea"]','main [contenteditable="true"]']);
  }
  const composerText = el => String(el?.value ?? el?.innerText ?? el?.textContent ?? '').trim();
  const stopButton = () => pick(['button[aria-label*="Stop" i]','button[aria-label*="Dừng" i]','button[data-test-id*="stop" i]']);
  function sendButton() {
    const c=composer();
    const local=c?.closest('form,input-container,.input-area-container,.input-area,.input-container') || c?.parentElement?.parentElement;
    const selectors=['button[data-testid="send-button"]','button[aria-label*="Send message" i]','button[aria-label*="Send" i]','button[aria-label*="Gửi" i]','button.send-button','button[type="submit"]'];
    if(local){for(const sel of selectors){const el=[...local.querySelectorAll(sel)].find(visible);if(el)return el;}}
    return pick(selectors);
  }
  const enabled = el => el && !el.disabled && el.getAttribute('aria-disabled') !== 'true';
  async function setText(el,text) {
    if(!el)throw new Error('Không tìm thấy ô nhập AI.');
    el.focus();
    if(el instanceof HTMLTextAreaElement || el instanceof HTMLInputElement) {
      const proto=el instanceof HTMLTextAreaElement?HTMLTextAreaElement.prototype:HTMLInputElement.prototype;
      const setter=Object.getOwnPropertyDescriptor(proto,'value')?.set;
      if(setter)setter.call(el,text);else el.value=text;
      el.dispatchEvent(new Event('input',{bubbles:true}));
      el.dispatchEvent(new Event('change',{bubbles:true}));
    } else {
      const selection=window.getSelection(),range=document.createRange();
      range.selectNodeContents(el);selection.removeAllRanges();selection.addRange(range);
      let inserted=false;
      try{inserted=document.execCommand('insertText',false,text);}catch(_){}
      if(!inserted)el.textContent=text;
      el.dispatchEvent(new InputEvent('input',{bubbles:true,inputType:'insertText',data:text}));
      el.dispatchEvent(new Event('change',{bubbles:true}));
    }
    await new Promise(r=>setTimeout(r,35));
    if(!composerText(el)){
      // Fallback cho một số bản Gemini thay editor sau khi focus.
      const current=composer();
      if(current && current!==el){
        current.focus();current.textContent=text;
        current.dispatchEvent(new InputEvent('input',{bubbles:true,inputType:'insertText',data:text}));
        await new Promise(r=>setTimeout(r,35));
        el=current;
      }
    }
    if(!composerText(el)) throw new Error('Không dán được văn bản vào Gemini. Hãy mở tab Gemini kiểm tra ô nhập.');
    return el;
  }
  const progress=(job,phase,phaseMessage)=>message({type:'WEB_AUTOMATION_PROGRESS',jobId:job.jobId,phase,phaseMessage}).catch(()=>{});
  async function newChat(signal) {
    const oldUrl=location.href, oldComposer=composer();
    const button=pick(['[data-test-id*="new-chat" i]','button[aria-label*="New chat" i]','a[aria-label*="New chat" i]','button[aria-label*="Cuộc trò chuyện mới" i]','a[aria-label*="Cuộc trò chuyện mới" i]']) || [...document.querySelectorAll('button,a,[role="button"]')].find(el=>visible(el)&&/^(New chat|New conversation|Cuộc trò chuyện mới|Trò chuyện mới)$/i.test((el.innerText||el.getAttribute('aria-label')||'').trim()));
    // Gemini đổi giao diện khá thường xuyên. Không để việc xoay chat làm hỏng cả phiên:
    // nếu không tìm thấy nút nhưng ô nhập hiện tại đang sạch thì tiếp tục dùng tab ấm.
    if(!button) {
      const current=composer();
      if(current && !composerText(current)) return false;
      throw new Error('Gemini đang có bản nháp hoặc chưa sẵn sàng. Hãy kiểm tra tab Gemini.');
    }
    assert(signal);button.click();
    const started=performance.now();
    let lastUrl=location.href, stableSince=started;
    try {
      await waitFor(()=>{
        const current=composer();
        if(!current || composerText(current))return false;
        const now=performance.now();
        if(location.href!==lastUrl){lastUrl=location.href;stableSince=now;return false;}
        const changed=location.href!==oldUrl || current!==oldComposer;
        // Nếu Gemini SPA không đổi URL/editor, chờ ngắn rồi vẫn tiếp tục. Mã job riêng
        // ở prompt bảo đảm không lấy nhầm câu trả lời của lượt trước.
        return ((changed && now-stableSince>=120) || now-started>=900) ? current : false;
      },4500,signal,'Gemini chưa sẵn sàng sau khi làm mới cuộc trò chuyện.');
      return true;
    } catch(e) {
      if(e?.name==='AbortError')throw e;
      const current=composer();
      if(current && !composerText(current))return false;
      throw e;
    }
  }
  function deepElements(selector, root=document, out=[], seen=new Set()) {
    if (!root || seen.has(root)) return out;
    seen.add(root);
    try {
      for (const el of root.querySelectorAll?.(selector) || []) out.push(el);
      for (const el of root.querySelectorAll?.('*') || []) if (el.shadowRoot) deepElements(selector, el.shadowRoot, out, seen);
    } catch (_) {}
    return out;
  }
  function deepPick(selectors) {
    for (const sel of selectors) {
      const el=deepElements(sel).find(visible);
      if(el)return el;
    }
    return null;
  }
  async function waitAttachmentVisible(files, signal, timeout=50000) {
    return waitFor(()=>{
      const names=files.map(f=>f.name);
      const roots=[document,...deepElements('form,.input-area-container,.input-area,.input-container,[class*="composer" i],[class*="prompt" i]')];
      const text=roots.map(r=>r?.textContent||'').join(' ')+' '+deepElements('[title],[aria-label]').map(n=>n.title||n.getAttribute('aria-label')||'').join(' ');
      const busy=deepElements('[role="progressbar"],[aria-busy="true"],.uploading,[class*="uploading" i]').some(visible);
      return !busy&&names.every(n=>text.includes(n));
    },timeout,signal,'Chưa xác nhận được PDF scan đã tải lên Gemini.');
  }
  function fileFrom(item) {
    const raw=atob(item.base64),bytes=new Uint8Array(raw.length);
    for(let i=0;i<raw.length;i++)bytes[i]=raw.charCodeAt(i);
    return new File([bytes],item.name,{type:item.mimeType||'application/pdf'});
  }
  async function attach(job,signal) {
    const files=job.attachments||[];if(!files.length)return;
    progress(job,'upload','Đang tải '+files.length+' PDF scan lên Gemini');
    const input=()=>deepElements('input[type="file"]').find(el=>!el.disabled && (!el.accept || /pdf|\*|document|application/i.test(el.accept)));
    const makeFiles=()=>files.map(fileFrom);

    let el=input();
    if(!el) {
      const button=deepPick([
        'button[aria-label*="Add files" i]','button[aria-label*="Upload" i]','button[aria-label*="Attach" i]',
        'button[aria-label*="Thêm tệp" i]','button[aria-label*="Tải tệp" i]','button[aria-label*="plus" i]',
        '[role="button"][aria-label*="Add" i]','[role="button"][aria-label*="Thêm" i]'
      ]);
      if(button) {
        button.click();
        const entry=await waitFor(()=>input()||deepElements('[role="menuitem"],button').find(node=>visible(node)&&/upload|tải tệp|from device|từ thiết bị/i.test((node.innerText||node.textContent||'').trim())),6500,signal,'Không mở được bộ chọn tệp Gemini.').catch(()=>null);
        if(entry && entry.type!=='file') { try{entry.click();}catch(_){} }
        el=await waitFor(input,6500,signal,'').catch(()=>null);
      }
    }

    if(el) {
      if(files.length>1&&!el.multiple) {
        for(const f of files) {
          const current=input()||el;
          const dt=new DataTransfer();dt.items.add(fileFrom(f));assert(signal);
          current.files=dt.files;current.dispatchEvent(new Event('change',{bubbles:true}));
          await waitAttachmentVisible([f],signal,50000);
        }
      } else {
        const dt=new DataTransfer();makeFiles().forEach(f=>dt.items.add(f));assert(signal);
        el.files=dt.files;el.dispatchEvent(new Event('change',{bubbles:true}));
        await waitAttachmentVisible(files,signal,55000);
      }
    } else {
      const target=composer()?.closest('form,.input-area-container,.input-area,.input-container,[class*="composer" i]') || composer()?.parentElement || composer();
      if(!target)throw new Error('Không tìm thấy vùng nhập Gemini để gửi PDF scan.');
      const dt=new DataTransfer();makeFiles().forEach(f=>dt.items.add(f));
      for(const type of ['dragenter','dragover','drop']) {
        try { target.dispatchEvent(new DragEvent(type,{bubbles:true,cancelable:true,dataTransfer:dt})); } catch (_) {
          const ev=new Event(type,{bubbles:true,cancelable:true});try{Object.defineProperty(ev,'dataTransfer',{value:dt});}catch(_){}target.dispatchEvent(ev);
        }
        await sleep(120,signal);
      }
      await waitAttachmentVisible(files,signal,55000);
    }
    progress(job,'uploaded','Đã xác nhận '+files.length+' PDF scan trên Gemini');
  }
  function waitResult(job,signal) {
    // Strict response selectors + per-request nonce exclude old replies and prompt echoes.
    return waitFor(()=>{
      const nodes=[...document.querySelectorAll(RESPONSE)];
      for(const el of nodes.slice(-3).reverse()) {
        const text=el.textContent||'';
        if(!text.includes(job.jobId))continue;
        const obj=core.parseRouting(text,job.jobId);
        if(obj)return JSON.stringify(obj);
      }
      return false;
    },job.timeoutMs||150000,signal,'Chưa nhận được JSON đúng phiên từ Gemini. Hãy mở Gemini kiểm tra phản hồi hoặc tăng thời gian chờ.');
  }
  async function run(job,controller) {
    const signal=controller.signal;
    let heartbeat, resultPromise;
    try {
      heartbeat=setInterval(()=>progress(job,'waiting','Gemini đang xử lý văn bản'),15000);
      const el=await waitFor(composer,30000,signal,'Không tìm thấy ô nhập Gemini. Hãy đăng nhập Gemini và thử lại.');
      await waitFor(()=>!stopButton(),15000,signal,'Gemini vẫn đang tạo câu trả lời trước.');
      if(job.newChatBeforeSend) {progress(job,'new-chat','Đang mở cuộc trò chuyện mới');await newChat(signal);}
      if(composerText(composer())) throw new Error('Tab Gemini có nội dung chưa gửi. Hãy xử lý bản nháp trước khi phân tích.');
      await attach(job,signal);
      assert(signal);await setText(composer()||el,job.prompt);
      const send=await waitFor(()=>enabled(sendButton())&&sendButton(),15000,signal,'Nút Gửi Gemini chưa sẵn sàng.');
      // Install observer BEFORE clicking send; a quick response cannot race registration.
      resultPromise=waitResult(job,signal);resultPromise.catch(()=>{});
      assert(signal);send.click();
      progress(job,'sent','Đã bấm gửi · đang chờ Gemini trả lời');
      const text=await resultPromise;
      assert(signal);
      const r=await message({type:'WEB_AUTOMATION_RESULT',jobId:job.jobId,text});
      if(!r?.ok)throw new Error(r?.error||'Không lưu được kết quả Gemini.');
    } catch(e) {
      if(e.name!=='AbortError') await message({type:'WEB_AUTOMATION_ERROR',jobId:job.jobId,error:e.message||String(e)}).catch(()=>{});
    } finally {
      clearInterval(heartbeat);controller.abort();
      if(active?.jobId===job.jobId)active=null;
    }
  }
  chrome.runtime.onMessage.addListener((m,sender,reply)=>{
    if(sender.id!==chrome.runtime.id)return;
    if(m?.type==='IOFFICE_WEB_BRIDGE_PING'){reply({ok:true,platform,version:core.VERSION,ready:!!composer(),busy:!!active});return;}
    if(m?.type==='IOFFICE_GEMINI_CANCEL'){
      if(active?.jobId===m.jobId){active.controller.abort();stopButton()?.click();}
      reply({ok:true});return;
    }
    if(m?.type==='IOFFICE_GEMINI_AUTORUN'&&platform==='gemini'){
      if(active){reply(active.jobId===m.jobId?{ok:true,started:true}:{ok:false,error:'Gemini đang xử lý phiên khác.'});return;}
      const controller=new AbortController();active={jobId:m.jobId,controller};
      reply({ok:true,started:true});void run(m,controller);return;
    }
    if(m?.type==='IOFFICE_WEB_BRIDGE_SEND'){
      if(active){reply({ok:false,error:'Tab AI đang xử lý phiên khác.'});return;}
      const controller=new AbortController(),signal=controller.signal;
      active={jobId:m.jobId,controller};
      (async()=>{const c=await waitFor(composer,30000,signal,'Chưa tìm thấy ô nhập AI.');assert(signal);if(composerText(c))throw new Error('Ô nhập có bản nháp chưa gửi.');await setText(c,m.prompt);if(m.autoSend){const b=await waitFor(()=>enabled(sendButton())&&sendButton(),15000,signal,'Nút gửi chưa sẵn sàng.');assert(signal);b.click();}return{ok:true,autoSent:!!m.autoSend};})().then(reply,e=>reply({ok:false,error:e.message})).finally(()=>{if(active?.jobId===m.jobId)active=null;});return true;
    }
  });

  // Sau khi Gemini full-navigation (ví dụ mở chat mới), nối lại đúng job đang chờ và dán prompt tự động.
  if(platform==='gemini')setTimeout(()=>{
    message({type:'WEB_BRIDGE_READY',platform})
      .then(r=>{
        if(!r?.autoRun||active)return;
        const controller=new AbortController();active={jobId:r.jobId,controller};
        void run(r,controller);
      })
      .catch(()=>{});
  },120);
})();
