(() => {
  const box=document.createElement('section');box.className='card';
  box.innerHTML='<h2>Cập nhật Internet</h2><p>Tự kiểm tra mỗi 5 phút khi Chrome hoạt động. Cần cài bộ hỗ trợ Windows một lần.</p><p id="internetStatus" role="status"></p><div class="webbuttons"><button class="btn secondary" id="internetCheck">Kiểm tra ngay</button><button class="btn primary" id="internetApply" hidden>Đồng ý cập nhật</button></div><p>Sau cập nhật, lưu công việc và làm mới tab iOffice để sử dụng bản mới.</p>';
  document.querySelector('footer.actions').before(box);
  const status=box.querySelector('#internetStatus'),check=box.querySelector('#internetCheck'),apply=box.querySelector('#internetApply');
  function render(s) {
    status.textContent=s?.phase==='applying'?'Đang tải và cài đặt…':s?.error || (s?.newer?`Có phiên bản ${s.version}. ${s.notes || ''}`:s?.current?`Phiên bản đã cài: ${s.current}`:'Chưa kiểm tra.');
    apply.hidden=!s?.newer;apply.disabled=s?.phase==='applying';check.disabled=s?.phase==='applying';
  }
  async function run(type) {
    check.disabled=apply.disabled=true;
    try {const r=await chrome.runtime.sendMessage({type});if(!r?.ok)throw new Error(r?.error || 'Không có phản hồi.');}
    catch(e){status.textContent=e.message;}
    finally{check.disabled=apply.disabled=false;}
  }
  check.onclick=()=>run('INTERNET_UPDATE_CHECK');apply.onclick=()=>run('INTERNET_UPDATE_APPLY');
  chrome.storage.local.get('internetUpdate').then(x=>render(x.internetUpdate));
  chrome.storage.onChanged.addListener((c,a)=>{if(a==='local'&&c.internetUpdate)render(c.internetUpdate.newValue);});
})();
