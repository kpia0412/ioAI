# Privacy Shield 2.0.0 — nguồn tham chiếu và chính sách kỹ thuật

Ngày rà soát: 02/10/2026

## 1. Nguồn pháp lý và kỹ thuật tham chiếu

### Luật Bảo vệ dữ liệu cá nhân số 91/2025/QH15
- Cơ quan ban hành: Quốc hội; hiệu lực từ 01/01/2026.
- Cổng văn bản Chính phủ: https://vanban.chinhphu.vn/?classid=1&docid=214590&pageid=27160&typegroup=
- Chính sách của Privacy Shield áp dụng các nguyên tắc: đúng mục đích, giới hạn phạm vi cần thiết, bảo vệ dữ liệu trong môi trường AI; phân loại rủi ro khi AI xử lý dữ liệu cá nhân.

### Nghị định 356/2025/NĐ-CP
- Hiệu lực từ 01/01/2026; quy định chi tiết Luật Bảo vệ dữ liệu cá nhân.
- Toàn văn VBPL Bộ Công an: https://vbpl.vn/bocongan/Pages/vbpq-toanvan.aspx?ItemID=187276
- Điều 3 được dùng làm danh mục tối thiểu cho dữ liệu cá nhân cơ bản: họ tên; ngày sinh; giới tính; nơi sinh/đăng ký/cư trú/địa chỉ liên hệ; quốc tịch; hình ảnh; điện thoại; định danh cá nhân; hộ chiếu; GPLX; biển số xe; hôn nhân; quan hệ gia đình; tài khoản số và thông tin khác giúp xác định cá nhân.
- Điều 4 được dùng làm danh mục tối thiểu cho dữ liệu cá nhân nhạy cảm: dân tộc; chính trị/tôn giáo/tín ngưỡng; đời tư/bí mật cá nhân-gia đình; sức khỏe; sinh trắc/di truyền; đời sống/xu hướng tình dục; dữ liệu tội phạm/vi phạm do cơ quan thực thi pháp luật lưu trữ; vị trí định vị; thông tin đăng nhập tài khoản định danh điện tử và hình ảnh giấy tờ căn cước; dữ liệu ngân hàng/tài chính/tín dụng/chứng khoán/bảo hiểm; dữ liệu theo dõi hành vi trực tuyến và dữ liệu khác cần bảo mật chặt chẽ.

### Luật Bảo vệ bí mật nhà nước số 29/2018/QH14
- Toàn văn VBPL: https://vbpl.vn/TW/Pages/vbpq-toanvan.aspx?ItemID=141824
- Privacy Shield áp dụng chính sách chặn tuyệt đối đường gửi AI bên ngoài khi phát hiện dấu mức độ MẬT/TỐI MẬT/TUYỆT MẬT. Đây là hàng rào kỹ thuật phòng ngừa, không thay thế quy trình nghiệp vụ xác định và quản lý bí mật nhà nước của cơ quan.

### NIST Privacy Framework / Privacy Engineering
- https://www.nist.gov/privacy-framework
- https://www.nist.gov/itl/applied-cybersecurity/privacy-engineering/collaboration-space/focus-areas/disassociability
- Dùng làm nguồn thực hành kỹ thuật tự nguyện: data minimization, privacy-risk assessment, xử lý local-first, disassociability, de-identification/tokenization và selective disclosure. NIST không phải pháp luật Việt Nam.

## 2. Nguyên tắc sản phẩm của Privacy Shield 2.0

1. **Mandatory before external AI**: mọi đường API Gemini và Web AI phải đi qua Privacy Shield. Cấu hình cũ tắt Privacy Shield không còn được phép bỏ qua lớp này.
2. **Local-first**: tên/ID cán bộ, local recipient binding và từ điển tên chỉ xử lý trên máy; không chèn nguyên bản vào prompt.
3. **Data minimization**: chỉ giữ dữ kiện thực sự cần để xác định phạm vi, chủ thể, nhiệm vụ, hạn và đơn vị xử lý. Địa danh/cơ quan cần cho phân luồng được giữ khi không phải địa chỉ cá nhân/tài sản cụ thể.
4. **De-identification/tokenization**: dữ liệu nhận dạng được thay bằng token ổn định trong cùng phiên, ví dụ `⟦PERSON_01⟧`, để AI vẫn hiểu quan hệ ngữ nghĩa mà không cần tên thật.
5. **Risk classification**: normal / elevated / high / critical. Hồ sơ high/critical có thể bị chặn thay vì cố gửi.
6. **Fail-closed final audit**: sau khi ghép toàn bộ prompt, Privacy Shield quét lần thứ hai. Còn dấu hiệu dữ liệu chưa được bảo vệ thì không gửi.
7. **No image OCR leakage**: PDF scan dạng ảnh có thể chứa khuôn mặt, giấy tờ, chữ ký và thông tin không thể che đáng tin cậy từ text nên mặc định không gửi ra AI bên ngoài.
8. **No secrets/credentials**: MẬT/TỐI MẬT/TUYỆT MẬT, mật khẩu, PIN, OTP, API key, access/refresh token bị chặn.
9. **No public recipient map**: Recipient Rules công khai chỉ chứa mã vai trò/lĩnh vực; tên và ID iOffice của người thật chỉ tồn tại trong local binding.
10. **Preserve routing context**: không xóa mù quáng tên cơ quan, xã/phường/tỉnh hoặc hạn xử lý chỉ vì chúng là địa danh/ngày tháng; chỉ che khi chúng tạo thành dữ liệu cá nhân hoặc vị trí/tài sản cụ thể không cần thiết.

## 3. Ma trận xử lý mặc định

| Nhóm | Ví dụ | Chính sách mặc định |
|---|---|---|
| Nhận dạng trực tiếp | họ tên, CCCD/CMND, hộ chiếu, GPLX, điện thoại, email | Token hóa |
| Hồ sơ định danh bổ sung | ngày sinh, địa chỉ nhà/cư trú, biển số xe, tài khoản số | Token hóa |
| Tài sản/đất cụ thể | địa chỉ thửa đất, số thửa/tờ bản đồ, tọa độ | Token hóa khi không cần phân luồng |
| Tài chính/ngân hàng | STK, số thẻ, lịch sử giao dịch, tín dụng | Token hóa; hồ sơ cá nhân chi tiết bị chặn |
| Sức khỏe/sinh trắc | bệnh án, chẩn đoán, xét nghiệm, vân tay, DNA | Hồ sơ cá nhân bị chặn |
| Trẻ em | danh sách/hồ sơ trẻ em, học sinh có định danh | Bị chặn; văn bản chính sách chung vẫn cho phép |
| Hộ nghèo/an sinh | danh sách/hồ sơ cá nhân | Bị chặn; kế hoạch/chính sách chung vẫn cho phép |
| Khiếu nại/tố cáo | đơn/hồ sơ gắn cá nhân | Bị chặn; văn bản quy trình/chỉ đạo chung vẫn cho phép |
| Thực thi pháp luật | hồ sơ vụ án, tội phạm/vi phạm gắn cá nhân | Bị chặn |
| Đời tư/gia đình | bí mật gia đình, hồ sơ ly hôn/bạo lực gia đình gắn cá nhân | Bị chặn |
| Hành vi trực tuyến | lịch sử truy cập/hoạt động mạng gắn cá nhân | Bị chặn |
| Danh sách/phụ lục cá nhân | bảng họ tên + ngày sinh/CCCD/địa chỉ... | Bị chặn mặc định |
| Bí mật nhà nước | MẬT/TỐI MẬT/TUYỆT MẬT | Chặn tuyệt đối đường AI bên ngoài |
| Credential | mật khẩu, PIN, OTP, API key/token | Chặn tuyệt đối |

## 4. Lưu ý phạm vi

Privacy Shield là lớp giảm thiểu rủi ro kỹ thuật cho tiện ích, không phải công cụ tự động kết luận tính hợp pháp của mọi hoạt động xử lý dữ liệu. Cơ quan vẫn cần tuân thủ quy chế nội bộ, phân quyền, quản lý bí mật nhà nước, hồ sơ đánh giá tác động và các nghĩa vụ pháp lý áp dụng cho từng hoạt động xử lý dữ liệu.
