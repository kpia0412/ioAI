// 1.4.0: intentionally silent. System updates are managed in Options/background only.
