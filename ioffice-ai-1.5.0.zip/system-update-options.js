'use strict';
(() => {
  const $=id=>document.getElementById(id);
  const button=$('systemUpdateAction'),status=$('systemUpdateStatus'),extEl=$('systemExtStatus'),ruleEl=$('systemRuleStatus'),recipientEl=$('systemRecipientStatus'),auto=$('systemAutoUpdate');
  if(!button||!status||!extEl||!ruleEl||!recipientEl||!auto)return;
  let pendingExtension=null,pendingRule=null,pendingRecipient=null,busy=false;
  const runtime=m=>new Promise(resolve=>{try{chrome.runtime.sendMessage(m,r=>resolve(chrome.runtime.lastError?{ok:false,error:chrome.runtime.lastError.message}:(r||{ok:false,error:'Không có phản hồi'})));}catch(e){resolve({ok:false,error:e.message});}});
  const set=(el,text,kind='')=>{el.textContent=text;el.className=kind;};
  function buttonLabel(){const n=[pendingExtension,pendingRule,pendingRecipient].filter(Boolean).length;if(n)return n===1?(pendingExtension?`Cập nhật tiện ích v${pendingExtension.version}`:pendingRule?`Cập nhật Rule ${pendingRule.version}`:`Cập nhật Recipient ${pendingRecipient.version}`):`Cập nhật ${n} thành phần`;return 'Kiểm tra cập nhật';}
  async function loadState(){
    const local=await chrome.storage.local.get({internetAutoUpdate:true,internetUpdate:{},ruleAutoUpdate:true,recipientRulesAutoUpdate:true});
    auto.checked=local.internetAutoUpdate!==false&&local.ruleAutoUpdate!==false&&local.recipientRulesAutoUpdate!==false;
    const ext=local.internetUpdate||{},cur=chrome.runtime.getManifest().version;pendingExtension=ext.newer?ext:null;
    if(ext.error)set(extEl,`v${cur} · lỗi kiểm tra`,'err');else if(ext.newer)set(extEl,`v${cur} → v${ext.version}`,'ok');else set(extEl,`v${cur}`,'ok');
    const [rr,pr]=await Promise.all([runtime({type:'RULE_UPDATE_STATUS'}),runtime({type:'RECIPIENT_RULES_GET'})]);
    if(rr?.ok){const r=rr.data||{};pendingRule=r.newer?r:null;if(r.phase==='error')set(ruleEl,`${r.currentVersion||'—'} · lỗi kiểm tra`,'err');else if(r.newer)set(ruleEl,`${r.currentVersion||'—'} → ${r.version}`,'ok');else set(ruleEl,`${r.currentVersion||'—'}`,'ok');}else{pendingRule=null;set(ruleEl,'Không đọc được trạng thái','err');}
    if(pr?.ok){const p=pr.data||{},m=p.meta||{},v=p.rules?.version||'—';pendingRecipient=m.newer?m:null;if(m.phase==='error')set(recipientEl,`${v} · lỗi kiểm tra`,'err');else if(m.newer)set(recipientEl,`${v} → ${m.version}`,'ok');else set(recipientEl,v,'ok');}else{pendingRecipient=null;set(recipientEl,'Không đọc được trạng thái','err');}
    button.textContent=buttonLabel();
  }
  async function checkAll(){
    busy=true;button.disabled=true;status.textContent='Đang kiểm tra 3 thành phần…';status.className='status';
    try{
      const [extRes,ruleRes,recipientRes]=await Promise.all([runtime({type:'INTERNET_UPDATE_CHECK'}),runtime({type:'RULE_UPDATE_CHECK'}),runtime({type:'RECIPIENT_UPDATE_CHECK'})]);
      const errors=[];if(!extRes?.ok)errors.push('Tiện ích: '+(extRes?.error||'lỗi'));if(!ruleRes?.ok)errors.push('Rule: '+(ruleRes?.error||'lỗi'));if(!recipientRes?.ok)errors.push('Recipient: '+(recipientRes?.error||'lỗi'));
      await loadState();
      if(errors.length){status.textContent='⚠ '+errors.join(' | ');status.className='status err';}
      else if(pendingExtension||pendingRule||pendingRecipient){const parts=[];if(pendingExtension)parts.push(`tiện ích v${pendingExtension.version}`);if(pendingRule)parts.push(`Rule ${pendingRule.version}`);if(pendingRecipient)parts.push(`Recipient ${pendingRecipient.version}`);status.textContent=`Có cập nhật: ${parts.join(' + ')}.`;status.className='status ok';}
      else{status.textContent='✓ Tiện ích, Rule Pack và Recipient Rules đều mới nhất.';status.className='status ok';}
    }finally{busy=false;button.disabled=false;button.textContent=buttonLabel();}
  }
  async function applyAll(){
    if(!pendingExtension&&!pendingRule&&!pendingRecipient)return checkAll();
    busy=true;button.disabled=true;status.textContent='Đang cập nhật hệ thống…';status.className='status';
    try{
      if(pendingRule){const r=await runtime({type:'RULE_UPDATE_APPLY'});if(!r?.ok)throw new Error('Rule: '+(r?.error||'cập nhật thất bại'));pendingRule=null;}
      if(pendingRecipient){const r=await runtime({type:'RECIPIENT_UPDATE_APPLY'});if(!r?.ok)throw new Error('Recipient: '+(r?.error||'cập nhật thất bại'));pendingRecipient=null;}
      if(pendingExtension){const r=await runtime({type:'INTERNET_UPDATE_APPLY',forceDirty:true});if(!r?.ok)throw new Error('Tiện ích: '+(r?.error||'cập nhật thất bại'));return;}
      status.textContent='✓ Đã cập nhật dữ liệu luật.';status.className='status ok';await loadState();
    }catch(e){status.textContent='✕ '+e.message;status.className='status err';}
    finally{busy=false;button.disabled=false;button.textContent=buttonLabel();}
  }
  button.addEventListener('click',()=>pendingExtension||pendingRule||pendingRecipient?applyAll():checkAll());
  auto.addEventListener('change',async()=>{await chrome.storage.local.set({internetAutoUpdate:auto.checked,ruleAutoUpdate:auto.checked,recipientRulesAutoUpdate:auto.checked});await Promise.all([runtime({type:'RULE_AUTO_SET',enabled:auto.checked}),runtime({type:'RECIPIENT_AUTO_SET',enabled:auto.checked})]);status.textContent=auto.checked?'✓ Đã bật cập nhật ngầm cả 3 thành phần.':'Đã tắt tự động cập nhật.';status.className='status ok';if(auto.checked)void runtime({type:'INTERNET_UPDATE_AUTO_NOW'});});
  chrome.storage.onChanged.addListener((changes,area)=>{if(area==='local'&&(changes.internetUpdate||changes.ruleInternetUpdate||changes.recipientRulesMeta||changes.internetAutoUpdate||changes.ruleAutoUpdate||changes.recipientRulesAutoUpdate))void loadState();});
  loadState().catch(e=>{status.textContent='✕ '+e.message;status.className='status err';});
})();
