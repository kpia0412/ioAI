(() => {
  if(window.top!==window)return;
  const host=document.createElement('div');
  host.style.cssText='position:fixed;bottom:12px;left:12px;z-index:2147483646;max-width:min(460px,calc(100vw - 24px))';
  const root=host.attachShadow({mode:'closed'});document.documentElement.append(host);
  let expanded=false,items=[],generation=0;
  const labels={awaiting_transfer:'Chờ xác nhận đã chuyển iOffice',queued:'Đã lưu · chờ gửi ngầm',sending:'Đang gửi ngầm…',sent:'Đã gửi hoàn tất vào Sổ',failed:'Gửi thất bại',unknown:'Chưa xác định kết quả · cần kiểm tra',cancelled:'Đã hủy lượt gửi'};
  function render(){
    root.replaceChildren();if(!items.length)return;
    const style=document.createElement('style');style.textContent=':host{font:13px/1.45 Arial;color:#17365d}section{background:#fff;border:1px solid #b6c9dc;border-radius:12px;box-shadow:0 4px 22px #0003;padding:10px}button{font:700 12px Arial;cursor:pointer;border:1px solid #bdcddd;border-radius:7px;padding:7px;background:#edf5ff;color:#17365d;margin:3px}article{border-top:1px solid #dfe7ef;padding:8px 0;overflow-wrap:anywhere}.sent{color:#15803d}.unknown,.failed{color:#b42318}.sending,.queued,.awaiting_transfer{color:#a16207}.list{max-height:330px;overflow:auto}small{display:block;color:#64748b}';root.append(style);
    const box=document.createElement('section');root.append(box);
    const title=document.createElement('button');const pending=items.filter(x=>!['sent','cancelled'].includes(x.status)).length;
    title.textContent=`📨 Lịch sử gửi Sổ${pending?' · '+pending+' cần chú ý':''} ${expanded?'▾':'▸'}`;title.onclick=()=>{expanded=!expanded;render();};box.append(title);
    const latest=items[0],summary=document.createElement('div');summary.className=latest.status;summary.textContent=(latest.data.sourceNo||latest.data.sourceSubject||'Văn bản').slice(0,85)+' · '+labels[latest.status];summary.setAttribute('role','status');box.append(summary);
    if(!expanded)return;
    const list=document.createElement('div');list.className='list';box.append(list);
    for(const item of items){
      const row=document.createElement('article'),name=document.createElement('b'),status=document.createElement('div'),meta=document.createElement('small');
      name.textContent=item.data.sourceNo||item.data.sourceSubject||'Văn bản';status.textContent=labels[item.status];status.className=item.status;
      meta.textContent=new Date(item.updatedAt).toLocaleString('vi-VN')+(item.taskId?' · Mã: '+item.taskId:'');row.append(name,status,meta);
      const task=document.createElement('div');task.textContent=item.data.taskText;row.append(task);
      if(item.error){const err=document.createElement('small');err.textContent=item.error;row.append(err);}
      const add=(label,action)=>{const b=document.createElement('button');b.textContent=label;b.onclick=async()=>{b.disabled=true;try{await action();}finally{await refresh();}};row.append(b);};
      if(item.status==='awaiting_transfer'){
        add('Đã chuyển iOffice · Gửi vào Sổ',async()=>{if(confirm('Chỉ xác nhận nếu văn bản '+(item.data.sourceNo||'này')+' đã chuyển thành công trên iOffice. Gửi nhiệm vụ đã lưu vào Sổ?'))await send('TRACKER_DELIVERY_COMMIT',{id:item.id});});
        add('Hủy lượt gửi',()=>send('TRACKER_DELIVERY_CANCEL',{id:item.id}));
      }
      if(['sent','failed','unknown'].includes(item.status))add('Mở Sổ kiểm tra',()=>send('TRACKER_OPEN_MANAGE'));
      list.append(row);
    }
  }
  async function send(type,data){try{const r=await chrome.runtime.sendMessage({type,data});if(!r?.ok)alert(r?.error||'Chưa thực hiện được.');return r;}catch(e){alert(e.message);}}
  async function refresh(){const run=++generation;try{const r=await chrome.runtime.sendMessage({type:'TRACKER_DELIVERY_LIST'});if(run!==generation)return;items=r?.ok?r.items:[];render();}catch(_){}}
  chrome.storage.onChanged.addListener((c,a)=>{if(a==='local'&&Object.keys(c).some(k=>k.startsWith('trackerDeliveryV1:')||['trackerToken','trackerApiUrl','trackerEnabled'].includes(k)))void refresh();});
  void refresh();
})();
