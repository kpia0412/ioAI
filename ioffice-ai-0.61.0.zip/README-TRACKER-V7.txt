iOffice AI 0.61.0 — Local Rule Pro 0.60.0 — Tracker 7.0.16 khuyến nghị

ĐIỂM MỚI VĂN BẢN ĐI
- Ngay khi mở Văn bản đi, tiện ích chỉ đọc nhẹ mục VĂN BẢN LIÊN QUAN và đối chiếu Sổ theo dõi.
- Bước này KHÔNG đọc FILE TRÌNH KÝ, KHÔNG gọi AI và KHÔNG làm thay nút Kiểm tra văn bản.
- Trên thanh tiêu đề có chip trạng thái: Đang đối chiếu / Đang xử lý / Trễ hạn / Hoàn thành / Nhiều nhiệm vụ / Không thấy nhiệm vụ.
- Bấm chip để xem nhanh nhiệm vụ, hạn, trạng thái; nhiệm vụ đang xử lý có nút Xác nhận Hoàn thành.
- Không tự đổi trạng thái. Mọi thay đổi trạng thái đều cần người dùng xác nhận.
- Nếu có nhiều nhiệm vụ gần khớp, chỉ hiển thị ứng viên và yêu cầu mở Sổ theo dõi để chọn, không tự cập nhật.

CÁCH ĐỐI CHIẾU
1. Ưu tiên ID iOffice của Văn bản liên quan khi DOM cung cấp được.
2. Ưu tiên cao nhất cho Số/Ký hiệu khớp chính xác.
3. Nếu thiếu Số/Ký hiệu mới dùng Trích yếu với ngưỡng tương đồng thận trọng.
4. Văn bản đi chỉ có Trích yếu chung chung không được dùng để tự kết luận nhiệm vụ đã hoàn thành.

TRACKER
- Tracker 7.0.16 thêm API matchTask để tra cả nhiệm vụ Đang xử lý và Hoàn thành.
- iOffice AI 0.61.0 vẫn chạy với Tracker 7.0.15: khi đó chỉ đối chiếu chắc chắn được nhiệm vụ đang xử lý; chip sẽ nhắc cập nhật Tracker nếu cần tra lịch sử Hoàn thành.
- Nâng Tracker từ 7.0.15 lên 7.0.16 KHÔNG chạy setupFreshV7(), KHÔNG tạo Sheet mới, giữ URL /exec và TOKEN cũ.

LUỒNG KIỂM TRA VĂN BẢN
- Nút Kiểm tra văn bản vẫn giữ nguyên: chỉ khi người dùng bấm mới đọc FILE TRÌNH KÝ/AI để kiểm tra nội dung, thể thức.
- Đối chiếu Sổ và Kiểm tra văn bản là hai luồng độc lập.

CẬP NHẬT GITHUB
1. Đưa ioffice-ai-0.61.0.zip lên thư mục gốc repo ioAI.
2. Sau khi ZIP có trên GitHub Pages, thay latest.json bằng tệp đi kèm.
3. URL ZIP: https://kpia0412.github.io/ioAI/ioffice-ai-0.61.0.zip
4. URL JSON: https://kpia0412.github.io/ioAI/latest.json
5. Không sửa ZIP sau khi tạo latest.json; nếu sửa phải tính lại SHA-256.
6. Không đưa TOKEN vào GitHub.

KIỂM TRA TĨNH
- JavaScript và JSON đã kiểm tra cú pháp.
- Đã kiểm tra gói ZIP có manifest 0.61.0.
- Chưa thể kiểm tra trực tiếp DOM iOffice thật và Apps Script đang triển khai; nên thử trước trên 1 Văn bản đi có Văn bản liên quan rõ Số/Ký hiệu.
