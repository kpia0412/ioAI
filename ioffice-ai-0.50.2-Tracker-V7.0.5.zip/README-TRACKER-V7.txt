iOffice AI 0.50.2 — tương thích Tracker V7.0.5 Compact
Ngày 29/09/2026.

CÀI / NÂNG CẤP
1. Giải nén vào đúng thư mục tiện ích đang dùng, ghi đè bản 0.50.1.
2. chrome://extensions > Tải lại tiện ích; sau đó tải lại trang iOffice.
3. Giữ nguyên URL /exec và TOKEN Tracker đang cấu hình. Không gỡ tiện ích để tránh mất cấu hình cục bộ.
4. Tracker phía Sheet nên cập nhật lên V7.0.5: thay Code.gs, Manage.html, Public.html rồi Deploy phiên bản mới. KHÔNG chạy setupFreshV7() nếu muốn giữ dữ liệu.

THAY ĐỔI CHÍNH
- Xóa khối “📌 NHIỆM VỤ THEO DÕI” bị trùng trong màn hình lãnh đạo.
- Khi bật “Ghi Sổ theo dõi”, trường “Ý kiến chỉ đạo” chính là “Nội dung nhiệm vụ” gửi sang Tracker.
- Chỉ giữ hàng theo dõi gọn: bật/tắt Ghi Sổ + Hạn xử lý; XLC tự lấy từ mục 1. Xử lý chính.
- Không còn chép Ý kiến chỉ đạo lần nữa vào Ghi chú Tracker.
- Sổ theo dõi trong tiện ích hiển thị STT đúng với Tracker/Trang quản lý.
- Bấm nhiệm vụ nào thì phần chi tiết mở ngay bên dưới nhiệm vụ đó; bấm lại để thu gọn, không đưa chi tiết lên đầu danh sách.
- Danh sách gọn hơn: STT, nội dung, trích yếu, đơn vị, hạn, trạng thái, đôn đốc và số minh chứng.
- Tracker V7.0.5 rút gọn Changelog; nhiệm vụ tạo từ tiện ích hiển thị dạng “thời gian · Tiện ích iOffice · Tạo nhiệm vụ”.

LƯU Ý
- Chỉ khi bật “Ghi Sổ theo dõi” và Chuyển văn bản thành công thì tiện ích mới gửi nhiệm vụ sang Tracker.
- Nếu bật Ghi Sổ, bắt buộc có Ý kiến chỉ đạo, Xử lý chính và Hạn xử lý.
- Tracker vẫn không tự gửi lại lệnh tạo khi mất phản hồi để tránh tạo trùng.
