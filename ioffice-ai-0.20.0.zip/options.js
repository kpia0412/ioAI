'use strict';
const $=id=>document.getElementById(id);
const CATALOG=globalThis.IOFFICE_PROVIDER_CATALOG||{};
const defaults={
  userRole:'leader',analysisMode:'gemini-web',fallbackAnalysisMode:'chatgpt-web',webGeminiForeground:false,
  aiRequireCompleteFiles:true,readerMode:'primary',readerTimeoutMs:5000,readerMaxFileSizeMb:10,readerIncludeRelated:false,
  trackerEnabled:false,trackerApiUrl:'',trackerToken:'',trackerReminderDays:3,
  clerkIncomingMainRecipient:'',clerkIncomingCoordRecipients:[],clerkIncomingViewRecipients:[],clerkIncomingMainRecipientId:'',clerkIncomingCoordRecipientIds:[],clerkIncomingViewRecipientIds:[],clerkAutoApplyIncoming:false,clerkAutoSendIncoming:false,clerkRecipientDirectory:[],
  providerOrder:['gemini','openai','none','none'],providerConfigs:{},requestTimeoutMs:45000,retriesPerProvider:1
};
let current={};
function deepMerge(base,extra){const out={...base};for(const [k,v] of Object.entries(extra||{})){out[k]=(v&&typeof v==='object'&&!Array.isArray(v)&&base?.[k]&&typeof base[k]==='object'&&!Array.isArray(base[k]))?deepMerge(base[k],v):v;}return out;}
function defaultProviderConfigs(){const out={};for(const [id,p] of Object.entries(CATALOG))out[id]={apiKey:'',model:p.defaultModel||'',baseUrl:p.baseUrl||'',authMode:'bearer',customHeaderName:'',customHeaderValue:'',deployment:'',apiVersion:'2025-04-01-preview'};return out;}
function msg(t,ok=true){$('msg').textContent=t;$('msg').className='msg '+(ok?'ok':'err');}
function runtime(message){return new Promise(resolve=>{try{chrome.runtime.sendMessage(message,r=>resolve(chrome.runtime.lastError?{ok:false,error:chrome.runtime.lastError.message}:r));}catch(e){resolve({ok:false,error:e.message});}});}
function selectedValues(el){return [...el.selectedOptions].map(o=>o.value).filter(Boolean);}
function fillDirectory(list){
  const clean=(Array.isArray(list)?list:[]).filter(x=>x&&x.key&&x.name);
  const main=$('clerkMain'),coord=$('clerkCoord'),view=$('clerkView');
  for(const el of [main,coord,view]){const first=el===main?'<option value="">— Chưa chọn —</option>':'';el.innerHTML=first+clean.map(x=>`<option value="${String(x.key).replaceAll('&','&amp;').replaceAll('"','&quot;')}">${String(x.name).replaceAll('&','&amp;').replaceAll('<','&lt;')}</option>`).join('');}
  main.value=current.clerkIncomingMainRecipientId||'';
  const c=new Set(current.clerkIncomingCoordRecipientIds||[]),v=new Set(current.clerkIncomingViewRecipientIds||[]);
  [...coord.options].forEach(o=>o.selected=c.has(o.value));[...view.options].forEach(o=>o.selected=v.has(o.value));
  $('directoryStatus').textContent=clean.length?`Đã có ${clean.length} người/đơn vị từ danh bạ iOffice.`:'Chưa có danh bạ. Mở một văn bản đến → Xử lý/Thông tin nhận trên iOffice để tiện ích ghi nhận.';
  $('directoryStatus').className='status '+(clean.length?'ok':'');
}
function loadApiProvider(id){const cfg=current.providerConfigs?.[id]||{};$('apiProvider').value=id;$('apiModel').value=cfg.model||'';$('apiBaseUrl').value=cfg.baseUrl||CATALOG[id]?.baseUrl||'';$('apiKey').value=cfg.apiKey||'';}
async function load(){
  const raw=await chrome.storage.local.get(null);current={...defaults,...raw,providerConfigs:deepMerge(defaultProviderConfigs(),raw.providerConfigs||{})};
  $('version').textContent='v'+chrome.runtime.getManifest().version;
  $('userRole').value=current.userRole==='clerk'?'clerk':'leader';$('analysisMode').value=['gemini-web','chatgpt-web','api'].includes(current.analysisMode)?current.analysisMode:'gemini-web';$('fallbackAnalysisMode').value=['gemini-web','chatgpt-web','api','none'].includes(current.fallbackAnalysisMode)?current.fallbackAnalysisMode:'chatgpt-web';$('webGeminiForeground').value=String(current.webGeminiForeground===true);$('aiRequireCompleteFiles').checked=current.aiRequireCompleteFiles!==false;
  $('readerMode').value=current.readerMode==='all'?'all':'primary';$('readerTimeoutSec').value=String(Math.round((Number(current.readerTimeoutMs)||5000)/1000));$('readerMaxFileSizeMb').value=String(Number(current.readerMaxFileSizeMb)||10);$('readerIncludeRelated').checked=current.readerIncludeRelated===true;
  $('trackerEnabled').checked=current.trackerEnabled===true;$('trackerApiUrl').value=current.trackerApiUrl||'';$('trackerToken').value=current.trackerToken||'';$('trackerReminderDays').value=String(Number(current.trackerReminderDays)||3);
  $('clerkAutoApplyIncoming').checked=current.clerkAutoApplyIncoming===true;$('clerkAutoSendIncoming').checked=current.clerkAutoSendIncoming===true;fillDirectory(current.clerkRecipientDirectory);
  const api=(current.providerOrder||[]).find(x=>['gemini','openai','gateway','custom'].includes(x))||'gemini';current._editingApi=api;loadApiProvider(api);
}
$('apiProvider').addEventListener('change',()=>{const prev=current._editingApi||((current.providerOrder||[]).find(x=>['gemini','openai','gateway','custom'].includes(x))||'gemini');current.providerConfigs[prev]={...(current.providerConfigs[prev]||{}),model:$('apiModel').value.trim(),baseUrl:$('apiBaseUrl').value.trim(),apiKey:$('apiKey').value.trim()};current._editingApi=$('apiProvider').value;loadApiProvider(current._editingApi);});
$('refreshDirectory').addEventListener('click',async()=>{const r=await chrome.storage.local.get({clerkRecipientDirectory:[]});current.clerkRecipientDirectory=r.clerkRecipientDirectory||[];fillDirectory(current.clerkRecipientDirectory);});
$('openGemini').addEventListener('click',()=>window.open('https://gemini.google.com/app','_blank','noopener'));$('openChatGPT').addEventListener('click',()=>window.open('https://chatgpt.com/','_blank','noopener'));
async function ensureTrackerPermission(url){if(!url)return false;const u=new URL(url);if(u.protocol!=='https:')throw new Error('URL Apps Script phải dùng HTTPS.');const origins=[`${u.protocol}//${u.hostname}/*`,'https://script.googleusercontent.com/*'];const miss=[];for(const origin of origins)if(!(await chrome.permissions.contains({origins:[origin]})))miss.push(origin);return !miss.length||await chrome.permissions.request({origins:miss});}
$('testTracker').addEventListener('click',async()=>{const el=$('trackerStatus');el.textContent='Đang kiểm tra…';try{const url=$('trackerApiUrl').value.trim(),token=$('trackerToken').value.trim();if(!url||!token)throw new Error('Nhập URL Web App và mã truy cập trước.');if(!(await ensureTrackerPermission(url)))throw new Error('Chưa cấp quyền Apps Script.');await chrome.storage.local.set({trackerEnabled:true,trackerApiUrl:url,trackerToken:token});const r=await runtime({type:'TRACKER_TEST'});if(!r?.ok)throw new Error(r?.error||'Không kết nối được Sổ.');el.textContent='✓ Đã kết nối Tracker '+(r.data?.version||'');el.className='status ok';}catch(e){el.textContent=e.message;el.className='status err';}});
$('save').addEventListener('click',async()=>{try{
  const api=$('apiProvider').value;current.providerConfigs[api]={...(current.providerConfigs[api]||{}),model:$('apiModel').value.trim(),baseUrl:$('apiBaseUrl').value.trim()||CATALOG[api]?.baseUrl||'',apiKey:$('apiKey').value.trim()};
  const dir=new Map((current.clerkRecipientDirectory||[]).map(x=>[x.key,x.name]));const mainId=$('clerkMain').value,coordIds=selectedValues($('clerkCoord')),viewIds=selectedValues($('clerkView'));
  const settings={userRole:$('userRole').value,analysisMode:$('analysisMode').value,fallbackAnalysisMode:$('fallbackAnalysisMode').value,webGeminiForeground:$('webGeminiForeground').value==='true',aiRequireCompleteFiles:$('aiRequireCompleteFiles').checked,
    readerMode:$('readerMode').value,readerTimeoutMs:Math.max(2000,Math.min(60000,Number($('readerTimeoutSec').value||5)*1000)),readerMaxFileSizeMb:Math.max(1,Math.min(50,Number($('readerMaxFileSizeMb').value||10))),readerIncludeRelated:$('readerIncludeRelated').checked,readerConcurrency:0,readerDeduplicateContent:true,readerScanEnabled:false,
    trackerEnabled:$('trackerEnabled').checked,trackerApiUrl:$('trackerApiUrl').value.trim(),trackerToken:$('trackerToken').value.trim(),trackerReminderDays:Number($('trackerReminderDays').value||3),
    clerkIncomingMainRecipientId:mainId,clerkIncomingCoordRecipientIds:coordIds,clerkIncomingViewRecipientIds:viewIds,clerkIncomingMainRecipient:dir.get(mainId)||'',clerkIncomingCoordRecipients:coordIds.map(x=>dir.get(x)||'').filter(Boolean),clerkIncomingViewRecipients:viewIds.map(x=>dir.get(x)||'').filter(Boolean),clerkAutoApplyIncoming:$('clerkAutoApplyIncoming').checked,clerkAutoSendIncoming:$('clerkAutoSendIncoming').checked,
    providerOrder:[api,'none','none','none'],providerConfigs:current.providerConfigs,retriesPerProvider:1,requestTimeoutMs:45000};
  if(settings.trackerEnabled){if(!settings.trackerApiUrl||!settings.trackerToken)throw new Error('Đã bật Sổ theo dõi nhưng chưa nhập URL/token.');if(!(await ensureTrackerPermission(settings.trackerApiUrl)))throw new Error('Chưa cấp quyền Apps Script.');}
  if(settings.analysisMode==='api'||settings.fallbackAnalysisMode==='api'){const u=new URL(settings.providerConfigs[api].baseUrl);const origin=`${u.protocol}//${u.hostname}/*`;if(!(await chrome.permissions.contains({origins:[origin]})))await chrome.permissions.request({origins:[origin]});}
  await chrome.storage.local.set(settings);current={...current,...settings};msg('Đã lưu. Có hiệu lực ngay trên tab iOffice.',true);
}catch(e){msg(e.message,false);}});
load().catch(e=>msg('Không tải được cấu hình: '+e.message,false));
