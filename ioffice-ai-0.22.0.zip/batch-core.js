/* Shared, dependency-free rules for the clerk queue. */
(function (root) {
  'use strict';
  const norm = x => String(x ?? '').replace(/\s+/g, ' ').trim();
  const ids = xs => [...new Set((Array.isArray(xs) ? xs : []).map(norm).filter(Boolean))];
  const terminal = item => ['sent', 'skipped'].includes(item.status);
  function preset(cfg) {
    const p = { main: norm(cfg.clerkIncomingMainRecipientId), coord: ids(cfg.clerkIncomingCoordRecipientIds), view: ids(cfg.clerkIncomingViewRecipientIds) };
    if (!p.main) throw new Error('Chọn đúng một Xử lý chính từ danh bạ trong Cấu hình trước khi lập hàng đợi.');
    const all = [p.main, ...p.coord, ...p.view];
    if (new Set(all).size !== all.length) throw new Error('Một người/đơn vị đang nằm trong nhiều vai trò của preset. Hãy sửa Cấu hình.');
    for (const [names, keys] of [[cfg.clerkIncomingCoordRecipients, p.coord], [cfg.clerkIncomingViewRecipients, p.view]]) {
      if (Array.isArray(names) && names.length > keys.length) throw new Error('Preset còn tên cũ chưa gắn ID danh bạ. Hãy chọn và lưu lại người nhận.');
    }
    return p;
  }
  function fingerprint(p) { return JSON.stringify([p.main, [...p.coord].sort(), [...p.view].sort()]); }
  function records(rows) {
    const map = new Map();
    for (const row of rows) {
      const id = norm(row.id);
      if (!/^\d+$/.test(id)) throw new Error('Danh sách có ID văn bản không hợp lệ.');
      if (!map.has(id)) map.set(id, { id, symbol: norm(row.symbol), title: norm(row.title), sender: norm(row.sender), status: 'pending', note: '', updatedAt: 0 });
    }
    return [...map.values()];
  }
  function recover(q) {
    if (!q) return null;
    const copy = JSON.parse(JSON.stringify(q));
    for (const item of copy.items) {
      if (item.status === 'sending') { item.status = 'uncertain'; item.note = 'Phiên bị gián đoạn sau khi chuẩn bị gửi. Kiểm tra iOffice trước khi xử lý tiếp.'; }
      if (item.status === 'processing') item.status = 'pending';
    }
    if (['running', 'collecting'].includes(copy.status)) copy.status = 'paused';
    return copy;
  }
  function counts(q) {
    return (q?.items || []).reduce((a, x) => { a[x.status] = (a[x.status] || 0) + 1; a.total++; return a; }, { total: 0, sent: 0, skipped: 0, pending: 0, uncertain: 0, error: 0 });
  }
  function classify(text) {
    const t = norm(text).toLowerCase();
    if (/không thành công|khong thanh cong|chưa thành công|chua thanh cong|thất bại|that bai|có lỗi|co loi|không thể|khong the/.test(t)) return 'failure';
    // A closing dialog or an HTTP 200 is never proof of a successful transfer.
    if (/(?:chuyển|chuyen|gửi|gui)(?:\s+[^.!?]{0,100})?\s+thành công|(?:chuyen|gui)(?:\s+[^.!?]{0,100})?\s+thanh cong/.test(t)) return 'success';
    return '';
  }
  const api = { norm, ids, preset, fingerprint, records, recover, counts, terminal, classify };
  root.IOfficeBatchCore = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(globalThis);
