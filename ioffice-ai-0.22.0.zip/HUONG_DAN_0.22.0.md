# iOffice AI Ea Ly 0.22.0

Gói đầy đủ được xây dựng từ bản 0.21.0 anh đã tải, bổ sung hàng đợi Văn thư dựa trên DOM danh sách và phân trang anh cung cấp ngày 28/09/2026.

## Cập nhật máy đang dùng

1. Giải nén `ioffice-ai-v0.22.0-COMPLETE.zip` vào một thư mục riêng.
2. Dừng các tác vụ đang chạy trong tiện ích; lưu nội dung đang nhập trên iOffice.
3. Chép **toàn bộ nội dung thư mục `extension`** vào đúng thư mục tiện ích đang được Chrome nạp, đồng ý ghi đè tệp trùng tên. Hoặc giải nén `ioffice-ai-0.22.0.zip` vào đúng thư mục đó. Không dùng thư mục chứa gói COMPLETE làm thư mục extension.
4. Mở `chrome://extensions` → iOffice AI - Ea Ly → **Tải lại / Reload**.
5. F5 tab iOffice; kiểm tra phiên bản **0.22.0** trong Cấu hình.

Giữ nguyên thư mục cài và ID tiện ích; không gỡ tiện ích trước khi cập nhật. Cấu hình vẫn nằm trong `chrome.storage`; bản 0.22.0 không thêm thao tác xóa hay đổi khóa thiết lập cũ. Logic chuyển đổi thiết lập từ 0.21.0 được giữ lại, nên không cam kết tuyệt đối mọi tùy chọn được giữ nguyên. Mã Apps Script Tracker V4.1 không đổi.

## Dùng hàng đợi Văn thư

1. Chọn vai trò **Văn thư**.
2. Trong Cấu hình, chọn preset từ danh bạ: đúng một **Xử lý chính**, tùy chọn **Phối hợp** và **Xem để biết**. Một ID không được nằm ở hai vai trò. Nếu chưa có danh bạ, mở một văn bản đến → Xử lý → Thông tin nhận, rồi vào Cấu hình để chọn và lưu lại.
3. Mở danh sách **Văn bản vào sổ** hoặc **Chưa chuyển xử lý**. Đóng cửa sổ chi tiết văn bản trước khi lập danh sách.
4. Trong khung **Văn thư · Hàng đợi văn bản đến**, chọn một phạm vi:
   - **Tất cả các trang của danh sách hiện tại**: gồm cả các trang chưa hiển thị. Tiện ích giữ mức 10/25/50 bản ghi đang chọn, tự đi từng trang từ trang đầu.
   - **Chỉ trang hiện tại**.
   - **Các văn bản đã tích trên trang hiện tại**: không bao gồm lựa chọn ở các trang khác.
5. Bấm **Lập danh sách**. Tiện ích thu thập ID trước, chưa chuyển văn bản.
6. Mở **Danh sách và kết quả**, kiểm tra số lượng văn bản và preset. Bấm **Bắt đầu chuyển theo preset** để áp cùng preset và chuyển tuần tự toàn bộ danh sách đã chốt.

Hàng đợi không gọi AI hoặc đọc nội dung tệp. Hai công tắc “Tự áp dụng preset” và “Tự bấm Chuyển” cho từng văn bản không phải điều kiện chạy hàng đợi. Khi còn hàng đợi chưa kết thúc, cơ chế tự áp từng văn bản được tạm ngưng để tránh chạy chồng.

Giữ nguyên tài khoản và preset trong lúc chạy. Hàng đợi tối đa 5.000 văn bản/500 trang. Nên dùng bộ lọc để chia các đợt lớn. Sau mỗi lần chuyển, tiện ích trở lại menu nguồn và tìm theo ID đã chốt; danh sách co lại không làm đổi văn bản tiếp theo. Bộ lọc của trang có thể được iOffice đặt lại khi trở về menu; những ID được xử lý vẫn thuộc hàng đợi đã lập.

## Dừng, tiếp tục và xử lý lỗi

- **Dừng**: nếu chưa gửi thì dừng trước khi chuyển; nếu lệnh đã gửi thì chờ kết quả của văn bản hiện tại rồi dừng. Không thể thu hồi lệnh đã gửi bằng nút Dừng.
- **Tiếp tục chuyển theo preset**: tiếp tục các văn bản còn chờ. Tải lại tab/khởi động lại Chrome không tự chạy tiếp.
- **Lỗi trước khi gửi**: sửa nguyên nhân rồi chọn **Thử lại sau khi sửa lỗi**, sau đó Tiếp tục.
- **Cần kiểm tra**: đã đi qua bước gửi hoặc phiên bị gián đoạn ở bước đó. Kiểm tra kết quả thật trên iOffice; chọn **Đã kiểm tra trên iOffice: đã chuyển** hoặc **Bỏ qua văn bản này**. Tiện ích không tự thử gửi lại trường hợp chưa rõ kết quả.
- Nếu xác minh văn bản chưa được chuyển, có thể bỏ qua mục đó ở hàng đợi hiện tại, kết thúc đợt và lập một đợt mới cho riêng văn bản này.
- **Xuất nhật ký**: tải JSON chứa ID, trạng thái và ghi chú. Hệ thống giữ một hàng đợi gần nhất; xuất nhật ký trước khi lập đợt mới nếu cần giữ lịch sử cũ.
- **Kết thúc / đợt mới**: kết thúc đợt hiện tại; các mục còn lại được ghi “Đã bỏ qua” khi anh xác nhận. Đây là thay đổi trạng thái theo dõi cục bộ, không thu hồi hay xóa văn bản trên iOffice.

Chỉ một tab được chạy hàng đợi tại một thời điểm. Sau khi một tab bị treo, khóa phiên có thể cần tối đa khoảng 45 giây để hết hạn; không bấm chuyển thủ công khi chưa kiểm tra văn bản đang gửi.

## Cập nhật qua Internet

Gói đã có `release/ioffice-ai-0.22.0.zip` và `release/latest.json`, với SHA-256 tính từ đúng ZIP này.

1. Tải ZIP mới lên thư mục phát hành của kho `ioAI` trước.
2. Sau khi ZIP tải được, cập nhật `latest.json` cùng thư mục.
3. URL nguồn kiểm tra: `https://kpia0412.github.io/ioAI/latest.json`.
4. Trên máy đã cài bộ hỗ trợ Windows: Cấu hình → Cập nhật Internet → Kiểm tra ngay → Đồng ý cập nhật.

Gói này **chưa được tải lên GitHub** trong phiên làm việc này. Không chỉ tải mã nguồn rời lên kho rồi mong các máy tự cập nhật; cần cả ZIP và `latest.json` khớp nhau. Không sửa ZIP sau khi tính mã SHA-256.

Máy mới có thể dùng `CAI_DAT_WINDOWS.cmd` để cài thư mục extension và bộ hỗ trợ cập nhật, hoặc chọn Load unpacked thủ công vào thư mục `extension`. Bộ hỗ trợ Windows được kế thừa từ gói 0.17.0 đã có; trình cài trong gói mới kiểm tra phiên bản 0.22.0. Phiên này không chạy bộ cài, không thay đăng ký Native Messaging và không cập nhật tiện ích đang cài trên máy anh.

## Kiểm chứng và giới hạn

- Qua kiểm tra cú pháp JavaScript, tham chiếu tệp manifest và cấu trúc gói.
- Qua 10 kiểm thử logic/lưu trữ; 13 kiểm thử DOM và hàng đợi bằng JSDOM; đối chiếu riêng 29 dòng DOM thật và phân trang 1/2/3 anh đã gửi.
- Các ca bao gồm 10/25/50 bản ghi mỗi trang, danh sách co lại, dừng/tiếp tục, đổi preset, đổi ID giữa bước chờ, lỗi sau gửi, thông báo thành công cũ, hai tab tranh khóa và khôi phục phiên gián đoạn.
- **Chưa kiểm thử chuyển văn bản trên máy chủ iOffice thật**, giao diện Chrome thật, cài đặt/cập nhật Native Messaging hoặc dịch vụ AI/Tracker trong phiên này. JSDOM có mô phỏng khả năng hiển thị, không phải kiểm thử bố cục.
- Chỉ ghi “Đã chuyển” tự động khi có thông báo mới nêu chuyển/gửi thành công và nút gửi không còn hiển thị. Nếu iOffice dùng một dạng thông báo khác, hàng đợi dừng để kiểm tra, không coi việc đóng hộp thoại hoặc HTTP 200 là đủ.

Nên kiểm tra một văn bản trước, rồi chạy một trang, sau đó mới chạy nhiều trang. Nội dung nhật ký có thông tin văn bản; chỉ chia sẻ khi cần thiết.
