/* DOM adapter based on the supplied Ea Ly list and existing recipient selectors. */
(() => {
  'use strict';
  const C = IOfficeBatchCore;
  const RECIPIENTS = {
    main: 'input[name="rd_unit_emp"],input[name="rd_unit_noibo_emp"]',
    coord: 'input[name="chk_unit_emp_xuly"],input[name="chk_unit_noibo_xuly"]',
    view: 'input[name="chk_unit_emp_xem"],input[name="chk_unit_noibo_xem"]'
  };
  const alerts = '[role="alert"],.alert,.toast,.toast-message,.swal2-popup,.bootbox-body,.ui-pnotify-text,.jGrowl-message,.notifyjs-wrapper,.bootstrap-growl';
  const visible = el => !!el && el.isConnected && !!el.getClientRects().length && getComputedStyle(el).visibility !== 'hidden' && getComputedStyle(el).display !== 'none';
  const controlVisible = el => visible(el) || visible(el?.closest('label') || el?.parentElement);
  const enabled = el => !!el && !el.disabled && el.getAttribute('aria-disabled') !== 'true';
  const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
  const all = (sel, root = document) => [...root.querySelectorAll(sel)];
  const currentId = () => C.norm(document.querySelector('#idVB')?.value || document.querySelector('#hide_docid')?.value);
  const isDetail = () => all('#div_thongtin_chitiet,#modal_detail_doc_popup,#btn_xuly').some(visible);
  function accountEmail() {
    const action = document.querySelector('#btnSearchVB_dsvb')?.getAttribute('onclick') || '';
    return action.match(/pageCache_([^'"\s,]+)/)?.[1] || '';
  }
  function account() {
    const name = C.norm(document.querySelector('#spanFullNameHomePage')?.textContent);
    return name ? `${location.origin}|${name}` : '';
  }
  function scope() {
    const title = C.norm(document.title);
    if (/^Văn bản vào sổ(?:\s*\(\d+\))?$/i.test(title)) return { menu: 'm2268', title };
    if (/^Chưa chuyển xử lý(?:\s*\(\d+\))?$/i.test(title)) return { menu: 'm2269', title };
    throw new Error('Mở danh sách “Văn bản vào sổ” hoặc “Chưa chuyển xử lý” để lập hàng đợi.');
  }
  function rows(selected = false) {
    return all('tr[id^="vb_"][flyid]').filter(visible).filter(row => {
      const box = row.querySelector('input[name="chk_vanban"]');
      return box && (!selected || box.checked);
    }).map(row => {
      const id = row.getAttribute('flyid');
      if (!/^\d+$/.test(id) || row.id !== `vb_${id}` || row.querySelector('input[name="chk_vanban"]').value !== id || row.getAttribute('congvan_dendi') !== '1')
        throw new Error('Dòng danh sách không khớp cấu trúc Văn bản đến đã xác minh.');
      return { id, symbol: row.getAttribute('so_ky_hieu'), title: row.getAttribute('trich_yeu'), sender: row.getAttribute('don_vi_ban_hanh'), element: row };
    });
  }
  function pagination() {
    const lists = all('.pagination').filter(visible);
    if (lists.length > 1) throw new Error('Có nhiều vùng phân trang; chưa xác định được danh sách văn bản.');
    if (!lists.length) return { current: 1, links: [] };
    const root = lists[0];
    const current = Number(C.norm(root.querySelector('li.active')?.textContent));
    if (!Number.isInteger(current) || current < 1) throw new Error('Không đọc được trang hiện tại.');
    const links = all('a[onclick]', root).filter(visible).filter(a => !a.closest('li.disabled')).map(a => ({ element: a, page: Number(a.getAttribute('onclick').match(/^\s*page\.gotoPage\((\d+)\);?\s*$/)?.[1]) })).filter(x => Number.isInteger(x.page) && x.page > 0);
    return { current, links };
  }
  async function waitFor(test, check, ms = 12000) {
    const until = Date.now() + ms;
    while (Date.now() < until) { check(); const result = test(); if (result) return result; await sleep(100); }
    throw new Error('iOffice tải quá thời gian chờ; hàng đợi đã dừng.');
  }
  async function settled(check) {
    let last = '', since = Date.now();
    return waitFor(() => {
      const list = rows();
      const signature = `${pagination().current}|${list.map(x => x.id).join(',')}`;
      if (signature !== last) { last = signature; since = Date.now(); }
      return list.length && Date.now() - since >= 450 ? list : false;
    }, check);
  }
  async function pageTo(link, check) {
    check();
    const old = rows()[0]?.element;
    link.element.click();
    await waitFor(() => pagination().current === link.page && (!old?.isConnected || rows()[0]?.element !== old), check);
    return settled(check);
  }
  async function firstPage(check) {
    for (let i = 0; i < 500; i++) {
      const p = pagination();
      if (p.current === 1) return;
      const link = p.links.filter(x => x.page < p.current).sort((a, b) => a.page - b.page)[0];
      if (!link) throw new Error('Không tìm được nút trở về trang đầu.');
      await pageTo(link, check);
    }
    throw new Error('Phân trang vượt giới hạn kiểm tra.');
  }
  async function collect(mode, check, progress) {
    scope();
    if (isDetail()) throw new Error('Đóng chi tiết văn bản trước khi lập hàng đợi.');
    const size = document.querySelector('#selectPageRec')?.value;
    if (size && !['10','25','50'].includes(size)) throw new Error('Số bản ghi/trang chưa được hỗ trợ.');
    if (mode !== 'all') return C.records(rows(mode === 'selected'));
    await firstPage(check);
    const result = [], seenPages = new Set(), seenIds = new Set();
    for (let i = 0; i < 500; i++) {
      const list = await settled(check), p = pagination();
      if (seenPages.has(p.current)) throw new Error('Phân trang lặp lại; hãy lập lại hàng đợi.');
      seenPages.add(p.current);
      for (const row of list) {
        if (seenIds.has(row.id)) throw new Error('Danh sách thay đổi trong lúc thu thập (ID lặp qua nhiều trang). Hãy lập lại hàng đợi.');
        seenIds.add(row.id); result.push(row);
      }
      if (result.length > 5000) throw new Error('Vượt 5.000 văn bản. Hãy lọc danh sách nhỏ hơn.');
      progress(`Đang thu thập trang ${p.current}: ${result.length} văn bản`);
      const next = p.links.filter(x => x.page > p.current).sort((a, b) => a.page - b.page)[0];
      if (!next) return C.records(result);
      if (next.page !== p.current + 1) throw new Error('Thiếu nút trang kế tiếp; không bỏ qua trang.');
      await pageTo(next, check);
    }
    throw new Error('Vượt 500 trang. Hãy lọc danh sách nhỏ hơn.');
  }
  async function returnToList(menu, check) {
    const link = document.getElementById(menu);
    if (!visible(link) || !enabled(link)) throw new Error('Không tìm thấy menu trở về danh sách.');
    const old = rows()[0]?.element;
    check(); link.click();
    await waitFor(() => !isDetail() && (!old?.isConnected || rows()[0]?.element !== old), check);
    // An empty list is valid after the final document has been sent.
    await sleep(500); check();
  }
  async function open(item, menu, check) {
    await returnToList(menu, check);
    if (!rows().length) throw new Error(`Không còn thấy ${item.symbol || item.id} trong danh sách. Kiểm tra trước khi bỏ qua.`);
    await firstPage(check);
    for (let i = 0; i < 500; i++) {
      const list = await settled(check), hit = list.find(x => x.id === item.id);
      if (hit) {
        if (C.norm(hit.symbol) !== item.symbol || C.norm(hit.title) !== item.title) throw new Error('Thông tin văn bản đã đổi so với hàng đợi. Hãy kiểm tra lại.');
        const cell = all('[onclick]', hit.element).filter(visible).find(el => new RegExp(`^\\s*showDocDetail\\(\\s*${item.id}\\s*,`).test(el.getAttribute('onclick')));
        if (!cell) throw new Error('Không tìm thấy thao tác mở đúng ID văn bản.');
        check(); cell.click();
        await waitFor(() => isDetail() && currentId() === item.id, check);
        return;
      }
      const p = pagination(), next = p.links.filter(x => x.page > p.current).sort((a, b) => a.page - b.page)[0];
      if (!next) break;
      if (next.page !== p.current + 1) throw new Error('Thiếu trang khi tìm văn bản.');
      await pageTo(next, check);
    }
    throw new Error(`Không còn thấy ${item.symbol || item.id}. Có thể văn bản đã được xử lý ở nơi khác.`);
  }
  function controls(sel) { return all(sel).filter(controlVisible); }
  function checked(p) {
    for (const role of ['main','coord','view']) {
      const expected = role === 'main' ? [p.main] : p[role];
      const selected = controls(RECIPIENTS[role]).filter(x => x.checked).map(x => C.norm(x.value));
      if (JSON.stringify([...selected].sort()) !== JSON.stringify([...expected].sort())) return false;
    }
    return true;
  }
  async function applyPreset(p, api, check) {
    check();
    if (!await api.ensureRecipients()) throw new Error('Không mở được Thông tin nhận.');
    check();
    await api.captureDirectory();
    const wanted = [];
    for (const role of ['main','coord','view']) {
      for (const key of role === 'main' ? [p.main] : p[role]) {
        const hits = controls(RECIPIENTS[role]).filter(x => C.norm(x.value) === key);
        if (hits.length !== 1 || !enabled(hits[0])) throw new Error(`Người nhận ${key} không khớp duy nhất hoặc đã bị khóa (${role}).`);
        wanted.push(hits[0]);
      }
    }
    // Validate all IDs before touching any checkbox; no fuzzy name matching.
    for (const el of controls(Object.values(RECIPIENTS).join(','))) {
      check(); if (el.checked && !api.setChecked(el, false)) throw new Error('Không bỏ được lựa chọn người nhận cũ.');
    }
    for (const el of wanted) { check(); if (!api.setChecked(el, true)) throw new Error('Không chọn được người nhận.'); }
    await sleep(200); check();
    if (!checked(p)) throw new Error('Trạng thái người nhận không khớp preset sau khi áp dụng.');
  }
  function sendButton() {
    const el = document.getElementById('btn_action_send');
    if (!visible(el) || !enabled(el) || !/^Chuyển$/i.test(C.norm(el.value || el.textContent))) throw new Error('Không tìm thấy nút Chuyển của Thông tin nhận.');
    return el;
  }
  function watchTransfer(button, timeout = 20000) {
    let finish, outcome = '', evidence = '', finished = false;
    const known = new WeakMap(all(alerts).map(el => [el, visible(el) ? C.norm(el.textContent) : '']));
    const inspect = () => {
      for (const el of all(alerts).filter(visible)) {
        const text = C.norm(el.textContent);
        if (text === known.get(el)) continue;
        known.set(el, text);
        const kind = C.classify(text);
        if (kind === 'failure' || (kind === 'success' && outcome !== 'failure')) { outcome = kind; evidence = text.slice(0, 400); }
      }
      if (outcome === 'failure') finish({ ok: false, error: evidence });
      else if (outcome === 'success' && !visible(button)) finish({ ok: true, evidence });
    };
    const observer = new MutationObserver(inspect);
    let timer, poll;
    const promise = new Promise(resolve => {
      finish = result => { if (finished) return; finished = true; observer.disconnect(); clearTimeout(timer); clearInterval(poll); resolve(result); };
      observer.observe(document.body, { subtree: true, childList: true, characterData: true, attributes: true, attributeFilter: ['class','style'] });
      poll = setInterval(inspect, 100);
      timer = setTimeout(() => finish({ ok: false, error: 'Chưa có thông báo Chuyển thành công mới cùng với việc đóng biểu mẫu. Kiểm tra iOffice; tiện ích không tự gửi lại.' }), timeout);
    });
    return { promise, cancel: () => finish({ ok: false, error: 'Đã hủy theo dõi trước khi gửi.' }) };
  }
  globalThis.IOfficeBatchDOM = { visible, account, accountEmail, scope, rows, pagination, collect, open, returnToList, currentId, applyPreset, checked, sendButton, watchTransfer, sleep };
})();
