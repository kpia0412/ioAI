/* Single writer in the MV3 worker; a session lease prevents two tabs sending together. */
(() => {
  'use strict';
  const KEY = 'ioffice_clerk_batch_v1', LOCK = 'ioffice_clerk_batch_lease_v1';
  let serial = Promise.resolve();
  async function handle(m, sender) {
    const now = Date.now();
    const raw = await chrome.storage.local.get(KEY);
    const session = await chrome.storage.session.get(LOCK);
    const lease = session[LOCK];
    let q = raw[KEY] || null;
    const owned = lease && lease.tabId === sender.tab.id && lease.token === m.token && lease.until > now;
    const active = lease && lease.until > now;
    const live = active && !owned;
    if (m.action === 'get') return { queue: q, locked: Boolean(live), active: Boolean(active) };
    if (!m.token || typeof m.token !== 'string') throw new Error('Thiếu mã phiên hàng đợi.');
    if (m.action === 'acquire') {
      if (typeof iofficeUpdateApplying !== 'undefined' && iofficeUpdateApplying) throw new Error('Tiện ích đang cập nhật.');
      if (live) throw new Error('Hàng đợi đang chạy ở tab iOffice khác.');
      if (!owned) {
        q = IOfficeBatchCore.recover(q);
        if (q) await chrome.storage.local.set({ [KEY]: q });
      }
      await chrome.storage.session.set({ [LOCK]: { tabId: sender.tab.id, token: m.token, until: now + 45000 } });
      return { queue: q };
    }
    if (!owned) throw new Error('Đã mất quyền chạy hàng đợi. Dừng để tránh gửi trùng.');
    if (m.action === 'heartbeat') {
      await chrome.storage.session.set({ [LOCK]: { ...lease, until: now + 45000 } });
      return {};
    }
    if (m.action === 'release') { await chrome.storage.session.remove(LOCK); return {}; }
    if (m.action === 'save') {
      const next = m.queue;
      const states = new Set(['pending','processing','sending','sent','uncertain','skipped','error']);
      if (!next || next.schema !== 1 || !next.id || !Array.isArray(next.items) || next.items.length > 5000 ||
          next.items.some(x => !/^\d+$/.test(x.id) || !states.has(x.status)) ||
          new Set(next.items.map(x => x.id)).size !== next.items.length) throw new Error('Dữ liệu hàng đợi không hợp lệ.');
      await chrome.storage.local.set({ [KEY]: next });
      return { queue: next };
    }
    throw new Error('Thao tác hàng đợi không được hỗ trợ.');
  }
  chrome.runtime.onMessage.addListener((m, sender, reply) => {
    if (m?.type !== 'IOFFICE_BATCH') return;
    if (sender.id !== chrome.runtime.id || !sender.tab || sender.frameId !== 0 ||
        !/^https:\/\/ioffice\.vnptdaklak\.vn\/qlvbdh_dlk\//.test(sender.url || '')) { reply({ ok: false, error: 'Nguồn yêu cầu không hợp lệ.' }); return; }
    const task = serial.then(() => handle(m, sender));
    serial = task.catch(() => {});
    task.then(data => reply({ ok: true, ...data })).catch(e => reply({ ok: false, error: e.message }));
    return true;
  });
  chrome.tabs.onRemoved.addListener(tabId => {
    serial = serial.then(async () => {
      const raw = await chrome.storage.session.get(LOCK);
      if (raw[LOCK]?.tabId === tabId) await chrome.storage.session.remove(LOCK);
    }).catch(() => {});
  });
})();
