(() => {
  'use strict';
  const C = IOfficeBatchCore, D = IOfficeBatchDOM;
  const KEY = 'ioffice_clerk_batch_v1';
  const token = crypto.randomUUID();
  let q = null, active = false, stopped = false, timer = null, lockRefreshTimer = null, leaseError = '', mounted = false, initialized = false, locked = false;
  let api, panel, message, list, scopeSelect, collectBtn, startBtn, stopBtn, newBtn, exportBtn;
  const labels = { pending: 'Chờ', processing: 'Đang mở', sending: 'Đang chờ xác nhận', sent: 'Đã chuyển', uncertain: 'Cần kiểm tra', skipped: 'Đã bỏ qua', error: 'Lỗi trước khi gửi' };
  async function rpc(action, extra = {}) {
    const result = await chrome.runtime.sendMessage({ type: 'IOFFICE_BATCH', token, action, ...extra });
    if (!result?.ok) throw new Error(result?.error || 'Không kết nối được hàng đợi. Hãy F5 sau khi tiện ích cập nhật.');
    return result;
  }
  function note(text) { message.textContent = text; }
  function check(stop = true) {
    if (stop && stopped) throw new Error('Đã yêu cầu dừng hàng đợi.');
    if (leaseError) throw new Error(leaseError);
    if (api.getRole() !== 'clerk') throw new Error('Vai trò hiện tại không còn là Văn thư.');
    if (q && D.account() !== q.account) throw new Error('Tài khoản iOffice không khớp hàng đợi đã lưu.');
    if (q?.accountEmail && D.accountEmail() && D.accountEmail() !== q.accountEmail) throw new Error('Tài khoản đăng nhập đã thay đổi.');
  }
  async function save() { q.updatedAt = Date.now(); await rpc('save', { queue: q }); render(); }
  async function acquire() {
    const r = await rpc('acquire'); q = r.queue; locked = false;
    timer = setInterval(() => { void rpc('heartbeat').catch(e => { leaseError = e.message; stopped = true; }); }, 10000);
  }
  async function release() {
    clearInterval(timer); timer = null;
    try { await rpc('release'); } catch (_) {}
  }
  function activity(value) { active = value; api.onActivity(value); render(); }
  function render() {
    if (!panel) return;
    panel.hidden = api.getRole() !== 'clerk';
    collectBtn.hidden = !!q?.collected;
    collectBtn.disabled = active || locked;
    scopeSelect.disabled = active || !!q?.collected;
    startBtn.hidden = !q?.collected;
    startBtn.disabled = active || locked || !q?.items.some(x => x.status === 'pending') || q.items.some(x => ['sending','uncertain','error'].includes(x.status));
    stopBtn.hidden = !active;
    stopBtn.disabled = stopped;
    newBtn.hidden = !q;
    newBtn.disabled = active || locked;
    exportBtn.hidden = !q;
    const count = C.counts(q);
    panel.querySelector('[data-summary]').textContent = q ? `${count.sent}/${count.total} đã chuyển · ${count.skipped} bỏ qua · ${count.uncertain + count.error} cần kiểm tra` : 'Lập danh sách trước, sau đó bắt đầu chuyển theo preset.';
    panel.querySelector('[data-preset]').textContent = q ? `Preset cố định: ${q.presetLabel || q.preset.main} · ${q.preset.coord.length} phối hợp · ${q.preset.view.length} xem để biết` : '';
    startBtn.textContent = count.sent ? 'Tiếp tục chuyển theo preset' : 'Bắt đầu chuyển theo preset';
    list.replaceChildren();
    for (const item of q?.items || []) {
      const row = document.createElement('div'); row.className = 'batch-row';
      const text = document.createElement('span'); text.textContent = `${labels[item.status] || item.status} · ${item.symbol || item.id} · ${item.title}`; row.append(text);
      if (item.note) { const small = document.createElement('small'); small.textContent = item.note; row.append(small); }
      if (!active && !locked && ['uncertain','error'].includes(item.status)) {
        const choices = item.status === 'uncertain' ? [['sent','Đã kiểm tra trên iOffice: đã chuyển'],['skipped','Bỏ qua văn bản này']] : [['pending','Thử lại sau khi sửa lỗi'],['skipped','Bỏ qua văn bản này']];
        for (const [status, label] of choices) {
          const b = document.createElement('button'); b.type = 'button'; b.textContent = label;
          b.onclick = () => void resolveItem(item.id, status); row.append(b);
        }
      }
      list.append(row);
    }
  }
  async function operation(work) {
    if (active || api.getBusy()) return;
    stopped = false; leaseError = ''; activity(true);
    try { await acquire(); await work(); }
    catch (e) { note(e.message); }
    finally { await release(); activity(false); }
  }
  async function collect() {
    await operation(async () => {
      if (q?.collected && q.items.some(x => !C.terminal(x))) throw new Error('Còn hàng đợi chưa hoàn tất. Xuất nhật ký hoặc kết thúc hàng đợi trước.');
      const cfg = await chrome.storage.local.get(null), p = C.preset(cfg);
      const account = D.account(), source = D.scope();
      if (!account) throw new Error('Chưa xác định được tài khoản iOffice.');
      q = { schema: 1, id: crypto.randomUUID(), version: '0.22.0', account, accountEmail: D.accountEmail(), menu: source.menu, sourceTitle: source.title, scope: scopeSelect.value, preset: p,
        presetLabel: (cfg.clerkRecipientDirectory || []).find(x => x.key === p.main)?.name || p.main,
        createdAt: Date.now(), status: 'collecting', collected: false, items: [] };
      await save();
      try {
        q.items = await D.collect(q.scope, () => { check(); if (D.scope().menu !== q.menu) throw new Error('Danh sách đã thay đổi trong lúc thu thập.'); }, note);
        if (!q.items.length) throw new Error('Không có văn bản trong phạm vi đã chọn.');
        q.collected = true; q.status = 'ready'; await save();
        note(`Đã chốt ${q.items.length} văn bản. Kiểm tra danh sách và preset rồi bấm Bắt đầu chuyển.`);
      } catch (e) { q.status = 'paused'; q.collected = false; await save(); throw e; }
    });
  }
  async function preSend(item) {
    check();
    if (D.currentId() !== item.id) throw new Error('Văn bản đang mở không khớp ID trong hàng đợi.');
    const cfg = await chrome.storage.local.get(null);
    if (cfg.userRole !== 'clerk' || cfg.iofficeAssistantEnabled === false) throw new Error('Vai trò hoặc trạng thái tiện ích đã đổi.');
    if (C.fingerprint(C.preset(cfg)) !== C.fingerprint(q.preset)) throw new Error('Preset đã thay đổi. Hoàn tất hoặc lập lại hàng đợi với preset mới.');
    await rpc('heartbeat'); check();
    if (D.currentId() !== item.id) throw new Error('Đã đổi văn bản trong lúc kiểm tra trước khi Chuyển.');
    if (!D.checked(q.preset)) throw new Error('Người nhận trên iOffice đã thay đổi. Chưa gửi.');
  }
  async function run() {
    await operation(async () => {
      if (!q?.collected) throw new Error('Hãy lập danh sách hoàn chỉnh trước.');
      check();
      if (q.items.some(x => ['uncertain','error'].includes(x.status))) throw new Error('Kiểm tra văn bản đang lỗi hoặc chưa rõ kết quả trước khi tiếp tục.');
      q.status = 'running'; await save();
      for (const item of q.items.filter(x => x.status === 'pending')) {
        let clicked = false, watcher = null;
        try {
          check(); item.status = 'processing'; item.note = ''; await save();
          note(`Đang mở ${item.symbol || item.id}…`);
          await D.open(item, q.menu, check);
          await D.applyPreset(q.preset, api, () => { check(); if (D.currentId() !== item.id) throw new Error('Đã đổi văn bản khi áp preset.'); });
          await preSend(item);
          const button = D.sendButton();
          item.status = 'sending'; await save(); // Durable before the irreversible click.
          await preSend(item);
          if (button !== D.sendButton() || !button.isConnected) throw new Error('Biểu mẫu Chuyển đã thay đổi.');
          watcher = D.watchTransfer(button);
          clicked = true; button.click();
          note(`Đã gửi lệnh cho ${item.symbol || item.id}; đang chờ iOffice xác nhận…`);
          const result = await watcher.promise;
          if (!result.ok) throw new Error(result.error);
          item.status = 'sent'; item.note = result.evidence; item.updatedAt = Date.now(); await save();
          if (stopped) break;
          await D.sleep(350);
        } catch (e) {
          watcher?.cancel();
          if (item.status !== 'sent') item.status = clicked ? 'uncertain' : (stopped && !leaseError ? 'pending' : 'error');
          item.note = e.message; item.updatedAt = Date.now(); q.status = 'paused';
          await save(); note(e.message); return;
        }
      }
      q.status = q.items.every(C.terminal) ? 'completed' : 'paused'; await save();
      note(q.status === 'completed' ? 'Đã hoàn tất hàng đợi. Có thể xuất nhật ký hoặc lập đợt mới.' : 'Đã dừng. Tiến độ được lưu; bấm Tiếp tục khi sẵn sàng.');
      if (q.status === 'completed' && !stopped) {
        try { await D.returnToList(q.menu, () => check(false)); } catch (_) { /* Transfer receipts are already durable. */ }
      }
    });
  }
  async function resolveItem(id, status) {
    await operation(async () => {
      check(); const item = q?.items.find(x => x.id === id);
      if (!item || !['error','uncertain'].includes(item.status)) throw new Error('Trạng thái văn bản đã thay đổi.');
      if (item.status === 'uncertain' && status === 'pending') throw new Error('Không tự gửi lại văn bản chưa rõ kết quả.');
      item.status = status; item.note = status === 'sent' ? 'Người dùng xác nhận đã kiểm tra trên iOffice.' : status === 'skipped' ? 'Người dùng chủ động bỏ qua.' : 'Người dùng yêu cầu thử lại lỗi trước khi gửi.';
      item.updatedAt = Date.now(); q.status = q.items.every(C.terminal) ? 'completed' : 'paused'; await save(); note('Đã lưu kết quả kiểm tra.');
    });
  }
  async function newQueue() {
    if (active || locked || !q) return;
    const unfinished = q.items.some(x => !C.terminal(x));
    if (unfinished && !window.confirm('Kết thúc hàng đợi này? Tiện ích sẽ lưu các văn bản còn lại là Bỏ qua. Bạn có thể xuất nhật ký trước khi lập đợt mới.')) return;
    await operation(async () => {
      check();
      for (const x of q.items) if (!C.terminal(x)) { x.status = 'skipped'; x.note = 'Người dùng kết thúc hàng đợi.'; }
      q.status = 'completed'; q.collected = false; await save();
      note('Đã kết thúc đợt này. Xuất nhật ký trước khi lập hàng đợi mới nếu cần giữ lịch sử.');
    });
  }
  function exportLog() {
    if (!q) return;
    const url = URL.createObjectURL(new Blob([JSON.stringify(q, null, 2)], { type: 'application/json' }));
    const a = document.createElement('a'); a.href = url; a.download = `ioffice-batch-${new Date(q.createdAt).toISOString().slice(0,10)}-${q.id.slice(0,8)}.json`; a.click(); setTimeout(() => URL.revokeObjectURL(url), 1000);
  }
  async function refresh() {
    clearTimeout(lockRefreshTimer);
    try { const r = await rpc('get'); if (!active) { q = r.active ? r.queue : C.recover(r.queue); locked = r.locked; } }
    catch (e) { if (message) note(e.message); locked = true; }
    initialized = true; render();
    // session storage events may not be exposed to content scripts. Refresh only
    // while another owner blocks this visible tab, so lease expiry cannot strand UI.
    if (locked && !active && !document.hidden) lockRefreshTimer = setTimeout(() => void refresh(), 5000);
  }
  function mount(options) {
    if (mounted) return; mounted = true; api = options;
    const style = document.createElement('style');
    style.textContent = '.clerk-batch{margin:10px 0;padding:10px;border:1px solid #b9cdec;border-radius:10px;background:#f4f8ff;color:#16365d;font:12px/1.5 Arial}.clerk-batch[hidden]{display:none}.clerk-batch h3{font-size:13px;margin:0 0 5px}.clerk-batch p{margin:5px 0}.clerk-batch select{width:100%;margin:5px 0}.clerk-batch button{padding:7px 9px;margin:3px 4px 3px 0;border:1px solid #b4c9df;border-radius:6px;background:white;color:#173c67;cursor:pointer;font-size:11px}.clerk-batch button[data-start]{background:#166534;color:white}.clerk-batch button[data-stop]{color:#b91c1c}.clerk-batch button:disabled{opacity:.45;cursor:not-allowed}.batch-list{max-height:210px;overflow:auto}.batch-row{border-top:1px solid #dbe5ef;padding:6px 0;overflow-wrap:anywhere}.batch-row small{display:block;color:#854d0e}.clerk-batch [role=status]{font-weight:bold}';
    options.root.append(style);
    panel = document.createElement('section'); panel.className = 'clerk-batch';
    panel.innerHTML = '<h3>Văn thư · Hàng đợi văn bản đến</h3><p data-summary></p><p data-preset></p><select aria-label="Phạm vi hàng đợi"><option value="all">Tất cả các trang của danh sách hiện tại</option><option value="page">Chỉ trang hiện tại</option><option value="selected">Các văn bản đã tích trên trang hiện tại</option></select><button data-collect>Lập danh sách</button><button data-start>Bắt đầu chuyển theo preset</button><button data-stop>Dừng</button><button data-new>Kết thúc / đợt mới</button><button data-export>Xuất nhật ký</button><p role="status" aria-live="polite">Mỗi văn bản sẽ được áp preset và chuyển tuần tự. Có thể dừng bất kỳ lúc nào.</p><details><summary>Danh sách và kết quả</summary><div class="batch-list"></div></details>';
    options.body.prepend(panel);
    message = panel.querySelector('[role=status]'); list = panel.querySelector('.batch-list'); scopeSelect = panel.querySelector('select');
    collectBtn = panel.querySelector('[data-collect]'); startBtn = panel.querySelector('[data-start]'); stopBtn = panel.querySelector('[data-stop]'); newBtn = panel.querySelector('[data-new]'); exportBtn = panel.querySelector('[data-export]');
    collectBtn.onclick = () => void collect(); startBtn.onclick = () => void run();
    stopBtn.onclick = () => { stopped = true; note('Đang dừng. Nếu đã gửi lệnh, tiện ích chờ xác nhận văn bản hiện tại rồi dừng.'); render(); };
    newBtn.onclick = () => void newQueue(); exportBtn.onclick = exportLog;
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === 'local' && (changes[KEY] || changes.userRole)) { if (changes.userRole && active) stopped = true; if (!active) void refresh(); }
      if (area === 'session' && changes.ioffice_clerk_batch_lease_v1 && !active) void refresh();
    });
    document.addEventListener('visibilitychange', () => { if (!document.hidden && !active) void refresh(); });
    void refresh();
  }
  globalThis.IOfficeClerkBatch = {
    mount, render, get active() { return active; },
    suppressesAuto: () => !initialized || active || locked || !!(q?.collected && q.status !== 'completed') ||
      !!q?.items.some(x => x.id === D.currentId() && ['sent','uncertain','skipped'].includes(x.status)),
    guardOtherActions: () => active || locked
  };
})();
