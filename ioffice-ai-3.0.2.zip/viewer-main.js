/* Runs only inside same-origin iOffice viewer frames, in the page's MAIN world. */
(() => {
  'use strict';
  if (window === window.top || !/\/web\/viewer\.jsp$/.test(location.pathname)) return;

  const jobs = new Map();
  const clean = (s) => String(s || '').replace(/\u00a0/g, ' ').replace(/\s+/g, ' ').trim();
  const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

  let lastCopiedText = '';

  function rememberCopiedText(value) {
    const t = clean(value);
    if (t.length >= 40 && t.length > lastCopiedText.length) lastCopiedText = t.slice(0, 40000);
  }

  // Không dùng Selection.addRange() nữa. iOffice/PDF.js thường render lại page node,
  // khiến Range vừa tạo đã thuộc một document/root khác và Chrome báo
  // "addRange(): The given range isn't in document." Range.toString() đọc được
  // text node mà không làm thay đổi selection thật của người dùng.
  function selectableText(el) {
    try {
      if (!el || !el.ownerDocument) return '';
      const doc = el.ownerDocument;
      if (el.nodeType !== 1 && el.nodeType !== 11) return '';
      const range = doc.createRange();
      range.selectNodeContents(el);
      return clean(range.toString());
    } catch (_) {
      try { return clean(el?.textContent || ''); } catch (_) { return ''; }
    }
  }

  // Bắt text nếu chính iOffice dùng thao tác copy/clipboard sau OCR.
  try {
    document.addEventListener('copy', () => {
      try { rememberCopiedText(document.getSelection?.()?.toString?.() || window.getSelection?.()?.toString?.() || ''); } catch (_) {}
    }, true);

    const originalExec = document.execCommand?.bind(document);
    if (originalExec) {
      document.execCommand = function(command, ...args) {
        if (String(command || '').toLowerCase() === 'copy') {
          try { rememberCopiedText(document.getSelection?.()?.toString?.() || window.getSelection?.()?.toString?.() || ''); } catch (_) {}
        }
        return originalExec(command, ...args);
      };
    }

    const cb = navigator.clipboard;
    if (cb && typeof cb.writeText === 'function') {
      const originalWriteText = cb.writeText.bind(cb);
      try {
        cb.writeText = function(value) {
          rememberCopiedText(value);
          return originalWriteText(value);
        };
      } catch (_) {}
    }
  } catch (_) {}

  function textFromAttributes(root, push) {
    try {
      const nodes = root.querySelectorAll?.(
        '[data-text],[data-ocr-text],[data-ioffice-ocr-text],[aria-label],[data-content],[data-value],[alt]'
      ) || [];
      for (const el of nodes) {
        if (el.closest?.('button,[role="button"],[role="toolbar"],#toolbarContainer,#secondaryToolbar,.toolbar')) continue;
        for (const name of ['data-text','data-ocr-text','data-ioffice-ocr-text','data-content','data-value','aria-label','alt']) {
          const v = el.getAttribute?.(name);
          if (v && clean(v).length >= 8) push(v);
        }
      }
    } catch (_) {}
  }

  function textFromPageRoot(root, maxChars = 32000, seenRoots = new Set()) {
    if (!root || seenRoots.has(root)) return '';
    seenRoots.add(root);

    const parts = [];
    const push = (value) => {
      const t = clean(value);
      if (t.length >= 12) parts.push(t);
    };

    if (lastCopiedText) push(lastCopiedText);

    const selectors = [
      '.textLayer', '.text-layer', '[class*="textLayer"]', '[class*="text-layer"]',
      '[data-ioffice-ocr-text]', '[data-ocr-text]', '[data-text]',
      '[class*="ocr" i] [class*="text" i]', '[class*="copy" i] [class*="text" i]',
      'textarea', '[contenteditable="true"]', 'svg text'
    ];
    for (const selector of selectors) {
      try {
        for (const el of root.querySelectorAll?.(selector) || []) {
          if (el.closest?.('button,[role="button"],[role="toolbar"],#toolbarContainer,#secondaryToolbar,.toolbar')) continue;
          push(['TEXTAREA','INPUT'].includes(el.tagName) ? el.value : (el.innerText || el.textContent || ''));
        }
      } catch (_) {}
    }
    textFromAttributes(root, push);

    let pageRoots = [];
    try {
      pageRoots = [...(root.querySelectorAll?.(
        '.page,[data-page-number],#viewer,.pdfViewer,#viewerContainer,[role="document"],[class*="pageContainer" i]'
      ) || [])];
    } catch (_) {}
    if (!pageRoots.length && root.body) pageRoots = [root.body];

    for (const page of pageRoots.slice(0, 120)) {
      try {
        push(selectableText(page));
        push(page.innerText || page.textContent || '');

        const pageDoc = page.ownerDocument || document;
        const pageWin = pageDoc.defaultView || window;
        const NF = pageWin.NodeFilter || NodeFilter;
        const walker = pageDoc.createTreeWalker(page, NF.SHOW_TEXT, {
          acceptNode(node) {
            const parent = node.parentElement;
            if (!parent) return NF.FILTER_REJECT;
            if (parent.closest('button,[role="button"],[role="toolbar"],#toolbarContainer,#secondaryToolbar,.toolbar,input,select,option,script,style,noscript')) return NF.FILTER_REJECT;
            const v = clean(node.nodeValue || '');
            return v.length >= 2 ? NF.FILTER_ACCEPT : NF.FILTER_REJECT;
          }
        });
        const textNodes = [];
        let node, charCount = 0;
        while ((node = walker.nextNode()) && charCount < maxChars) {
          const v = node.nodeValue || '';
          textNodes.push(v);
          charCount += v.length + 1;
        }
        push(textNodes.join(' '));
        textFromAttributes(page, push);
      } catch (_) {}
    }

    try {
      const views = window.PDFViewerApplication?.pdfViewer?._pages || [];
      for (const view of Array.isArray(views) ? views : []) {
        const candidates = [
          view?.textLayer?.div,
          view?.textLayer?.textLayerDiv,
          view?.textLayer?.container,
          view?.div,
          view?.canvas?.parentElement
        ];
        for (const el of candidates) {
          if (!el) continue;
          push(selectableText(el));
          push(el.innerText || el.textContent || '');
          textFromAttributes(el, push);
        }
      }
    } catch (_) {}

    try {
      for (const el of root.querySelectorAll?.('*') || []) {
        if (el.shadowRoot) push(textFromPageRoot(el.shadowRoot, maxChars, seenRoots));
        if (el.tagName === 'IFRAME') {
          try {
            const childDoc = el.contentDocument;
            if (childDoc) push(textFromPageRoot(childDoc, maxChars, seenRoots));
          } catch (_) {}
        }
      }
    } catch (_) {}

    const unique = [...new Set(parts.map(clean).filter(Boolean))];
    unique.sort((a, b) => b.length - a.length);
    const best = unique[0] || '';
    if (best.length >= 120) return best.slice(0, maxChars);
    return clean(unique.join('\n\n')).slice(0, maxChars);
  }

  function textFromDom(maxChars = 32000) {
    return textFromPageRoot(document, maxChars);
  }

  async function readPdfText(pdf, { maxPages, maxChars, check }) {
    const totalPages = pdf.numPages;
    const limitPages = Math.min(totalPages, Math.max(1, Math.min(80, maxPages || 20)));
    const charLimit = Math.min(40000, Math.max(500, maxChars || 24000));
    const hw = Math.max(2, Number(navigator.hardwareConcurrency || 4));
    const pageConcurrency = hw >= 12 ? 4 : hw >= 6 ? 3 : 2;
    const pages = [];
    let chars = 0, pagesRead = 0, empty = 0;

    for (let start = 1; start <= limitPages; start += pageConcurrency) {
      check();
      const nums = [];
      for (let n = start; n < Math.min(start + pageConcurrency, limitPages + 1); n++) nums.push(n);
      const batch = await Promise.all(nums.map(async (n) => {
        check();
        const page = await pdf.getPage(n);
        check();
        const content = await page.getTextContent();
        check();
        return clean((content.items || []).map((x) => x.str || '').join(' '));
      }));
      for (const t of batch) {
        pages.push(t); chars += t.length; pagesRead += 1; empty = t ? 0 : empty + 1;
      }
      if (chars >= charLimit || (!chars && empty >= 4)) break;
    }
    return {
      text: clean(pages.join('\n\n')).slice(0, charLimit),
      pagesRead,
      totalPages,
      truncated: pagesRead < totalPages || chars > charLimit
    };
  }

  const NATIVE_OCR_STATE_KEY = 'ioffice-ai-native-ocr-v1';

  function currentViewerToken() {
    try { return new URL(location.href).searchParams.get('file') || ''; }
    catch (_) { return ''; }
  }

  function readNativeOcrState() {
    try {
      const raw = sessionStorage.getItem(NATIVE_OCR_STATE_KEY);
      return raw ? JSON.parse(raw) : null;
    } catch (_) { return null; }
  }

  function writeNativeOcrState(value) {
    try {
      if (value) sessionStorage.setItem(NATIVE_OCR_STATE_KEY, JSON.stringify(value));
      else sessionStorage.removeItem(NATIVE_OCR_STATE_KEY);
    } catch (_) {}
  }

  function restoreNativeOcrFlags(state) {
    if (!state) return;
    try {
      const params = window.parent?.VBParams;
      if (!params) return;
      if (state.hadVbtcFlag) params.config_display_lay_vbtc = state.oldVbtcFlag;
      else delete params.config_display_lay_vbtc;
      if (state.hadVblqFlag) params.config_display_lay_vblq = state.oldVblqFlag;
      else delete params.config_display_lay_vblq;
      if (state.hadVbtcMode) params.vbtc = state.oldVbtcMode;
      else delete params.vbtc;
    } catch (_) {}
  }

  function nativeOcrResults() {
    try {
      // ocr.js khai báo `const ocrResults` ở global lexical scope của chính viewer.
      // window.eval chạy trong đúng realm này nên đọc được Map mà không phụ thuộc cache ở trang cha.
      return window.eval('typeof ocrResults !== "undefined" ? ocrResults : null');
    } catch (_) { return null; }
  }

  function nativeOcrEntries(results) {
    const entries = [];
    try {
      // Không dùng instanceof Map: Map của script/realm khác có thể làm instanceof sai.
      if (results && typeof results.forEach === 'function') {
        results.forEach((value, key) => entries.push([key, value]));
      } else if (results && typeof results === 'object') {
        for (const key of Object.keys(results)) entries.push([key, results[key]]);
      }
    } catch (_) {}
    entries.sort((a, b) => Number(a[0]) - Number(b[0]));
    return entries;
  }

  function nativeOcrPageValue(results, pageNumber) {
    const key = String(pageNumber);
    try {
      if (results && typeof results.get === 'function') {
        return results.get(key) ?? results.get(pageNumber);
      }
    } catch (_) {}
    try { return results?.[key] ?? results?.[pageNumber]; } catch (_) { return undefined; }
  }

  function armNativeIofficeOcr(fileId = '') {
    const params = window.parent?.VBParams;
    if (!params) return false;
    const viewerToken = currentViewerToken();
    const previous = readNativeOcrState();
    const alreadyArmed = previous && previous.viewerToken === viewerToken &&
      String(previous.fileId || '') === String(fileId || params.file_id || '') &&
      String(params.config_display_lay_vbtc ?? '') === '1';
    if (alreadyArmed) return false;

    writeNativeOcrState({
      viewerToken,
      fileId: String(fileId || params.file_id || ''),
      hadVbtcFlag: Object.prototype.hasOwnProperty.call(params, 'config_display_lay_vbtc'),
      oldVbtcFlag: params.config_display_lay_vbtc,
      hadVblqFlag: Object.prototype.hasOwnProperty.call(params, 'config_display_lay_vblq'),
      oldVblqFlag: params.config_display_lay_vblq,
      hadVbtcMode: Object.prototype.hasOwnProperty.call(params, 'vbtc'),
      oldVbtcMode: params.vbtc,
      originalPage: Number(window.PDFViewerApplication?.pdfViewer?.currentPageNumber || 1),
      armedAt: Date.now()
    });

    params.vbtc = true;
    params.config_display_lay_vbtc = '1';
    params.config_display_lay_vblq = '0';
    return true;
  }

  async function waitForNativeIofficeOcr(pdf, opts) {
    const {
      check,
      maxPages = 80,
      maxChars = 40000,
      maxFileBytes = 10 * 1024 * 1024,
      progress,
      fileId = ''
    } = opts || {};

    check();

    // Chặn file lớn trước khi bật OCR để không khởi động worker nặng vô ích.
    try {
      const bytes = await pdf.getData();
      check();
      if (Number(bytes?.byteLength || 0) > maxFileBytes) {
        return {
          text: '', source: 'scan-too-large', status: 'scan-too-large',
          scanSizeBytes: Number(bytes.byteLength || 0), totalPages: pdf.numPages,
          pagesRead: 0, pagesSucceeded: 0, failedPages: [],
          actionLabel: 'Bỏ qua OCR vì vượt giới hạn dung lượng'
        };
      }
    } catch (_) {}

    const viewerToken = currentViewerToken();
    let state = readNativeOcrState();
    const stateMatches = state && state.viewerToken === viewerToken &&
      (!fileId || !state.fileId || String(state.fileId) === String(fileId));

    // Lượt đầu: bật đúng cờ mà ocr.js của iOffice đọc lúc khởi tạo, rồi reload CHÍNH viewer.
    // Parent vẫn sống và readFrameMain sẽ tự gửi lại cùng job id sau reload.
    if (!stateMatches || String(window.parent?.VBParams?.config_display_lay_vbtc ?? '') !== '1') {
      if (!armNativeIofficeOcr(fileId)) {
        return { text:'', source:'ioffice-native-ocr', status:'ocr-failed', totalPages:pdf.numPages, actionLabel:'Không bật được OCR gốc iOffice' };
      }
      progress?.({ page: 0, totalPages: pdf.numPages, phase: 'ocr-native-reload' });
      setTimeout(() => { try { location.reload(); } catch (_) {} }, 0);
      // Script hiện tại sẽ bị hủy bởi reload; không trả kết quả sai cho parent.
      return await new Promise(() => {});
    }

    state = readNativeOcrState() || state;
    const app = window.PDFViewerApplication;
    const viewer = app?.pdfViewer;
    const totalPages = Number(pdf.numPages || 0);
    const pageLimit = Math.min(totalPages, Math.max(1, Math.min(80, Number(maxPages) || 80)));
    const charLimit = Math.min(40000, Math.max(500, Number(maxChars) || 40000));
    const originalPage = Number(state?.originalPage || viewer?.currentPageNumber || 1);
    const failedPages = [];
    let pagesRead = 0;
    let pagesSucceeded = 0;

    try {
      // Chờ ocr.js khởi tạo biến lexical ocrResults. Nếu Tesseract/lang model tải chậm,
      // loop này vẫn nằm trong timeout chung của viewer job.
      while (!nativeOcrResults()) {
        check();
        await sleep(120);
      }

      for (let pageNumber = 1; pageNumber <= pageLimit; pageNumber++) {
        check();
        let results = nativeOcrResults();
        let value = nativeOcrPageValue(results, pageNumber);
        let text = clean(value?.data?.text || '');

        if (!text) {
          progress?.({ page: pageNumber, totalPages, phase: 'ocr-page-start' });
          try {
            if (viewer && Number(viewer.currentPageNumber || 0) !== pageNumber) {
              viewer.currentPageNumber = pageNumber;
            }
          } catch (_) {}

          // Đợi chính ocr.js của iOffice xử lý canvas của trang vừa render.
          while (true) {
            check();
            results = nativeOcrResults();
            value = nativeOcrPageValue(results, pageNumber);
            if (value && value !== 'processing' && typeof value?.data?.text === 'string') break;
            await sleep(180);
          }
          text = clean(value?.data?.text || '');
        }

        pagesRead += 1;
        if (text) {
          pagesSucceeded += 1;
          progress?.({ page: pageNumber, totalPages, phase: 'ocr-page-done', chars: text.length });
        } else {
          failedPages.push(pageNumber);
          progress?.({ page: pageNumber, totalPages, phase: 'ocr-page-error', error: 'OCR không trả text.' });
        }
      }

      const entries = nativeOcrEntries(nativeOcrResults())
        .filter(([page, value]) => Number(page) <= pageLimit && value && value !== 'processing' && typeof value?.data?.text === 'string')
        .map(([page, value]) => [Number(page), clean(value.data.text || '')])
        .filter(([, text]) => text);

      const fullText = entries.map(([page, text]) => `[Trang ${page}] ${text}`).join('\n\n');
      const text = clean(fullText).slice(0, charLimit);
      const partial = failedPages.length > 0 || pagesSucceeded < pageLimit || pageLimit < totalPages;

      return {
        text,
        source: 'ioffice-native-ocr',
        status: text.length >= 120 ? (partial ? 'ocr-partial' : 'ocr-text') : 'ocr-weak',
        pagesRead,
        pagesSucceeded,
        failedPages,
        totalPages,
        ocrPartial: partial,
        truncated: pageLimit < totalPages || fullText.length > charLimit,
        actionLabel: partial
          ? `OCR gốc iOffice · ${pagesSucceeded}/${pageLimit} trang có nội dung`
          : `OCR gốc iOffice · ${pagesSucceeded}/${pageLimit} trang`
      };
    } catch (error) {
      if (/Đã dừng|Hết thời gian/i.test(String(error?.message || ''))) throw error;
      return {
        text:'', source:'ioffice-native-ocr', status:'ocr-failed',
        pagesRead, pagesSucceeded, failedPages, totalPages, ocrPartial:true,
        actionLabel:`OCR gốc iOffice gặp lỗi: ${String(error?.message || error || 'không rõ lỗi')}`
      };
    } finally {
      try { if (viewer && originalPage >= 1 && originalPage <= totalPages) viewer.currentPageNumber = originalPage; } catch (_) {}
      restoreNativeOcrFlags(state);
      writeNativeOcrState(null);
    }
  }

  async function waitForOcrText(pdf, opts) {
    const { check, maxPages, maxChars, maxFileBytes, progress, fileId = '' } = opts;

    // Nếu chính viewer đã có kết quả OCR gốc, lấy thẳng từ ocrResults cùng realm.
    const existing = nativeOcrEntries(nativeOcrResults())
      .filter(([, value]) => value && value !== 'processing' && typeof value?.data?.text === 'string')
      .slice(0, Math.max(1, Math.min(80, Number(maxPages) || 80)));
    if (existing.length) {
      const text = clean(existing.map(([page, value]) => `[Trang ${Number(page)}] ${value.data.text || ''}`).join('\n\n')).slice(0, maxChars);
      if (text.length >= 120) {
        return {
          text,
          source:'ioffice-native-ocr',
          status:'ocr-text',
          pagesRead:existing.length,
          pagesSucceeded:existing.length,
          failedPages:[],
          totalPages:pdf.numPages,
          actionLabel:'Dùng OCR gốc iOffice đã có trong viewer'
        };
      }
    }

    // Không tự OCR bằng worker riêng của tiện ích. Chỉ kích hoạt đúng ocr.js/Tesseract của iOffice.
    return waitForNativeIofficeOcr(pdf, {
      check,
      maxPages,
      maxChars,
      maxFileBytes:Number(maxFileBytes) || 10 * 1024 * 1024,
      progress,
      fileId
    });
  }

  window.addEventListener('message', async (event) => {
    if (event.source !== parent || event.origin !== location.origin) return;
    const m = event.data;
    if (m?.channel !== 'ioffice-reader-v2' || typeof m.id !== 'string') return;
    if (m.type === 'cancel') { jobs.get(m.id)?.abort(); return; }
    if (m.type !== 'read' || jobs.has(m.id)) return;

    const controller = new AbortController();
    jobs.set(m.id, controller);
    // Stable 1.3.2: timeout của viewer phải khớp với timeout parent. Bản 1.3.1 ép tối thiểu 12s
    // trong khi parent thường chỉ chờ 6-7s, nên parent hủy job trước khi PDF.js đọc xong.
    // OCR nếu được bật sẽ tự truyền timeout dài hơn; đọc text thường dùng đúng ngân sách caller.
    const overallMs = Math.min(185000, Math.max(2200, Number(m.timeoutMs) || 6000));
    const until = Date.now() + overallMs;
    const check = () => {
      if (controller.signal.aborted) throw new Error('Đã dừng đọc viewer.');
      if (Date.now() > until) throw new Error('Hết thời gian đọc/OCR viewer.');
    };

    let output;
    try {
      let app;
      while (!(app = window.PDFViewerApplication)?.pdfDocument) { check(); await sleep(80); }
      const pdf = app.pdfDocument;
      const maxPages = Math.min(80, Math.max(1, Number(m.maxPages) || 20));
      const maxChars = Math.min(40000, Math.max(500, Number(m.maxChars) || 24000));

      const initial = await readPdfText(pdf, { maxPages, maxChars, check });
      output = { ...initial, source: 'pdf-main-world', status: initial.text.length >= 120 ? 'text' : 'scan-no-text' };

      // Nếu đã xác định không có lớp chữ, lấy đúng kích thước PDF đang mở để chặn >10 MB
      // trước khi hỏi người dùng OCR. Không giữ bytes trong kết quả.
      if (initial.text.length < 120 && m.tryIofficeOcr === false && m.captureScanBinary === false) {
        try {
          const bytes = await pdf.getData();
          check();
          output.scanSizeBytes = Number(bytes?.byteLength || 0);
          if (output.scanSizeBytes > (Number(m.maxFileBytes) || 10 * 1024 * 1024)) output.status = 'scan-too-large';
        } catch (_) {}
      }

      // Scan PDF: OCR chỉ chạy khi parent đã bật tryIofficeOcr sau khi người dùng đồng ý.
      if (initial.text.length < 120 && m.tryIofficeOcr !== false) {
        const left = Math.max(5000, until - Date.now() - 1200);
        const progress = (data) => {
          try {
            parent.postMessage({
              channel: 'ioffice-reader-v2',
              id: m.id,
              type: 'progress',
              progress: data || {}
            }, event.origin);
          } catch (_) {}
        };
        const ocr = await waitForOcrText(pdf, {
          check,
          signal: controller.signal,
          maxPages,
          maxChars,
          timeoutMs: Math.min(180000, left),
          maxFileBytes: Number(m.maxFileBytes) || 10 * 1024 * 1024,
          progress,
          fileId: String(m.fileId || '')
        });
        check();
        if ((ocr.text || '').length >= 120) {
          output = {
            ...output,
            ...ocr,
            text: clean(ocr.text).slice(0, maxChars),
            status: ocr.status === 'ocr-partial' ? 'ocr-partial' : 'ocr-text',
            pagesRead: ocr.pagesRead || output.pagesRead || 0,
            pagesSucceeded: Number(ocr.pagesSucceeded || ocr.pagesRead || 0),
            failedPages: Array.isArray(ocr.failedPages) ? ocr.failedPages : [],
            totalPages: ocr.totalPages || output.totalPages || pdf.numPages,
            ocrPartial: ocr.status === 'ocr-partial' || ocr.ocrPartial === true,
            ocrAction: ocr.actionLabel || ''
          };
        } else {
          output.ocrAttempted = true;
          output.ocrAction = ocr.actionLabel || '';
          output.ocrPartialChars = (ocr.text || '').length;
          if (ocr.status) output.status = ocr.status;
          if (ocr.scanSizeBytes) output.scanSizeBytes = ocr.scanSizeBytes;
          if (ocr.pagesRead) output.pagesRead = ocr.pagesRead;
          if (ocr.totalPages) output.totalPages = ocr.totalPages;
        }
      }

      if ((output.text || '').length < 120 && m.captureScanBinary) {
        const bytes = await pdf.getData();
        check();
        output.scanSizeBytes = bytes.byteLength;
        if (bytes.byteLength <= (Number(m.maxFileBytes) || 10 * 1024 * 1024)) {
          output.scanBytes = bytes;
          output.status = 'scan-ready-for-ai';
        } else {
          output.status = 'scan-too-large';
        }
      }

      check();
      parent.postMessage({ channel: 'ioffice-reader-v2', id: m.id, ok: true, data: output }, event.origin);
    } catch (e) {
      if (!controller.signal.aborted) parent.postMessage({ channel: 'ioffice-reader-v2', id: m.id, ok: false, error: e.message }, event.origin);
    } finally {
      jobs.delete(m.id);
    }
  });
})();
