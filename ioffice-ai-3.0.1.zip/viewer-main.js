/* Runs only inside same-origin iOffice viewer frames, in the page's MAIN world. */
(() => {
  'use strict';
  if (window === window.top || !/\/web\/viewer\.jsp$/.test(location.pathname)) return;

  const jobs = new Map();
  const BRIDGE_REQUEST_ATTR = 'data-ioai-reader-request';
  const BRIDGE_RESPONSE_ATTR = 'data-ioai-reader-response';
  const BRIDGE_PROGRESS_ATTR = 'data-ioai-reader-progress';
  const BRIDGE_READY_ATTR = 'data-ioai-reader-main-ready';
  const PDF_STATE_ATTR = 'data-ioai-pdf-state';
  const PDF_PAGES_ATTR = 'data-ioai-pdf-pages';
  const PDF_CHECKED_ATTR = 'data-ioai-pdf-checked-pages';
  const PDF_CHARS_ATTR = 'data-ioai-pdf-text-chars';
  const PDF_BYTES_ATTR = 'data-ioai-pdf-bytes';
  const clean = (s) => String(s || '').replace(/\u00a0/g, ' ').replace(/\s+/g, ' ').trim();

  try {
    document.documentElement?.setAttribute(BRIDGE_READY_ATTR, '1');
    document.documentElement?.setAttribute('data-ioai-reader-version', '3.0.1');
  } catch (_) {}
  const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

  let lastCopiedText = '';

  function rememberCopiedText(value) {
    const t = clean(value);
    if (t.length >= 40 && t.length > lastCopiedText.length) lastCopiedText = t.slice(0, 40000);
  }

  // Không dùng Selection.addRange() nữa. iOffice/PDF.js thường render lại page node,
  // khiến Range vừa tạo đã thuộc một document/root khác và Chrome báo
  // "addRange(): The given range isn't in document." Range.toString() đọc được
  // text node mà không làm thay đổi selection thật của người dùng.
  function selectableText(el) {
    try {
      if (!el || !el.ownerDocument) return '';
      const doc = el.ownerDocument;
      if (el.nodeType !== 1 && el.nodeType !== 11) return '';
      const range = doc.createRange();
      range.selectNodeContents(el);
      return clean(range.toString());
    } catch (_) {
      try { return clean(el?.textContent || ''); } catch (_) { return ''; }
    }
  }

  // Bắt text nếu chính iOffice dùng thao tác copy/clipboard sau OCR.
  try {
    document.addEventListener('copy', () => {
      try { rememberCopiedText(document.getSelection?.()?.toString?.() || window.getSelection?.()?.toString?.() || ''); } catch (_) {}
    }, true);

    const originalExec = document.execCommand?.bind(document);
    if (originalExec) {
      document.execCommand = function(command, ...args) {
        if (String(command || '').toLowerCase() === 'copy') {
          try { rememberCopiedText(document.getSelection?.()?.toString?.() || window.getSelection?.()?.toString?.() || ''); } catch (_) {}
        }
        return originalExec(command, ...args);
      };
    }

    const cb = navigator.clipboard;
    if (cb && typeof cb.writeText === 'function') {
      const originalWriteText = cb.writeText.bind(cb);
      try {
        cb.writeText = function(value) {
          rememberCopiedText(value);
          return originalWriteText(value);
        };
      } catch (_) {}
    }
  } catch (_) {}

  function textFromAttributes(root, push) {
    try {
      const nodes = root.querySelectorAll?.(
        '[data-text],[data-ocr-text],[data-ioffice-ocr-text],[aria-label],[data-content],[data-value],[alt]'
      ) || [];
      for (const el of nodes) {
        if (el.closest?.('button,[role="button"],[role="toolbar"],#toolbarContainer,#secondaryToolbar,.toolbar')) continue;
        for (const name of ['data-text','data-ocr-text','data-ioffice-ocr-text','data-content','data-value','aria-label','alt']) {
          const v = el.getAttribute?.(name);
          if (v && clean(v).length >= 8) push(v);
        }
      }
    } catch (_) {}
  }

  function textFromPageRoot(root, maxChars = 32000, seenRoots = new Set()) {
    if (!root || seenRoots.has(root)) return '';
    seenRoots.add(root);

    const parts = [];
    const push = (value) => {
      const t = clean(value);
      if (t.length >= 12) parts.push(t);
    };

    if (lastCopiedText) push(lastCopiedText);

    const selectors = [
      '.textLayer', '.text-layer', '[class*="textLayer"]', '[class*="text-layer"]',
      '[data-ioffice-ocr-text]', '[data-ocr-text]', '[data-text]',
      '[class*="ocr" i] [class*="text" i]', '[class*="copy" i] [class*="text" i]',
      'textarea', '[contenteditable="true"]', 'svg text'
    ];
    for (const selector of selectors) {
      try {
        for (const el of root.querySelectorAll?.(selector) || []) {
          if (el.closest?.('button,[role="button"],[role="toolbar"],#toolbarContainer,#secondaryToolbar,.toolbar')) continue;
          push(['TEXTAREA','INPUT'].includes(el.tagName) ? el.value : (el.innerText || el.textContent || ''));
        }
      } catch (_) {}
    }
    textFromAttributes(root, push);

    let pageRoots = [];
    try {
      pageRoots = [...(root.querySelectorAll?.(
        '.page,[data-page-number],#viewer,.pdfViewer,#viewerContainer,[role="document"],[class*="pageContainer" i]'
      ) || [])];
    } catch (_) {}
    if (!pageRoots.length && root.body) pageRoots = [root.body];

    for (const page of pageRoots.slice(0, 120)) {
      try {
        push(selectableText(page));
        push(page.innerText || page.textContent || '');

        const pageDoc = page.ownerDocument || document;
        const pageWin = pageDoc.defaultView || window;
        const NF = pageWin.NodeFilter || NodeFilter;
        const walker = pageDoc.createTreeWalker(page, NF.SHOW_TEXT, {
          acceptNode(node) {
            const parent = node.parentElement;
            if (!parent) return NF.FILTER_REJECT;
            if (parent.closest('button,[role="button"],[role="toolbar"],#toolbarContainer,#secondaryToolbar,.toolbar,input,select,option,script,style,noscript')) return NF.FILTER_REJECT;
            const v = clean(node.nodeValue || '');
            return v.length >= 2 ? NF.FILTER_ACCEPT : NF.FILTER_REJECT;
          }
        });
        const textNodes = [];
        let node, charCount = 0;
        while ((node = walker.nextNode()) && charCount < maxChars) {
          const v = node.nodeValue || '';
          textNodes.push(v);
          charCount += v.length + 1;
        }
        push(textNodes.join(' '));
        textFromAttributes(page, push);
      } catch (_) {}
    }

    try {
      const views = window.PDFViewerApplication?.pdfViewer?._pages || [];
      for (const view of Array.isArray(views) ? views : []) {
        const candidates = [
          view?.textLayer?.div,
          view?.textLayer?.textLayerDiv,
          view?.textLayer?.container,
          view?.div,
          view?.canvas?.parentElement
        ];
        for (const el of candidates) {
          if (!el) continue;
          push(selectableText(el));
          push(el.innerText || el.textContent || '');
          textFromAttributes(el, push);
        }
      }
    } catch (_) {}

    try {
      for (const el of root.querySelectorAll?.('*') || []) {
        if (el.shadowRoot) push(textFromPageRoot(el.shadowRoot, maxChars, seenRoots));
        if (el.tagName === 'IFRAME') {
          try {
            const childDoc = el.contentDocument;
            if (childDoc) push(textFromPageRoot(childDoc, maxChars, seenRoots));
          } catch (_) {}
        }
      }
    } catch (_) {}

    const unique = [...new Set(parts.map(clean).filter(Boolean))];
    unique.sort((a, b) => b.length - a.length);
    const best = unique[0] || '';
    if (best.length >= 120) return best.slice(0, maxChars);
    return clean(unique.join('\n\n')).slice(0, maxChars);
  }

  function textFromDom(maxChars = 32000) {
    return textFromPageRoot(document, maxChars);
  }

  async function readPdfText(pdf, { maxPages, maxChars, check }) {
    const totalPages = pdf.numPages;
    const limitPages = Math.min(totalPages, Math.max(1, Math.min(80, maxPages || 20)));
    const charLimit = Math.min(40000, Math.max(500, maxChars || 24000));
    const hw = Math.max(2, Number(navigator.hardwareConcurrency || 4));
    const pageConcurrency = hw >= 12 ? 4 : hw >= 6 ? 3 : 2;
    const pages = [];
    let chars = 0, pagesRead = 0;

    for (let start = 1; start <= limitPages; start += pageConcurrency) {
      check();
      const nums = [];
      for (let n = start; n < Math.min(start + pageConcurrency, limitPages + 1); n++) nums.push(n);
      const batch = await Promise.all(nums.map(async (n) => {
        check();
        const page = await pdf.getPage(n);
        check();
        const content = await page.getTextContent();
        check();
        return clean((content.items || []).map((x) => x.str || '').join(' '));
      }));
      for (const t of batch) {
        pages.push(t); chars += t.length; pagesRead += 1;
      }
      // Không dừng sau vài trang rỗng: PDF hỗn hợp có thể có các trang scan ở đầu nhưng
      // lớp chữ ở trang sau. Chỉ dừng khi đã đủ ngân sách text hoặc hết số trang cần kiểm tra.
      if (chars >= charLimit) break;
    }
    return {
      text: clean(pages.join('\n\n')).slice(0, charLimit),
      pagesRead,
      totalPages,
      truncated: pagesRead < totalPages || chars > charLimit
    };
  }

  function cachedIofficeOcrText(maxPages = 80, maxChars = 32000, totalPages = 0, expectedFileId = '') {
    try {
      const params = window.parent?.VBParams || null;
      const fileId = String(expectedFileId || params?.file_id || '').trim();
      const cache = Array.isArray(params?.ocrDataCache) ? params.ocrDataCache : [];
      if (!fileId || !cache.length) return null;

      const pageCap = Math.max(1, Math.min(80, Number(maxPages) || 20));
      const expectedPages = Math.max(1, Math.min(pageCap, Number(totalPages) || pageCap));
      const candidates = cache
        .filter((x) => String(x?.file_id || '').trim() === fileId && x?.ocrResults)
        .map((target) => {
          const entries = target.ocrResults instanceof Map
            ? [...target.ocrResults.entries()]
            : Object.entries(target.ocrResults || {});
          const ready = entries
            .filter(([, value]) => value && typeof value === 'object' && value.data && typeof value.data.text === 'string')
            .sort((a, b) => Number(a[0]) - Number(b[0]))
            .slice(0, pageCap);
          return { target, ready };
        })
        .sort((a, b) => b.ready.length - a.ready.length);

      const best = candidates[0];
      // Không giả định cache chỉ có type=vbtc/vblq. Dùng bản cùng file_id có nhiều trang hoàn tất nhất.
      if (!best || best.ready.length < expectedPages) return null;
      const text = clean(best.ready.map(([page, value]) => `[Trang ${Number(page)}] ${value.data.text || ''}`).join('\n\n')).slice(0, maxChars);
      return text.length >= 120 ? {
        text,
        pagesRead: best.ready.length,
        pagesSucceeded: best.ready.length,
        failedPages: [],
        source: 'ioffice-ocr-cache',
        status: 'ocr-text',
        actionLabel: 'Dùng OCR iOffice đã có sẵn'
      } : null;
    } catch (_) {
      return null;
    }
  }

  async function waitForTesseract(check, timeoutMs = 4000) {
    const until = Date.now() + Math.max(500, Math.min(8000, Number(timeoutMs) || 4000));
    while (Date.now() < until) {
      check();
      if (window.Tesseract && typeof window.Tesseract.createWorker === 'function') return window.Tesseract;
      await sleep(100);
    }
    return null;
  }

  async function runDirectTesseractOcr(pdf, opts) {
    const {
      check,
      signal,
      maxPages = 20,
      maxChars = 24000,
      maxFileBytes = 10 * 1024 * 1024,
      progress
    } = opts || {};

    check();

    // Chốt giới hạn dung lượng trước khi khởi tạo OCR nặng.
    let bytes = null;
    try {
      bytes = await pdf.getData();
      check();
      if (bytes?.byteLength > maxFileBytes) {
        return {
          text: '',
          source: 'scan-too-large',
          status: 'scan-too-large',
          scanSizeBytes: bytes.byteLength,
          pagesRead: 0,
          pagesSucceeded: 0,
          failedPages: [],
          totalPages: pdf.numPages,
          actionLabel: 'Bỏ qua OCR vì vượt giới hạn dung lượng'
        };
      }
    } catch (_) {
      // Nếu PDF.js không trả bytes nhưng trang vẫn render được thì vẫn thử OCR.
    }

    const Tess = await waitForTesseract(check, 4500);
    if (!Tess) {
      return {
        text: '',
        source: 'tesseract-unavailable',
        status: 'ocr-unavailable',
        pagesRead: 0,
        pagesSucceeded: 0,
        failedPages: [],
        totalPages: pdf.numPages,
        actionLabel: 'Tesseract của iOffice chưa sẵn sàng'
      };
    }

    const totalPages = Number(pdf.numPages || 0);
    const pageLimit = Math.min(totalPages, Math.max(1, Math.min(80, Number(maxPages) || 20)));
    const charLimit = Math.min(40000, Math.max(500, Number(maxChars) || 24000));
    const parts = [];
    const failedPages = [];
    let pagesRead = 0;
    let pagesSucceeded = 0;
    let worker = null;
    let aborted = false;

    const terminateWorker = () => {
      try {
        const out = worker?.terminate?.();
        if (out?.catch) out.catch(() => {});
      } catch (_) {}
      worker = null;
    };

    const onAbort = () => {
      aborted = true;
      terminateWorker();
    };
    signal?.addEventListener?.('abort', onAbort, { once: true });

    try {
      worker = await Tess.createWorker('vie');
      check();
      await worker.setParameters?.({ tessedit_preserve_interword_spaces: '1' });

      for (let pageNumber = 1; pageNumber <= pageLimit; pageNumber++) {
        check();
        if (aborted) throw new Error('Đã dừng OCR.');

        progress?.({ page: pageNumber, totalPages, phase: 'ocr-page-start' });

        let page = null;
        let canvas = null;
        let pageText = '';
        try {
          page = await pdf.getPage(pageNumber);
          check();

          // PDF hỗn hợp: trang nào đã có lớp chữ đủ tốt thì dùng text đó, không OCR lại.
          try {
            const content = await page.getTextContent();
            pageText = clean((content.items || []).map((x) => x.str || '').join(' '));
          } catch (_) {}

          if (pageText.length < 40) {
            const originalText = pageText;
            const baseViewport = page.getViewport({ scale: 1 });
            const targetWidth = 1450;
            const scale = Math.max(1.45, Math.min(2.35, targetWidth / Math.max(1, baseViewport.width)));
            const viewport = page.getViewport({ scale });
            canvas = document.createElement('canvas');
            canvas.width = Math.max(1, Math.ceil(viewport.width));
            canvas.height = Math.max(1, Math.ceil(viewport.height));
            const ctx = canvas.getContext('2d', { alpha: false });
            if (!ctx) throw new Error('Không tạo được canvas OCR.');
            await page.render({ canvasContext: ctx, viewport }).promise;
            check();

            const recognized = await worker.recognize(canvas.toDataURL('image/png'));
            check();
            const recognizedText = clean(recognized?.data?.text || '');
            pageText = recognizedText.length >= originalText.length ? recognizedText : originalText;
          }

          pagesRead += 1;
          if (pageText) {
            pagesSucceeded += 1;
            // Giữ dấu trang để AI/nhật ký có thể đối chiếu nguồn OCR.
            parts.push(`[Trang ${pageNumber}] ${pageText}`);
          }
          progress?.({ page: pageNumber, totalPages, phase: 'ocr-page-done', chars: pageText.length });
        } catch (error) {
          if (signal?.aborted || aborted) throw error;
          pagesRead += 1;
          failedPages.push(pageNumber);
          progress?.({
            page: pageNumber,
            totalPages,
            phase: 'ocr-page-error',
            error: String(error?.message || error || 'OCR lỗi')
          });
          // Một trang lỗi không làm mất kết quả các trang khác.
        } finally {
          try {
            if (canvas) {
              canvas.width = 1;
              canvas.height = 1;
              canvas.remove?.();
            }
          } catch (_) {}
        }

        // Không giữ chuỗi OCR vô hạn; Reader chỉ cần tối đa charLimit để phân tích.
        if (clean(parts.join('\n\n')).length >= charLimit) break;
      }

      const text = clean(parts.join('\n\n')).slice(0, charLimit);
      const partial = failedPages.length > 0 || pagesRead < totalPages;
      return {
        text,
        source: text.length >= 120 ? 'ioffice-tesseract-vie' : 'ioffice-tesseract-partial',
        status: text.length >= 120 ? (partial ? 'ocr-partial' : 'ocr-text') : 'ocr-weak',
        pagesRead,
        pagesSucceeded,
        failedPages,
        totalPages,
        ocrPartial: partial,
        truncated: pagesRead < totalPages || text.length >= charLimit,
        scanSizeBytes: bytes?.byteLength || 0,
        actionLabel: partial
          ? `OCR Tesseract tiếng Việt của iOffice · ${pagesSucceeded}/${pagesRead} trang có nội dung`
          : 'OCR Tesseract tiếng Việt của iOffice'
      };
    } catch (error) {
      if (signal?.aborted || aborted) throw error;
      return {
        text: clean(parts.join('\n\n')).slice(0, charLimit),
        source: 'ioffice-tesseract-partial',
        status: parts.length ? 'ocr-partial' : 'ocr-failed',
        pagesRead,
        pagesSucceeded,
        failedPages,
        totalPages,
        ocrPartial: true,
        scanSizeBytes: bytes?.byteLength || 0,
        actionLabel: `OCR gặp lỗi: ${String(error?.message || error || 'không rõ lỗi')}`
      };
    } finally {
      signal?.removeEventListener?.('abort', onAbort);
      terminateWorker();
    }
  }

  async function waitForOcrText(pdf, opts) {
    const { check, signal, maxPages, maxChars, timeoutMs = 120000, maxFileBytes, progress, fileId = '' } = opts;
    // 1) Nếu iOffice đã OCR sẵn thì dùng cache, không chạy lại.
    const cached = cachedIofficeOcrText(maxPages, maxChars, pdf.numPages, fileId);
    if (cached) return { ...cached, totalPages: pdf.numPages };

    // 2) DOM/text layer có thể đã có OCR sẵn.
    const already = textFromDom(maxChars);
    if (already.length >= 120) return { text: already, source: 'ioffice-ocr-textlayer', actionLabel: 'OCR/text layer đã sẵn sàng', totalPages: pdf.numPages };
    if (lastCopiedText.length >= 120) return { text: lastCopiedText.slice(0, maxChars), source: 'ioffice-copy-captured', actionLabel: 'Đã bắt text từ thao tác copy của iOffice', totalPages: pdf.numPages };

    // 3) Không tự bấm "Xem dạng copy được": nút đó chỉ chuyển sang Chrome PDF Viewer.
    //    Khi người dùng đã đồng ý OCR, chạy Tesseract tiếng Việt của chính iOffice trên canvas ẩn.
    const direct = await runDirectTesseractOcr(pdf, {
      check,
      signal,
      maxPages,
      maxChars,
      maxFileBytes: Number(maxFileBytes) || 10 * 1024 * 1024,
      progress
    });
    return direct || { text: '', source: 'scan-no-ocr-text', status: 'ocr-failed', totalPages: pdf.numPages, actionLabel: '' };
  }

  async function probePdfState() {
    const root = document.documentElement;
    if (!root) return;
    try {
      let app = null;
      const until = Date.now() + 15000;
      while (!(app = window.PDFViewerApplication)?.pdfDocument && Date.now() < until) await sleep(100);
      const pdf = app?.pdfDocument;
      if (!pdf) return;
      const totalPages = Number(pdf.numPages || 0);
      root.setAttribute(PDF_PAGES_ATTR, String(totalPages || 0));

      // Passive fallback phải nhẹ để không làm chậm PDF bình thường. Chỉ tự xác nhận hoàn toàn
      // với tài liệu ngắn (<=4 trang); tài liệu dài được Reader hỏi qua DOM bridge khi thật sự cần.
      const cap = Math.min(4, Math.max(0, totalPages));
      let checked = 0, chars = 0;
      for (let n = 1; n <= cap; n++) {
        const page = await pdf.getPage(n);
        const content = await page.getTextContent();
        const text = clean((content.items || []).map(x => x.str || '').join(' '));
        chars += text.length;
        checked += 1;
        if (chars >= 120) break;
      }
      root.setAttribute(PDF_CHECKED_ATTR, String(checked));
      root.setAttribute(PDF_CHARS_ATTR, String(chars));
      if (chars >= 120) root.setAttribute(PDF_STATE_ATTR, 'text');
      else if (totalPages > 0 && totalPages <= 4 && checked >= totalPages) root.setAttribute(PDF_STATE_ATTR, 'scan');
      else root.setAttribute(PDF_STATE_ATTR, 'unknown');

      try {
        const bytes = await pdf.getData();
        root.setAttribute(PDF_BYTES_ATTR, String(Number(bytes?.byteLength || 0)));
      } catch (_) {}
    } catch (_) {
      try { root.setAttribute(PDF_STATE_ATTR, 'unknown'); } catch (_) {}
    }
  }

  // Chạy thụ động một lần để top-frame có thể xác nhận scan ngay cả khi message đầu tiên bị lỡ.
  void probePdfState();

  async function executeReaderRequest(m, controller, progress) {
    const overallMs = Math.min(185000, Math.max(2200, Number(m.timeoutMs) || 6000));
    const until = Date.now() + overallMs;
    const check = () => {
      if (controller.signal.aborted) throw new Error('Đã dừng đọc viewer.');
      if (Date.now() > until) throw new Error('Hết thời gian đọc/OCR viewer.');
    };

    let app;
    while (!(app = window.PDFViewerApplication)?.pdfDocument) { check(); await sleep(80); }
    const pdf = app.pdfDocument;
    const maxPages = Math.min(80, Math.max(1, Number(m.maxPages) || 20));
    const maxChars = Math.min(40000, Math.max(500, Number(m.maxChars) || 24000));

    const initial = await readPdfText(pdf, { maxPages, maxChars, check });
    let output = { ...initial, source: 'pdf-main-world', status: initial.text.length >= 120 ? 'text' : 'scan-no-text' };

    if (initial.text.length < 120 && m.tryIofficeOcr === false && m.captureScanBinary === false) {
      try {
        const bytes = await pdf.getData();
        check();
        output.scanSizeBytes = Number(bytes?.byteLength || 0);
        if (output.scanSizeBytes > (Number(m.maxFileBytes) || 10 * 1024 * 1024)) output.status = 'scan-too-large';
      } catch (_) {}
    }

    if (initial.text.length < 120 && m.tryIofficeOcr !== false) {
      const left = Math.max(5000, until - Date.now() - 1200);
      const ocr = await waitForOcrText(pdf, {
        check,
        signal: controller.signal,
        maxPages,
        maxChars,
        timeoutMs: Math.min(180000, left),
        maxFileBytes: Number(m.maxFileBytes) || 10 * 1024 * 1024,
        progress,
        fileId: String(m.fileId || '')
      });
      check();
      if ((ocr.text || '').length >= 120) {
        output = {
          ...output,
          ...ocr,
          text: clean(ocr.text).slice(0, maxChars),
          status: ocr.status === 'ocr-partial' ? 'ocr-partial' : 'ocr-text',
          pagesRead: ocr.pagesRead || output.pagesRead || 0,
          pagesSucceeded: Number(ocr.pagesSucceeded || ocr.pagesRead || 0),
          failedPages: Array.isArray(ocr.failedPages) ? ocr.failedPages : [],
          totalPages: ocr.totalPages || output.totalPages || pdf.numPages,
          ocrPartial: ocr.status === 'ocr-partial' || ocr.ocrPartial === true,
          ocrAction: ocr.actionLabel || ''
        };
      } else {
        output.ocrAttempted = true;
        output.ocrAction = ocr.actionLabel || '';
        output.ocrPartialChars = (ocr.text || '').length;
        if (ocr.status) output.status = ocr.status;
        if (ocr.scanSizeBytes) output.scanSizeBytes = ocr.scanSizeBytes;
        if (ocr.pagesRead) output.pagesRead = ocr.pagesRead;
        if (ocr.totalPages) output.totalPages = ocr.totalPages;
      }
    }

    if ((output.text || '').length < 120 && m.captureScanBinary) {
      const bytes = await pdf.getData();
      check();
      output.scanSizeBytes = bytes.byteLength;
      if (bytes.byteLength <= (Number(m.maxFileBytes) || 10 * 1024 * 1024)) {
        output.scanBytes = bytes;
        output.status = 'scan-ready-for-ai';
      } else {
        output.status = 'scan-too-large';
      }
    }

    check();
    return output;
  }

  async function startReaderJob(m, respond, progress) {
    if (!m || typeof m.id !== 'string' || !m.id) return;
    if (m.type === 'cancel') {
      jobs.get(m.id)?.abort();
      return;
    }
    if (m.type !== 'read' || jobs.has(m.id)) return;

    const controller = new AbortController();
    jobs.set(m.id, controller);
    try {
      const output = await executeReaderRequest(m, controller, progress);
      respond({ channel: 'ioffice-reader-v2', id: m.id, ok: true, data: output });
    } catch (e) {
      if (!controller.signal.aborted) respond({ channel: 'ioffice-reader-v2', id: m.id, ok: false, error: e?.message || String(e) });
    } finally {
      jobs.delete(m.id);
    }
  }

  // Bridge chuẩn qua postMessage.
  window.addEventListener('message', (event) => {
    if (event.source !== parent || event.origin !== location.origin) return;
    const m = event.data;
    if (m?.channel !== 'ioffice-reader-v2' || typeof m.id !== 'string') return;
    const respond = (payload) => {
      try { parent.postMessage(payload, event.origin); } catch (_) {}
    };
    const progress = (data) => respond({ channel:'ioffice-reader-v2', id:m.id, type:'progress', progress:data || {} });
    void startReaderJob(m, respond, progress);
  });

  // Bridge DOM dự phòng. Isolated-world content script và MAIN world cùng nhìn thấy DOM,
  // nên đường này không phụ thuộc việc window.postMessage giữa hai world có bị lỡ hay không.
  function writeBridgeJson(attr, payload) {
    try { document.documentElement?.setAttribute(attr, JSON.stringify(payload)); } catch (_) {}
  }
  async function consumeDomBridgeRequest() {
    const root = document.documentElement;
    if (!root) return;
    const raw = root.getAttribute(BRIDGE_REQUEST_ATTR) || '';
    if (!raw) return;
    let m;
    try { m = JSON.parse(raw); } catch (_) { return; }
    if (!m || typeof m.id !== 'string') return;
    if (root.getAttribute('data-ioai-reader-last-request') === m.id + ':' + String(m.type || '')) return;
    root.setAttribute('data-ioai-reader-last-request', m.id + ':' + String(m.type || ''));
    const respond = (payload) => writeBridgeJson(BRIDGE_RESPONSE_ATTR, payload);
    const progress = (data) => writeBridgeJson(BRIDGE_PROGRESS_ATTR, { id:m.id, progress:data || {}, ts:Date.now() });
    await startReaderJob(m, respond, progress);
  }

  try {
    const root = document.documentElement;
    const observer = new MutationObserver((mutations) => {
      if (mutations.some(x => x.type === 'attributes' && x.attributeName === BRIDGE_REQUEST_ATTR)) void consumeDomBridgeRequest();
    });
    observer.observe(root, { attributes:true, attributeFilter:[BRIDGE_REQUEST_ATTR] });
    void consumeDomBridgeRequest();
  } catch (_) {}

})();
