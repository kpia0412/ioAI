/* Runs only inside same-origin iOffice viewer frames, in the page's MAIN world. */
(() => {
  'use strict';
  if (window === window.top || !/\/web\/viewer\.jsp$/.test(location.pathname)) return;

  const jobs = new Map();
  const clean = (s) => String(s || '').replace(/\u00a0/g, ' ').replace(/\s+/g, ' ').trim();
  const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

  let lastCopiedText = '';

  function rememberCopiedText(value) {
    const t = clean(value);
    if (t.length >= 40 && t.length > lastCopiedText.length) lastCopiedText = t.slice(0, 40000);
  }

  // Không dùng Selection.addRange() nữa. iOffice/PDF.js thường render lại page node,
  // khiến Range vừa tạo đã thuộc một document/root khác và Chrome báo
  // "addRange(): The given range isn't in document." Range.toString() đọc được
  // text node mà không làm thay đổi selection thật của người dùng.
  function selectableText(el) {
    try {
      if (!el || !el.ownerDocument) return '';
      const doc = el.ownerDocument;
      if (el.nodeType !== 1 && el.nodeType !== 11) return '';
      const range = doc.createRange();
      range.selectNodeContents(el);
      return clean(range.toString());
    } catch (_) {
      try { return clean(el?.textContent || ''); } catch (_) { return ''; }
    }
  }

  // Bắt text nếu chính iOffice dùng thao tác copy/clipboard sau OCR.
  try {
    document.addEventListener('copy', () => {
      try { rememberCopiedText(document.getSelection?.()?.toString?.() || window.getSelection?.()?.toString?.() || ''); } catch (_) {}
    }, true);

    const originalExec = document.execCommand?.bind(document);
    if (originalExec) {
      document.execCommand = function(command, ...args) {
        if (String(command || '').toLowerCase() === 'copy') {
          try { rememberCopiedText(document.getSelection?.()?.toString?.() || window.getSelection?.()?.toString?.() || ''); } catch (_) {}
        }
        return originalExec(command, ...args);
      };
    }

    const cb = navigator.clipboard;
    if (cb && typeof cb.writeText === 'function') {
      const originalWriteText = cb.writeText.bind(cb);
      try {
        cb.writeText = function(value) {
          rememberCopiedText(value);
          return originalWriteText(value);
        };
      } catch (_) {}
    }
  } catch (_) {}

  function textFromAttributes(root, push) {
    try {
      const nodes = root.querySelectorAll?.(
        '[data-text],[data-ocr-text],[data-ioffice-ocr-text],[aria-label],[data-content],[data-value],[alt]'
      ) || [];
      for (const el of nodes) {
        if (el.closest?.('button,[role="button"],[role="toolbar"],#toolbarContainer,#secondaryToolbar,.toolbar')) continue;
        for (const name of ['data-text','data-ocr-text','data-ioffice-ocr-text','data-content','data-value','aria-label','alt']) {
          const v = el.getAttribute?.(name);
          if (v && clean(v).length >= 8) push(v);
        }
      }
    } catch (_) {}
  }

  function textFromPageRoot(root, maxChars = 32000, seenRoots = new Set()) {
    if (!root || seenRoots.has(root)) return '';
    seenRoots.add(root);

    const parts = [];
    const push = (value) => {
      const t = clean(value);
      if (t.length >= 12) parts.push(t);
    };

    if (lastCopiedText) push(lastCopiedText);

    const selectors = [
      '.textLayer', '.text-layer', '[class*="textLayer"]', '[class*="text-layer"]',
      '[data-ioffice-ocr-text]', '[data-ocr-text]', '[data-text]',
      '[class*="ocr" i] [class*="text" i]', '[class*="copy" i] [class*="text" i]',
      'textarea', '[contenteditable="true"]', 'svg text'
    ];
    for (const selector of selectors) {
      try {
        for (const el of root.querySelectorAll?.(selector) || []) {
          if (el.closest?.('button,[role="button"],[role="toolbar"],#toolbarContainer,#secondaryToolbar,.toolbar')) continue;
          push(['TEXTAREA','INPUT'].includes(el.tagName) ? el.value : (el.innerText || el.textContent || ''));
        }
      } catch (_) {}
    }
    textFromAttributes(root, push);

    let pageRoots = [];
    try {
      pageRoots = [...(root.querySelectorAll?.(
        '.page,[data-page-number],#viewer,.pdfViewer,#viewerContainer,[role="document"],[class*="pageContainer" i]'
      ) || [])];
    } catch (_) {}
    if (!pageRoots.length && root.body) pageRoots = [root.body];

    for (const page of pageRoots.slice(0, 120)) {
      try {
        push(selectableText(page));
        push(page.innerText || page.textContent || '');

        const pageDoc = page.ownerDocument || document;
        const pageWin = pageDoc.defaultView || window;
        const NF = pageWin.NodeFilter || NodeFilter;
        const walker = pageDoc.createTreeWalker(page, NF.SHOW_TEXT, {
          acceptNode(node) {
            const parent = node.parentElement;
            if (!parent) return NF.FILTER_REJECT;
            if (parent.closest('button,[role="button"],[role="toolbar"],#toolbarContainer,#secondaryToolbar,.toolbar,input,select,option,script,style,noscript')) return NF.FILTER_REJECT;
            const v = clean(node.nodeValue || '');
            return v.length >= 2 ? NF.FILTER_ACCEPT : NF.FILTER_REJECT;
          }
        });
        const textNodes = [];
        let node, charCount = 0;
        while ((node = walker.nextNode()) && charCount < maxChars) {
          const v = node.nodeValue || '';
          textNodes.push(v);
          charCount += v.length + 1;
        }
        push(textNodes.join(' '));
        textFromAttributes(page, push);
      } catch (_) {}
    }

    try {
      const views = window.PDFViewerApplication?.pdfViewer?._pages || [];
      for (const view of Array.isArray(views) ? views : []) {
        const candidates = [
          view?.textLayer?.div,
          view?.textLayer?.textLayerDiv,
          view?.textLayer?.container,
          view?.div,
          view?.canvas?.parentElement
        ];
        for (const el of candidates) {
          if (!el) continue;
          push(selectableText(el));
          push(el.innerText || el.textContent || '');
          textFromAttributes(el, push);
        }
      }
    } catch (_) {}

    try {
      for (const el of root.querySelectorAll?.('*') || []) {
        if (el.shadowRoot) push(textFromPageRoot(el.shadowRoot, maxChars, seenRoots));
        if (el.tagName === 'IFRAME') {
          try {
            const childDoc = el.contentDocument;
            if (childDoc) push(textFromPageRoot(childDoc, maxChars, seenRoots));
          } catch (_) {}
        }
      }
    } catch (_) {}

    const unique = [...new Set(parts.map(clean).filter(Boolean))];
    unique.sort((a, b) => b.length - a.length);
    const best = unique[0] || '';
    if (best.length >= 120) return best.slice(0, maxChars);
    return clean(unique.join('\n\n')).slice(0, maxChars);
  }

  function textFromDom(maxChars = 32000) {
    return textFromPageRoot(document, maxChars);
  }

  async function readPdfText(pdf, { maxPages, maxChars, check }) {
    const totalPages = pdf.numPages;
    const limitPages = Math.min(totalPages, Math.max(1, Math.min(80, maxPages || 20)));
    const charLimit = Math.min(40000, Math.max(500, maxChars || 24000));
    const hw = Math.max(2, Number(navigator.hardwareConcurrency || 4));
    const pageConcurrency = hw >= 12 ? 4 : hw >= 6 ? 3 : 2;
    const pages = [];
    let chars = 0, pagesRead = 0, empty = 0;

    for (let start = 1; start <= limitPages; start += pageConcurrency) {
      check();
      const nums = [];
      for (let n = start; n < Math.min(start + pageConcurrency, limitPages + 1); n++) nums.push(n);
      const batch = await Promise.all(nums.map(async (n) => {
        check();
        const page = await pdf.getPage(n);
        check();
        const content = await page.getTextContent();
        check();
        return clean((content.items || []).map((x) => x.str || '').join(' '));
      }));
      for (const t of batch) {
        pages.push(t); chars += t.length; pagesRead += 1; empty = t ? 0 : empty + 1;
      }
      if (chars >= charLimit || (!chars && empty >= 4)) break;
    }
    return {
      text: clean(pages.join('\n\n')).slice(0, charLimit),
      pagesRead,
      totalPages,
      truncated: pagesRead < totalPages || chars > charLimit
    };
  }

  function cachedIofficeOcrText(maxPages = 80, maxChars = 32000, totalPages = 0) {
    try {
      const params = window.parent?.VBParams || null;
      const fileId = String(params?.file_id || '').trim();
      const cache = Array.isArray(params?.ocrDataCache) ? params.ocrDataCache : [];
      if (!fileId || !cache.length) return null;
      const target = cache.find((x) => String(x?.file_id || '').trim() === fileId && x?.ocrResults);
      if (!target?.ocrResults) return null;
      const entries = target.ocrResults instanceof Map
        ? [...target.ocrResults.entries()]
        : Object.entries(target.ocrResults || {});
      const pageCap = Math.max(1, Math.min(80, Number(maxPages) || 20));
      const expectedPages = Math.max(1, Math.min(pageCap, Number(totalPages) || pageCap));
      const ready = entries
        .filter(([, value]) => value && typeof value === 'object' && value.data && typeof value.data.text === 'string')
        .sort((a, b) => Number(a[0]) - Number(b[0]))
        .slice(0, pageCap);
      // Chỉ dùng cache khi đủ các trang cần đọc. Cache một vài trang do người dùng mới cuộn
      // chưa đủ để thay thế OCR toàn tài liệu.
      if (ready.length < expectedPages) return null;
      const text = clean(ready.map(([, value]) => value.data.text || '').join('\n\n')).slice(0, maxChars);
      return text.length >= 120 ? { text, pagesRead: ready.length, source: 'ioffice-ocr-cache', actionLabel: 'Dùng OCR iOffice đã có sẵn' } : null;
    } catch (_) {
      return null;
    }
  }

  async function waitForTesseract(check, timeoutMs = 4000) {
    const until = Date.now() + Math.max(500, Math.min(8000, Number(timeoutMs) || 4000));
    while (Date.now() < until) {
      check();
      if (window.Tesseract && typeof window.Tesseract.createWorker === 'function') return window.Tesseract;
      await sleep(100);
    }
    return null;
  }

  async function runDirectTesseractOcr(pdf, opts) {
    const {
      check,
      signal,
      maxPages = 20,
      maxChars = 24000,
      maxFileBytes = 10 * 1024 * 1024,
      progress
    } = opts || {};

    check();

    // Chốt giới hạn dung lượng trước khi khởi tạo OCR nặng.
    let bytes = null;
    try {
      bytes = await pdf.getData();
      check();
      if (bytes?.byteLength > maxFileBytes) {
        return {
          text: '',
          source: 'scan-too-large',
          status: 'scan-too-large',
          scanSizeBytes: bytes.byteLength,
          pagesRead: 0,
          totalPages: pdf.numPages,
          actionLabel: 'Bỏ qua OCR vì vượt giới hạn dung lượng'
        };
      }
    } catch (_) {
      // Nếu PDF.js không trả bytes nhưng trang vẫn render được thì vẫn thử OCR.
    }

    const Tess = await waitForTesseract(check, 4500);
    if (!Tess) {
      return {
        text: '',
        source: 'tesseract-unavailable',
        status: 'ocr-unavailable',
        pagesRead: 0,
        totalPages: pdf.numPages,
        actionLabel: 'Tesseract của iOffice chưa sẵn sàng'
      };
    }

    const totalPages = Number(pdf.numPages || 0);
    const pageLimit = Math.min(totalPages, Math.max(1, Math.min(80, Number(maxPages) || 20)));
    const charLimit = Math.min(40000, Math.max(500, Number(maxChars) || 24000));
    const parts = [];
    let pagesRead = 0;
    let worker = null;
    let aborted = false;

    const terminateWorker = () => {
      try {
        const out = worker?.terminate?.();
        if (out?.catch) out.catch(() => {});
      } catch (_) {}
      worker = null;
    };

    const onAbort = () => {
      aborted = true;
      terminateWorker();
    };
    signal?.addEventListener?.('abort', onAbort, { once: true });

    try {
      worker = await Tess.createWorker('vie');
      check();
      await worker.setParameters?.({ tessedit_preserve_interword_spaces: '1' });

      for (let pageNumber = 1; pageNumber <= pageLimit; pageNumber++) {
        check();
        if (aborted) throw new Error('Đã dừng OCR.');

        progress?.({ page: pageNumber, totalPages, phase: 'ocr-page-start' });

        const page = await pdf.getPage(pageNumber);
        check();

        // PDF hỗn hợp: trang nào đã có lớp chữ đủ tốt thì dùng text đó, không OCR lại.
        let pageText = '';
        try {
          const content = await page.getTextContent();
          pageText = clean((content.items || []).map((x) => x.str || '').join(' '));
        } catch (_) {}

        if (pageText.length < 40) {
          const baseViewport = page.getViewport({ scale: 1 });
          const targetWidth = 1450;
          const scale = Math.max(1.45, Math.min(2.35, targetWidth / Math.max(1, baseViewport.width)));
          const viewport = page.getViewport({ scale });
          const canvas = document.createElement('canvas');
          canvas.width = Math.max(1, Math.ceil(viewport.width));
          canvas.height = Math.max(1, Math.ceil(viewport.height));
          const ctx = canvas.getContext('2d', { alpha: false });
          await page.render({ canvasContext: ctx, viewport }).promise;
          check();

          const recognized = await worker.recognize(canvas.toDataURL('image/png'));
          check();
          pageText = clean(recognized?.data?.text || '');
          canvas.width = 1;
          canvas.height = 1;
        }

        pagesRead += 1;
        if (pageText) parts.push(pageText);
        progress?.({ page: pageNumber, totalPages, phase: 'ocr-page-done', chars: pageText.length });

        const reachedLimit = clean(parts.join('\n\n')).length >= charLimit;
        try { page.cleanup?.(); } catch (_) {}
        if (reachedLimit) break;
      }

      const text = clean(parts.join('\n\n')).slice(0, charLimit);
      return {
        text,
        source: text.length >= 120 ? 'ioffice-tesseract-vie' : 'ioffice-tesseract-partial',
        status: text.length >= 120 ? 'ocr-text' : 'ocr-weak',
        pagesRead,
        totalPages,
        truncated: pagesRead < totalPages || text.length >= charLimit,
        scanSizeBytes: bytes?.byteLength || 0,
        actionLabel: 'OCR Tesseract tiếng Việt của iOffice'
      };
    } finally {
      signal?.removeEventListener?.('abort', onAbort);
      terminateWorker();
    }
  }

  async function waitForOcrText(pdf, opts) {
    const { check, signal, maxPages, maxChars, timeoutMs = 120000, maxFileBytes, progress } = opts;
    // 1) Nếu iOffice đã OCR sẵn thì dùng cache, không chạy lại.
    const cached = cachedIofficeOcrText(maxPages, maxChars, pdf.numPages);
    if (cached) return { ...cached, totalPages: pdf.numPages };

    // 2) DOM/text layer có thể đã có OCR sẵn.
    const already = textFromDom(maxChars);
    if (already.length >= 120) return { text: already, source: 'ioffice-ocr-textlayer', actionLabel: 'OCR/text layer đã sẵn sàng', totalPages: pdf.numPages };
    if (lastCopiedText.length >= 120) return { text: lastCopiedText.slice(0, maxChars), source: 'ioffice-copy-captured', actionLabel: 'Đã bắt text từ thao tác copy của iOffice', totalPages: pdf.numPages };

    // 3) Không tự bấm "Xem dạng copy được": nút đó chỉ chuyển sang Chrome PDF Viewer.
    //    Khi người dùng đã đồng ý OCR, chạy Tesseract tiếng Việt của chính iOffice trên canvas ẩn.
    const direct = await runDirectTesseractOcr(pdf, {
      check,
      signal,
      maxPages,
      maxChars,
      maxFileBytes: Number(maxFileBytes) || 10 * 1024 * 1024,
      progress
    });
    return direct || { text: '', source: 'scan-no-ocr-text', status: 'ocr-failed', totalPages: pdf.numPages, actionLabel: '' };
  }

  window.addEventListener('message', async (event) => {
    if (event.source !== parent || event.origin !== location.origin) return;
    const m = event.data;
    if (m?.channel !== 'ioffice-reader-v2' || typeof m.id !== 'string') return;
    if (m.type === 'cancel') { jobs.get(m.id)?.abort(); return; }
    if (m.type !== 'read' || jobs.has(m.id)) return;

    const controller = new AbortController();
    jobs.set(m.id, controller);
    // Stable 1.3.2: timeout của viewer phải khớp với timeout parent. Bản 1.3.1 ép tối thiểu 12s
    // trong khi parent thường chỉ chờ 6-7s, nên parent hủy job trước khi PDF.js đọc xong.
    // OCR nếu được bật sẽ tự truyền timeout dài hơn; đọc text thường dùng đúng ngân sách caller.
    const overallMs = Math.min(185000, Math.max(2200, Number(m.timeoutMs) || 6000));
    const until = Date.now() + overallMs;
    const check = () => {
      if (controller.signal.aborted) throw new Error('Đã dừng đọc viewer.');
      if (Date.now() > until) throw new Error('Hết thời gian đọc/OCR viewer.');
    };

    let output;
    try {
      let app;
      while (!(app = window.PDFViewerApplication)?.pdfDocument) { check(); await sleep(80); }
      const pdf = app.pdfDocument;
      const maxPages = Math.min(80, Math.max(1, Number(m.maxPages) || 20));
      const maxChars = Math.min(40000, Math.max(500, Number(m.maxChars) || 24000));

      const initial = await readPdfText(pdf, { maxPages, maxChars, check });
      output = { ...initial, source: 'pdf-main-world', status: initial.text.length >= 120 ? 'text' : 'scan-no-text' };

      // Nếu đã xác định không có lớp chữ, lấy đúng kích thước PDF đang mở để chặn >10 MB
      // trước khi hỏi người dùng OCR. Không giữ bytes trong kết quả.
      if (initial.text.length < 120 && m.tryIofficeOcr === false && m.captureScanBinary === false) {
        try {
          const bytes = await pdf.getData();
          check();
          output.scanSizeBytes = Number(bytes?.byteLength || 0);
          if (output.scanSizeBytes > (Number(m.maxFileBytes) || 10 * 1024 * 1024)) output.status = 'scan-too-large';
        } catch (_) {}
      }

      // Scan PDF: OCR chỉ chạy khi parent đã bật tryIofficeOcr sau khi người dùng đồng ý.
      if (initial.text.length < 120 && m.tryIofficeOcr !== false) {
        const left = Math.max(5000, until - Date.now() - 1200);
        const progress = (data) => {
          try {
            parent.postMessage({
              channel: 'ioffice-reader-v2',
              id: m.id,
              type: 'progress',
              progress: data || {}
            }, event.origin);
          } catch (_) {}
        };
        const ocr = await waitForOcrText(pdf, {
          check,
          signal: controller.signal,
          maxPages,
          maxChars,
          timeoutMs: Math.min(180000, left),
          maxFileBytes: Number(m.maxFileBytes) || 10 * 1024 * 1024,
          progress
        });
        check();
        if ((ocr.text || '').length >= 120) {
          output = {
            ...output,
            ...ocr,
            text: clean(ocr.text).slice(0, maxChars),
            status: 'ocr-text',
            pagesRead: ocr.pagesRead || output.pagesRead || 0,
            totalPages: ocr.totalPages || output.totalPages || pdf.numPages,
            ocrAction: ocr.actionLabel || ''
          };
        } else {
          output.ocrAttempted = true;
          output.ocrAction = ocr.actionLabel || '';
          output.ocrPartialChars = (ocr.text || '').length;
          if (ocr.status) output.status = ocr.status;
          if (ocr.scanSizeBytes) output.scanSizeBytes = ocr.scanSizeBytes;
          if (ocr.pagesRead) output.pagesRead = ocr.pagesRead;
          if (ocr.totalPages) output.totalPages = ocr.totalPages;
        }
      }

      if ((output.text || '').length < 120 && m.captureScanBinary) {
        const bytes = await pdf.getData();
        check();
        output.scanSizeBytes = bytes.byteLength;
        if (bytes.byteLength <= 8 * 1024 * 1024) {
          output.scanBytes = bytes;
          output.status = 'scan-ready-for-ai';
        } else {
          output.status = 'scan-too-large';
        }
      }

      check();
      parent.postMessage({ channel: 'ioffice-reader-v2', id: m.id, ok: true, data: output }, event.origin);
    } catch (e) {
      if (!controller.signal.aborted) parent.postMessage({ channel: 'ioffice-reader-v2', id: m.id, ok: false, error: e.message }, event.origin);
    } finally {
      jobs.delete(m.id);
    }
  });
})();
