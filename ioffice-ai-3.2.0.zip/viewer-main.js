/* iOffice AI 3.2.0 · lightweight PDF.js reader for Office preview fallbacks.
   PDF attachments themselves are handled only by pdf-scan-bridge.js in TOP MAIN world. */
(() => {
  'use strict';
  if (window === window.top || !/\/web\/viewer\.jsp$/.test(location.pathname)) return;

  const jobs = new Map();
  const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
  const clean = (s) => String(s || '').replace(/\u00a0/g, ' ').replace(/[\t\r ]+/g, ' ').replace(/\n{3,}/g, '\n\n').trim();

  async function readPdfText(pdf, { maxPages, maxChars, check }) {
    const totalPages = Number(pdf?.numPages || 0);
    const limitPages = Math.max(1, Math.min(80, Number(maxPages) || 20, totalPages || 1));
    const charLimit = Math.max(500, Math.min(40000, Number(maxChars) || 24000));
    const hw = Math.max(2, Number(navigator.hardwareConcurrency || 4));
    const concurrency = hw >= 12 ? 4 : hw >= 6 ? 3 : 2;
    const parts = [];
    let chars = 0;
    let pagesRead = 0;

    for (let start = 1; start <= limitPages; start += concurrency) {
      check();
      const nums = [];
      for (let n = start; n < Math.min(start + concurrency, limitPages + 1); n++) nums.push(n);
      const batch = await Promise.all(nums.map(async (n) => {
        check();
        const page = await pdf.getPage(n);
        check();
        const tc = await page.getTextContent();
        check();
        return { page:n, text:clean((tc.items || []).map((x) => x.str || '').join(' ')), items:Number(tc.items?.length || 0) };
      }));
      for (const item of batch) {
        parts.push(item);
        chars += item.text.length;
        pagesRead += 1;
      }
      if (chars >= charLimit) break;
    }

    const text = clean(parts.filter((x)=>x.text).map((x)=>`[Trang ${x.page}] ${x.text}`).join('\n\n')).slice(0, charLimit);
    const emptyPages = parts.filter((x)=>!x.text && x.items===0).map((x)=>x.page);
    return {
      text,
      pagesRead,
      totalPages,
      emptyPages,
      truncated:pagesRead < totalPages || chars > charLimit
    };
  }

  window.addEventListener('message', async (event) => {
    if (event.source !== parent || event.origin !== location.origin) return;
    const m = event.data;
    if (m?.channel !== 'ioffice-reader-v2' || typeof m.id !== 'string') return;
    if (m.type === 'cancel') { jobs.get(m.id)?.abort(); return; }
    if (m.type !== 'read' || jobs.has(m.id)) return;

    const controller = new AbortController();
    jobs.set(m.id, controller);
    const overallMs = Math.max(2200, Math.min(30000, Number(m.timeoutMs) || 6000));
    const until = Date.now() + overallMs;
    const check = () => {
      if (controller.signal.aborted) throw new Error('Đã dừng đọc viewer.');
      if (Date.now() > until) throw new Error('Hết thời gian đọc viewer.');
    };

    try {
      let app = null;
      while (!(app = window.PDFViewerApplication)?.pdfDocument) { check(); await sleep(80); }
      const data = await readPdfText(app.pdfDocument, {
        maxPages:Math.min(80, Math.max(1, Number(m.maxPages) || 20)),
        maxChars:Math.min(40000, Math.max(500, Number(m.maxChars) || 24000)),
        check
      });
      const output = { ...data, status:data.text.length >= 120 ? 'text' : 'scan-no-text', source:'pdf-main-world' };
      parent.postMessage({ channel:'ioffice-reader-v2', id:m.id, ok:true, data:output }, event.origin);
    } catch (error) {
      if (!controller.signal.aborted) parent.postMessage({ channel:'ioffice-reader-v2', id:m.id, ok:false, error:error?.message || String(error) }, event.origin);
    } finally {
      jobs.delete(m.id);
    }
  });
})();
