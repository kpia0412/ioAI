iOffice AI 0.61.1 — Local Rule Pro 0.60.0 — Tracker 7.0.16

ĐIỂM MỚI 0.61.1
- Thu gọn nút Lịch sử gửi Sổ thành chip nhỏ “📨 Sổ”.
- Khi vừa gửi Sổ thành công, chỉ hiện thông báo ngắn khoảng 6,5 giây; có nút × để ẩn ngay.
- Lịch sử đầy đủ vẫn giữ lại và chỉ bung ra khi bấm chip; không xóa dữ liệu Tracker.
- Sửa bộ đếm Gemini Web: chỉ tính 1 lượt sau khi thao tác Gửi thực sự được commit.
- Sau đủ số lượt cấu hình (mặc định 3), trước lượt tiếp theo Gemini Web sẽ điều hướng về cuộc trò chuyện mới trong tab Gemini đang dùng, thay vì phụ thuộc nút “New chat” của giao diện.
- Nếu Gemini chưa tạo được cuộc trò chuyện mới, tiện ích báo lỗi rõ và không tiếp tục gửi vào chat cũ.

GIỮ NGUYÊN TỪ 0.61.0
- Văn bản đi tự đối chiếu mục VĂN BẢN LIÊN QUAN với Sổ theo dõi.
- Chip trạng thái nhiệm vụ trên thanh tiêu đề.
- Nút Kiểm tra văn bản là luồng riêng, chỉ khi bấm mới đọc FILE TRÌNH KÝ/AI.
- Tương thích Tracker 7.0.16; không cần cập nhật Tracker cho bản 0.61.1.

CẬP NHẬT GITHUB
1. Đưa ioffice-ai-0.61.1.zip lên thư mục gốc repo ioAI.
2. Thay latest.json bằng file đi kèm.
3. URL ZIP: https://kpia0412.github.io/ioAI/ioffice-ai-0.61.1.zip
4. URL JSON: https://kpia0412.github.io/ioAI/latest.json
5. Không sửa ZIP sau khi tạo latest.json; nếu sửa ZIP phải tính lại SHA-256.
6. Không đưa TOKEN vào GitHub.

KIỂM TRA SAU CẬP NHẬT
- Gửi 1 nhiệm vụ vào Sổ: thông báo thành công hiện ngắn rồi tự biến mất, chip “📨 Sổ” vẫn còn để mở lịch sử.
- Chọn Gemini Web, giữ “Tạo chat mới sau = 3 lượt”.
- Gửi liên tiếp 4 lần: lượt 1–3 dùng cùng cuộc trò chuyện; trước lượt 4 Gemini phải chuyển sang cuộc trò chuyện mới.
- Cấu hình, URL Apps Script và TOKEN được giữ nguyên khi cập nhật cùng ID tiện ích.
