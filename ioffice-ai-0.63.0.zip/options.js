'use strict';
const $=id=>document.getElementById(id);
const CATALOG=globalThis.IOFFICE_PROVIDER_CATALOG||{};
const defaults={
  analysisMode:'gemini-web',fallbackAnalysisMode:'chatgpt-web',aiRequireCompleteFiles:true,webAiEnabled:true,
  webGeminiMaxTurns:3,webChatgptMaxTurns:3,webGeminiTimeoutMs:150000,webChatgptTimeoutMs:150000,
  readerMode:'primary',readerTimeoutMs:5000,readerMaxFileSizeMb:10,readerIncludeRelated:false,
  trackerEnabled:true,trackerApiUrl:'',trackerToken:'',trackerReminderDays:3,
  instructionPrefixEnabled:false,instructionPrefixText:'VP đề xuất:',providerOrder:['gemini','none','none','none'],providerConfigs:{}
};
let current={...defaults};
function msg(t,ok=true){$('msg').textContent=t;$('msg').className='msg '+(ok?'ok':'err');}
function runtime(m){return new Promise(resolve=>{try{chrome.runtime.sendMessage(m,r=>resolve(chrome.runtime.lastError?{ok:false,error:chrome.runtime.lastError.message}:(r||{ok:false})));}catch(e){resolve({ok:false,error:e.message});}});}
async function load(){
  current=await chrome.storage.local.get(defaults);
  $('version').textContent='v'+chrome.runtime.getManifest().version;
  $('analysisMode').value=current.analysisMode||'gemini-web';$('fallbackAnalysisMode').value=current.fallbackAnalysisMode||'chatgpt-web';
  $('aiRequireCompleteFiles').checked=current.aiRequireCompleteFiles!==false;$('webAiEnabled').checked=current.webAiEnabled!==false;
  $('webAiMaxTurns').value=String(current.webGeminiMaxTurns||3);$('webAiTimeoutSec').value=String(Math.round((current.webGeminiTimeoutMs||150000)/1000));
  $('instructionPrefixEnabled').checked=current.instructionPrefixEnabled===true;$('instructionPrefixText').value=current.instructionPrefixText||'VP đề xuất:';
  $('trackerEnabled').checked=true;$('trackerApiUrl').value=current.trackerApiUrl||'';$('trackerToken').value=current.trackerToken||'';$('trackerReminderDays').value=String(current.trackerReminderDays||3);
  $('readerMode').value=current.readerMode||'primary';$('readerTimeoutSec').value=String(Math.round((current.readerTimeoutMs||5000)/1000));$('readerMaxFileSizeMb').value=String(current.readerMaxFileSizeMb||10);$('readerIncludeRelated').checked=current.readerIncludeRelated===true;
  const api=(Array.isArray(current.providerOrder)&&current.providerOrder.find(x=>x&&x!=='none'))||'gemini';$('apiProvider').value=['gemini','openai','gateway','custom'].includes(api)?api:'gemini';fillApi();
}
function fillApi(){const api=$('apiProvider').value;const cfg=current.providerConfigs?.[api]||{};$('apiModel').value=cfg.model||CATALOG[api]?.defaultModel||'';$('apiBaseUrl').value=cfg.baseUrl||CATALOG[api]?.baseUrl||'';$('apiKey').value=cfg.apiKey||'';}
$('apiProvider')?.addEventListener('change',fillApi);
async function testWebAi(provider){const el=$('webAiHealth'),label=provider==='chatgpt'?'ChatGPT Web':'Gemini Web';el.textContent=`Đang kiểm tra ${label}…`;el.className='status';const r=await runtime({type:'WEB_AUTOMATION_PREWARM',provider});if(!r?.ok){el.textContent=`✕ ${label}: ${r?.error||'không sẵn sàng'}`;el.className='status err';return;}el.textContent=`✓ ${label}: ô nhập ${r.data?.composerFound?'OK':'chưa thấy'} · nút gửi ${r.data?.sendFound?'OK':'chưa sẵn sàng'}.`;el.className='status ok';}
$('testGeminiWeb')?.addEventListener('click',()=>void testWebAi('gemini'));$('testChatgptWeb')?.addEventListener('click',()=>void testWebAi('chatgpt'));
async function ensureTrackerPermission(url){if(!url)return false;const u=new URL(url);if(u.protocol!=='https:'||u.hostname!=='script.google.com'||!/^\/macros\/s\/[^/]+\/exec$/.test(u.pathname)||u.username||u.password)throw new Error('Nhập URL Apps Script dạng https://script.google.com/macros/s/.../exec.');const origins=[`${u.protocol}//${u.hostname}/*`,'https://script.googleusercontent.com/*'];const miss=[];for(const origin of origins)if(!(await chrome.permissions.contains({origins:[origin]})))miss.push(origin);return !miss.length||await chrome.permissions.request({origins:miss});}
$('testTracker')?.addEventListener('click',async()=>{const el=$('trackerStatus');el.textContent='Đang kiểm tra…';el.className='status';try{const url=$('trackerApiUrl').value.trim(),token=$('trackerToken').value.trim();if(!url||!token)throw new Error('Nhập URL Web App và mã truy cập trước.');if(!(await ensureTrackerPermission(url)))throw new Error('Chưa cấp quyền Apps Script.');await chrome.storage.local.set({trackerEnabled:true,trackerApiUrl:url,trackerToken:token});$('trackerEnabled').checked=true;const r=await runtime({type:'TRACKER_TEST'});if(!r?.ok)throw new Error(r?.error||'Không kết nối được Sổ.');el.textContent=`✓ Đã kết nối Tracker ${r.data?.version||''}`;el.className='status ok';}catch(e){el.textContent=e.message;el.className='status err';}});
$('save')?.addEventListener('click',async()=>{try{
  const api=$('apiProvider').value;const providerConfigs={...(current.providerConfigs||{})};providerConfigs[api]={...(providerConfigs[api]||{}),model:$('apiModel').value.trim(),baseUrl:$('apiBaseUrl').value.trim()||CATALOG[api]?.baseUrl||'',apiKey:$('apiKey').value.trim()};
  const settings={userRole:'leader',analysisMode:$('analysisMode').value,fallbackAnalysisMode:$('fallbackAnalysisMode').value,webAiEnabled:$('webAiEnabled').checked,webGeminiForeground:false,webGeminiFirstForeground:false,webChatgptForeground:false,webChatgptFirstForeground:false,webGeminiMaxTurns:Math.max(2,Math.min(5,Number($('webAiMaxTurns').value)||3)),webChatgptMaxTurns:Math.max(2,Math.min(5,Number($('webAiMaxTurns').value)||3)),webGeminiTimeoutMs:Math.max(60000,Math.min(240000,Number($('webAiTimeoutSec').value||150)*1000)),webChatgptTimeoutMs:Math.max(60000,Math.min(240000,Number($('webAiTimeoutSec').value||150)*1000)),aiRequireCompleteFiles:$('aiRequireCompleteFiles').checked,readerMode:$('readerMode').value,readerTimeoutMs:Math.max(2000,Math.min(60000,Number($('readerTimeoutSec').value||5)*1000)),readerMaxFileSizeMb:Math.max(1,Math.min(50,Number($('readerMaxFileSizeMb').value||10))),readerIncludeRelated:$('readerIncludeRelated').checked,readerConcurrency:0,readerDeduplicateContent:true,readerScanEnabled:false,trackerEnabled:true,trackerApiUrl:$('trackerApiUrl').value.trim(),trackerToken:$('trackerToken').value.trim(),trackerReminderDays:Number($('trackerReminderDays').value||3),instructionPrefixEnabled:$('instructionPrefixEnabled').checked,instructionPrefixText:String($('instructionPrefixText').value||'VP đề xuất:').trim(),providerOrder:[api,'none','none','none'],providerConfigs,retriesPerProvider:1,requestTimeoutMs:45000};
  if(settings.trackerEnabled){if(!settings.trackerApiUrl||!settings.trackerToken)throw new Error('Đã bật Sổ theo dõi nhưng chưa nhập URL/token.');if(!(await ensureTrackerPermission(settings.trackerApiUrl)))throw new Error('Chưa cấp quyền Apps Script.');}
  if(settings.analysisMode==='api'||settings.fallbackAnalysisMode==='api'){const u=new URL(settings.providerConfigs[api].baseUrl);const origin=`${u.protocol}//${u.hostname}/*`;if(!(await chrome.permissions.contains({origins:[origin]})))await chrome.permissions.request({origins:[origin]});}
  await chrome.storage.local.set(settings);current={...current,...settings};msg('Đã lưu cấu hình.',true);
}catch(e){msg(e.message,false);}});
load().catch(e=>msg('Không tải được cấu hình: '+e.message,false));
