(() => {
  'use strict';
  const FEED_URL='https://kpia0412.github.io/ioAI/latest-rules.json';
  const ALARM='ioffice-rule-pack-update';
  const PERIOD_MIN=15;
  const STATE_KEY='ruleInternetUpdate';
  const HISTORY_KEY='aiRulePackHistory';
  const HISTORY_MAX=3;

  const now=()=>Date.now();
  const clone=v=>JSON.parse(JSON.stringify(v));
  const activePackFromRaw=(raw)=>globalThis.IOfficeRulePack.resolvePack(raw?.aiRulePack);
  async function currentPackInfo(){
    const raw=await chrome.storage.local.get({
      aiRulePack:null,aiRulePackVersion:'',aiRulePackSource:'embedded',aiRulePackUpdatedAt:0,
      ruleAutoUpdate:true,[STATE_KEY]:{},[HISTORY_KEY]:[]
    });
    const pack=activePackFromRaw(raw);
    return {
      pack,
      version:pack.version,
      source:raw.aiRulePack ? (raw.aiRulePackSource||'local') : 'embedded',
      updatedAt:Number(raw.aiRulePackUpdatedAt||0),
      auto:raw.ruleAutoUpdate!==false,
      updateState:raw[STATE_KEY]||{},
      history:Array.isArray(raw[HISTORY_KEY])?raw[HISTORY_KEY]:[]
    };
  }
  async function setState(patch){
    const raw=await chrome.storage.local.get({[STATE_KEY]:{}});
    const next={...(raw[STATE_KEY]||{}),...patch};
    await chrome.storage.local.set({[STATE_KEY]:next});
    return next;
  }
  function runGolden(pack){
    const tests=globalThis.IOfficeGoldenTests?.run?.(pack);
    if(!tests) throw new Error('Golden Test Suite chưa sẵn sàng.');
    if(!tests.ok) throw new Error(`Rule Pack không vượt Golden Tests (${tests.passed}/${tests.total}): ${tests.failures.slice(0,4).join(' | ')}`);
    return tests;
  }
  async function pushHistory(cur){
    if(!cur?.pack) return;
    const raw=await chrome.storage.local.get({[HISTORY_KEY]:[]});
    const history=Array.isArray(raw[HISTORY_KEY])?raw[HISTORY_KEY]:[];
    const entry={pack:clone(cur.pack),version:String(cur.version||cur.pack.version||''),source:String(cur.source||'local'),updatedAt:Number(cur.updatedAt||0),savedAt:now()};
    const filtered=history.filter(x=>String(x?.version||'')!==entry.version || JSON.stringify(x?.pack)!==JSON.stringify(entry.pack));
    filtered.unshift(entry);
    await chrome.storage.local.set({[HISTORY_KEY]:filtered.slice(0,HISTORY_MAX)});
  }
  async function fetchJson(url,timeoutMs=15000){
    const u=new URL(url);
    if(u.protocol!=='https:'||u.username||u.password) throw new Error('Rule update chỉ chấp nhận HTTPS.');
    const c=new AbortController(),timer=setTimeout(()=>c.abort(),timeoutMs);
    try{
      const r=await fetch(u.href,{cache:'no-store',signal:c.signal,headers:{'Accept':'application/json'}});
      if(!r.ok) throw new Error(`HTTP ${r.status}`);
      const text=await r.text();
      return {data:JSON.parse(text),text,url:u.href};
    } finally { clearTimeout(timer); }
  }
  async function sha256Hex(text){
    const bytes=new TextEncoder().encode(text);
    const hash=await crypto.subtle.digest('SHA-256',bytes);
    return [...new Uint8Array(hash)].map(x=>x.toString(16).padStart(2,'0')).join('');
  }
  function validateRelease(data,currentVersion){
    if(!data||data.format!=='ioffice-ai-rules-release-v1') throw new Error('latest-rules.json sai format.');
    const version=String(data.version||'');
    if(!/^\d{4}\.\d{2}\.\d{2}\.\d{2}$/.test(version)) throw new Error('Version Rule Pack không hợp lệ.');
    const u=new URL(String(data.downloadUrl||''));
    if(u.protocol!=='https:'||u.username||u.password) throw new Error('downloadUrl Rule Pack phải dùng HTTPS.');
    const newer=globalThis.IOfficeCore.compareVersions(version,currentVersion)>0;
    return {version,newer,downloadUrl:u.href,notes:String(data.notes||'').slice(0,1800),sha256:/^[a-f0-9]{64}$/i.test(String(data.sha256||''))?String(data.sha256).toLowerCase():''};
  }
  async function check(){
    const cur=await currentPackInfo();
    await setState({phase:'checking',error:'',checkedAt:now()});
    try{
      const {data}=await fetchJson(FEED_URL);
      const rel=validateRelease(data,cur.version);
      return await setState({...rel,phase:rel.newer?'available':'current',error:'',checkedAt:now(),currentVersion:cur.version,feedUrl:FEED_URL});
    }catch(e){
      return await setState({phase:'error',error:`Không kiểm tra được Rule Pack: ${e.message}`,checkedAt:now(),currentVersion:cur.version,feedUrl:FEED_URL});
    }
  }
  async function applyRelease(release=null,source='internet'){
    const cur=await currentPackInfo();
    const rel=release || cur.updateState;
    if(!rel?.downloadUrl) throw new Error('Chưa có Rule Pack mới để áp dụng.');
    await setState({phase:'applying',error:'',applyStartedAt:now()});
    const {data,text,url}=await fetchJson(rel.downloadUrl,20000);
    if(rel.sha256){
      const actual=await sha256Hex(text);
      if(actual!==String(rel.sha256).toLowerCase()) throw new Error('SHA-256 Rule Pack không khớp.');
    }
    const pack=globalThis.IOfficeRulePack.validate(data);
    if(rel.version && pack.version!==rel.version) throw new Error('Version trong Rule Pack không khớp latest-rules.json.');
    const tests=runGolden(pack);
    await pushHistory(cur);
    await chrome.storage.local.set({
      aiRulePack:pack,
      aiRulePackVersion:pack.version,
      aiRulePackSource:source,
      aiRulePackUpdatedAt:now()
    });
    await setState({phase:'installed',newer:false,currentVersion:pack.version,version:pack.version,downloadUrl:url,error:'',installedAt:now()});
    return {ok:true,version:pack.version,pack,tests};
  }
  async function autoCycle(){
    const cur=await currentPackInfo();
    if(!cur.auto) return {ok:true,skipped:true};
    const st=await check();
    if(st?.newer){
      try{return await applyRelease(st,'internet-auto');}
      catch(e){await setState({phase:'error',error:`Có Rule Pack mới nhưng áp dụng thất bại: ${e.message}`});return {ok:false,error:e.message};}
    }
    return {ok:true,state:st};
  }
  async function ensureAlarm(){
    const a=await chrome.alarms.get(ALARM);
    if(!a) await chrome.alarms.create(ALARM,{delayInMinutes:2,periodInMinutes:PERIOD_MIN});
  }
  chrome.alarms.onAlarm.addListener(a=>{if(a.name===ALARM)autoCycle().catch(()=>{});});
  chrome.runtime.onStartup.addListener(()=>{ensureAlarm().then(autoCycle).catch(()=>{});});
  chrome.runtime.onInstalled.addListener(()=>{ensureAlarm().then(autoCycle).catch(()=>{});});
  ensureAlarm().catch(()=>{});

  chrome.runtime.onMessage.addListener((m,_sender,sendResponse)=>{
    const type=m?.type;
    if(!type||!type.startsWith('RULE_')) return;
    (async()=>{
      if(type==='RULE_PACK_GET'){
        const cur=await currentPackInfo();
        return {ok:true,data:{active:cur.pack,defaultPack:globalThis.IOfficeRulePack.defaultPack(),version:cur.version,source:cur.source,updatedAt:cur.updatedAt,auto:cur.auto,updateState:cur.updateState,feedUrl:FEED_URL,history:cur.history.map(x=>({version:x.version,source:x.source,savedAt:x.savedAt}))}};
      }
      if(type==='RULE_PACK_VALIDATE'){
        const pack=globalThis.IOfficeRulePack.validate(m.pack);
        const tests=runGolden(pack);
        return {ok:true,data:{version:pack.version,units:pack.units.length,format:pack.format,schemaVersion:pack.schemaVersion,tests}};
      }
      if(type==='RULE_PACK_SET_MANUAL'){
        const cur=await currentPackInfo();
        const pack=globalThis.IOfficeRulePack.validate(m.pack);
        const tests=runGolden(pack);
        await pushHistory(cur);
        await chrome.storage.local.set({aiRulePack:pack,aiRulePackVersion:pack.version,aiRulePackSource:'manual',aiRulePackUpdatedAt:now()});
        return {ok:true,data:{version:pack.version,tests}};
      }
      if(type==='RULE_PACK_RESTORE_DEFAULT'){
        const cur=await currentPackInfo();
        const def=globalThis.IOfficeRulePack.defaultPack();
        const tests=runGolden(def);
        await pushHistory(cur);
        await chrome.storage.local.remove('aiRulePack');
        await chrome.storage.local.set({aiRulePackVersion:def.version,aiRulePackSource:'embedded',aiRulePackUpdatedAt:now()});
        return {ok:true,data:{version:def.version,pack:def,tests}};
      }
      if(type==='RULE_PACK_ROLLBACK'){
        const cur=await currentPackInfo();
        const history=Array.isArray(cur.history)?cur.history:[];
        if(!history.length) throw new Error('Chưa có Rule Pack trước đó để hoàn tác.');
        const entry=history[0];
        const pack=globalThis.IOfficeRulePack.validate(entry.pack);
        const tests=runGolden(pack);
        const rest=history.slice(1,HISTORY_MAX);
        // Lưu bản hiện tại vào cuối lịch sử để vẫn có thể quay lại nếu cần.
        rest.push({pack:clone(cur.pack),version:cur.version,source:cur.source,updatedAt:cur.updatedAt,savedAt:now()});
        await chrome.storage.local.set({[HISTORY_KEY]:rest.slice(0,HISTORY_MAX),aiRulePack:pack,aiRulePackVersion:pack.version,aiRulePackSource:'rollback',aiRulePackUpdatedAt:now()});
        return {ok:true,data:{version:pack.version,pack,tests}};
      }
      if(type==='RULE_UPDATE_CHECK') return {ok:true,data:await check()};
      if(type==='RULE_UPDATE_APPLY') return {ok:true,data:await applyRelease(null,'internet-manual')};
      if(type==='RULE_UPDATE_STATUS'){const cur=await currentPackInfo();return {ok:true,data:{...cur.updateState,currentVersion:cur.version,source:cur.source,auto:cur.auto,feedUrl:FEED_URL}};}
      if(type==='RULE_AUTO_SET'){await chrome.storage.local.set({ruleAutoUpdate:m.enabled!==false});return {ok:true};}
      throw new Error('Lệnh Rule Pack không hỗ trợ.');
    })().then(sendResponse).catch(e=>sendResponse({ok:false,error:e.message}));
    return true;
  });
})();