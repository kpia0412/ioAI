Tracker 1.2.0 tương thích iOffice AI 1.2.0.
Rule Pack vẫn 1.0.0.
