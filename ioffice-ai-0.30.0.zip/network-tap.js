(() => {
  'use strict';

  const CHANNEL = 'ioffice-file-network-v1';
  const ACTION_CHANNEL = 'ioffice-tracker-action-v1';
  let actionWatch = null;
  let fileCaptureUntil = 0;
  const fileCaptureActive = () => Date.now() < fileCaptureUntil;
  const armFileCapture = (ms = 20000) => { fileCaptureUntil = Math.max(fileCaptureUntil, Date.now() + Math.max(3000, Math.min(45000, Number(ms || 20000)))); };
  const MAX_CAPTURE_BYTES = 20 * 1024 * 1024;
  const seen = new Set();
  const postedBinary = new Set();
  let resolveOpen = null;

  const topWindow = () => {
    try { return window.top || window; } catch (_) { return window; }
  };

  function absoluteUrl(value) {
    try { return new URL(String(value || ''), location.href).href; }
    catch (_) { return ''; }
  }

  function sameOrigin(url) {
    try { return new URL(url).origin === location.origin; }
    catch (_) { return false; }
  }

  function post(message, transfer = []) {
    try {
      topWindow().postMessage({ channel: CHANNEL, frameUrl: location.href, ...message }, location.origin, transfer);
    } catch (_) {
      try { topWindow().postMessage({ channel: CHANNEL, frameUrl: location.href, ...message }, location.origin); } catch (_) {}
    }
  }

  function postActionResponse(payload = {}) {
    try {
      const w = actionWatch;
      if (!w || Date.now() > w.until || !w.watchId) return;
      topWindow().postMessage({
        channel: ACTION_CHANNEL,
        type: 'response',
        watchId: w.watchId,
        action: w.action,
        url: String(payload.url || ''),
        method: String(payload.method || ''),
        status: Number(payload.status || 0),
        text: String(payload.text || '').replace(/\u00a0/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 6000)
      }, location.origin);
    } catch (_) {}
  }

  function requestBodySnippet(value) {
    try {
      if (value == null) return '';
      if (typeof value === 'string') return value.slice(0, 3000);
      if (value instanceof URLSearchParams) return value.toString().slice(0, 3000);
      if (value instanceof FormData) {
        const out=[];
        for (const [k,v] of value.entries()) out.push(`${k}=${typeof v === 'string' ? v : '[file]'}`);
        return out.join('&').slice(0,3000);
      }
      return String(value).slice(0,3000);
    } catch (_) { return ''; }
  }

  async function captureActionFetchResponse(response, requestUrl, method, requestBody = '') {
    try {
      const w = actionWatch;
      if (!w || Date.now() > w.until) return;
      const finalUrl = response?.url || absoluteUrl(requestUrl);
      if (!sameOrigin(finalUrl)) return;
      const contentType = response?.headers?.get?.('content-type') || '';
      let text = '';
      if (/json|text|javascript|html|xml/i.test(contentType) || !contentType) {
        try { text = await response.clone().text(); } catch (_) {}
      }
      postActionResponse({url:finalUrl, method, status:response?.status || 0, text:`${requestBody || ''} ${text || ''}`});
    } catch (_) {}
  }

  try {
    window.addEventListener('message', (event) => {
      if (event.source !== window || event.origin !== location.origin) return;
      const d = event.data;
      if (!d || d.channel !== ACTION_CHANNEL || d.type !== 'arm' || !d.watchId) return;
      const ttl = Math.max(5000, Math.min(120000, Number(d.untilMs || 90000)));
      actionWatch = { watchId:String(d.watchId), action:String(d.action || ''), until:Date.now()+ttl };
    });
  } catch (_) {}

  function postCopyText(value, source = 'copy') {
    try {
      const text = String(value || '').replace(/\u00a0/g, ' ').replace(/\s+/g, ' ').trim();
      if (text.length < 40) return;
      post({ type: 'copy-text', source, text: text.slice(0, 40000), chars: Math.min(text.length, 40000) });
    } catch (_) {}
  }

  // Bắt đúng text mà iOffice đưa vào thao tác Copy/OCR ở bất kỳ frame cùng miền nào.
  // Không đọc clipboard hệ thống; chỉ quan sát dữ liệu trước khi trang ghi ra clipboard.
  try {
    document.addEventListener('copy', () => {
      try { postCopyText(document.getSelection?.()?.toString?.() || window.getSelection?.()?.toString?.() || '', 'copy-event'); } catch (_) {}
    }, true);
    const cb = navigator.clipboard;
    if (cb && typeof cb.writeText === 'function' && !cb.writeText.__iofficeCopyWrapped) {
      const original = cb.writeText.bind(cb);
      const wrapped = function(value) { postCopyText(value, 'clipboard-writeText'); return original(value); };
      try { Object.defineProperty(wrapped, '__iofficeCopyWrapped', { value: true }); cb.writeText = wrapped; } catch (_) {}
    }
  } catch (_) {}



  function postOcrText(value, source = 'ocr-response', url = '') {
    try {
      let text = String(value || '').replace(/\u00a0/g, ' ').replace(/\s+/g, ' ').trim();
      if (text.length < 40) return;
      // JSON OCR services often wrap text in fields. Keep printable text; document-reader will de-duplicate.
      if (text.length > 80000) text = text.slice(0, 80000);
      post({ type:'copy-text', source, text, chars:text.length, url:absoluteUrl(url) });
    } catch (_) {}
  }

  function looksLikeOcrTextResponse(url, contentType = '') {
    const path = (() => { try { return new URL(url, location.href).pathname.toLowerCase(); } catch (_) { return String(url || '').toLowerCase(); } })();
    const ct = String(contentType || '').toLowerCase();
    return /ocr|recogn|extract.?text|text.?extract|copy.?text|searchify/.test(path) || /application\/json|text\//.test(ct);
  }

  function postResource(url, initiatorType = '', extra = {}) {
    if (!fileCaptureActive() && extra.force !== true) return;
    const absolute = absoluteUrl(url);
    if (!absolute || !sameOrigin(absolute)) return;
    const key = `${absolute}|${location.href}|${initiatorType}|${extra.method || ''}`;
    if (seen.has(key)) return;
    seen.add(key);
    if (seen.size > 1200) seen.delete(seen.values().next().value);
    post({ type: 'resource', url: absolute, initiatorType: String(initiatorType || ''), ...extra });
  }

  function dispositionFilename(value) {
    const text = String(value || '');
    let m = text.match(/filename\*=UTF-8''([^;]+)/i);
    if (m) {
      try { return decodeURIComponent(m[1].trim().replace(/^"|"$/g, '')); } catch (_) { return m[1].trim(); }
    }
    m = text.match(/filename\s*=\s*"([^"]+)"/i) || text.match(/filename\s*=\s*([^;]+)/i);
    return m ? String(m[1] || '').trim().replace(/^"|"$/g, '') : '';
  }

  function looksLikeFileResponse(url, contentType, disposition) {
    const u = String(url || '');
    const ct = String(contentType || '').toLowerCase();
    const cd = String(disposition || '').toLowerCase();
    if (/attachment|filename=|filename\*/i.test(cd)) return true;
    if (/(?:application\/(?:pdf|msword|rtf|octet-stream|vnd\.ms-|vnd\.openxmlformats)|text\/plain)/i.test(ct)) return true;
    return /\.(?:pdf|docx?|xlsx?|xls|rtf|txt)(?:$|[?#])/i.test(u) || /(?:download|attachment|getfile|viewfile|filedownload)/i.test(u);
  }

  function signatureKind(bytes) {
    if (!bytes?.length) return '';
    if (bytes.length >= 5 && String.fromCharCode(...bytes.slice(0, 5)) === '%PDF-') return 'pdf';
    if (bytes.length >= 4 && bytes[0] === 0x50 && bytes[1] === 0x4b && [0x03, 0x05, 0x07].includes(bytes[2]) && [0x04, 0x06, 0x08].includes(bytes[3])) return 'zip';
    if (bytes.length >= 8 && bytes[0] === 0xd0 && bytes[1] === 0xcf && bytes[2] === 0x11 && bytes[3] === 0xe0 && bytes[4] === 0xa1 && bytes[5] === 0xb1 && bytes[6] === 0x1a && bytes[7] === 0xe1) return 'ole';
    const prefix = new TextDecoder('utf-8', { fatal: false }).decode(bytes.slice(0, Math.min(bytes.length, 250))).trimStart().toLowerCase();
    if (/^\{\\rtf/.test(prefix)) return 'rtf';
    if (/^(?:<!doctype\s+html|<html|<head|<body)/.test(prefix)) return 'html';
    return 'other';
  }

  function postFileBytes({ url, contentType = '', disposition = '', method = 'GET', bytes, initiatorType = '' }) {
    const absolute = absoluteUrl(url);
    if (!absolute || !sameOrigin(absolute) || !bytes?.byteLength || bytes.byteLength > MAX_CAPTURE_BYTES) return;
    const view = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
    const kind = signatureKind(view);
    if (kind === 'html') return;
    const filename = dispositionFilename(disposition);
    const key = `${absolute}|${view.byteLength}|${filename}|${kind}`;
    if (postedBinary.has(key)) return;
    postedBinary.add(key);
    if (postedBinary.size > 120) postedBinary.delete(postedBinary.values().next().value);
    const copy = view.buffer.slice(view.byteOffset, view.byteOffset + view.byteLength);
    post({
      type: 'file-bytes',
      url: absolute,
      initiatorType,
      method,
      contentType,
      disposition,
      filename,
      sizeBytes: view.byteLength,
      signature: kind,
      bytes: copy
    }, [copy]);
  }

  async function captureFetchResponse(response, requestUrl, method) {
    try {
      if (!response || !response.ok) return;
      const finalUrl = response.url || absoluteUrl(requestUrl);
      if (!sameOrigin(finalUrl)) return;
      const contentType = response.headers.get('content-type') || '';
      const disposition = response.headers.get('content-disposition') || '';
      const len = Number(response.headers.get('content-length') || 0);
      if (looksLikeFileResponse(finalUrl, contentType, disposition)) {
        postResource(finalUrl, 'fetch-response', { method, contentLength: len, contentType, disposition });
      }
      if (len > MAX_CAPTURE_BYTES) return;
      if (looksLikeOcrTextResponse(finalUrl, contentType)) {
        try { const txt = await response.clone().text(); postOcrText(txt, 'ocr-fetch-response', finalUrl); } catch (_) {}
      }
      if (!looksLikeFileResponse(finalUrl, contentType, disposition)) return;
      const clone = response.clone();
      const buffer = await clone.arrayBuffer();
      if (!buffer.byteLength || buffer.byteLength > MAX_CAPTURE_BYTES) return;
      postFileBytes({ url: finalUrl, contentType, disposition, method, bytes: new Uint8Array(buffer), initiatorType: 'fetch-response' });
    } catch (_) {}
  }

  // v0.19: bỏ PerformanceObserver toàn trang; chỉ bắt mạng trong cửa sổ đọc tệp được arm.

  // Capture the real URL created by legacy showFileNewTab/window.open flows.
  // When the isolated-world reader explicitly asks to resolve a showFileNewTab call,
  // temporarily suppress only that programmatic window.open so no extra tab flashes on screen.
  try {
    const originalOpen = window.open;
    if (typeof originalOpen === 'function' && !originalOpen.__iofficeWrapped) {
      const wrapped = function(url, ...rest) {
        const absolute = absoluteUrl(url);
        postResource(absolute, 'window.open');
        if (resolveOpen && Date.now() <= resolveOpen.until) {
          post({ type: 'resolved-viewer', requestId: resolveOpen.requestId, url: absolute, ok: Boolean(absolute) });
          resolveOpen = null;
          return { closed: false, focus(){}, close(){}, location: { href: absolute || '' } };
        }
        return originalOpen.call(this, url, ...rest);
      };
      Object.defineProperty(wrapped, '__iofficeWrapped', { value: true });
      window.open = wrapped;
    }
  } catch (_) {}

  if (window === window.top) {
    window.addEventListener('message', (event) => {
      if (event.source !== window || event.origin !== location.origin || event.data?.channel !== CHANNEL || event.data?.type !== 'resolve-show-file') return;
      const requestId = String(event.data.requestId || '');
      const args = Array.isArray(event.data.args) ? event.data.args.map(x => String(x ?? '')) : [];
      const nodeId = String(event.data.nodeId || '');
      if (!requestId) return;
      armFileCapture(22000);

      // Đường ưu tiên: gọi chính showFileDinhKem như thao tác “Xem” thật của iOffice,
      // nhưng render vào một container ẩn. Cách này giữ nguyên token/session/version mà
      // server yêu cầu và đặc biệt ổn định với DOC/DOCX được iOffice chuyển sang PDF.
      const showInline = window.showFileDinhKem;
      if (typeof showInline === 'function' && args.length >= 3) {
        const probeId = `__ioffice_ai_probe_${requestId.replace(/[^a-z0-9_-]/gi,'')}`;
        const probe = document.createElement('div');
        probe.id = probeId;
        probe.setAttribute('aria-hidden','true');
        probe.style.cssText = 'position:fixed;left:-14000px;top:0;width:900px;height:700px;opacity:.01;pointer-events:none;overflow:hidden;z-index:-1';
        document.documentElement.appendChild(probe);
        let done = false;
        const finish = (payload) => {
          if (done) return;
          done = true;
          try { observer.disconnect(); } catch (_) {}
          // Chỉ dùng probe để iOffice sinh đúng viewer URL. Không giữ viewer phụ quá lâu vì
          // content reader sẽ mở URL đã khóa riêng; giữ lâu dễ tạo 2 viewer/file và tranh trạng thái.
          setTimeout(() => { try { probe.remove(); } catch (_) {} }, 1400);
          post({ type:'resolved-viewer', requestId, ...payload });
        };
        const inspect = () => {
          const frame = probe.querySelector('iframe[src]');
          const src = frame?.getAttribute('src') || '';
          if (src) {
            const absolute = absoluteUrl(src);
            postResource(absolute, 'ioffice-hidden-showFileDinhKem');
            finish({ url:absolute, ok:Boolean(absolute) });
            return true;
          }
          return false;
        };
        const observer = new MutationObserver(inspect);
        observer.observe(probe, { childList:true, subtree:true, attributes:true, attributeFilter:['src'] });
        try {
          showInline.call(window, args[0], args[1], args[2], 'vb', probeId, undefined, undefined, true);
          // v0.16.0 FINAL: PDF scan bị bỏ qua; không tự bấm OCR/copy trong probe ẩn.
          if (inspect()) return;
          setTimeout(() => { if (!inspect()) finish({ url:'', ok:false, error:'showFileDinhKem không tạo viewer trong thời gian chờ.' }); }, 5000);
          return;
        } catch (error) {
          try { observer.disconnect(); probe.remove(); } catch (_) {}
          // Rơi xuống showFileNewTab ở dưới.
        }
      }

      const fn = window.showFileNewTab;
      let invoke = null;
      if (typeof fn === 'function') invoke = () => fn.apply(window, args);
      else if (nodeId) {
        let target = null;
        try {
          const card = document.getElementById(nodeId);
          target = card?.querySelector?.('[onclick*="showFileNewTab"], [onclick*="viewer" i], a[href*="viewer" i]') || null;
        } catch (_) {}
        if (target) invoke = () => { target.click(); return null; };
      }
      if (!invoke) {
        post({ type: 'resolved-viewer', requestId, url: '', ok: false, error: 'Không tìm thấy hành động mở tệp của iOffice.' });
        return;
      }
      resolveOpen = { requestId, until: Date.now() + 1800 };
      try {
        const returned = invoke();
        if (resolveOpen?.requestId === requestId) {
          let returnedUrl = '';
          try {
            if (typeof returned === 'string') returnedUrl = absoluteUrl(returned);
            else if (returned?.location?.href) returnedUrl = absoluteUrl(returned.location.href);
            else if (returned?.url) returnedUrl = absoluteUrl(returned.url);
          } catch (_) {}
          if (returnedUrl) {
            resolveOpen = null;
            post({ type:'resolved-viewer', requestId, url:returnedUrl, ok:true });
            return;
          }
        }
        setTimeout(() => {
          if (resolveOpen?.requestId === requestId) {
            resolveOpen = null;
            post({ type: 'resolved-viewer', requestId, url: '', ok: false, error: 'showFileNewTab không tạo URL qua window.open.' });
          }
        }, 1600);
      } catch (error) {
        resolveOpen = null;
        post({ type: 'resolved-viewer', requestId, url: '', ok: false, error: error?.message || String(error) });
      }
    });
  }

  // Capture fetch URLs immediately and copy file responses asynchronously without delaying iOffice.
  try {
    const originalFetch = window.fetch;
    if (typeof originalFetch === 'function' && !originalFetch.__iofficeWrapped) {
      const wrappedFetch = function(input, init) {
        const reqUrl = typeof input === 'string' || input instanceof URL ? input : input?.url;
        const method = String(init?.method || input?.method || 'GET').toUpperCase();
        const bodySnippet = actionWatch ? requestBodySnippet(init?.body) : '';
        if (fileCaptureActive()) postResource(reqUrl, 'fetch', { method });
        const promise = originalFetch.apply(this, arguments);
        if (fileCaptureActive() || actionWatch) {
          Promise.resolve(promise).then((response) => {
            if (fileCaptureActive()) captureFetchResponse(response, reqUrl, method);
            if (actionWatch) captureActionFetchResponse(response, reqUrl, method, bodySnippet);
          }).catch(() => {});
        }
        return promise;
      };
      Object.defineProperty(wrappedFetch, '__iofficeWrapped', { value: true });
      window.fetch = wrappedFetch;
    }
  } catch (_) {}

  // Legacy iOffice/jQuery often uses XHR. Capture both the request URL and binary/blob response.
  try {
    const XHR = window.XMLHttpRequest;
    if (XHR?.prototype && !XHR.prototype.__iofficeWrapped) {
      const open = XHR.prototype.open;
      const send = XHR.prototype.send;
      XHR.prototype.open = function(method, url) {
        this.__iofficeRequestMethod = String(method || 'GET').toUpperCase();
        this.__iofficeRequestUrl = absoluteUrl(url);
        if (fileCaptureActive()) postResource(this.__iofficeRequestUrl, 'xmlhttprequest', { method: this.__iofficeRequestMethod });
        return open.apply(this, arguments);
      };
      XHR.prototype.send = function(body) {
        this.__iofficeRequestBodySnippet = actionWatch ? requestBodySnippet(body) : '';
        const needActionCapture = !!(actionWatch && Date.now() <= actionWatch.until);
        const needFileCapture = fileCaptureActive();
        if ((needActionCapture || needFileCapture) && !this.__iofficeCaptureBound) {
          this.__iofficeCaptureBound = true;
          this.addEventListener('loadend', () => {
            try {
              const url = this.responseURL || this.__iofficeRequestUrl || '';
              if (!sameOrigin(url)) return;
              if (actionWatch && Date.now() <= actionWatch.until) {
                try {
                  let actionText = '';
                  if (!this.responseType || this.responseType === 'text') actionText = this.responseText || '';
                  else if (this.responseType === 'json') actionText = JSON.stringify(this.response || {});
                  postActionResponse({url, method:this.__iofficeRequestMethod, status:this.status, text:`${this.__iofficeRequestBodySnippet || ''} ${actionText || ''}`});
                } catch (_) {}
              }
              if (!fileCaptureActive() || this.status < 200 || this.status >= 300) return;
              const contentType = this.getResponseHeader('content-type') || '';
              const disposition = this.getResponseHeader('content-disposition') || '';
              if (looksLikeOcrTextResponse(url, contentType)) {
                try {
                  if (!this.responseType || this.responseType === 'text') postOcrText(this.responseText || '', 'ocr-xhr-response', url);
                  else if (this.responseType === 'json') postOcrText(JSON.stringify(this.response || {}), 'ocr-xhr-json', url);
                } catch (_) {}
              }
              if (!looksLikeFileResponse(url, contentType, disposition)) return;
              const contentLength = Number(this.getResponseHeader('content-length') || 0) || Number(this.response?.size || this.response?.byteLength || 0);
              postResource(url, 'xhr-response', { method: this.__iofficeRequestMethod, contentLength, contentType, disposition });
              const response = this.response;
              if (response instanceof ArrayBuffer) {
                postFileBytes({ url, contentType, disposition, method: this.__iofficeRequestMethod, bytes: new Uint8Array(response.slice(0)), initiatorType: 'xhr-response' });
              } else if (response instanceof Blob && response.size <= MAX_CAPTURE_BYTES) {
                response.arrayBuffer().then((buf) => postFileBytes({ url, contentType, disposition, method: this.__iofficeRequestMethod, bytes: new Uint8Array(buf), initiatorType: 'xhr-response' })).catch(() => {});
              }
            } catch (_) {}
          });
        }
        return send.apply(this, arguments);
      };
      Object.defineProperty(XHR.prototype, '__iofficeWrapped', { value: true });
    }
  } catch (_) {}

  // v0.19: không phát sự kiện navigation khi idle.
})();
