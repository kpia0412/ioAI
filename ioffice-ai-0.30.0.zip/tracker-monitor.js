(() => {
  'use strict';

  const VERSION = '0.30.0';
  const ACTION_CHANNEL = 'ioffice-tracker-action-v1';
  const WIDGET_HOST_ID = 'ealy-ioffice-ai-host';
  const CARD_ID = 'trackerWatch';
  const CACHE_KEY = 'trackerClientCacheV4';
  const CACHE_TTL_MS = 10 * 60 * 1000;

  const state = {
    enabled: false,
    userRole: 'leader',
    scanTimer: null,
    lastFingerprint: '',
    currentMatch: null,
    currentRelatedDocs: [],
    currentContext: null,
    pendingAction: null,
    actionResponses: new Map(),
    lastRender: '',
    cache: { updatedAt: 0, tasks: [] },
    cacheRefreshing: false,
    refreshedForKey: new Set(),
    remoteFallbackKeys: new Set()
  };

  const norm = (v) => String(v ?? '').replace(/\u00a0/g, ' ').replace(/\s+/g, ' ').trim();
  const fold = (v) => norm(v).normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/đ/g,'d').replace(/Đ/g,'D').toLowerCase();
  const normSymbol = (v) => fold(v).toUpperCase().replace(/\s+/g,'').replace(/[–—−]/g,'-').replace(/[;,]+$/,'');
  const esc = (v) => String(v ?? '').replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;').replaceAll("'",'&#039;');

  function visible(el) {
    if (!el) return false;
    try {
      const s = getComputedStyle(el), r = el.getBoundingClientRect();
      return s.display !== 'none' && s.visibility !== 'hidden' && r.width > 0 && r.height > 0;
    } catch (_) { return false; }
  }

  function firstValue(selectors) {
    for (const sel of selectors) {
      for (const el of document.querySelectorAll(sel)) {
        const v = norm(el.value || el.textContent || '');
        if (v) return v;
      }
    }
    return '';
  }

  function workflowText() {
    return norm(document.getElementById(WIDGET_HOST_ID)?.shadowRoot?.getElementById('workflowBadge')?.textContent || '').toLowerCase();
  }

  function detectOutgoing() {
    if (/văn bản đi|van ban di/.test(workflowText())) return true;
    if (/văn bản đi|van ban di/.test(norm(document.title).toLowerCase())) return true;
    if (document.querySelector('#thongtinvb div.download')) return true;
    return Boolean(document.querySelector('#TRICH_YEU,#txt_idedit,#btn_vdi_savedoc,#btn_ky_vbTrinhKy,#btnBanhanh'));
  }

  function parseRelatedText(el) {
    const rawText = norm(el.textContent || '');
    if (!/Trích\s*yếu\s*:/i.test(rawText) || !/Số\s*ký\s*hiệu\s*:/i.test(rawText)) return null;
    const cleaned = rawText.replace(/^\d+\.\s*/, '');
    const subjectMatch = cleaned.match(/Trích\s*yếu\s*:\s*(.*?)\s*Số\s*ký\s*hiệu\s*:/i);
    let symbol = '';
    const after = cleaned.split(/Số\s*ký\s*hiệu\s*:/i)[1] || '';
    if (after) {
      symbol = norm(after.split(/\s*\(|\s+Người\s+gửi\s*:|\s+-\s+\d{1,2}\/\d{1,2}\/\d{4}/i)[0] || '');
      if (symbol.length > 80) symbol = symbol.split(/\s{2,}|\|/)[0] || symbol;
    }
    const onclick = el.getAttribute('onclick') || el.querySelector('[onclick*="get_detail_doc_popup_v1"]')?.getAttribute('onclick') || '';
    const idm = onclick.match(/get_detail_doc_popup_v1\(['"]?([^'")]+)['"]?\)/i);
    const subject = norm(subjectMatch?.[1] || '');
    if (!symbol && !idm?.[1]) return null;
    return { relatedIofficeId:norm(idm?.[1] || ''), symbol, subject, rawText };
  }

  function readRelatedDocuments() {
    const root = document.querySelector('#thongtinvb');
    if (!root) return [];
    const out = [];
    for (const el of root.querySelectorAll('div.download')) {
      const r = parseRelatedText(el);
      if (r) out.push(r);
    }
    const seen = new Set();
    return out.filter(x => {
      const k = `${x.relatedIofficeId}|${normSymbol(x.symbol)}|${fold(x.subject)}`;
      if (seen.has(k)) return false;
      seen.add(k); return true;
    });
  }

  function signedFileName() {
    const values = [...document.querySelectorAll('input[id^="txt_file_name_"]')].map(x => norm(x.value)).filter(Boolean);
    return values.find(x => /\.signed(?:\.signed)*\.pdf$/i.test(x)) || values.find(x => /signed/i.test(x) && /\.pdf$/i.test(x)) || values.find(x => /\.pdf$/i.test(x)) || '';
  }

  function signatureFingerprint() {
    const parts = [];
    for (const el of document.querySelectorAll('input[id^="txt_file_signature_"],input[id^="txt_file_name_"]')) {
      const v = norm(el.value);
      if (v && (/signature/i.test(el.id) || /signed|\.pdf$/i.test(v))) parts.push(`${el.id}:${v}`);
    }
    return parts.sort().join('|');
  }

  function readOutgoingContext() {
    return {
      resultIofficeId: firstValue(['#txt_idedit','#idVB','#hide_docid']),
      resultSymbol: firstValue(['#hide_sokyhieu','#SO_KY_HIEU','#SO_KY_HIEU_VB','#txt_so_ky_hieu','input[id^="vbdi_sokyhieu_"]']),
      resultSubject: firstValue(['#TRICH_YEU','textarea[id*="TRICH_YEU" i]','textarea[name*="trich" i]']),
      resultDate: firstValue(['#NGAY_VAN_BAN','#ngay_tao_doc','input.ngayBanHanh']),
      resultUrl: location.href,
      signedFileName: signedFileName()
    };
  }

  function outgoingKey(ctx = readOutgoingContext()) {
    return norm(ctx.resultIofficeId || [ctx.resultSymbol,ctx.resultDate,ctx.resultSubject].join('|')).toLowerCase();
  }

  function pageFingerprint() {
    const docs = readRelatedDocuments();
    return `${detectOutgoing()?'O':'N'}|${outgoingKey()}|${docs.map(d=>`${d.relatedIofficeId}:${normSymbol(d.symbol)}`).join('|')}`;
  }

  function statusLabel(s) {
    return ({PROCESSING:'Đang xử lý',WAITING_PUBLISH:'Đã xử lý - chờ ban hành',COMPLETED:'Đã hoàn thành',STOPPED:'Dừng theo dõi'})[norm(s)] || norm(s) || 'Đang xử lý';
  }

  function deadlineLabel(v) {
    const m = norm(v).match(/^(\d{4})-(\d{2})-(\d{2})$/);
    return m ? `${m[3]}/${m[2]}/${m[1]}` : norm(v);
  }

  function ensureCard() {
    const root = document.getElementById(WIDGET_HOST_ID)?.shadowRoot;
    if (!root) return null;
    let card = root.getElementById(CARD_ID);
    if (card) return card;
    card = document.createElement('div');
    card.id = CARD_ID;
    card.className = 'tracker-watch hidden';
    const body = root.getElementById('body');
    const message = root.getElementById('message');
    if (!body) return null;
    if (message?.nextSibling) body.insertBefore(card,message.nextSibling); else body.appendChild(card);
    const style = document.createElement('style');
    style.textContent = `
      .tracker-watch{margin:8px 0;padding:9px 10px;border:1px solid #b8d8c5;border-left:5px solid #15803d;border-radius:10px;background:#f2faf4;color:#244c34;font-size:10.5px;line-height:1.45}
      .tracker-watch.hidden{display:none!important}.tracker-watch.wait{border-color:#c9d8f6;border-left-color:#2563eb;background:#eff6ff;color:#1e3a8a}.tracker-watch.warn{border-color:#f0cf84;border-left-color:#d97706;background:#fff9eb;color:#7a4c00}.tracker-watch.err{border-color:#fecaca;border-left-color:#dc2626;background:#fff5f5;color:#8b1e1e}
      .tracker-watch .tw-head{font-size:11px;font-weight:900}.tracker-watch .tw-row{margin-top:3px}.tracker-watch .tw-symbol{font-weight:900;color:#14532d}.tracker-watch .tw-status{font-weight:900}.tracker-watch .tw-small{font-size:9.5px;color:#64748b;margin-top:3px}`;
    root.appendChild(style);
    return card;
  }

  function render(html, cls='') {
    const card = ensureCard(); if (!card) return;
    const sig = `${cls}|${html}`; if (sig === state.lastRender) return;
    state.lastRender = sig; card.className = `tracker-watch ${cls}`.trim(); card.innerHTML = html;
  }
  function hideCard() { const card=ensureCard(); if(!card)return; state.lastRender=''; card.className='tracker-watch hidden'; card.innerHTML=''; }

  function renderMatch(match=state.currentMatch, source='local') {
    if (!match?.matched || !match.task) return hideCard();
    const t = match.task, role = state.userRole==='clerk'?'Văn thư':state.userRole==='chief'?'Chánh Văn phòng':'Lãnh đạo', s=statusLabel(t.businessStatus);
    let hint='';
    if (t.businessStatus==='COMPLETED') hint='Nhiệm vụ này đã hoàn thành; tiện ích không tạo hoặc cập nhật lại.';
    else if (t.businessStatus==='WAITING_PUBLISH') hint=state.userRole==='clerk'?'Đã được lãnh đạo xử lý. Chỉ hoàn thành sau khi Ban hành thành công và có Số/Ký hiệu.':'Đã chờ ban hành; mở xem không làm thay đổi trạng thái.';
    else hint=state.userRole==='leader'?'Mở xem không đổi trạng thái. Chỉ chuyển Chờ ban hành sau khi Ký thành công.':state.userRole==='chief'?'Mở xem không đổi trạng thái; Chánh Văn phòng không tự đánh dấu đã ký.':'Nhiệm vụ vẫn đang xử lý; Văn thư không tự đóng trước khi lãnh đạo ký.';
    render(`
      <div class="tw-head">🔗 Đã nhận diện nhiệm vụ liên quan · ${esc(role)}</div>
      <div class="tw-row"><span class="tw-symbol">${esc(t.sourceSymbol||'')}</span> · ${esc(t.taskText||t.sourceSubject||'')}</div>
      ${t.deadline?`<div class="tw-row"><b>Hạn:</b> ${esc(deadlineLabel(t.deadline))}</div>`:''}
      <div class="tw-row"><b>Trạng thái:</b> <span class="tw-status">${esc(s)}</span></div>
      <div class="tw-small">${esc(hint)} · Khớp ${source==='local'?'cục bộ theo Số/Ký hiệu':'sau đối chiếu Sổ'}.</div>
    `, t.businessStatus==='WAITING_PUBLISH'?'wait':'');
  }

  function renderAmbiguous(tasks, reason='') {
    const items=(tasks||[]).slice(0,3).map(t=>`<div class="tw-row">• <b>${esc(t.sourceSymbol||'')}</b> · ${esc(t.taskText||t.sourceSubject||'')}</div>`).join('');
    render(`<div class="tw-head">⚠ Chưa tự cập nhật trạng thái</div>${items}<div class="tw-small">${esc(reason||'Có nhiều nhiệm vụ/văn bản nguồn phù hợp. Cần kiểm tra trước khi thay đổi Sổ.')}</div>`,'warn');
  }

  function renderNoTracked(symbols) {
    render(`<div class="tw-head">ℹ Văn bản liên quan chưa có trong Sổ theo dõi</div><div class="tw-small">${esc(symbols.join(', '))}. Tiện ích không tự tạo hoặc đổi trạng thái.</div>`,'');
  }

  function send(type,data={}) {
    return new Promise(resolve=>{
      try { chrome.runtime.sendMessage({type,data},r=>{if(chrome.runtime.lastError)return resolve({ok:false,error:chrome.runtime.lastError.message});resolve(r||{ok:false,error:'NO_RESPONSE'});}); }
      catch(e){resolve({ok:false,error:e.message||String(e)});}
    });
  }

  async function loadCacheFromStorage() {
    try {
      const s=await chrome.storage.local.get({[CACHE_KEY]:null});
      const c=s[CACHE_KEY];
      if (c && Array.isArray(c.tasks)) state.cache={updatedAt:Number(c.updatedAt||0),tasks:c.tasks};
    } catch (_) {}
  }

  function cacheFresh() { return state.cache.updatedAt && Date.now()-state.cache.updatedAt < CACHE_TTL_MS; }

  async function refreshCache(force=false) {
    if (!state.enabled || state.cacheRefreshing) return false;
    state.cacheRefreshing=true;
    try {
      const r=await send('TRACKER_CACHE_REFRESH',{force});
      if (r?.ok && r.cache && Array.isArray(r.cache.tasks)) {
        state.cache={updatedAt:Number(r.cache.updatedAt||Date.now()),tasks:r.cache.tasks};
        return true;
      }
    } finally { state.cacheRefreshing=false; }
    return false;
  }

  function localCandidates(relatedDocs) {
    const tasks=Array.isArray(state.cache.tasks)?state.cache.tasks:[];
    const byId=new Map();
    for (const rel of relatedDocs) {
      const rs=normSymbol(rel.symbol), rid=norm(rel.relatedIofficeId);
      for (const t of tasks) {
        if (norm(t.businessStatus)==='STOPPED') continue;
        const idHit=rid && norm(t.sourceIofficeId)===rid;
        const symHit=rs && normSymbol(t.sourceSymbol||t.soKyHieu)===rs;
        if (!idHit && !symHit) continue;
        const key=norm(t.taskId)||`${normSymbol(t.sourceSymbol)}|${norm(t.taskText)}`;
        const score=(idHit?200:0)+(symHit?100:0);
        const prev=byId.get(key);
        if(!prev||score>prev._score) byId.set(key,{...t,_score:score,_rel:rel});
      }
    }
    return [...byId.values()].sort((a,b)=>b._score-a._score);
  }

  async function resolveCurrent(force=false) {
    if (!state.enabled || !detectOutgoing() || state.pendingAction) { if(!detectOutgoing())hideCard(); return; }
    const relatedDocs=readRelatedDocuments();
    if (!relatedDocs.length) { state.currentMatch=null;state.currentRelatedDocs=[];state.currentContext=null;hideCard();return; }
    const ctx=readOutgoingContext();
    const fp=`${outgoingKey(ctx)}|${relatedDocs.map(x=>`${x.relatedIofficeId}:${normSymbol(x.symbol)}`).join('|')}`;
    if (!force && fp===state.lastFingerprint && state.currentMatch) { renderMatch(); return; }
    state.lastFingerprint=fp; state.currentRelatedDocs=relatedDocs; state.currentContext=ctx;

    let candidates=localCandidates(relatedDocs);
    if (candidates.length===1) {
      state.currentMatch={matched:true,task:candidates[0],matchMethod:candidates[0]._score>=200?'IOFFICE_ID+SYMBOL':'SYMBOL',matchScore:candidates[0]._score};
      renderMatch(state.currentMatch,'local'); return;
    }
    if (candidates.length>1) {
      // Nếu một ứng viên khớp ID iOffice duy nhất thì được phép chọn ngay.
      const idTop=candidates.filter(x=>x._score>=200);
      if (idTop.length===1) {
        state.currentMatch={matched:true,task:idTop[0],matchMethod:'IOFFICE_ID',matchScore:idTop[0]._score}; renderMatch(state.currentMatch,'local'); return;
      }
      // Nhiều nhiệm vụ cùng ký hiệu: chỉ fallback server 1 lần cho văn bản hiện tại.
      if (!state.remoteFallbackKeys.has(fp)) {
        state.remoteFallbackKeys.add(fp);
        const r=await send('TRACKER_MATCH',{relatedDocs,...ctx});
        const d=r?.data;
        if (r?.ok && d?.matched) { state.currentMatch=d; renderMatch(d,'server'); return; }
      }
      state.currentMatch=null; renderAmbiguous(candidates,'Một Số/Ký hiệu đang gắn với nhiều nhiệm vụ mở; tiện ích không tự chọn để tránh đóng nhầm.'); return;
    }

    // Không thấy trong cache: làm mới đúng một lần cho văn bản hiện tại.
    if (!state.refreshedForKey.has(fp)) {
      state.refreshedForKey.add(fp);
      if (!cacheFresh() || force) {
        if (!state.cache.tasks.length) render('<div class="tw-head">📒 Đang tải danh sách nhiệm vụ…</div>','wait');
        await refreshCache(true);
        candidates=localCandidates(relatedDocs);
        if (candidates.length===1) { state.currentMatch={matched:true,task:candidates[0],matchMethod:'SYMBOL',matchScore:candidates[0]._score};renderMatch(state.currentMatch,'local');return; }
        if (candidates.length>1) { state.currentMatch=null;renderAmbiguous(candidates);return; }
      }
    }
    state.currentMatch=null; renderNoTracked(relatedDocs.map(x=>x.symbol).filter(Boolean));
  }

  function scheduleScan(delay=160) {
    clearTimeout(state.scanTimer);
    state.scanTimer=setTimeout(()=>{const fp=pageFingerprint();if(fp!==state.lastFingerprint||!state.currentMatch)void resolveCurrent(false);},delay);
  }

  function alertText() {
    const sels='[role="alert"],.alert,.toast,.toast-message,.swal2-popup,.bootbox,.modal.show,.modal.in,.ui-dialog';
    return [...document.querySelectorAll(sels)].filter(visible).map(x=>norm(x.textContent)).filter(Boolean).join(' | ').slice(0,12000);
  }

  function classifyText(text,action) {
    const t=norm(text).toLowerCase(); if(!t)return'';
    if(/không thành công|khong thanh cong|thất bại|that bai|có lỗi|co loi|không thể|khong the|"success"\s*:\s*false|"status"\s*:\s*0|\berror\b/.test(t))return'failure';
    if(/thành công|thanh cong|"success"\s*:\s*true|"status"\s*:\s*1|"status"\s*:\s*"(?:success|ok)"/.test(t)){
      if(action==='sign'&&/(ký|ky|sign|duyệt|duyet)/.test(t))return'success';
      if(action==='publish'&&/(ban hành|ban hanh|publish|phát hành|phat hanh)/.test(t))return'success';
    }
    return'';
  }

  function responseClassification(watchId,action) {
    const list=state.actionResponses.get(watchId)||[]; let ok=false;
    for(const x of list){const c=classifyText(`${x.text||''} ${x.url||''}`,action);if(c==='failure')return'failure';if(c==='success')ok=true;}
    return ok?'success':'';
  }

  function armNetworkWatch(pending) {
    try{window.postMessage({channel:ACTION_CHANNEL,type:'arm',watchId:pending.watchId,action:pending.action,untilMs:65000},location.origin);}catch(_){}
  }

  async function finishActionSuccess(pending,evidence) {
    if(state.pendingAction!==pending)return;
    const ctx=readOutgoingContext(), task=state.currentMatch?.task;
    if(!task?.taskId){state.pendingAction=null;render('<div class="tw-head">⚠ Không còn xác định được nhiệm vụ nguồn</div><div class="tw-small">Sổ chưa đổi trạng thái.</div>','err');return;}
    let type,data;
    const rel=state.currentRelatedDocs.find(x=>normSymbol(x.symbol)===normSymbol(task.sourceSymbol))||state.currentRelatedDocs[0]||{};
    if(pending.action==='sign'){
      type='TRACKER_MARK_SIGNED';
      data={taskId:task.taskId,...ctx,matchedSourceIofficeId:rel.relatedIofficeId||'',matchedSourceSymbol:rel.symbol||task.sourceSymbol||'',matchMethod:'RELATED_SYMBOL_LOCAL',matchScore:100,relatedRawText:rel.rawText||'',signedAt:new Date().toISOString(),role:'LEADER',evidence};
      render('<div class="tw-head">✓ iOffice đã xác nhận ký · đang ghi Sổ…</div>','wait');
    } else {
      if(!ctx.resultSymbol){state.pendingAction=null;render('<div class="tw-head">⚠ Ban hành đã xử lý nhưng chưa đọc được Số/Ký hiệu</div><div class="tw-small">Không đánh dấu hoàn thành để tránh sai dữ liệu.</div>','err');return;}
      type='TRACKER_MARK_PUBLISHED';
      data={taskId:task.taskId,...ctx,matchedSourceIofficeId:rel.relatedIofficeId||'',matchedSourceSymbol:rel.symbol||task.sourceSymbol||'',matchMethod:'RELATED_SYMBOL_LOCAL',matchScore:100,relatedRawText:rel.rawText||'',publishedAt:new Date().toISOString(),role:'CLERK',evidence};
      render('<div class="tw-head">✓ iOffice đã xác nhận Ban hành · đang hoàn thành nhiệm vụ…</div>','wait');
    }
    const r=await send(type,data); state.pendingAction=null;
    if(!r?.ok){render(`<div class="tw-head">⚠ iOffice đã xử lý nhưng cập nhật Sổ lỗi</div><div class="tw-small">${esc(r?.error||'Không rõ lỗi')}. Không lặp lại thao tác iOffice.</div>`,'err');return;}
    const d=r.data||{};
    if(r.queued||d.queued){render(`<div class="tw-head">✓ iOffice đã xử lý · đang chờ đồng bộ Sổ</div><div class="tw-small">Dữ liệu đã lưu hàng chờ cục bộ và sẽ tự gửi lại khi kết nối ổn định.</div>`,'warn');return;}
    task.businessStatus=d.businessStatus||(pending.action==='sign'?'WAITING_PUBLISH':'COMPLETED'); if(ctx.resultSymbol)task.resultSymbol=ctx.resultSymbol;
    const label=pending.action==='sign'?'Đã xử lý - chờ ban hành':'Đã hoàn thành';
    render(`<div class="tw-head">✓ ${esc(label)}</div><div class="tw-row"><b>${esc(task.sourceSymbol||'')}</b>${ctx.resultSymbol?` → ${esc(ctx.resultSymbol)}`:''}</div><div class="tw-small">${esc(evidence)}</div>`,pending.action==='sign'?'wait':'');
    void refreshCache(true);
  }

  function finishActionFailure(pending,evidence){if(state.pendingAction!==pending)return;state.pendingAction=null;render(`<div class="tw-head">✕ iOffice chưa ${pending.action==='sign'?'ký':'ban hành'} thành công</div><div class="tw-small">${esc(evidence)} · Sổ không đổi trạng thái.</div>`,'err');}

  async function watchAction(pending) {
    const deadline=Date.now()+65000; let publishGoneSince=0;
    while(state.pendingAction===pending&&Date.now()<deadline){
      await new Promise(r=>setTimeout(r,350));
      const net=responseClassification(pending.watchId,pending.action); if(net==='failure')return finishActionFailure(pending,'Phản hồi iOffice báo không thành công'); if(net==='success')return finishActionSuccess(pending,'Xác nhận từ máy chủ iOffice');
      const ui=classifyText(alertText(),pending.action); if(ui==='failure')return finishActionFailure(pending,'Thông báo iOffice báo lỗi'); if(ui==='success')return finishActionSuccess(pending,'Thông báo thành công trên iOffice');
      if(pending.action==='sign'){
        const sig=signatureFingerprint(); if(sig&&sig!==pending.beforeSignature)return finishActionSuccess(pending,'Tệp/chữ ký số đã thay đổi');
      } else {
        const finalVisible=[...document.querySelectorAll('#btnBanhanh')].some(visible); const formVisible=[...document.querySelectorAll('#btn_vdi_savedoc,#TRICH_YEU')].some(visible);
        const nowKey=outgoingKey(readOutgoingContext()); const keyChanged=nowKey&&nowKey!==pending.beforeDocKey;
        if((!finalVisible&&!formVisible)||keyChanged){if(!publishGoneSince)publishGoneSince=Date.now();if(Date.now()-publishGoneSince>1200)return finishActionSuccess(pending,'Màn hình Ban hành đã đóng/chuyển');}else publishGoneSince=0;
      }
    }
    if(state.pendingAction===pending){state.pendingAction=null;render(`<div class="tw-head">⚠ Chưa xác nhận được ${pending.action==='sign'?'Ký':'Ban hành'} thành công</div><div class="tw-small">Sổ chưa đổi trạng thái để tránh ghi sai.</div>`,'warn');}
  }

  function beginAction(action) {
    const task=state.currentMatch?.task; if(!state.currentMatch?.matched||!task?.taskId||state.pendingAction)return;
    if(action==='sign'){
      if(state.userRole!=='leader'||['COMPLETED','WAITING_PUBLISH','STOPPED'].includes(task.businessStatus))return;
    } else {
      if(state.userRole!=='clerk'||task.businessStatus==='COMPLETED'||task.businessStatus==='STOPPED')return;
      if(task.businessStatus!=='WAITING_PUBLISH'){render('<div class="tw-head">⚠ Nhiệm vụ chưa ở trạng thái Chờ ban hành</div><div class="tw-small">Không tự hoàn thành trước khi lãnh đạo ký/xử lý.</div>','err');return;}
    }
    const ctx=readOutgoingContext(); if(action==='publish'&&!ctx.resultSymbol){render('<div class="tw-head">⚠ Chưa có Số/Ký hiệu văn bản đi</div><div class="tw-small">Không đánh dấu hoàn thành cho đến khi văn bản đã được vào số.</div>','err');return;}
    const pending={action,watchId:`tw-${Date.now()}-${Math.random().toString(36).slice(2,8)}`,beforeSignature:signatureFingerprint(),beforeDocKey:outgoingKey(ctx)};
    state.pendingAction=pending;state.actionResponses.set(pending.watchId,[]);armNetworkWatch(pending);
    render(`<div class="tw-head">⏳ Chờ iOffice xác nhận ${action==='sign'?'Ký':'Ban hành'}…</div><div class="tw-small">Chưa cập nhật Sổ cho tới khi có tín hiệu thành công.</div>`,'wait');
    void watchAction(pending);
  }

  document.addEventListener('click',ev=>{
    if(!state.enabled||!detectOutgoing())return; const target=ev.target instanceof Element?ev.target:null;if(!target)return;
    if(target.closest('#btn_ky_vbTrinhKy')&&state.userRole==='leader'){beginAction('sign');return;}
    if(target.closest('#btnBanhanh')&&state.userRole==='clerk'){beginAction('publish');}
  },true);

  window.addEventListener('message',event=>{
    if(event.source!==window||event.origin!==location.origin)return;const d=event.data;if(!d||d.channel!==ACTION_CHANNEL||d.type!=='response'||!d.watchId)return;
    const arr=state.actionResponses.get(d.watchId)||[];arr.push({url:norm(d.url),text:norm(d.text).slice(0,6000),status:Number(d.status||0),method:norm(d.method)});if(arr.length>24)arr.shift();state.actionResponses.set(d.watchId,arr);
  });

  function mutationRelevant(mutations) {
    const host=document.getElementById(WIDGET_HOST_ID);
    const selector='#thongtinvb,#div_thongtin_chitiet,#modal_detail_doc_popup,#rightContentDLK,#btn_ky_vbTrinhKy,#btnBanhanh,#TRICH_YEU,#txt_idedit,#idVB,#hide_docid';
    const nodeRelevant=n=>{
      if(!(n instanceof Element))return false;
      if(host&&(n===host||host.contains(n)))return false;
      try{return n.matches(selector)||Boolean(n.querySelector(selector))||Boolean(n.closest('#thongtinvb,#div_thongtin_chitiet,#modal_detail_doc_popup,#rightContentDLK'));}catch(_){return false;}
    };
    for(const m of mutations){
      if(host&&(m.target===host||host.contains(m.target)))continue;
      if(nodeRelevant(m.target))return true;
      for(const n of m.addedNodes||[])if(nodeRelevant(n))return true;
      for(const n of m.removedNodes||[])if(nodeRelevant(n))return true;
    }
    return false;
  }

  async function loadSettings() {
    try{
      const s=await chrome.storage.local.get({trackerEnabled:false,userRole:'leader',[CACHE_KEY]:null});
      state.enabled=s.trackerEnabled===true;state.userRole=['leader','chief','clerk'].includes(s.userRole)?s.userRole:'leader';
      const c=s[CACHE_KEY];if(c&&Array.isArray(c.tasks))state.cache={updatedAt:Number(c.updatedAt||0),tasks:c.tasks};
      if(!state.enabled){hideCard();return;}
      scheduleScan(100); if(!cacheFresh())void refreshCache(false);
    }catch(_){}
  }

  try{chrome.storage.onChanged.addListener((changes,area)=>{
    if(area!=='local')return;
    if(changes.trackerEnabled)state.enabled=changes.trackerEnabled.newValue===true;
    if(changes.userRole)state.userRole=['leader','chief','clerk'].includes(changes.userRole.newValue)?changes.userRole.newValue:'leader';
    if(changes[CACHE_KEY]?.newValue){const c=changes[CACHE_KEY].newValue;if(c&&Array.isArray(c.tasks))state.cache={updatedAt:Number(c.updatedAt||0),tasks:c.tasks};}
    state.lastFingerprint='';state.currentMatch=null;state.refreshedForKey.clear();state.remoteFallbackKeys.clear();
    if(!state.enabled)hideCard();else scheduleScan(80);
  });}catch(_){}

  const observer=new MutationObserver(ms=>{if(state.enabled&&mutationRelevant(ms))scheduleScan(220);});
  const startObserver=()=>{if(document.body)observer.observe(document.body,{subtree:true,childList:true});};
  startObserver();
  document.addEventListener('visibilitychange',()=>{if(state.enabled&&!document.hidden){scheduleScan(80);if(!cacheFresh())void refreshCache(false);}});

  void loadCacheFromStorage().finally(loadSettings);
})();
