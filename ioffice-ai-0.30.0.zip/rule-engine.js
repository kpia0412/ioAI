/* Local, transparent routing rules. This is NOT AI. */
(() => {
  'use strict';

  const VERSION = '0.16.4-rules';
  const norm = (v) => String(v || '')
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .replace(/đ/g, 'd').replace(/Đ/g, 'D')
    .toLowerCase().replace(/\s+/g, ' ').trim();
  const uniq = (a) => [...new Set((a || []).filter(Boolean))];
  const arr = (v) => Array.isArray(v) ? v : [];

  function phraseMatches(haystack, phrases) {
    const h = norm(haystack);
    if (!h) return [];
    const out = [];
    for (const raw of arr(phrases)) {
      const p = norm(raw);
      if (p && h.includes(p)) out.push(String(raw).trim());
    }
    return uniq(out);
  }

  function cleanRule(rule) {
    const weights = rule?.weights || {};
    return {
      ...rule,
      enabled: rule?.enabled !== false,
      priority: Number(rule?.priority || 0),
      minScore: Math.max(0, Number(rule?.minScore || 0)),
      match: {
        senderAny: arr(rule?.match?.senderAny),
        subjectAny: arr(rule?.match?.subjectAny),
        contentAny: arr(rule?.match?.contentAny),
        attachmentAny: arr(rule?.match?.attachmentAny),
        excludeAny: arr(rule?.match?.excludeAny)
      },
      weights: {
        sender: Number(weights.sender ?? 18),
        subject: Number(weights.subject ?? 14),
        content: Number(weights.content ?? 9),
        attachment: Number(weights.attachment ?? 5)
      }
    };
  }

  function categoryScore(matches, weight, capMatches = 3) {
    return Math.min(capMatches, matches.length) * Math.max(0, Number(weight) || 0);
  }

  function analyze(context, config, availableUnits = []) {
    const rules = arr(config?.rules).map(cleanRule).filter((r) => r.enabled && /^U\d+$/.test(r.mainUnit || ''));
    const allowed = new Set((availableUnits || []).map((u) => u.value || u.id).filter((x) => /^U\d+$/.test(x)));
    for (const u of arr(config?.units)) if (/^U\d+$/.test(u.id || '')) allowed.add(u.id);

    const bundle = context?.documentBundle || {};
    const content = [
      context?.previewText || '',
      bundle?.combinedText || '',
      bundle?.primaryDocument?.text || '',
      ...arr(bundle?.supportingDocuments).map((d) => d?.text || '')
    ].join('\n');
    const attachmentText = arr(context?.attachmentNames).join(' | ');
    const whole = [context?.trichYeu, context?.sender, content, attachmentText].join('\n');

    const unitScores = new Map();
    const matchedRules = [];
    const roleVotes = { coordination: new Map(), view: new Map() };

    for (const rule of rules) {
      if (!allowed.has(rule.mainUnit)) continue;
      const excluded = phraseMatches(whole, rule.match.excludeAny);
      if (excluded.length) continue;

      const sender = phraseMatches(context?.sender, rule.match.senderAny);
      const subject = phraseMatches(context?.trichYeu, rule.match.subjectAny);
      const body = phraseMatches(content, rule.match.contentAny);
      const attachment = phraseMatches(attachmentText, rule.match.attachmentAny);
      const anyCondition = rule.match.senderAny.length || rule.match.subjectAny.length || rule.match.contentAny.length || rule.match.attachmentAny.length;
      if (anyCondition && !(sender.length || subject.length || body.length || attachment.length)) continue;

      let score = 5;
      score += categoryScore(sender, rule.weights.sender, 2);
      score += categoryScore(subject, rule.weights.subject, 3);
      score += categoryScore(body, rule.weights.content, 4);
      score += categoryScore(attachment, rule.weights.attachment, 2);
      score += Math.max(0, Math.min(10, rule.priority / 20));
      if (score < rule.minScore) continue;

      unitScores.set(rule.mainUnit, (unitScores.get(rule.mainUnit) || 0) + score);
      for (const id of arr(rule.coordinationUnits)) {
        if (!allowed.has(id) || id === rule.mainUnit) continue;
        roleVotes.coordination.set(id, (roleVotes.coordination.get(id) || 0) + score);
      }
      for (const id of arr(rule.viewUnits)) {
        if (!allowed.has(id) || id === rule.mainUnit) continue;
        roleVotes.view.set(id, (roleVotes.view.get(id) || 0) + score);
      }
      matchedRules.push({
        id: rule.id || '', name: rule.name || rule.id || 'Quy tắc', mainUnit: rule.mainUnit,
        score: Number(score.toFixed(1)), sender, subject, content: body, attachment,
        instruction: String(rule.instruction || '').trim()
      });
    }

    const ranking = [...unitScores.entries()].sort((a, b) => b[1] - a[1]);
    if (!ranking.length) {
      const err = new Error('Bộ quy tắc chưa có điều kiện đủ mạnh cho văn bản này. Hãy bổ sung quy tắc hoặc dùng Gemini Web, ChatGPT Web hoặc API.');
      err.code = 'NO_RULE_MATCH';
      throw err;
    }
    const [mainUnit, topScore] = ranking[0];
    const secondScore = ranking[1]?.[1] || 0;
    const confidence = Math.max(0.35, Math.min(0.98, topScore / (topScore + secondScore + 8)));

    const coordinationUnits = [...roleVotes.coordination.entries()]
      .filter(([id]) => id !== mainUnit)
      .sort((a, b) => b[1] - a[1])
      .filter(([, score]) => score >= Math.max(18, topScore * 0.2))
      .slice(0, 5).map(([id]) => id);
    const viewUnits = [...roleVotes.view.entries()]
      .filter(([id]) => id !== mainUnit && !coordinationUnits.includes(id))
      .sort((a, b) => b[1] - a[1])
      .filter(([, score]) => score >= Math.max(16, topScore * 0.18))
      .slice(0, 8).map(([id]) => id);

    const topRules = matchedRules.filter((r) => r.mainUnit === mainUnit).sort((a, b) => b.score - a.score).slice(0, 4);
    const signals = [];
    for (const r of topRules) {
      const parts = [];
      if (r.subject.length) parts.push(`trích yếu: ${r.subject.slice(0,2).join(', ')}`);
      if (r.sender.length) parts.push(`đơn vị gửi: ${r.sender.slice(0,2).join(', ')}`);
      if (r.content.length) parts.push(`nội dung: ${r.content.slice(0,2).join(', ')}`);
      if (r.attachment.length) parts.push(`tệp: ${r.attachment.slice(0,2).join(', ')}`);
      signals.push(`${r.name} (+${Math.round(r.score)}${parts.length ? ` · ${parts.join(' · ')}` : ''})`);
    }

    const instruction = topRules.find((r) => r.instruction)?.instruction || '';
    const unreadableCount = Number(bundle?.stats?.unreadableCount || 0);
    const requiresReview = confidence < 0.72 || unreadableCount > 0;
    const reason = `Quy tắc chấm ${mainUnit} ${Math.round(topScore)} điểm${secondScore ? `; phương án kế tiếp ${Math.round(secondScore)} điểm` : ''}. ${topRules.length ? `Khớp ${topRules.map((r) => r.name).join(', ')}.` : ''}`.trim();

    return {
      mainUnit,
      coordinationUnits: uniq(coordinationUnits),
      viewUnits: uniq(viewUnits),
      instruction,
      reason,
      confidence: Number(confidence.toFixed(3)),
      requiresReview,
      signals: signals.slice(0, 4),
      provider: 'local-rules',
      providerLabel: 'Phân tích bằng quy tắc',
      localRuleMeta: {
        version: VERSION,
        topScore: Number(topScore.toFixed(1)),
        secondScore: Number(secondScore.toFixed(1)),
        ranking: ranking.slice(0, 6).map(([unit, score]) => ({ unit, score: Number(score.toFixed(1)) })),
        matchedRules: matchedRules.sort((a, b) => b.score - a.score).slice(0, 12)
      }
    };
  }

  globalThis.IOfficeRuleEngine = Object.freeze({ VERSION, analyze });
})();
