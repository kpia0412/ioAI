/* Internet updater. Native helper is installed once on Windows. */
let iofficeUpdateApplying = false;
let iofficeUpdateCheck = null;
const UPDATE_HOST = 'vn.ealy.ioffice_updater';
const UPDATE_ALARM = 'ioffice-internet-update';
function nativeUpdate(message) {
  return new Promise((resolve, reject) => {
    // A native port keeps the MV3 worker alive while the helper downloads files.
    const port = chrome.runtime.connectNative(UPDATE_HOST);
    let done = false;
    port.onMessage.addListener(reply => {
      if (done) return; done = true; port.disconnect();
      reply?.ok ? resolve(reply) : reject(new Error(reply?.error || 'Bộ cập nhật không trả kết quả hợp lệ.'));
    });
    port.onDisconnect.addListener(() => {
      const error = chrome.runtime.lastError;
      if (!done) { done = true; reject(new Error(error?.message || 'Mất kết nối bộ cập nhật Windows.')); }
    });
    port.postMessage(message);
  });
}
async function updateState(patch) {
  const { internetUpdate = {} } = await chrome.storage.local.get('internetUpdate');
  const next = { ...internetUpdate, ...patch };
  await chrome.storage.local.set({ internetUpdate: next }); return next;
}
async function checkInternetUpdate() {
  if (iofficeUpdateApplying) return;
  if (iofficeUpdateCheck) return iofficeUpdateCheck;
  iofficeUpdateCheck = (async () => {
    try {
      const data = await nativeUpdate({ command: 'check' });
      return await updateState({ ...data, phase: data.newer ? 'available' : 'current', error: '', checkedAt: Date.now() });
    } catch (e) {
      return await updateState({ phase: 'error', error: 'Chưa kiểm tra được. Kiểm tra Internet và bộ hỗ trợ Windows. Chi tiết: ' + e.message, checkedAt: Date.now() });
    }
  })();
  try { return await iofficeUpdateCheck; } finally { iofficeUpdateCheck = null; }
}
async function applyInternetUpdate() {
  if (iofficeUpdateApplying) throw new Error('Đang cập nhật, vui lòng chờ.');
  iofficeUpdateApplying = true;
  if (iofficeUpdateCheck) await iofficeUpdateCheck;
  const locked = [];
  let applied = false;
  try {
    // Set the gate before inspecting jobs to prevent a new analysis starting.
    if (apiRequests.size || (await webAiActiveJobCount()) > 0) throw new Error('Đang phân tích AI. Hãy chờ xong rồi cập nhật.');
    const session = await chrome.storage.session.get(null);
    if (Object.entries(session).some(([k,v]) => k.startsWith(WEB_JOB_PREFIX) && v && !terminal(v) && Date.now() < v.deadline))
      throw new Error('Web AI đang phân tích. Hãy chờ xong rồi cập nhật.');
    const tabs = await chrome.tabs.query({url:'https://ioffice.vnptdaklak.vn/qlvbdh_dlk/*'});
    for (const tab of tabs) {
      if (tab.discarded || /\/web\/viewer.jsp/.test(tab.url || '')) continue;
      let reply;
      try { reply = await chrome.tabs.sendMessage(tab.id, {type:'IOFFICE_UPDATE_LOCK'}); }
      catch (_) { throw new Error('Hãy làm mới các tab iOffice trước lần cập nhật này.'); }
      if (!reply?.ok) throw new Error('Một tab iOffice đang đọc tệp hoặc phân tích. Hãy chờ xong rồi cập nhật.');
      locked.push(tab.id);
    }
    const {internetUpdate: release} = await chrome.storage.local.get('internetUpdate');
    if (!release?.newer || !release.sha256) throw new Error('Hãy kiểm tra bản mới trước.');
    await updateState({phase:'applying',error:''});
    const result = await nativeUpdate({command:'apply',version:release.version,sha256:release.sha256});
    if (!result.applied) throw new Error('Chưa thay được phiên bản.');
    applied = true;
    await updateState({phase:'installed',newer:false,current:result.version,error:''});
    await Promise.allSettled(locked.map(id => chrome.tabs.sendMessage(id,{type:'IOFFICE_UPDATE_DONE',version:result.version})));
    // Reload extension only; users decide when to refresh pages with unsaved forms.
    setTimeout(() => chrome.runtime.reload(), 500);
    return {ok:true};
  } catch (e) {
    await updateState({phase:'error',error:e.message}); throw e;
  } finally {
    if (!applied) {
      iofficeUpdateApplying = false;
      await Promise.allSettled(locked.map(id => chrome.tabs.sendMessage(id,{type:'IOFFICE_UPDATE_UNLOCK'})));
    }
  }
}
async function ensureUpdateAlarm() {
  if (!await chrome.alarms.get(UPDATE_ALARM)) await chrome.alarms.create(UPDATE_ALARM,{delayInMinutes:1,periodInMinutes:5});
}
chrome.alarms.onAlarm.addListener(alarm => { if (alarm.name === UPDATE_ALARM) checkInternetUpdate().catch(console.error); });
chrome.runtime.onStartup.addListener(() => { ensureUpdateAlarm().then(checkInternetUpdate).catch(console.error); });
chrome.runtime.onInstalled.addListener(() => { ensureUpdateAlarm().then(checkInternetUpdate).catch(console.error); });
ensureUpdateAlarm().catch(console.error);
chrome.runtime.onMessage.addListener((m,s,reply) => {
  if (!['INTERNET_UPDATE_CHECK','INTERNET_UPDATE_APPLY','INTERNET_UPDATE_OPTIONS'].includes(m?.type)) return;
  const options = s.url === chrome.runtime.getURL('options.html');
  const office = s.id === chrome.runtime.id && /^https:\/\/ioffice\.vnptdaklak\.vn\/qlvbdh_dlk\//.test(s.url || '');
  if (s.id !== chrome.runtime.id || (!options && !office)) return;
  if (m.type === 'INTERNET_UPDATE_OPTIONS') { chrome.runtime.openOptionsPage(); reply({ok:true}); return; }
  const task = m.type === 'INTERNET_UPDATE_CHECK' ? checkInternetUpdate() : applyInternetUpdate();
  task.then(data => reply({ok:true,data})).catch(e => reply({ok:false,error:e.message})); return true;
});
