(() => {
  if (window.top !== window) return;
  let host, message, button, refreshing = false;
  function show(text, action, label) {
    if (!host) {
      host = document.createElement('div');
      host.style.cssText='position:fixed;bottom:12px;left:12px;z-index:2147483647;max-width:430px';
      const root=host.attachShadow({mode:'closed'});
      const box=document.createElement('div');
      box.style.cssText='background:#123d48;color:white;padding:14px;border-radius:12px;box-shadow:0 4px 18px #0004;font:14px/1.5 Arial';
      message=document.createElement('div'); button=document.createElement('button');
      button.style.cssText='margin-top:8px;padding:8px 12px;cursor:pointer;border:0;border-radius:6px;background:#ccf3e0;color:#123d48;font-weight:bold';
      box.append(message,button);root.append(box);document.documentElement.append(host);
    }
    host.hidden=false;message.textContent=text;button.textContent=label;button.disabled=!action;
    button.onclick=action ? event => {if(event.isTrusted) action();} : null;
  }
  function render(s) {
    if (refreshing) return;
    if(s?.phase==='applying') show('Đang tải và cài bản cập nhật. Vui lòng giữ Chrome mở.',null,'Đang cập nhật…');
    else if(s?.newer) show(`iOffice AI có bản ${s.version}. ${s.error || 'Có thể cập nhật ngay trong trình duyệt.'}`, async () => {
      button.disabled=true;
      try {
        const r=await chrome.runtime.sendMessage({type:'INTERNET_UPDATE_APPLY'});
        if(!r?.ok) show(r?.error || 'Chưa cập nhật được.',()=>chrome.runtime.sendMessage({type:'INTERNET_UPDATE_OPTIONS'}),'Mở cài đặt');
      } catch (_) { if(!refreshing) show('Kết nối tiện ích đã thay đổi. Hãy lưu công việc và làm mới trang.',()=>location.reload(),'Làm mới iOffice'); }
    },'Đồng ý cập nhật');
    else if(host) host.hidden=true;
  }
  chrome.storage.local.get('internetUpdate').then(x=>render(x.internetUpdate));
  chrome.storage.onChanged.addListener((c,a)=>{if(a==='local'&&c.internetUpdate)render(c.internetUpdate.newValue);});
  chrome.runtime.onMessage.addListener(m=>{
    if(m?.type==='IOFFICE_UPDATE_DONE') {
      refreshing=true;
      show(`Đã cài iOffice AI ${m.version}. Lưu nội dung đang nhập, rồi làm mới trang để sử dụng.`,()=>location.reload(),'Làm mới iOffice');
    }
  });
})();
