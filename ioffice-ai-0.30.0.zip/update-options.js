(() => {
  const status=document.getElementById('internetStatus'),check=document.getElementById('internetCheck'),apply=document.getElementById('internetApply');
  if(!status||!check||!apply)return;
  function render(s){status.textContent=s?.phase==='applying'?'Đang tải và cài đặt…':s?.error||(s?.newer?`Có phiên bản ${s.version}. ${s.notes||''}`:s?.current?`Phiên bản đã cài: ${s.current}`:'Chưa kiểm tra.');status.className='status '+(s?.error?'err':s?.newer?'ok':'');apply.hidden=!s?.newer;apply.disabled=s?.phase==='applying';check.disabled=s?.phase==='applying';}
  async function run(type){check.disabled=apply.disabled=true;try{const r=await chrome.runtime.sendMessage({type});if(!r?.ok)throw new Error(r?.error||'Không có phản hồi.');}catch(e){status.textContent=e.message;status.className='status err';}finally{check.disabled=apply.disabled=false;}}
  check.onclick=()=>run('INTERNET_UPDATE_CHECK');apply.onclick=()=>run('INTERNET_UPDATE_APPLY');chrome.storage.local.get('internetUpdate').then(x=>render(x.internetUpdate));chrome.storage.onChanged.addListener((c,a)=>{if(a==='local'&&c.internetUpdate)render(c.internetUpdate.newValue);});
})();
