(() => {
  'use strict';

  const HOST_ID = 'ealy-ioffice-ai-host';
  const VERSION = '0.21.0';

  const state = {
    runId: 0,
    prepKey: '',
    rules: null,
    root: null,
    refs: {},
    lastSuggestion: null,
    lastContext: null,
    lastSignals: [],
    busy: false,
    updateLocked: false,
    lastPrep: null,
    documentKey: '',
    analyzedKey: '',
    pickerRole: null,
    analysisStartedAt: 0,
    analysisTimer: null,
    lastAnalysisMeta: null,
    pendingWeb: null,
    pendingWebJob: null,
    analysisMode: 'gemini-web',
    fallbackAnalysisMode: 'chatgpt-web',
    progressLog: [],
    activeAbortController: null,
    cancelRequested: false,
    lastGeminiPhase: '',
    geminiEventCache: new Map(),
    geminiWaiters: new Map(),
    appliedKey: '',
    finalizing: false,
    lastAnalysisKind: '',
    inputAudit: null,
    workflowPhase: 'analyze',
    userRole: 'leader',
    documentDirection: 'incoming',
    workflow: 'leader-incoming',
    forceReadAllOnce: false,
    trackerEnabled: false,
    trackerReminderDays: 3,
    trackerConnected: null,
    trackerCandidate: null,
    clerkAutoAppliedKey: '',
    pendingAppliedSuggestion: null,
    pendingTrackerContextSnapshot: null,
    chiefDefaultViewRecipientIds: []
  };


  let extensionContextInvalid = false;
  function chromeContextAlive() {
    if (extensionContextInvalid) return false;
    try { return Boolean(globalThis.chrome?.runtime?.id); }
    catch (_) { extensionContextInvalid = true; return false; }
  }
  function contextInvalidError(error) {
    return /Extension context invalidated|context invalidated|Receiving end does not exist/i.test(String(error?.message || error || ''));
  }
  function markExtensionContextInvalid(error = null) {
    if (error && !contextInvalidError(error)) return false;
    extensionContextInvalid = true;
    try {
      const el = state?.refs?.message;
      if (el) {
        el.textContent = 'Tiện ích vừa được Reload/Cập nhật. Hãy F5 tab iOffice một lần để nạp phiên bản mới.';
        el.className = 'message warn';
      }
    } catch (_) {}
    return true;
  }
  async function safeStorageGet(defaults = {}) {
    if (!chromeContextAlive()) return { ...defaults };
    try { return await chrome.storage.local.get(defaults); }
    catch (error) { if (markExtensionContextInvalid(error)) return { ...defaults }; throw error; }
  }
  async function safeStorageSet(values) {
    if (!chromeContextAlive()) return false;
    try { await chrome.storage.local.set(values); return true; }
    catch (error) { if (markExtensionContextInvalid(error)) return false; throw error; }
  }
  function safeRuntimeSend(message, { quiet = false } = {}) {
    return new Promise((resolve, reject) => {
      if (!chromeContextAlive()) {
        const error = new Error('Extension context invalidated');
        markExtensionContextInvalid(error);
        return quiet ? resolve(null) : reject(error);
      }
      try {
        chrome.runtime.sendMessage(message, (response) => {
          const last = chrome.runtime?.lastError;
          if (last) {
            const error = new Error(last.message || 'Không gửi được yêu cầu tới tiện ích.');
            if (markExtensionContextInvalid(error) && quiet) return resolve(null);
            return quiet ? resolve(null) : reject(error);
          }
          resolve(response);
        });
      } catch (error) {
        if (markExtensionContextInvalid(error) && quiet) return resolve(null);
        quiet ? resolve(null) : reject(error);
      }
    });
  }

  const normalizeText = (value) => (value || '')
    .replace(/\u00a0/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();

  const escapeHtml = (value) => String(value || '')
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;');

  const uniq = (items) => [...new Set((items || []).filter(Boolean))];
  const clamp = (n, min, max) => Math.max(min, Math.min(max, Number(n) || 0));

  const COMMON_METADATA_LABELS = [
    'trích yếu','đơn vị ban hành','cơ quan ban hành','cơ quan gửi','số ký hiệu','số, ký hiệu',
    'số đến','độ khẩn','người soạn thảo','người ký','văn bản giấy','ghi chú','ngày văn bản',
    'hình thức','loại văn bản','lĩnh vực','ngày đến','hạn xử lý'
  ];

  function looksLikeMetadataLabel(value) {
    const text = normalizeText(value).replace(/[:：]+$/, '').toLowerCase();
    if (!text || text.length > 60) return false;
    return COMMON_METADATA_LABELS.some((label) => text === label || text.startsWith(`${label}:`));
  }

  function looksLikeGarbageText(value) {
    const text = normalizeText(value);
    return !text || /:hover\s*\{|text-decoration\s*:|display\s*:|font-size\s*:|\.\w+[^{]{0,50}\{|content\s*:\s*["']?/i.test(text);
  }

  function formatDuration(ms) {
    const value = Math.max(0, Number(ms) || 0);
    if (value < 1000) return `${Math.round(value)} ms`;
    if (value < 10000) return `${(value / 1000).toFixed(1)} s`;
    return `${Math.round(value / 1000)} s`;
  }

  function getTokenUsage(ai) {
    const usage = ai?.usageMetadata || {};
    const firstNumber = (...values) => {
      for (const value of values) {
        const n = Number(value);
        if (Number.isFinite(n) && n >= 0) return n;
      }
      return null;
    };
    const input = firstNumber(usage.promptTokenCount, usage.input_tokens, usage.inputTokens, usage.prompt_tokens);
    const output = firstNumber(usage.candidatesTokenCount, usage.output_tokens, usage.outputTokens, usage.completion_tokens);
    let total = firstNumber(usage.totalTokenCount, usage.total_tokens, usage.totalTokens);
    if (total == null && input != null && output != null) total = input + output;
    if (total != null) return { total: Math.round(total), input, output, estimated: false };
    if (ai?.promptChars) return { total: Math.max(1, Math.round(Number(ai.promptChars) / 4)), input: null, output: null, estimated: true };
    return { total: 0, input: null, output: null, estimated: false };
  }

  function confidenceStyle(pct) {
    if (pct >= 80) return { cls: 'high', color: '#16a34a' };
    if (pct >= 60) return { cls: 'mid', color: '#f59e0b' };
    return { cls: 'low', color: '#ef4444' };
  }

  const SHORT_UNIT_NAMES = {
    U100: 'UBND xã',
    U140: 'Văn phòng',
    U141: 'Phòng Kinh tế',
    U142: 'Phòng VH-XH',
    U120: 'TT Phục vụ HCC',
    U183: 'TT Cung ứng DV sự nghiệp công',
    U260: 'HĐND xã',
    U340: 'Công an xã',
    U360: 'Ban CHQS',
    U200: 'Trạm Y tế',
    U221: 'Trường THCS',
    U222: 'Trường Tiểu học',
    U240: 'Trường Mẫu giáo'
  };

  function shortUnitName(id, fallback = '') {
    return SHORT_UNIT_NAMES[id] || normalizeText(fallback || id)
      .replace(/\s*-\s*tỉnh\s+Đắk\s+Lắk$/i, '')
      .replace(/^Văn\s+Phòng\s+HĐND\s+và\s+UBND$/i, 'Văn phòng')
      .replace(/^Phòng\s+Văn\s+hóa\s*-\s*Xã\s+hội$/i, 'Phòng VH-XH')
      .replace(/^Trung\s+tâm\s+Phục\s+vụ\s+hành\s+chính\s+công$/i, 'TT Phục vụ HCC')
      .replace(/^Trung\s+tâm\s+Cung\s+ứng\s+dịch\s+vụ\s+sự\s+nghiệp\s+công\s+xã\s+Ea\s+Ly$/i, 'TT Cung ứng DV sự nghiệp công')
      .replace(/^CÔNG\s+AN\s+XÃ\s+EA\s+LY$/i, 'Công an xã')
      .replace(/^BAN\s+CHỈ\s+HUY\s+QUÂN\s+SỰ\s+XÃ\s+EA\s+LY$/i, 'Ban CHQS')
      .replace(/^Trạm\s+Y\s+tế\s+xã\s+Ea\s+Ly$/i, 'Trạm Y tế');
  }

  function cleanTrichYeu(value) {
    let text = normalizeText(value);
    if (!text || looksLikeGarbageText(text) || looksLikeMetadataLabel(text)) return '';
    text = text.replace(/^\[[^\]]+\]\s*/, '');
    text = text.split(/(?:Nén\s+và\s+tải\s+tất\s+cả|FILE\s+ĐÍNH\s+KÈM|TỆP\s+ĐÍNH\s+KÈM|Tệp\s+đính\s+kèm|File\s+đính\s+kèm)/i)[0];
    // Nếu tên file bị dính vào trích yếu, cắt trước phần mở rộng đầu tiên.
    const fileAt = text.search(/\s+[^|]{2,}\.(?:pdf|docx?|xlsx?|xls|pptx?|zip|rar)(?:\s*\||\s|$)/i);
    if (fileAt > 12) text = text.slice(0, fileAt);
    return normalizeText(text).replace(/[|·\-]+\s*$/, '').trim();
  }

  function displayTrichYeu(value, maxWords = 32) {
    const text = cleanTrichYeu(value);
    const words = text.split(/\s+/).filter(Boolean);
    if (words.length <= maxWords) return text;
    return `${words.slice(0, maxWords).join(' ')}…`;
  }

  function isElementVisible(el) {
    if (!el) return false;
    const style = getComputedStyle(el);
    const rect = el.getBoundingClientRect();
    return style.display !== 'none' && style.visibility !== 'hidden' && rect.width > 0 && rect.height > 0;
  }

  async function loadRules() {
    try {
      const response = await safeRuntimeSend({ type: 'GET_ROUTING_RULES' });
      if (!response?.ok) throw new Error(response?.error || 'Không đọc được routing-rules.json');
      state.rules = response.rules;
    } catch (error) {
      console.error('[iOffice AI] Không tải được routing-rules.json qua service worker', error);
      state.rules = { policy: {}, legalBasis: [], units: [] };
    }
  }

  function rulesUnitMap() {
    return new Map((state.rules?.units || []).map((u) => [u.id, u]));
  }

  function getNearbyName(input) {
    if (!input) return '';
    const candidates = [
      input.closest('tr'),
      input.closest('li'),
      input.closest('.row'),
      input.parentElement,
      input.parentElement?.parentElement,
      input.parentElement?.parentElement?.parentElement
    ].filter(Boolean);

    for (const container of candidates) {
      const labels = [...container.querySelectorAll('label')]
        .map((x) => normalizeText(x.innerText))
        .filter(Boolean)
        .filter((x) => !/^(P\.ban|C\.Nhân|Gửi SMS|Kết thúc văn bản|Chỉ hiển thị)/i.test(x));
      if (labels.length) {
        const exact = labels.find((x) => !x.includes('(')) || labels[0];
        if (exact) return exact;
      }
      const text = normalizeText(container.innerText);
      if (text && text.length <= 180 && !/^(P\.ban|C\.Nhân|Gửi SMS)$/i.test(text)) return text;
    }
    return input.value || input.id || 'Không rõ';
  }

  function scanRecipients() {
    const mainControls = [...document.querySelectorAll(
      'input[name="rdo_chuyentiep"], input.chk_chuyentiep_multixlc, input[name="chk_chuyen_lienthong_noibo_chutri"]'
    )];
    const coordinationControls = [...document.querySelectorAll(
      'input[name="chk_chuyentiep"], input.chk_chuyentiep_class, input[name="chk_chuyen_lienthong_noibo"]'
    )];
    const viewControls = [...document.querySelectorAll(
      'input[name="chk_chuyentiep_ph"], input.chk_chuyentiep_ph_class, input[name="chk_chuyen_lienthong_noibo_xem"]'
    )];

    const ruleMap = rulesUnitMap();
    const toEntity = (el) => {
      const code = unitCodeFromControl(el);
      return {
        id: el.id || '',
        value: code || el.value || '',
        name: ruleMap.get(code)?.name || getNearbyName(el),
        visible: controlVisible(el),
        checked: !!el.checked,
        element: el
      };
    };

    const dedupeUnits = (items) => {
      const map = new Map();
      for (const item of items.map(toEntity)) {
        if (!/^U\d+$/i.test(item.value)) continue;
        const current = map.get(item.value);
        if (!current || (!current.visible && item.visible)) map.set(item.value, item);
      }
      return [...map.values()];
    };

    const mainUnits = dedupeUnits(mainControls);
    const coordinationUnits = dedupeUnits(coordinationControls);
    const viewUnits = dedupeUnits(viewControls);
    const all = new Map();
    for (const item of [...mainUnits, ...coordinationUnits, ...viewUnits]) {
      if (!all.has(item.value)) all.set(item.value, item);
    }

    return { mainUnits, coordinationUnits, viewUnits, units: [...all.values()] };
  }

  function getAvailableUnits() {
    const scanned = scanRecipients().units;
    const map = new Map();
    for (const unit of state.rules?.units || []) map.set(unit.id, { value: unit.id, name: unit.name, rule: unit });
    for (const unit of scanned) {
      const existing = map.get(unit.value);
      map.set(unit.value, { value: unit.value, name: existing?.name || unit.name, rule: existing?.rule || null });
    }
    return [...map.values()];
  }

  function extractAttachmentNames() {
    try {
      const smart = globalThis.IOfficeDocumentReader?.getAttachmentNames?.();
      if (Array.isArray(smart) && smart.length) return smart;
    } catch (_) {}
    const names = [];
    for (const el of document.querySelectorAll('#div_file_list > [id^="file_"]')) {
      let text = normalizeText(el.innerText || '');
      text = text.replace(/^(?:Xoá|Xóa)\s+Tải file\s+Xem\s+/i, '');
      text = text.replace(/^(?:Tải file\s+Xem\s+)/i, '');
      if (text && !names.includes(text)) names.push(text);
    }
    return names;
  }

  function labelMatches(text, wanted) {
    const key = normalizeText(text).replace(/\(\*\)/g, '').replace(/[:：]+$/, '').toLowerCase();
    return !!key && wanted.some((x) => key === x || key.startsWith(`${x}:`) || key.startsWith(`${x} `));
  }

  function readControlOrText(el) {
    if (!el) return '';
    const control = el.matches?.('input,textarea,select') ? el : el.querySelector?.('input,textarea,select');
    const value = normalizeText(control?.value || el.innerText || el.textContent || '');
    return value;
  }

  function findValueByLabels(labels) {
    const wanted = labels.map((x) => normalizeText(x).toLowerCase());
    const roots = [
      document.querySelector('#divThongTinVanBan'),
      document.querySelector('#rightContentDLK'),
      document.querySelector('#div_doc_detail'),
      document.querySelector('#div_thongtin_chitiet')
    ].filter(el=>el && isElementVisible(el));
    if(!roots.length)roots.push(document.body);

    // 1) Bảng kiểu iOffice: một hàng có nhiều cặp nhãn/giá trị (td1->td2, td3->td4...).
    for (const root of roots) {
      for (const row of root.querySelectorAll('tr')) {
        if (!isElementVisible(row)) continue;
        const cells = [...row.querySelectorAll(':scope > th, :scope > td')];
        for (let i = 0; i < cells.length; i++) {
          if (!labelMatches(cells[i].innerText, wanted)) continue;
          const candidate = readControlOrText(cells[i + 1]);
          if (candidate && !labelMatches(candidate, wanted) && !looksLikeMetadataLabel(candidate) && !looksLikeGarbageText(candidate)) return candidate;
        }
      }
    }

    // 2) Các form div/label thông thường.
    for (const root of roots) {
      const rows = [...root.querySelectorAll('.info-row, .form-group, .row')];
      for (const row of rows) {
        if (!isElementVisible(row)) continue;
        const keyNodes = [...row.querySelectorAll('.info-row-key, .control-label, label, th')];
        const keyEl = keyNodes.find((el) => labelMatches(el.innerText, wanted));
        if (!keyEl) continue;
        const candidates = [
          row.querySelector('.info-row-value'),
          keyEl.nextElementSibling,
          ...[...row.children].filter((x) => x !== keyEl)
        ].filter(Boolean);
        for (const node of candidates) {
          const value = readControlOrText(node);
          if (value && !labelMatches(value, wanted) && !looksLikeMetadataLabel(value) && !looksLikeGarbageText(value)) return value;
        }
      }
    }

    // 3) Fallback: tìm đúng ô có chữ nhãn rồi lấy sibling bên cạnh.
    const selectors = 'label,th,td,span,.info-row-key,.control-label,div';
    for (const root of roots) {
      for (const el of root.querySelectorAll(selectors)) {
        if (el.childElementCount > 2)continue;
        const text = normalizeText(el.textContent || '');
        if(text.length>80 || !isElementVisible(el))continue;
        if (text.length > 80 || !labelMatches(text, wanted)) continue;
        const candidates = [el.nextElementSibling, el.parentElement?.nextElementSibling];
        if (el.parentElement) {
          const siblings = [...el.parentElement.children];
          const idx = siblings.indexOf(el);
          if (idx >= 0) candidates.push(siblings[idx + 1]);
        }
        for (const node of candidates.filter(Boolean)) {
          const value = readControlOrText(node);
          if (value && !labelMatches(value, wanted) && !looksLikeMetadataLabel(value) && !looksLikeGarbageText(value) && value.length < 500) return value;
        }
      }
    }
    return '';
  }

  function extractHeading() {
    const root = document.querySelector('#div_thongtin_chitiet');
    const rootText = normalizeText(root?.innerText || '');

    // Ưu tiên đúng dòng tiêu đề văn bản đang hiển thị; tránh bắt nhầm CSS kiểu [selector]:hover {...}.
    const visibleCandidates = root
      ? [...root.querySelectorAll('div,span,p,b,strong,h1,h2,h3,h4')]
          .filter(isElementVisible)
          .map((el) => normalizeText(el.innerText || el.textContent || ''))
          .filter((text) => text.length >= 20 && text.length <= 650 && /^\[[^\]]+\]\s*/.test(text))
          .sort((a, b) => a.length - b.length)
      : [];

    const candidates = [...visibleCandidates, rootText];
    for (const text of candidates) {
      const matches = [...String(text).matchAll(/\[([^\]]{5,240})\]\s*([^\[]+?)(?=Nén\s+và\s+tải\s+tất\s+cả|FILE\s+ĐÍNH\s+KÈM|TỆP\s+ĐÍNH\s+KÈM|Đơn vị ban hành|Số đến|Độ khẩn|$)/ig)];
      for (const match of matches) {
        const bracket = normalizeText(match[1]);
        const summary = cleanTrichYeu(match[2]);
        if (!summary || looksLikeGarbageText(summary)) continue;
        // Header iOffice thật thường có loại VB/số/ngày; loại CSS selector giả sẽ không thỏa điều kiện này.
        if (!/(?:công\s*văn|thông\s*báo|quyết\s*định|kế\s*hoạch|báo\s*cáo|tờ\s*trình|giấy\s*mời|nghị\s*quyết|chỉ\s*thị|số\s*[:\d])/i.test(bracket)) continue;
        return { bracket, summary };
      }
    }
    return { bracket: '', summary: '' };
  }


  function detectDocumentDirection() {
    const title = normalizeText(document.title || '').toLowerCase();
    const outgoingDom = Boolean(
      document.querySelector('#btn_vdi_savedoc,#nguoinhan_modal,#vanbandi_lienthong_modal,[name="vbdi_chk_donvi_truc"],[name="vbdi_rd_unit_noibo_emp"]')
    );
    const incomingDom = Boolean(
      document.querySelector('#txt_so_den,#txt_ngay_den,#modal_xuly_vanbanscan,[name="rd_unit_noibo_emp"],[name="rd_unit_emp"]')
    );
    if (outgoingDom || /văn bản đi|van ban di/.test(title)) return 'outgoing';
    if (incomingDom || /văn bản đến|văn bản vào sổ|van ban den|vao so/.test(title)) return 'incoming';
    // “Chờ xử lý” của văn thư văn bản đi có các control vbdi; nếu chưa render thì ưu tiên incoming để không ban hành nhầm.
    return 'incoming';
  }

  function currentWorkflow() {
    const role = state.userRole === 'clerk' ? 'clerk' : state.userRole === 'chief' ? 'chief' : 'leader';
    const direction = detectDocumentDirection();
    state.documentDirection = direction;
    state.workflow = `${role}-${direction}`;
    return state.workflow;
  }

  function workflowLabel(workflow = currentWorkflow()) {
    const map = {
      'leader-incoming':'Lãnh đạo · Văn bản đến',
      'leader-outgoing':'Lãnh đạo · Văn bản đi',
      'chief-incoming':'Chánh Văn phòng · Văn bản đến',
      'chief-outgoing':'Chánh Văn phòng · Văn bản đi',
      'clerk-incoming':'Văn thư · Văn bản đến',
      'clerk-outgoing':'Văn thư · Văn bản đi'
    };
    return map[workflow] || workflow;
  }

  function isoToVi(value) {
    const m = String(value || '').match(/^(\d{4})-(\d{2})-(\d{2})$/);
    return m ? `${m[3]}/${m[2]}/${m[1]}` : String(value || '');
  }

  function parseIsoLocal(value) {
    const m = String(value || '').match(/^(\d{4})-(\d{2})-(\d{2})$/);
    if (!m) return null;
    const d = new Date(Number(m[1]), Number(m[2])-1, Number(m[3]));
    return Number.isNaN(d.getTime()) ? null : d;
  }

  function daysUntil(value) {
    const d = parseIsoLocal(value);
    if (!d) return null;
    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    return Math.round((d - today) / 86400000);
  }

  function reminderDate(value, beforeDays = state.trackerReminderDays) {
    const d = parseIsoLocal(value);
    if (!d) return '';
    d.setDate(d.getDate() - Math.max(0, Number(beforeDays) || 0));
    const z=n=>String(n).padStart(2,'0');
    return `${z(d.getDate())}/${z(d.getMonth()+1)}/${d.getFullYear()}`;
  }

  function primaryDeadline(suggestion = state.lastSuggestion) {
    const tasks = Array.isArray(suggestion?.tasks) ? suggestion.tasks : [];
    return tasks.find(t => /^\d{4}-\d{2}-\d{2}$/.test(String(t?.deadline || ''))) || null;
  }

  function extractDocumentContext() {
    const heading = extractHeading();
    const titleText = cleanTrichYeu(heading.summary || findValueByLabels(['Trích yếu']));
    const sender = findValueByLabels(['Đơn vị ban hành', 'Cơ quan ban hành', 'Cơ quan gửi']);
    const urgency = findValueByLabels(['Độ khẩn']);
    const docTypeRaw = document.querySelector('#dcmTypeCode')?.value || findValueByLabels(['Hình thức']);
    const descriptors=globalThis.IOfficeDocumentReader?.getAttachmentDescriptors?.() || [];
    const attachments=descriptors.length?uniq(descriptors.map(d=>d.name)):extractAttachmentNames();
    const previewText = ''; // Text is read only from explicitly scoped attachment descriptors.

    let symbol = findValueByLabels(['Số ký hiệu', 'Số, ký hiệu']);
    if (!symbol && heading.bracket) {
      const m = heading.bracket.match(/(?:số\s*)?([^\s]+\/[A-ZĐ0-9-]+)/i);
      if (m) symbol = m[1];
    }

    let documentDate = findValueByLabels(['Ngày văn bản']);
    if (!documentDate && heading.bracket) {
      const m = heading.bracket.match(/ngày\s+(\d{1,2}\/\d{1,2}\/\d{4})/i);
      if (m) documentDate = m[1];
    }

    const fallbackText = normalizeText(document.querySelector('#div_thongtin_chitiet')?.innerText || '');
    const fallbackTitle = titleText || (() => {
      const vv = fallbackText.match(/(?:V\/v|Về việc)\s+(.{10,320}?)(?=FILE ĐÍNH KÈM|Đơn vị ban hành|$)/i);
      return vv ? cleanTrichYeu(vv[0]) : '';
    })();

    const documentId = document.querySelector('#idVB')?.value || document.querySelector('#hide_docid')?.value || '';

    return {
      documentId: normalizeText(documentId),
      detected: !!(document.querySelector('#btn_xuly,#div_thongtin_chitiet,#btn_vdi_savedoc,#btn_action_publish,#modal_detail_doc_popup,#idVB,#hide_docid')),
      trichYeu: fallbackTitle || 'Chưa nhận diện được trích yếu',
      sender: sender || 'Chưa nhận diện được đơn vị ban hành',
      symbol,
      documentDate,
      docType: normalizeText(docTypeRaw),
      urgency: urgency || 'Thường',
      attachmentNames: attachments,
      attachmentRevision: descriptors.map(d=>[d.fileId,d.viewerToken,d.date,d.scopeKind].join(':')).join('|'),
      previewText,
      previewChars: previewText.length,
      direction: detectDocumentDirection()
    };
  }

  function getDocumentKey(ctx) {
    if (!ctx?.detected) return '';
    // ID văn bản là khóa ổn định. Không đưa trạng thái tệp/viewer vào khóa vì chúng tải bất đồng bộ và từng làm cùng một văn bản bị nhận nhầm là văn bản mới.
    if (ctx.documentId) return `id:${ctx.documentId}`;
    return [ctx.symbol, ctx.documentDate, ctx.sender, ctx.trichYeu, ...(ctx.attachmentNames || []).slice(0, 3)]
      .map((x) => normalizeText(x).toLowerCase())
      .filter(Boolean)
      .join('|');
  }

  function resetProgressLog() {
    state.progressLog = [];
    state.lastGeminiPhase = '';
    if (state.refs.progressDetails) state.refs.progressDetails.open = false;
    if (state.refs.aiInfoDetails) state.refs.aiInfoDetails.open = false;
    renderProgressLog();
  }

  function progressElapsed() {
    return state.analysisStartedAt ? Math.max(0, performance.now() - state.analysisStartedAt) : 0;
  }

  function addProgress(message, kind = 'info', key = '') {
    const text = normalizeText(message);
    if (!text) return;
    const last = state.progressLog[state.progressLog.length - 1];
    if (key && last?.key === key && last?.message === text) return;
    if (!key && last?.message === text) return;
    state.progressLog.push({
      atMs: progressElapsed(),
      message: text,
      kind,
      key: key || ''
    });
    if (state.progressLog.length > 40) state.progressLog = state.progressLog.slice(-40);
    renderProgressLog();
  }

  function renderProgressLog() {
    if (!state.refs.source) return;
    const items = state.progressLog || [];
    if (!items.length) {
      state.refs.source.innerHTML = '<div class="progress-empty">Chưa chạy phân tích.</div>';
    } else {
      state.refs.source.innerHTML = items.map((item) => {
        const icon = item.kind === 'success' ? '✓' : item.kind === 'warn' ? '⚠' : item.kind === 'error' ? '✕' : '•';
        return `<div class="progress-row ${escapeHtml(item.kind)}"><span class="progress-time">${escapeHtml(formatDuration(item.atMs))}</span><span class="progress-icon">${icon}</span><span class="progress-text">${escapeHtml(item.message)}</span></div>`;
      }).join('');
    }
    if (state.refs.progressSummary) {
      state.refs.progressSummary.textContent = `▸ Tiến trình xử lý${items.length ? ` (${items.length})` : ''}`;
    }
  }

  function handleReaderProgress(progress) {
    const message = progress?.message || 'Đang đọc tài liệu…';
    setMessage(message, 'info');
    const kind = progress?.phase === 'bundle' || progress?.phase === 'dedupe' || progress?.phase === 'scan-ready' ? 'success'
      : progress?.phase === 'file-result' && Number(progress?.chars || 0) < 120 ? 'warn'
      : 'info';
    addProgress(message, kind, `${progress?.phase || 'reader'}:${progress?.name || progress?.index || ''}`);
  }

  async function stopCurrentAnalysis() {
    if(!state.busy)return;
    state.cancelRequested=true;state.activeAbortController?.abort();
    runtimeMessagePromise({type:'AI_CANCEL'}).catch(()=>{});
    if(state.pendingWebJob)runtimeMessagePromise({type:'WEB_AUTOMATION_CANCEL',jobId:state.pendingWebJob}).catch(()=>{});
    setMessage('Đang dừng tác vụ…','info');
  }

  function updatePrimaryAction() {
    const btn = state.refs.suggestBtn;
    if (!btn) return;
    const phase = state.workflowPhase || 'analyze';
    const workflow = currentWorkflow();
    btn.className = 'primary-btn';
    const canSplitApply = ['leader-incoming','chief-incoming'].includes(workflow) && phase === 'apply' && !state.busy;
    state.refs.applyOnlyBtn?.classList.toggle('hidden', !canSplitApply);
    if (state.refs.applyOnlyBtn) state.refs.applyOnlyBtn.disabled = Boolean(state.busy);
    btn.disabled = Boolean(state.busy) || !state.lastContext?.detected || ['transferred','reviewed','recipients-applied'].includes(phase);
    if (state.refs.modeSelect) {
      state.refs.modeSelect.classList.toggle('hidden', phase !== 'analyze' || state.busy);
      state.refs.modeSelect.disabled = Boolean(state.busy) || phase !== 'analyze';
    }
    if (state.busy) {
      const mode = normalizeAnalysisMode(state.analysisMode);
      btn.textContent = mode === 'rules' ? '⏳ Đang chạy quy tắc…' : '⏳ Đang phân tích…';
      btn.className = 'primary-btn busy';
      return;
    }
    if (phase === 'apply') {
      btn.textContent = ['leader-incoming','chief-incoming'].includes(workflow) ? 'Áp dụng & Chuyển' : 'Áp dụng nơi nhận';
      btn.className = 'primary-btn apply-state';
    } else if (phase === 'transfer') {
      btn.textContent = 'Chuyển';
      btn.className = 'primary-btn transfer-state';
    } else if (phase === 'transferred') {
      btn.textContent = 'Đã chuyển';
      btn.className = 'primary-btn transfer-state';
    } else if (phase === 'recipients-applied') {
      btn.textContent = 'Đã chọn nơi nhận';
      btn.className = 'primary-btn transfer-state';
    } else if (phase === 'reviewed') {
      btn.textContent = 'Đã kiểm tra';
      btn.className = 'primary-btn transfer-state';
    } else {
      btn.textContent = ['leader-outgoing','chief-outgoing'].includes(workflow) ? 'Kiểm tra văn bản' : workflow.startsWith('clerk-') ? 'Phân tích nơi nhận' : 'Phân tích';
      btn.className = 'primary-btn';
    }
  }

  async function handlePrimaryAction() {
    if (state.busy || state.updateLocked) return;
    const phase = state.workflowPhase || 'analyze';
    if (phase === 'apply') return applyCurrentSuggestion(true);
    if (phase === 'transfer') return finalizeCurrentTransfer();
    if (phase === 'transferred') return;
    return runSelectedAnalysis();
  }

  function clearAnalysisVisuals() {
    state.runId++;
    if(state.busy)runtimeMessagePromise({type:'AI_CANCEL'}).catch(()=>{});
    if(state.pendingWebJob) runtimeMessagePromise({type:'WEB_AUTOMATION_CANCEL',jobId:state.pendingWebJob}).catch(()=>{});
    state.busy=false;
    state.prepKey='';
    state.lastSuggestion = null;
    state.lastPrep = null;
    state.lastSignals = [];
    state.analyzedKey = '';
    state.pendingWeb = null;
    state.pendingWebJob = null;
    state.cancelRequested = false;
    state.appliedKey = '';
    state.finalizing = false;
    state.lastAnalysisKind = '';
    state.inputAudit = null;
    state.lastAnalysisMeta = null;
    state.trackerCandidate = null;
    state.pendingAppliedSuggestion = null;
    state.pendingTrackerContextSnapshot = null;
    state.workflowPhase = 'analyze';
    try { state.activeAbortController?.abort(); } catch (_) {}
    state.activeAbortController = null;
    resetProgressLog();
    renderInputAudit(null);
    state.refs.importWebBtn?.classList.add('hidden');
    hideFallbackActions();
    if (!state.refs.suggestBtn) return;
    updatePrimaryAction();
    if (state.refs.ruleBtn) state.refs.ruleBtn.classList.add('hidden');
    state.refs.reanalyzeBtn?.classList.add('hidden');
    state.refs.analysisPanel?.classList.add('hidden');
    state.refs.instruction.value = '';
    autoSizeInstruction();
    state.refs.confidenceValue.textContent = '—';
    state.refs.confidenceValue.className = 'confidence-value';
    state.refs.confidenceFill.style.width = '0%';
    state.refs.confidenceFill.style.background = '#cbd5e1';
    state.refs.mainRoleSection?.style.removeProperty('--confidence-color');
    clearAnalysisTimer();
    if (state.refs.analysisMeta) { state.refs.analysisMeta.textContent = ''; state.refs.analysisMeta.title = ''; }
    state.refs.review.textContent = 'Chưa phân tích';
    state.refs.review.className = 'review warn';
    state.refs.reason.textContent = '';
    if (state.refs.analysisRouting) state.refs.analysisRouting.textContent = '';
    if (state.refs.signalList) state.refs.signalList.innerHTML = '';
    if (state.refs.deadlineCard) { state.refs.deadlineCard.innerHTML = ''; state.refs.deadlineCard.classList.add('hidden'); }
    if (state.refs.modeResult) { state.refs.modeResult.innerHTML = ''; state.refs.modeResult.classList.add('hidden'); }
    renderProgressLog();
    refreshUnitOptions(true);
    renderRoleChips();
    setBusy(false);
  }

  function markAnalyzed() {
    state.analyzedKey = state.documentKey;
    const workflow = currentWorkflow();
    state.workflowPhase = ['leader-outgoing','chief-outgoing'].includes(workflow) ? 'reviewed' : 'apply';
    updatePrimaryAction();
    if (state.refs.ruleBtn) state.refs.ruleBtn.classList.add('hidden');
    if (state.refs.analysisTitle) state.refs.analysisTitle.textContent = state.lastAnalysisKind === 'rules' ? 'Phân tích · Quy tắc' : `Phân tích · ${state.analysisMode === 'gemini-web' ? 'Gemini Web' : state.analysisMode === 'chatgpt-web' ? 'ChatGPT Web' : 'API'}`;
    state.refs.reanalyzeBtn?.classList.remove('hidden');
    state.refs.analysisPanel?.classList.remove('hidden');
  }

  function cleanAnalysisReason(value) {
    let text = normalizeText(value || '');
    if (!text) return '';
    // Phần phân tích chỉ giữ lý do nghiệp vụ. Metadata đã hiển thị ở đầu widget nên không lặp lại.
    text = text
      .replace(/(?:^|[.;\n]\s*)(?:Số\s*\/?\s*ký\s*hiệu|Số\s*văn\s*bản|Nơi\s*nhận|Đơn\s*vị\s*ban\s*hành|Cơ\s*quan\s*ban\s*hành|Cơ\s*quan\s*gửi|Trích\s*yếu|Xử\s*lý\s*chính|Phối\s*hợp|Xem\s*để\s*biết)\s*:\s*[^.;\n]*/gi, ' ')
      .replace(/\s{2,}/g, ' ')
      .replace(/^[\s.;,:-]+|[\s.;,:-]+$/g, '')
      .trim();
    return text;
  }

  function sanitizeSuggestion(raw, ctx) {
    const allowed = new Set(getAvailableUnits().map((x) => x.value));
    const ruleIds = new Set((state.rules?.units || []).map((x) => x.id));
    const isAllowed = (id) => allowed.has(id) || ruleIds.has(id);

    if (!raw || typeof raw !== 'object') throw new Error('Kết quả phân tích không hợp lệ.');
    let mainUnit = raw.mainUnit == null || raw.mainUnit === '' ? null : String(raw.mainUnit);
    if (mainUnit && !isAllowed(mainUnit)) throw new Error(`Kết quả trả đơn vị XLC không hợp lệ: ${mainUnit}`);
    if (!Array.isArray(raw.coordinationUnits) || !Array.isArray(raw.viewUnits)) throw new Error('Kết quả trả sai cấu trúc PH/Xem.');

    let coordinationUnits = uniq(raw.coordinationUnits).filter((id) => isAllowed(id) && id !== mainUnit);
    let viewUnits = uniq(raw.viewUnits).filter((id) => isAllowed(id) && id !== mainUnit && !coordinationUnits.includes(id));
    const wf = currentWorkflow();
    if (['leader-incoming','chief-incoming'].includes(wf)) {
      // Tracker đã đảm nhiệm việc theo dõi. Không dùng Xem để biết như một "bản sao theo dõi" chung.
      viewUnits = [];
      // iOffice cần một đầu mối nhận chính. Nếu AI xác định Ea Ly chỉ phối hợp nhưng đã chỉ rõ một phòng chuyên môn,
      // nâng phòng phối hợp đầu tiên thành XLC để văn thư phòng nhận được văn bản; Tracker vẫn không tạo nhiệm vụ nếu trackRecommended=false.
      if (!mainUnit && coordinationUnits.length) {
        mainUnit = coordinationUnits[0];
        coordinationUnits = coordinationUnits.slice(1);
      }
    }
    const rawConfidence = Number(raw.confidence);
    if (!Number.isFinite(rawConfidence)) throw new Error('Kết quả không có confidence hợp lệ.');
    if (typeof raw.requiresReview !== 'boolean') throw new Error('Kết quả không có requiresReview hợp lệ.');
    const tasks = (Array.isArray(raw.tasks) ? raw.tasks : []).map((task, index) => ({
      index: index + 1,
      task: normalizeText(task?.task || ''),
      deadline: /^\d{4}-\d{2}-\d{2}$/.test(String(task?.deadline || '')) ? String(task.deadline) : null,
      deadlineText: normalizeText(task?.deadlineText || ''),
      deadlineEvidence: normalizeText(task?.deadlineEvidence || ''),
      deadlineSource: normalizeText(task?.deadlineSource || ''),
      responsibleUnit: isAllowed(task?.responsibleUnit) ? task.responsibleUnit : (mainUnit || null),
      scope: ['direct','coordination','information','other-locality','ambiguous'].includes(String(task?.scope||'')) ? String(task.scope) : '',
      trackRecommended: task?.trackRecommended === true
    })).filter(t => t.task || t.deadline);
    const actionRequired = typeof raw.actionRequired === 'boolean' ? raw.actionRequired : Boolean(mainUnit || tasks.length);
    const recipientNames = uniq((Array.isArray(raw.recipientNames) ? raw.recipientNames : []).map(normalizeText)).filter(Boolean);
    const reviewIssues = (Array.isArray(raw.reviewIssues) ? raw.reviewIssues : []).map(x => ({
      severity: ['high','medium','low'].includes(String(x?.severity || '').toLowerCase()) ? String(x.severity).toLowerCase() : 'low',
      category: normalizeText(x?.category || ''), detail: normalizeText(x?.detail || ''), evidence: normalizeText(x?.evidence || '')
    })).filter(x => x.detail).slice(0, 30);
    return {
      workflow: normalizeText(raw.workflow || currentWorkflow()),
      actionRequired,
      mainUnit,
      coordinationUnits,
      viewUnits,
      instruction: normalizeText(raw.instruction),
      tasks,
      recipientNames,
      reviewSummary: normalizeText(raw.reviewSummary || ''),
      reviewIssues,
      taskScope: ['direct','coordination','information','other-locality','ambiguous'].includes(String(raw.taskScope||'')) ? String(raw.taskScope) : (actionRequired ? 'direct' : 'information'),
      trackRecommended: raw.trackRecommended === true,
      trackingReason: normalizeText(raw.trackingReason || ''),
      reason: cleanAnalysisReason(raw.reason),
      confidence: clamp(rawConfidence, 0, ctx.documentBundle?.requiresReviewForUnreadable ? 0.69 : 1),
      requiresReview: raw.requiresReview || !!ctx.documentBundle?.requiresReviewForUnreadable || (['leader-incoming','chief-incoming'].includes(currentWorkflow()) && !mainUnit),
      signals: uniq(Array.isArray(raw.signals) ? raw.signals : []).slice(0, 8),
      source: raw.source || 'ai',
      provider: raw.provider || '', providerLabel: raw.providerLabel || '', model: raw.model || '', usageMetadata: raw.usageMetadata || null, promptChars: raw.promptChars || 0
    };
  }

  function buildAiPayload(ctx, signals) {
    const availableIds = new Set(getAvailableUnits().map((x) => x.value));
    const units = (state.rules?.units || [])
      .filter((u) => availableIds.has(u.id) || availableIds.size === 0)
      .map((u) => ({
        id: u.id,
        name: u.name,
        kind: u.kind,
        preferredMain: !!u.preferredMain,
        operationalOnly: !!u.operationalOnly,
        functions: u.functions || []
      }));

    const workflow = currentWorkflow();
    return {
      workflow,
      direction: state.documentDirection,
      readerMode: state.forceReadAllOnce ? 'all' : undefined,
      context: {
        trichYeu: ctx.trichYeu,
        sender: ctx.sender,
        symbol: ctx.symbol,
        documentDate: ctx.documentDate,
        docType: ctx.docType,
        urgency: ctx.urgency,
        attachmentNames: ctx.attachmentNames,
        previewText: ctx.previewText,
        documentBundle: ctx.documentBundle || null,
        direction: ctx.direction || state.documentDirection
      },
      routingPolicy: state.rules?.policy || {},
      legalBasis: state.rules?.legalBasis || [],
      availableUnits: units,
      heuristicSignals: []
    };
  }

  function callAi(payload) {
    return safeRuntimeSend({ type:'AI_ANALYZE', payload }).then((response) => {
      if (!response?.ok) throw new Error(response?.error || 'Không gọi được AI Gateway');
      return response.data;
    });
  }

  function nativeSetValue(el, value) {
    const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const descriptor = Object.getOwnPropertyDescriptor(proto, 'value');
    if (descriptor?.set) descriptor.set.call(el, value); else el.value = value;
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    el.dispatchEvent(new Event('blur', { bubbles: true }));
  }

  function findCommentField() {
    const selectors = [
      '#txtCommentChuyenTiep',
      '#txtCommentChuyenTiepDSNhan',
      'textarea[id*="CommentChuyenTiep"]',
      'textarea[id*="commentChuyen"]',
      'textarea[placeholder*="nội dung" i]'
    ];
    for (const selector of selectors) {
      const all = [...document.querySelectorAll(selector)];
      const visible = all.find(isElementVisible);
      if (visible) return visible;
      if (all[0]) return all[0];
    }
    return null;
  }


  const sleepUi = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
  const actionText = (el) => normalizeText(el?.value || el?.innerText || el?.textContent || el?.getAttribute?.('aria-label') || el?.getAttribute?.('title') || '');
  const actionEnabled = (el) => !!el && !el.disabled && el.getAttribute?.('aria-disabled') !== 'true';

  function findActionElement(exactPattern, preferredSelectors = [], scope = document) {
    const candidates = [];
    for (const selector of preferredSelectors) {
      try { candidates.push(...scope.querySelectorAll(selector)); } catch (_) {}
    }
    try { candidates.push(...scope.querySelectorAll('button,a,input[type="button"],input[type="submit"],[role="button"]')); } catch (_) {}
    const seen = new Set();
    return candidates.find((el) => {
      if (!el || seen.has(el)) return false;
      seen.add(el);
      return isElementVisible(el) && actionEnabled(el) && exactPattern.test(actionText(el));
    }) || null;
  }

  function findOpenTransferButton() {
    // iOffice có nhiều nút cùng tên. Ưu tiên nút Chuyển xử lý đã được
    // chẩn đoán là mở bảng người nhận (chuyenTiepVanBanV2), sau đó mới
    // fallback sang nút editDoc/Xử lý ở các giao diện cũ.
    const preferred = [
      '#div_btn_chuyentiep_detail > button',
      '#div_btn_chuyentiep_detail button.btn-success',
      '#div_btn_xuly_detail > button',
      '#div_btn_xuly_detail button.btn-success'
    ];
    for (const selector of preferred) {
      const el = document.querySelector(selector);
      if (el && isElementVisible(el) && actionEnabled(el) && /^Chuyển\s*xử\s*lý$/i.test(actionText(el))) return el;
    }
    const transfer = findActionElement(/^Chuyển\s*xử\s*lý$/i, preferred);
    if (transfer) return transfer;
    const legacy = document.querySelector('#btn_xuly');
    if (legacy && isElementVisible(legacy) && actionEnabled(legacy)) return legacy;
    return findActionElement(/^Xử\s*lý$/i, ['#btn_xuly','[id*="xuly" i]']);
  }

  function processingFormReady(mainCode = '') {
    const comment = findCommentField();
    const main = mainCode ? findMainUnitControl(mainCode) : null;
    return !!(comment && controlVisible(comment) && (!mainCode || (main && controlVisible(main) && !main.disabled)));
  }

  async function waitForProcessingForm(mainCode, timeoutMs = 6500) {
    const started = performance.now();
    while (performance.now() - started < timeoutMs) {
      if (processingFormReady(mainCode)) return true;
      await sleepUi(90);
    }
    return processingFormReady(mainCode);
  }

  async function ensureProcessingForm(suggestion) {
    if (processingFormReadyForSuggestion(suggestion)) return true;
    const button = findOpenTransferButton();
    if (!button) return false;
    button.click();
    // Modal xuất hiện trước bảng người nhận. Chờ đúng toàn bộ control mà đề xuất cần.
    return await waitForSuggestionControls(suggestion, 15000);
  }

  function findTransferSubmitButton() {
    // Nút gửi thật trong cửa sổ “THÔNG TIN VĂN BẢN PHÁT HÀNH”.
    // Không được nhầm với nút “Chuyển xử lý” trên thanh công cụ.
    const exact = document.querySelector('#btndetail_action_send');
    if (exact && isElementVisible(exact) && actionEnabled(exact) && /^Chuyển$/i.test(actionText(exact))) return exact;

    const comment = findCommentField();
    const local = comment?.closest?.('[role="dialog"],.modal,.modal-dialog,.ui-dialog,.bootbox,.popup,.dialog') || null;
    const pattern = /^(?:Chuyển|Gửi)$/i;
    const preferred = ['#btndetail_action_send','button[id*="action_send" i]','input[id*="action_send" i]'];
    const localHit = local ? findActionElement(pattern, preferred, local) : null;
    if (localHit) return localHit;

    const hit = findActionElement(pattern, preferred, document);
    if (hit) return hit;

    // Fallback có kiểm soát cho một số phiên bản iOffice cũ.
    const candidates = [...document.querySelectorAll('button,a,input[type="button"],input[type="submit"]')];
    return candidates.find((el) => {
      if (!isElementVisible(el) || !actionEnabled(el)) return false;
      if (!/^(?:Chuyển|Gửi)$/i.test(actionText(el))) return false;
      const onclick = el.getAttribute?.('onclick') || '';
      return !/chuyenTiepVanBanV2|editDoc/i.test(onclick);
    }) || null;
  }

  function nativeSetChecked(el, checked) {
    if (!el) return false;
    const wanted = Boolean(checked);
    try {
      if (Boolean(el.checked) !== wanted) {
        // iOffice gắn khá nhiều handler trực tiếp lên checkbox. Click trước để
        // nghiệp vụ gốc chạy; nếu handler không đổi trạng thái thì mới ép property.
        try { el.click(); } catch (_) {}
      }
      if (Boolean(el.checked) !== wanted) {
        const proto = HTMLInputElement.prototype;
        const descriptor = Object.getOwnPropertyDescriptor(proto, 'checked');
        if (descriptor?.set) descriptor.set.call(el, wanted); else el.checked = wanted;
        el.dispatchEvent(new Event('input', { bubbles: true }));
        el.dispatchEvent(new Event('change', { bubbles: true }));
      }
      return Boolean(el.checked) === wanted;
    } catch (_) { return false; }
  }

  const controlVisible = el => !!el && (isElementVisible(el) || isElementVisible(el.closest?.('label') || el.parentElement));
  const chooseControl = selector => {const all=[...document.querySelectorAll(selector)];return all.find(controlVisible)||all[0]||null;};

  function unitCodeFromControl(el) {
    if (!el) return '';
    const candidates = [el.id, el.value, el.getAttribute?.('data-unit-id'), el.getAttribute?.('data-id'), el.name];
    for (const raw of candidates) {
      const m = String(raw || '').match(/(?:^|[^A-Z0-9])(U\d+)(?:$|[^A-Z0-9])/i) || String(raw || '').match(/(U\d+)/i);
      if (m) return m[1].toUpperCase();
    }
    return '';
  }

  function findMainUnitControl(code) {
    const c=CSS.escape(code);return chooseControl(`#rdunitemp${c},#chk_chuyen_lienthong_noibo_chutri${c},input[name="rdo_chuyentiep"][value="${c}"],input[name="chk_chuyen_lienthong_noibo_chutri"][value="${c}"]`);
  }
  function findCoordinationUnitControl(code) {
    const c=CSS.escape(code);return chooseControl(`#chkcanhanxuly${c},#chk_chuyen_lienthong_noibo${c},input[name="chk_chuyentiep"][value="${c}"],input[name="chk_chuyen_lienthong_noibo"][value="${c}"]`);
  }
  function findViewUnitControl(code) {
    const c=CSS.escape(code);return chooseControl(`#chkunitempxem${c},#chk_chuyen_lienthong_noibo_xem${c},input[name="chk_chuyentiep_ph"][value="${c}"],input[name="chk_chuyen_lienthong_noibo_xem"][value="${c}"]`);
  }

  function allRoutingControls() {
    return [...document.querySelectorAll([
      'input[name="rdo_chuyentiep"]','input[name="chk_chuyentiep"]','input[name="chk_chuyentiep_ph"]',
      'input[name="chk_chuyen_lienthong_noibo_chutri"]','input[name="chk_chuyen_lienthong_noibo"]','input[name="chk_chuyen_lienthong_noibo_xem"]',
      'input[id^="rdunitempU"]','input[id^="chkcanhanxulyU"]','input[id^="chkunitempxemU"]'
    ].join(','))];
  }

  function clearUnitSelections() {
    for (const el of allRoutingControls()) {
      if (!unitCodeFromControl(el) || !controlVisible(el)) continue;
      if (el.checked) nativeSetChecked(el, false);
    }
  }

  function requestedControlsForSuggestion(suggestion) {
    const items = [];
    if (suggestion?.mainUnit) items.push({ role:'XLC', code:suggestion.mainUnit, el:findMainUnitControl(suggestion.mainUnit) });
    for (const code of suggestion?.coordinationUnits || []) {
      if (code && code !== suggestion.mainUnit) items.push({ role:'PH', code, el:findCoordinationUnitControl(code) });
    }
    for (const code of suggestion?.viewUnits || []) {
      if (!code || code === suggestion.mainUnit || (suggestion.coordinationUnits || []).includes(code)) continue;
      items.push({ role:'Xem', code, el:findViewUnitControl(code) });
    }
    return items;
  }

  function processingFormReadyForSuggestion(suggestion) {
    const comment = findCommentField();
    const controls = requestedControlsForSuggestion(suggestion);
    const needsComment = Boolean(normalizeText(suggestion?.instruction || ''));
    return Boolean((!needsComment || (comment && controlVisible(comment))) && controls.length && controls.every(x => x.el && !x.el.disabled && controlVisible(x.el)));
  }

  async function waitForSuggestionControls(suggestion, timeoutMs = 15000) {
    const started = performance.now();
    while (performance.now() - started < timeoutMs) {
      if (processingFormReadyForSuggestion(suggestion)) return true;
      await sleepUi(100);
    }
    return processingFormReadyForSuggestion(suggestion);
  }

  function findDeadlineField() {
    const selectors = ['#txtHanXuLyChuyenTiep','input[id*="HanXuLyChuyenTiep" i]','input[name*="HanXuLy" i]'];
    for (const selector of selectors) {
      const all=[...document.querySelectorAll(selector)];
      const visible=all.find(isElementVisible);
      if (visible) return visible;
      if (all[0]) return all[0];
    }
    return null;
  }

  function applySuggestion(suggestion) {
    const report = { main: false, coordination: [], view: [], comment: false, deadline: false, warnings: [] };
    const requested = requestedControlsForSuggestion(suggestion);
    const missing = requested.filter(x => !x.el || x.el.disabled || !controlVisible(x.el));
    const needsComment = Boolean(normalizeText(suggestion?.instruction || ''));
    if (missing.length || (needsComment && !findCommentField())) {
      report.warnings.push(`Danh sách đơn vị chưa sẵn sàng${missing.length ? `: ${missing.map(x=>`${x.role} ${x.code}`).join(', ')}` : ''}.`);
      return report;
    }

    clearUnitSelections();

    if (suggestion?.mainUnit) {
      const main = findMainUnitControl(suggestion.mainUnit);
      report.main = nativeSetChecked(main, true);
      if (!report.main) report.warnings.push(`Không chọn được Xử lý chính ${suggestion.mainUnit}.`);
    } else {
      report.main = true; // Văn bản chỉ để biết có thể không có XLC.
    }

    for (const code of suggestion.coordinationUnits || []) {
      if (code === suggestion.mainUnit) continue;
      const el = findCoordinationUnitControl(code);
      const ok = nativeSetChecked(el, true);
      report.coordination.push({ code, ok });
      if (!ok) report.warnings.push(`Không chọn được Phối hợp ${code}.`);
    }

    for (const code of suggestion.viewUnits || []) {
      if (code === suggestion.mainUnit || (suggestion.coordinationUnits || []).includes(code)) continue;
      const el = findViewUnitControl(code);
      const ok = nativeSetChecked(el, true);
      report.view.push({ code, ok });
      if (!ok) report.warnings.push(`Không chọn được Xem để biết ${code}.`);
    }

    const comment = findCommentField();
    if (comment && needsComment) {
      nativeSetValue(comment, suggestion.instruction || '');
      report.comment = String(comment.value || '').trim() === String(suggestion.instruction || '').trim();
      if (!report.comment) report.warnings.push('Không điền được Ý kiến chỉ đạo.');
    } else report.comment = !needsComment;

    const deadline = primaryDeadline(suggestion);
    if (deadline?.deadline) {
      const field = findDeadlineField();
      if (field) {
        nativeSetValue(field, isoToVi(deadline.deadline));
        report.deadline = normalizeText(field.value).includes(isoToVi(deadline.deadline));
        if (!report.deadline) report.warnings.push('Không điền được Hạn xử lý trên iOffice.');
      } else {
        // Không chặn chuyển nếu giao diện iOffice hiện tại không có trường hạn; Sổ vẫn ghi hạn từ văn bản.
        report.warnings.push('Không tìm thấy ô Hạn xử lý trên iOffice; chưa tự điền hạn vào iOffice.');
      }
    } else report.deadline = true;

    const verify = requestedControlsForSuggestion(suggestion);
    for (const item of verify) {
      if (!item.el?.checked) report.warnings.push(`${item.role} ${item.code} chưa được đánh dấu trên iOffice.`);
    }
    return report;
  }

  function getSelectedCodes(container) {
    return [...container.querySelectorAll('input[type="checkbox"]:checked')].map((x) => x.value);
  }

  function syncExclusiveRoles() {
    const main = state.refs.mainSelect?.value;
    const coord = new Set(getSelectedCodes(state.refs.coordBox));
    for (const box of state.refs.coordBox.querySelectorAll('input')) {
      if (box.value === main) box.checked = false;
    }
    for (const box of state.refs.viewBox.querySelectorAll('input')) {
      if (box.value === main || coord.has(box.value)) box.checked = false;
    }
  }

  function refreshUnitOptions(reset = false) {
    const units = getAvailableUnits().filter((u) => u.value !== 'U100');
    const select = state.refs.mainSelect;
    if (!select) return;
    const oldMain = reset ? '' : select.value;
    const oldCoord = reset ? new Set() : new Set(getSelectedCodes(state.refs.coordBox));
    const oldView = reset ? new Set() : new Set(getSelectedCodes(state.refs.viewBox));

    select.innerHTML = `<option value="">— Chọn đơn vị xử lý chính —</option>` + units.map((u) => `<option value="${escapeHtml(u.value)}" title="${escapeHtml(u.name)}">${escapeHtml(shortUnitName(u.value, u.name))}</option>`).join('');
    if (units.some((u) => u.value === oldMain)) select.value = oldMain;

    const buildChecks = (container, selected) => {
      container.innerHTML = '';
      for (const unit of units) {
        const box = document.createElement('input');
        box.type = 'checkbox';
        box.value = unit.value;
        box.dataset.name = unit.name;
        box.checked = selected.has(unit.value);
        box.addEventListener('change', () => { syncExclusiveRoles(); renderRoleChips(); });
        container.appendChild(box);
      }
    };
    buildChecks(state.refs.coordBox, oldCoord);
    buildChecks(state.refs.viewBox, oldView);
    syncExclusiveRoles();
    renderRoleChips();
  }

  function unitNameById(id) {
    const unit = getAvailableUnits().find((x) => x.value === id);
    return unit?.name || rulesUnitMap().get(id)?.name || id;
  }

  function unitDisplayNameById(id) {
    return shortUnitName(id, unitNameById(id));
  }

  function renderRoleChips() {
    if (!state.refs.coordChips || !state.refs.viewChips) return;
    const render = (role, target, codes) => {
      target.innerHTML = '';
      if (!codes.length) {
        target.innerHTML = '<span class="role-empty">Chưa chọn</span>';
        return;
      }
      for (const code of codes) {
        const chip = document.createElement('button');
        chip.type = 'button';
        chip.className = 'role-chip';
        chip.title = `Bấm để bỏ chọn: ${unitNameById(code)}`;
        chip.textContent = unitDisplayNameById(code);
        chip.addEventListener('click', () => {
          const box = (role === 'coord' ? state.refs.coordBox : state.refs.viewBox).querySelector(`input[value="${CSS.escape(code)}"]`);
          if (box) box.checked = false;
          syncExclusiveRoles();
          renderRoleChips();
        });
        target.appendChild(chip);
      }
    };
    render('coord', state.refs.coordChips, getSelectedCodes(state.refs.coordBox));
    render('view', state.refs.viewChips, getSelectedCodes(state.refs.viewBox));
  }

  function renderPickerList() {
    const role = state.pickerRole;
    if (!role || !state.refs.pickerList) return;
    const query = normalizeText(state.refs.pickerSearch.value).toLowerCase();
    const main = state.refs.mainSelect.value;
    const coord = new Set(getSelectedCodes(state.refs.coordBox));
    const store = role === 'coord' ? state.refs.coordBox : state.refs.viewBox;
    const units = getAvailableUnits().filter((u) => u.value !== 'U100' && (!query || `${u.name} ${u.value}`.toLowerCase().includes(query)));
    state.refs.pickerList.innerHTML = '';
    for (const unit of units) {
      const row = document.createElement('label');
      row.className = 'picker-row';
      const disabled = unit.value === main || (role === 'view' && coord.has(unit.value));
      const checked = !!store.querySelector(`input[value="${CSS.escape(unit.value)}"]`)?.checked;
      row.innerHTML = `<input type="checkbox" ${checked ? 'checked' : ''} ${disabled ? 'disabled' : ''}><span><b title="${escapeHtml(unit.name)}">${escapeHtml(shortUnitName(unit.value, unit.name))}</b></span>`;
      const box = row.querySelector('input');
      box.addEventListener('change', () => {
        const target = store.querySelector(`input[value="${CSS.escape(unit.value)}"]`);
        if (target) target.checked = box.checked;
        syncExclusiveRoles();
        renderRoleChips();
      });
      state.refs.pickerList.appendChild(row);
    }
  }

  function openRolePicker(role) {
    state.pickerRole = role;
    state.refs.pickerTitle.textContent = role === 'coord' ? 'Chọn đơn vị phối hợp xử lý' : 'Chọn đơn vị xem để biết';
    state.refs.pickerSearch.value = '';
    state.refs.picker.classList.remove('hidden');
    renderPickerList();
    setTimeout(() => state.refs.pickerSearch.focus(), 0);
  }

  function closeRolePicker() {
    state.pickerRole = null;
    state.refs.picker.classList.add('hidden');
  }


  function clearAnalysisTimer() {
    if (state.analysisTimer) clearInterval(state.analysisTimer);
    state.analysisTimer = null;
  }

  function beginAnalysisTimer() {
    clearAnalysisTimer();
    state.analysisStartedAt = performance.now();
    state.lastAnalysisMeta = null;
    if (state.refs.analysisPanel) state.refs.analysisPanel.classList.remove('hidden');
    if (state.refs.analysisMeta) state.refs.analysisMeta.textContent = 'Đang xử lý · 0.0 s';
    renderAiInfoSummary();
    state.analysisTimer = setInterval(() => {
      if (!state.refs.analysisMeta || !state.analysisStartedAt) return;
      state.refs.analysisMeta.textContent = `Đang xử lý · ${formatDuration(performance.now() - state.analysisStartedAt)}`;
      renderAiInfoSummary();
    }, 250);
  }

  function finishAnalysisMeta(ai, timing = {}, fallbackLabel = '') {
    clearAnalysisTimer();
    const totalMs = Number(timing.totalMs ?? (state.analysisStartedAt ? performance.now() - state.analysisStartedAt : 0));
    const aiMs = Number(timing.aiMs || 0);
    const prepMs = Number(timing.prepMs || 0);
    const usage = getTokenUsage(ai);
    const provider = fallbackLabel || ai?.providerLabel || ai?.provider || 'AI';
    const model = fallbackLabel ? '' : (ai?.model || 'model');
    const isRules = ai?.provider === 'local-rules' || /quy tắc/i.test(provider);
    const tokenText = usage.estimated ? `~${usage.total.toLocaleString('vi-VN')} token` : `${usage.total.toLocaleString('vi-VN')} token`;
    const pieces = [provider];
    if (model) pieces.push(model);
    if (!isRules) pieces.push(tokenText);
    pieces.push(formatDuration(totalMs));
    const titleParts = [];
    if (usage.input != null) titleParts.push(`Input: ${Number(usage.input).toLocaleString('vi-VN')} token`);
    if (usage.output != null) titleParts.push(`Output: ${Number(usage.output).toLocaleString('vi-VN')} token`);
    if (prepMs) titleParts.push(`Đọc tài liệu: ${formatDuration(prepMs)}`);
    if (aiMs) titleParts.push(`AI: ${formatDuration(aiMs)}`);
    state.lastAnalysisMeta = { provider, model, usage, totalMs, aiMs, prepMs };
    if (state.refs.analysisMeta) {
      state.refs.analysisMeta.textContent = pieces.join(' · ');
      state.refs.analysisMeta.title = titleParts.join(' · ');
    }
    renderAiInfoSummary();
  }


  function ensureVpProposalPrefix(value) {
    const text = normalizeText(value || '').replace(/^VP\s*đề\s*xuất\s*:\s*/i,'');
    return text ? `VP đề xuất: ${text}` : '';
  }

  function autoSizeInstruction() {
    const el = state.refs?.instruction;
    if (!el) return;
    try {
      el.style.height = 'auto';
      const next = Math.max(96, Math.ceil(el.scrollHeight + 2));
      el.style.height = `${next}px`;
      el.style.overflowY = 'hidden';
    } catch (_) {}
  }



  function setWorkflowUi() {
    const workflow = currentWorkflow();
    if (state.refs.workflowBadge) state.refs.workflowBadge.textContent = workflowLabel(workflow);
    if (state.refs.roleSelect) state.refs.roleSelect.value = state.userRole;
    const showRouting = workflow === 'leader-incoming' || workflow === 'chief-incoming';
    state.refs.mainRoleSection?.classList.toggle('hidden', !showRouting);
    state.refs.coordSection?.classList.toggle('hidden', !showRouting);
    state.refs.viewSection?.classList.toggle('hidden', true);
    state.refs.instructionSection?.classList.toggle('hidden', !showRouting);
    if (state.refs.instructionLabel) state.refs.instructionLabel.textContent = 'VP đề xuất / Ý kiến chỉ đạo';
    updatePrimaryAction();
  }

  function renderDeadlineCard(s) {
    const box = state.refs.deadlineCard;
    if (!box) return;
    const workflow = currentWorkflow();
    if (!['leader-incoming','chief-incoming'].includes(workflow) || !s) { box.classList.add('hidden'); box.innerHTML=''; return; }
    const aiTasks = Array.isArray(s.tasks) ? s.tasks : [];
    const tasks = aiTasks.length ? aiTasks : [{
      task: cleanTrichYeu(state.lastContext?.trichYeu || ''), deadline: '', deadlineEvidence: '', deadlineSource: 'manual',
      responsibleUnit: s.mainUnit || '', scope: s.taskScope || 'information', trackRecommended: false, _manual: true
    }];
    const scopeText = ({direct:'Nhiệm vụ trực tiếp của Ea Ly',coordination:'Ea Ly chỉ phối hợp/theo dõi',information:'Văn bản để biết', 'other-locality':'Nhiệm vụ thuộc địa phương khác',ambiguous:'Chưa đủ căn cứ xác định nhiệm vụ'})[s.taskScope] || '';
    const rows = tasks.map((t,i)=>{
      const checked = t.trackRecommended === true || (s.trackRecommended === true && (t.scope === 'direct' || (!t.scope && s.taskScope === 'direct')));
      const left=t.deadline?daysUntil(t.deadline):null;
      const badge=left==null?'':left<0?`QUÁ HẠN ${Math.abs(left)} NGÀY`:left===0?'ĐẾN HẠN HÔM NAY':left<=2?`CÒN ${left} NGÀY · GẤP`:left<=3?`CÒN ${left} NGÀY · SẮP HẠN`:`Còn ${left} ngày`;
      const unitValue=t.responsibleUnit||s.mainUnit||'';
      const unitOptions=['<option value="">— Chọn XLC —</option>',...getAvailableUnits().map(u=>`<option value="${escapeHtml(u.value)}" ${u.value===unitValue?'selected':''}>${escapeHtml(unitDisplayNameById(u.value))}</option>`)].join('');
      return `<div class="track-item" data-index="${i}">
        <div class="track-head"><label class="track-toggle"><input type="checkbox" class="track-check" ${checked?'checked':''}> <b>Theo dõi nhiệm vụ</b></label>${badge?`<span class="track-badge">${escapeHtml(badge)}</span>`:''}</div>
        <textarea class="track-text" rows="2" maxlength="900" placeholder="Nội dung nhiệm vụ">${escapeHtml(t.task||'')}</textarea>
        <div class="track-fields"><label>Hạn <input class="track-deadline" type="date" value="${escapeHtml(t.deadline||'')}"></label><label class="track-unit">XLC <select class="track-unit-select">${unitOptions}</select></label></div>
        ${t.deadlineEvidence?`<div class="track-evidence">Căn cứ hạn: ${escapeHtml(t.deadlineEvidence)}</div>`:''}
      </div>`;
    }).join('');
    const tracker = state.trackerEnabled ? '<span class="track-online">● Sổ đang kết nối</span>' : '<span class="track-offline">● Sổ chưa bật</span>';
    box.innerHTML = `<div class="task-card-title"><span>📌 NHIỆM VỤ</span>${tracker}</div><div class="task-scope">${escapeHtml(scopeText)}${s.trackingReason?` · ${escapeHtml(s.trackingReason)}`:''}</div>${rows}`;
    box.classList.remove('hidden');
  }

  function trackingItemsFromUi(suggestion) {
    const box=state.refs.deadlineCard;
    if(!box || box.classList.contains('hidden')) return [];
    const items=[];
    box.querySelectorAll('.track-item').forEach((row,index)=>{
      const check=row.querySelector('.track-check'); if(!check?.checked)return;
      const text=normalizeText(row.querySelector('.track-text')?.value||'');
      const deadline=textDateToIso(row.querySelector('.track-deadline')?.value||'');
      const base=(suggestion.tasks||[])[Number(row.dataset.index)||0]||{};
      const responsibleUnit=normalizeText(row.querySelector('.track-unit-select')?.value||base.responsibleUnit||suggestion.mainUnit||'');
      items.push({
        task:text || cleanTrichYeu(state.lastContext?.trichYeu||''), deadline,
        deadlineText:base.deadlineText||'', deadlineEvidence:base.deadlineEvidence||'', deadlineSource:deadline ? (base.deadlineSource||'manual') : 'none',
        responsibleUnit, scope:base.scope||suggestion.taskScope||'direct', trackRecommended:true,
        manualOverride: !(base.trackRecommended===true && text===normalizeText(base.task||'') && deadline===(base.deadline||'') && responsibleUnit===(base.responsibleUnit||suggestion.mainUnit||''))
      });
    });
    return items;
  }



  function textDateToIso(value) {
    const s=normalizeText(value||'');
    let m=s.match(/^(\d{4})-(\d{2})-(\d{2})$/); if(m)return s;
    m=s.match(/^(\d{1,2})[\/\-.](\d{1,2})[\/\-.](\d{4})$/); if(m)return `${m[3]}-${String(m[2]).padStart(2,'0')}-${String(m[1]).padStart(2,'0')}`;
    return '';
  }

  function taskResultMatchScore(task, ctx) {
    const out=foldRecipientText(`${ctx?.symbol||''} ${ctx?.trichYeu||''} ${state.lastPrep?.combinedText||ctx?.documentBundle?.combinedText||''}`).slice(0,50000);
    if(!out)return 0;
    let score=0;
    const symbol=foldRecipientText(task?.soKyHieu||'');
    if(symbol && symbol.length>=5 && out.includes(symbol)) score+=0.58;
    const source=foldRecipientText(`${task?.trichYeu||''} ${task?.nhiemVu||''}`);
    const stop=new Set(['va','cua','theo','ve','viec','thuc','hien','bao','cao','ubnd','xa','tinh','de','nghi','yeu','cau','tai','cac','noi','dung']);
    const words=[...new Set(source.split(' ').filter(x=>x.length>=3&&!stop.has(x)))].slice(0,40);
    if(words.length){const hit=words.filter(w=>out.includes(w)).length;score+=Math.min(.38,(hit/words.length)*.38);if(hit>=5)score+=.06;}
    return Math.min(1,score);
  }

  async function refreshTrackerCompletionCandidate() {
    // v0.18.3: không còn suy đoán văn bản kết quả bằng nội dung/AI ở đây.
    // tracker-monitor.js đọc đúng #thongtinvb div.download và quản lý vòng đời
    // Đang xử lý → Đã xử lý - chờ ban hành → Đã hoàn thành.
    return;
  }

  function renderModeResult(s) {
    const box = state.refs.modeResult;
    if (!box) return;
    const workflow = currentWorkflow();
    if (['leader-outgoing','chief-outgoing'].includes(workflow)) {
      const issues = (s.reviewIssues || []).map(x => `<div class="review-issue ${escapeHtml(x.severity)}"><b>${escapeHtml(x.category || 'Kiểm tra')}</b><span>${escapeHtml(x.detail)}</span>${x.evidence?`<small>${escapeHtml(x.evidence)}</small>`:''}</div>`).join('');
      box.innerHTML = `<div class="mode-result-title">🔎 Kiểm tra văn bản đi</div><div class="review-summary">${escapeHtml(s.reviewSummary || 'Đã kiểm tra trong phạm vi dữ liệu đọc được.')}</div>${issues || '<div class="mode-empty">Không có mục cần lưu ý bổ sung.</div>'}`;
      box.classList.remove('hidden'); return;
    }
    if (workflow.startsWith('clerk-')) {
      const names = s.recipientNames || [];
      box.innerHTML = `<div class="mode-result-title">📬 Nơi nhận phát hiện (${names.length})</div>${names.length ? `<div class="recipient-list">${names.map(x=>`<div>• ${escapeHtml(x)}</div>`).join('')}</div>` : '<div class="mode-empty">Không xác định được nơi nhận cụ thể từ file chính · cần kiểm tra thủ công.</div>'}`;
      box.classList.remove('hidden'); return;
    }
    if (!s.actionRequired) {
      box.innerHTML = '<div class="info-only">ℹ️ <b>Không phát sinh nhiệm vụ Tracker cho xã.</b><br>Vẫn chọn 1 Xử lý chính để phòng/đơn vị tiếp nhận văn bản trên iOffice.</div>';
      box.classList.remove('hidden'); return;
    }
    box.classList.add('hidden'); box.innerHTML='';
  }

  function populateSuggestion(s) {
    setWorkflowUi();
    refreshUnitOptions();
    state.refs.mainSelect.value = '';
    if (s.mainUnit && [...state.refs.mainSelect.options].some((o) => o.value === s.mainUnit)) state.refs.mainSelect.value = s.mainUnit;
    for (const box of state.refs.coordBox.querySelectorAll('input')) box.checked = (s.coordinationUnits || []).includes(box.value);
    for (const box of state.refs.viewBox.querySelectorAll('input')) box.checked = (s.viewUnits || []).includes(box.value);
    state.refs.instruction.value = ['leader-incoming','chief-incoming'].includes(currentWorkflow()) ? ensureVpProposalPrefix(s.instruction || '') : (s.instruction || '');
    autoSizeInstruction();
    syncExclusiveRoles();
    renderRoleChips();

    const pct = Math.round((s.confidence || 0) * 100);
    const conf = confidenceStyle(pct);
    state.refs.confidenceValue.textContent = `${pct}%`;
    state.refs.confidenceValue.className = `confidence-value ${conf.cls}`;
    state.refs.confidenceFill.style.width = `${pct}%`;
    state.refs.confidenceFill.style.background = conf.color;
    state.refs.mainRoleSection?.style.setProperty('--confidence-color', conf.color);

    if (['leader-incoming','chief-incoming'].includes(currentWorkflow()) && !s.actionRequired) {
      state.refs.review.textContent = '✓ Chỉ để biết · không tạo nhiệm vụ';
      state.refs.review.className = 'review ok';
    } else {
      state.refs.review.textContent = s.requiresReview ? '⚠ Cần kiểm tra kỹ' : '✓ Có thể xem xét áp dụng';
      state.refs.review.className = `review ${s.requiresReview ? 'warn' : 'ok'}`;
    }
    state.refs.reason.textContent = cleanAnalysisReason(s.reason) || s.reviewSummary || '';
    renderDeadlineCard(s);
    renderModeResult(s);
    if (['leader-outgoing','chief-outgoing'].includes(currentWorkflow())) void refreshTrackerCompletionCandidate(state.lastContext || extractDocumentContext());

    if (state.refs.analysisRouting) {
      const parts = [];
      if (s.mainUnit) parts.push(`Xử lý chính: ${unitDisplayNameById(s.mainUnit)}`);
      if (s.coordinationUnits?.length) parts.push(`Phối hợp: ${s.coordinationUnits.map(unitDisplayNameById).join(', ')}`);
      if (s.viewUnits?.length) parts.push(`Xem: ${s.viewUnits.map(unitDisplayNameById).join(', ')}`);
      state.refs.analysisRouting.textContent = parts.join(' · ');
    }
    if (state.refs.signalList) {
      state.refs.signalList.innerHTML = '';
      state.refs.signalList.classList.add('hidden');
    }
  }

  function analysisModeLabel(mode = state.analysisMode) {
    mode = normalizeAnalysisMode(mode);
    return mode === 'gemini-web' ? 'Gemini Web'
      : mode === 'chatgpt-web' ? 'ChatGPT Web'
      : 'API';
  }

  function renderAiInfoSummary() {
    const summaryEl = state.refs.aiInfoSummary || state.refs.inputAuditText;
    if (!summaryEl) return;
    const modeLabel = analysisModeLabel();
    const audit = state.inputAudit;
    const meta = state.lastAnalysisMeta;
    const parts = [modeLabel];
    if (audit) {
      if (audit.detected) parts.push(`${audit.ready}/${audit.detected} tệp`);
      if (audit.skippedScans) parts.push(`bỏ ${audit.skippedScans} PDF scan`);
      if (audit.oversizedSkipped) parts.push(`bỏ ${audit.oversizedSkipped} tệp quá dung lượng`);
      if (audit.duplicatesSkipped) parts.push(`gộp ${audit.duplicatesSkipped} tệp trùng`);
      if (audit.sentWords || audit.extractedWords) {
        if (normalizeAnalysisMode(state.analysisMode) === 'rules') parts.push(`${audit.sentWords.toLocaleString('vi-VN')} từ dùng quy tắc`);
        else parts.push(`${audit.sentWords.toLocaleString('vi-VN')} từ → AI`);
      }
    } else if (state.busy) {
      parts.push('đang chuẩn bị tài liệu…');
    } else {
      parts.push('chưa đọc tệp');
    }
    if (meta) {
      const usage = meta.usage || {};
      if (normalizeAnalysisMode(state.analysisMode) !== 'rules' && Number(usage.total || 0)) {
        parts.push(`${usage.estimated ? '~' : ''}${Number(usage.total).toLocaleString('vi-VN')} token`);
      }
      if (Number(meta.totalMs || 0)) parts.push(formatDuration(meta.totalMs));
    }
    summaryEl.textContent = parts.join(' · ');
    if (state.refs.aiInfoDetails) {
      const cls = audit ? (audit.complete && !audit.skippedScans && !audit.oversizedSkipped ? 'ok' : 'warn') : 'pending';
      state.refs.aiInfoDetails.className = `ai-info ${cls}`;
    }
  }

  function renderInputAudit(bundle = null) {
    const box = state.refs.inputAudit;
    const textEl = state.refs.inputAuditText;
    const filesEl = state.refs.inputAuditFiles;
    if (!box || !textEl || !filesEl) return;
    if (!bundle?.stats) {
      box.className = 'ai-info pending';
      filesEl.innerHTML = '';
      if (state.refs.inputAuditDetail) state.refs.inputAuditDetail.textContent = 'Chưa kiểm tra nội dung tệp.';
      state.inputAudit = null;
      state.refs.readAllBtn?.classList.add('hidden');
      renderAiInfoSummary();
      return;
    }
    const st = bundle.stats;
    const detected = Number(st.filesDetected || 0);
    const discovered = Number(st.filesDiscovered || detected);
    const ready = Number(st.filesReadyForAi || 0);
    const readMode = String(bundle.readMode || st.readMode || 'all');
    const extractedWords = Number(st.extractedWords || 0);
    const sentWords = Number(st.aiTextWords || 0);
    const scans = Number(st.scanAttachmentsPrepared || 0);
    const skippedScans = Number(st.scanSkippedCount || 0);
    const oversizedSkipped = Number(st.oversizedSkippedCount || 0);
    const duplicatesSkipped = Number(st.duplicatesSkipped || st.duplicateCount || 0);
    const complete = bundle.aiReady !== false;
    box.className = `ai-info ${complete && !skippedScans && !oversizedSkipped ? 'ok' : 'warn'}`;
    const isRules = normalizeAnalysisMode(state.analysisMode) === 'rules';
    const sourceLabel = (source) => {
      source=String(source||'');
      if(source.startsWith('original-')) return `file gốc ${source.slice(9).toUpperCase()}`;
      if(source==='captured-original'||source==='original-file') return 'file gốc từ request iOffice';
      if(source.startsWith('captured-') && source!=='captured-pdf') return `file gốc ${source.slice(9).toUpperCase()}`;
      if(source==='ioffice-converted-pdf') return 'PDF do iOffice chuyển đổi';
      if(source==='captured-pdf') return 'PDF bắt từ viewer iOffice';
      if(source==='pdf-main-world') return 'PDF.js';
      if(source==='word-viewer') return 'viewer Word';
      if(source==='ioffice-copy-captured') return 'text Copy/OCR iOffice';
      if(source==='ioffice-ocr-textlayer'||source==='ioffice-ocr-pdfjs'||source==='ioffice-ocr-partial') return 'OCR iOffice';
      if(source==='current-viewer'||source==='hidden-viewer'||source==='viewer-ocr-or-text') return 'viewer iOffice';
      return source ? source : '';
    };
    const statusText = (item) => item.status === 'duplicate-not-sent' ? `Trùng nội dung với ${item.duplicateOf ? '“'+item.duplicateOf+'”' : 'tệp khác'} · đã gộp, không gửi lặp`
      : item.status === 'text-ready' ? `Đã đọc · ${Number(item.words||0).toLocaleString('vi-VN')} từ${sourceLabel(item.source) ? ` · ${sourceLabel(item.source)}` : ''}`
      : item.status === 'scan-skipped' ? 'PDF scan · tạm bỏ qua, chưa lấy nội dung'
      : item.status === 'size-limit-skipped' ? `Tệp quá dung lượng · tạm bỏ qua${item.sizeBytes ? ` · ${(Number(item.sizeBytes)/1024/1024).toFixed(1)} MB` : ''}`
      : item.status === 'scan-attached' ? 'PDF scan · trạng thái cũ, không gửi trong phiên bản này'
      : `Chưa đọc được${item.error ? ` · ${item.error}` : ''}`;
    filesEl.innerHTML = (bundle.fileResults || []).map((item) => {
      const skipped = item.status === 'scan-skipped';
      const cls = item.readyForAi ? 'ok' : 'bad';
      const icon = item.readyForAi ? '✓' : '⚠';
      return `<div class="input-file ${cls}"><span>${icon}</span><b>${escapeHtml(item.name)}</b><small>${escapeHtml(statusText(item))}</small></div>`;
    }).join('');
    state.inputAudit = { detected, discovered, ready, extractedWords, sentWords, scans, skippedScans, oversizedSkipped, duplicatesSkipped, complete, readMode };
    if (state.refs.inputAuditDetail) {
      state.refs.inputAuditDetail.textContent = detected
        ? `${ready}/${readMode === 'primary' ? Math.max(1, detected) : detected} tệp đã đọc${readMode === 'primary' && discovered > detected ? ` · ưu tiên file chính · ${discovered - detected} tệp khác chưa đọc` : ''}${skippedScans ? ` · bỏ qua ${skippedScans} PDF scan` : ''}${oversizedSkipped ? ` · bỏ qua ${oversizedSkipped} tệp quá dung lượng` : ''}${duplicatesSkipped ? ` · gộp ${duplicatesSkipped} tệp trùng` : ''} · lấy ${extractedWords.toLocaleString('vi-VN')} từ văn bản · ${isRules ? 'dùng cho quy tắc' : 'gửi AI'} ${sentWords.toLocaleString('vi-VN')} từ`
        : `Không có tệp đính kèm · ${sentWords.toLocaleString('vi-VN')} từ nội dung sẵn có`;
    }
    if (state.refs.readAllBtn) {
      const otherCount = Math.max(0, discovered - detected);
      state.refs.readAllBtn.classList.toggle('hidden', !(readMode === 'primary' && otherCount > 0));
      state.refs.readAllBtn.textContent = otherCount > 0 ? `Đọc toàn bộ (${otherCount + detected} tệp)` : 'Đọc toàn bộ';
    }
    renderAiInfoSummary();
  }

  function renderSourceContext(ctx, signals, prep = state.lastPrep) {
    if (prep?.bundle) renderInputAudit(prep.bundle);
    if (prep?.stats) {
      addProgress(
        `Tổng hợp tài liệu: ${prep.stats.filesReadyForAi}/${prep.stats.filesDetected} tệp đã đọc${Number(prep.stats.scanSkippedCount||0) ? ` · bỏ qua ${Number(prep.stats.scanSkippedCount||0)} PDF scan` : ''}${Number(prep.stats.oversizedSkippedCount||0) ? ` · bỏ qua ${Number(prep.stats.oversizedSkippedCount||0)} tệp quá dung lượng` : ''}${Number(prep.stats.duplicatesSkipped||0) ? ` · gộp ${Number(prep.stats.duplicatesSkipped||0)} tệp trùng` : ''} · lấy ${Number(prep.stats.extractedWords || 0).toLocaleString('vi-VN')} từ · ${normalizeAnalysisMode(state.analysisMode)==='rules'?'dùng quy tắc':'dự kiến gửi AI'} ${Number(prep.stats.aiTextWords || 0).toLocaleString('vi-VN')} từ.`,
        prep.bundle?.aiReady === false ? 'warn' : 'success',
        'reader-summary'
      );
    }
    renderProgressLog();
  }

  function setMessage(text, kind = 'info') {
    if (!state.refs.message) return;
    state.refs.message.textContent = text;
    state.refs.message.className = `message ${kind}`;
  }

  function setBusy(busy) {
    state.busy = busy;
    if (state.refs.ruleBtn) state.refs.ruleBtn.disabled = true;
    for(const el of state.root.querySelectorAll('.ai-mode-btn,#reanalyzeBtn')) el.disabled=busy;
    state.refs.stopBtn?.classList.toggle('hidden', !busy);
    if (!busy && state.lastSuggestion && state.analyzedKey === state.documentKey && state.workflowPhase === 'analyze') {
      state.workflowPhase = 'apply';
    }
    updatePrimaryAction();
  }



  function normalizeAnalysisMode(value) {
    return ['gemini-web', 'chatgpt-web', 'api'].includes(value) ? value : 'gemini-web';
  }

  function updateAnalysisModeUi() {
    const mode = normalizeAnalysisMode(state.analysisMode);
    state.analysisMode = mode;
    if (state.refs.modeSelect) state.refs.modeSelect.value = mode;
    if (state.refs.suggestBtn && !state.busy && (state.workflowPhase || 'analyze') === 'analyze') state.refs.suggestBtn.textContent = 'Phân tích';
    renderInputAudit(state.lastPrep?.bundle || null);
    renderAiInfoSummary();
    updatePrimaryAction();
  }

  function setAnalysisMode(mode, persist = true) {
    if(state.busy || state.updateLocked)return;
    mode = normalizeAnalysisMode(mode);
    if (state.analysisMode === mode) { updateAnalysisModeUi(); return; }
    state.analysisMode = mode;
    if (persist) void safeStorageSet({ analysisMode: mode });
    if (state.lastSuggestion) clearAnalysisVisuals();
    updateAnalysisModeUi();
    // v0.19: không làm nóng Gemini khi chỉ đổi chế độ; chỉ khởi động khi người dùng thật sự bấm Phân tích.
    setMessage(mode === 'gemini-web'
      ? 'Đã chọn Gemini Web.'
      : mode === 'chatgpt-web'
        ? 'Đã chọn ChatGPT Web.'
        : mode === 'api'
          ? 'Đã chọn API.'
          : 'Đã chọn Quy tắc · xử lý tại máy.', 'info');
  }

  function hideFallbackActions(){ state.refs.fallbackActions?.classList.add('hidden'); }
  function showFallbackActions(){
    const box=state.refs.fallbackActions;if(!box)return;
    box.classList.remove('hidden');
    for(const b of box.querySelectorAll('[data-mode]')) b.classList.toggle('hidden', b.dataset.mode===state.analysisMode);
  }
  async function runFallbackMode(mode){
    if(state.busy)return; hideFallbackActions(); setAnalysisMode(mode,true); await runSelectedAnalysis();
  }

  async function runSelectedAnalysis() {
    const mode = normalizeAnalysisMode(state.analysisMode);
    if (mode === 'rules') return runRuleAnalysis();
    if (mode === 'gemini-web') return startGeminiAuto();
    if (mode === 'chatgpt-web') return startWebAi('chatgpt');
    return runSuggestion();
  }


  async function prepareWebPayload(overrides = null) {
    const ctx = extractDocumentContext();
    if (!ctx.detected) throw new Error('Chưa nhận diện được văn bản đang mở.');
    const signal = state.activeAbortController?.signal || null;
    let prep = state.lastPrep;
    const storedOptions = await safeStorageGet({readerMode:'primary',readerConcurrency:0,readerIncludeRelated:false,readerDeduplicateContent:true,readerScanEnabled:false,readerTimeoutMs:5000,readerMaxFileSizeMb:10,aiRequireCompleteFiles:true});
    const options = { ...storedOptions, ...(overrides || {}), readerMode: state.forceReadAllOnce ? 'all' : (overrides?.readerMode || storedOptions.readerMode || 'primary'), readerScanEnabled:false };
    const prepKey=getDocumentKey(ctx)+'|'+JSON.stringify(options);
    if (!prep || state.prepKey !== prepKey) {
      if (globalThis.IOfficeDocumentReader?.collectAndPrepare) {
        setMessage('Đang đọc đúng các tệp của văn bản…', 'info');
        addProgress('Bắt đầu đọc FILE ĐÍNH KÈM / Văn bản liên quan.', 'info', 'reader-start');
        prep = await globalThis.IOfficeDocumentReader.collectAndPrepare(ctx, handleReaderProgress, { signal, ...options });
        if(signal?.aborted)throw new DOMException('Đã dừng phân tích.','AbortError');
        state.lastPrep = prep;state.prepKey=prepKey;state.forceReadAllOnce=false;
        if (prep?.combinedText) { ctx.previewText = prep.combinedText; ctx.previewChars = prep.combinedText.length; }
        ctx.documentBundle = prep?.bundle || null;
      }
    } else if (prep) {
      addProgress('Dùng lại kết quả đọc tài liệu đã có của văn bản này.', 'success', 'reader-cache');
      ctx.previewText = prep.combinedText || ''; ctx.previewChars = ctx.previewText.length; ctx.documentBundle = prep?.bundle || null;
    }
    if (!ctx.documentBundle) {
      ctx.documentBundle = {
        version: 'metadata-only',
        primaryDocument: null,
        supportingDocuments: [],
        duplicates: [],
        unreadable: (ctx.attachmentNames || []).map((name) => ({ name, status: 'reader-no-text' })),
        fileResults: (ctx.attachmentNames || []).map((name) => ({name,status:ctx.previewText?'metadata-only':'reader-no-text',readyForAi:false,words:0,error:'Không lấy được nội dung tệp.'})),
        stats: {
          filesDetected: (ctx.attachmentNames || []).length,
          filesWithText: 0, filesReadyForAi: 0,
          uniqueGroups: (ctx.attachmentNames || []).length,
          duplicatesSkipped: 0,
          unreadableCount: (ctx.attachmentNames || []).length,
          requiredUnreadableCount: (ctx.attachmentNames || []).length,
          extractedWords: 0, aiTextWords: 0, aiTextChars: (ctx.previewText || '').length
        },
        aiReady: (ctx.attachmentNames || []).length === 0,
        aiBlockedReason: (ctx.attachmentNames || []).length ? 'Không lấy được nội dung tệp đính kèm.' : '',
        requiresReviewForUnreadable: !!(ctx.attachmentNames || []).length,
        combinedText: ctx.previewText || ''
      };
    }
    const signals = [];
    state.lastContext = ctx; state.lastSignals = signals;
    renderSourceContext(ctx, signals, prep);
    return { ctx, signals, payload: buildAiPayload(ctx, signals), settings: options };
  }

  function runtimeMessagePromise(message) {
    return safeRuntimeSend(message).then((response) => {
      if (!response?.ok) throw new Error(response?.error || 'Extension không trả kết quả.');
      return response.data ?? response;
    });
  }

  function handleGeminiJobEvent(message) {
    if (!message?.jobId || message.jobId !== state.pendingWebJob) return;
    state.geminiEventCache.set(message.jobId, message);
    const phase = message.phase || message.status || 'waiting';
    const phaseMessage = message.phaseMessage || 'Gemini đang xử lý';
    if (message.kind === 'progress') {
      setMessage(`${phaseMessage} · ${formatDuration(message.elapsedMs || 0)}`, 'info');
      if (phase !== state.lastGeminiPhase) {
        state.lastGeminiPhase = phase;
        addProgress(phaseMessage, 'info', `gemini:${phase}`);
      }
    }
    const waiter = state.geminiWaiters.get(message.jobId);
    if (waiter) waiter(message);
  }

  async function waitGeminiBackgroundJob(jobId,timeoutMs=340000,signal) {
    return new Promise((resolve,reject)=>{
      let done=false,polling=false;
      const finish=(error,value)=>{if(done)return;done=true;clearTimeout(timer);clearInterval(poll);state.geminiWaiters.delete(jobId);signal?.removeEventListener('abort',abort);error?reject(error):resolve(value);};
      const abort=()=>finish(new Error('Đã dừng phân tích.'));
      const receive=event=>{
        if(event.status==='done')finish(null,event);
        else if(event.status==='error')finish(new Error(event.error||event.phaseMessage||'Gemini không hoàn tất.'));
        else if(event.status==='cancelled')abort();
      };
      const recover=async()=>{if(done||polling)return;polling=true;try{receive(await runtimeMessagePromise({type:'WEB_AUTOMATION_STATUS',jobId}));}catch(e){finish(e);}finally{polling=false;}};
      state.geminiWaiters.set(jobId,receive);
      const timer=setTimeout(()=>finish(new Error('Hết thời gian chờ Gemini.')),timeoutMs);
      // Small status message recovers lost push and wakes the MV3 worker. It never scans Gemini DOM.
      const poll=setInterval(recover,5000);
      signal?.addEventListener('abort',abort,{once:true});
      if(signal?.aborted)return abort();
      const cached=state.geminiEventCache.get(jobId);if(cached)receive(cached);
      if(!done)void recover();
    });
  }

  async function startGeminiAuto() { return runAnalysis('gemini-web'); }
  async function startWebAi(target) { return runAnalysis(target==='gemini'?'gemini-web':'chatgpt-web'); }
  async function runSuggestion() { return runAnalysis('api'); }
  function waitWithSignal(promise,signal) {
    return new Promise((resolve,reject)=>{
      const abort=()=>reject(new DOMException('Đã dừng phân tích.','AbortError'));
      if(signal.aborted){abort();Promise.resolve(promise).catch(()=>{});return;}
      signal.addEventListener('abort',abort,{once:true});
      Promise.resolve(promise).then(resolve,reject).finally(()=>signal.removeEventListener('abort',abort));
    });
  }
  async function rerunLastAnalysis() {
    if (state.lastAnalysisKind === 'rules') return runRuleAnalysis();
    return runSelectedAnalysis();
  }

  async function runRuleAnalysis() {
    if (state.busy || state.updateLocked) return;
    updateDetection();
    if (!['leader-incoming','chief-incoming'].includes(currentWorkflow())) return setMessage('Chế độ Quy tắc chỉ áp dụng cho Văn bản đến của Lãnh đạo/Chánh Văn phòng.', 'error');
    if (!state.lastContext?.detected) return setMessage('Hãy mở một văn bản trên iOffice.','error');
    const run=++state.runId,key=state.documentKey,startedAt=performance.now();
    const controller=new AbortController(),signal=controller.signal;
    state.activeAbortController=controller; state.cancelRequested=false; state.lastSuggestion=null; state.analyzedKey=''; state.appliedKey=''; state.workflowPhase='analyze';
    state.lastAnalysisKind='rules';
    const assertCurrent=()=>{if(signal.aborted||run!==state.runId||key!==getDocumentKey(extractDocumentContext()))throw new DOMException('Đã dừng phân tích.','AbortError');};
    let prepMs=0;
    resetProgressLog(); beginAnalysisTimer(); setBusy(true); state.refs.importWebBtn.classList.add('hidden');
    try {
      addProgress('Đang đọc tài liệu trước khi chạy bộ quy tắc.','info','start');
      const t=performance.now();
      const prepared=await waitWithSignal(prepareWebPayload({ readerScanEnabled:false, aiRequireCompleteFiles:false }),signal); prepMs=performance.now()-t; assertCurrent();
      if (!globalThis.IOfficeRuleEngine?.analyze) throw new Error('Không tải được bộ máy phân tích quy tắc.');
      const ruleStart=performance.now();
      const raw=globalThis.IOfficeRuleEngine.analyze(prepared.ctx,state.rules,getAvailableUnits());
      assertCurrent();
      const suggestion=sanitizeSuggestion(raw,prepared.ctx);
      // Quy tắc chỉ đọc được TEXT. PDF scan dù AI có thể nhận file gốc vẫn là dữ liệu thiếu đối với bộ quy tắc.
      const ruleScanOnly = Number(prepared.ctx.documentBundle?.stats?.scanSkippedCount || 0) > 0;
      if (prepared.ctx.documentBundle?.blockedByScanOnly) throw new Error(prepared.ctx.documentBundle?.aiBlockedReason || 'Các tệp đính kèm đều là PDF scan nên chưa thể phân tích.');
      const ruleDataIncomplete = prepared.ctx.documentBundle?.aiReady === false || ruleScanOnly;
      if (ruleDataIncomplete) {
        suggestion.requiresReview = true;
        suggestion.confidence = Math.min(suggestion.confidence, 0.69);
        const warning = ruleScanOnly
          ? 'Có PDF scan đã bị bỏ qua; bộ quy tắc chỉ phân tích các tệp có text, kết quả cần kiểm tra kỹ.'
          : 'Dữ liệu tệp chưa đầy đủ; kết quả quy tắc chỉ là gợi ý.';
        suggestion.signals = uniq([...(suggestion.signals||[]), warning]).slice(0,8);
      }
      state.lastSuggestion=suggestion; populateSuggestion(suggestion); markAnalyzed();
      finishAnalysisMeta(raw,{totalMs:performance.now()-startedAt,prepMs,aiMs:performance.now()-ruleStart},'Phân tích bằng quy tắc');
      addProgress('Đã chấm điểm bằng bộ quy tắc cục bộ; không gửi dữ liệu ra AI.','success','done');
      setMessage(ruleDataIncomplete ? 'Quy tắc đã phân tích nhưng chưa đọc đủ nội dung dạng text. Hãy kiểm tra kỹ rồi bấm Áp dụng.' : 'Phân tích quy tắc xong. Kiểm tra đề xuất rồi bấm Áp dụng.','success');
      state.refs.progressDetails.open=false;
    } catch(e) {
      if (run===state.runId) {
        const cancelled=signal.aborted||e.name==='AbortError'||/Đã dừng/.test(e.message);
        addProgress(cancelled?'Đã dừng xử lý.':e.message,cancelled?'warn':'error','error');
        setMessage(cancelled?'Đã dừng. Anh có thể phân tích lại.':e.message,cancelled?'info':'error');
        finishAnalysisMeta({provider:'local-rules'},{totalMs:performance.now()-startedAt,prepMs},cancelled?'Đã dừng':'Phân tích bằng quy tắc');
      }
    } finally {
      if(run===state.runId){state.activeAbortController=null;clearAnalysisTimer();setBusy(false);}
    }
  }

  async function runAnalysis(mode) {
    if(state.busy || state.updateLocked)return;
    updateDetection();
    if(!state.lastContext?.detected)return setMessage('Hãy mở một văn bản trên iOffice.','error');
    const run=++state.runId,key=state.documentKey,startedAt=performance.now();
    const controller=new AbortController(),signal=controller.signal;
    state.activeAbortController=controller;state.cancelRequested=false;state.lastSuggestion=null;state.analyzedKey='';state.appliedKey='';state.workflowPhase='analyze';
    state.lastAnalysisKind='ai';
    state.pendingWebJob=mode==='gemini-web'?`gweb_${crypto.randomUUID()}`:null;
    const jobId=state.pendingWebJob;
    const assertCurrent=()=>{if(signal.aborted||run!==state.runId||key!==getDocumentKey(extractDocumentContext()))throw new DOMException('Đã dừng phân tích.','AbortError');};
    let prepMs=0;
    hideFallbackActions();resetProgressLog();beginAnalysisTimer();setBusy(true);state.refs.importWebBtn.classList.add('hidden');
    try {
      addProgress('Đang chuẩn bị tài liệu cho AI.','info','start');
      const warm=mode==='gemini-web'?runtimeMessagePromise({type:'WEB_AUTOMATION_PREWARM'}).catch(e=>({error:e.message})):Promise.resolve();
      const t=performance.now(),prepared=await waitWithSignal(prepareWebPayload(),signal);prepMs=performance.now()-t;assertCurrent();
      const bundle=prepared.ctx.documentBundle || {};
      // v0.15.1: PDF scan không OCR/không upload. Nếu toàn bộ tệp đều là scan thì luôn dừng.
      if (bundle.blockedByScanOnly) {
        throw new Error(bundle.aiBlockedReason || 'Các tệp đính kèm đều là PDF scan nên chưa thể phân tích.');
      }
      // Nếu còn tệp lỗi thật (không phải PDF scan bị bỏ qua), vẫn tôn trọng chế độ chặn khi thiếu tệp.
      if (prepared.settings?.aiRequireCompleteFiles !== false && bundle.aiReady === false) {
        const st=bundle.stats || {};
        throw new Error(`Chưa gửi AI: mới sẵn sàng ${Number(st.filesReadyForAi||0)}/${Number(st.filesDetected||0)} tệp. ${bundle.aiBlockedReason || 'Hãy kiểm tra phần dữ liệu đầu vào.'}`);
      }
      const warmed=await waitWithSignal(warm,signal);assertCurrent();if(warmed?.error)throw new Error(warmed.error);
      let result,status;
      const aiStart=performance.now();
      if(mode==='gemini-web') {
        const start=await waitWithSignal(runtimeMessagePromise({type:'WEB_AUTOMATION_START',jobId,payload:prepared.payload}),signal);assertCurrent();
        addProgress(start.message,'info','sent');
        status=await waitGeminiBackgroundJob(jobId,340000,signal);assertCurrent();result=status.result;
      }else if(mode==='api') {
        result=await waitWithSignal(callAi(prepared.payload),signal);assertCurrent();
      }else {
        const sent=await waitWithSignal(runtimeMessagePromise({type:'WEB_HANDOFF_START',target:'chatgpt',payload:prepared.payload}),signal);assertCurrent();
        state.pendingWeb={target:'chatgpt',payload:prepared.payload,key};state.refs.importWebBtn.classList.remove('hidden');
        setMessage(`${sent.message} Copy JSON từ ChatGPT rồi bấm Nhận kết quả.`,'info');return;
      }
      if(!result)throw new Error('AI hoàn tất nhưng không có kết quả.');
      const suggestion=sanitizeSuggestion(result,prepared.ctx);state.lastSuggestion=suggestion;
      populateSuggestion(suggestion);markAnalyzed();finishAnalysisMeta(result,{totalMs:performance.now()-startedAt,prepMs,aiMs:performance.now()-aiStart});
      addProgress('Đã nhận kết quả AI đúng phiên văn bản.','success','done');
      setMessage('Phân tích xong. Có thể Áp dụng để kiểm tra trên iOffice hoặc Áp dụng & Chuyển ngay.','success');
      state.refs.progressDetails.open=false;
      if(jobId)await runtimeMessagePromise({type:'WEB_AUTOMATION_CONSUME',jobId}).catch(()=>{});
    }catch(e){
      if(jobId)await runtimeMessagePromise({type:'WEB_AUTOMATION_CANCEL',jobId}).catch(()=>{});
      if(run===state.runId){
        const cancelled=signal.aborted||e.name==='AbortError'||/Đã dừng/.test(e.message);
        addProgress(cancelled?'Đã dừng xử lý.':e.message,cancelled?'warn':'error','error');
        setMessage(cancelled?'Đã dừng. Anh có thể phân tích lại.':e.message,cancelled?'info':'error');
        if(!cancelled)showFallbackActions();
        finishAnalysisMeta(null,{totalMs:performance.now()-startedAt,prepMs},cancelled?'Đã dừng':'Chưa hoàn tất');
      }
    }finally{
      if(jobId){state.geminiEventCache.delete(jobId);state.geminiWaiters.delete(jobId);}
      if(run===state.runId){state.pendingWebJob=null;state.activeAbortController=null;clearAnalysisTimer();setBusy(false);}
    }
  }

  async function importWebResult() {
    if (state.pendingWeb && state.pendingWeb.key !== getDocumentKey(extractDocumentContext())) { state.pendingWeb=null; return setMessage('Đã đổi văn bản. Hãy phân tích lại.','error'); }
    if (!state.pendingWeb) return setMessage('Chưa có phiên Web AI đang chờ kết quả.', 'error');
    try {
      let text = '';
      try { text = await navigator.clipboard.readText(); } catch (_) {}
      if (!text) text = window.prompt('Dán toàn bộ câu trả lời JSON từ Web AI vào đây:') || '';
      if (!text.trim()) return setMessage('Clipboard chưa có câu trả lời.', 'error');
      const imported = await safeRuntimeSend({ type:'WEB_HANDOFF_IMPORT', target:state.pendingWeb.target, text, payload:state.pendingWeb.payload });
      if (!imported?.ok) throw new Error(imported?.error || 'Không đọc được kết quả Web AI.');
      const result = imported.data;
      const ctx = state.lastContext || extractDocumentContext();
      const suggestion = sanitizeSuggestion(result, ctx);
      state.lastSuggestion = suggestion;
      populateSuggestion(suggestion);
      markAnalyzed();
      finishAnalysisMeta(result, { totalMs: 0, prepMs: 0, aiMs: 0 });
      setMessage(`${result.providerLabel || 'Web AI'} đã được nhập. Hãy kiểm tra trước khi Áp dụng.`, 'success');
      state.pendingWeb = null;
      state.refs.importWebBtn?.classList.add('hidden');
    } catch (error) { setMessage(`Không nhập được kết quả Web AI: ${error.message}`, 'error'); }
  }

  async function maybeAutoClerkIncoming(ctx,key){
    if(state.userRole!=='clerk' || currentWorkflow()!=='clerk-incoming' || !ctx?.detected || !key || state.busy)return;
    const cfg=await safeStorageGet({clerkAutoApplyIncoming:false});
    if(!cfg.clerkAutoApplyIncoming || state.clerkAutoAppliedKey===key)return;
    state.clerkAutoAppliedKey=key;
    // Chỉ tự áp dụng preset đã cấu hình; không gọi AI, không đọc file.
    setTimeout(()=>{ if(getDocumentKey(extractDocumentContext())===key) void applyClerkRecipients('clerk-incoming',{recipientNames:[]},true); },220);
  }

  function updateDetection() {
    const ctx = extractDocumentContext();
    const nextKey = getDocumentKey(ctx);
    const changed = !!state.documentKey && state.documentKey !== nextKey;
    if(!state.busy || changed)state.lastContext = ctx;
    if (changed) {
      state.documentKey = nextKey;
      clearAnalysisVisuals();
      setMessage('Đã chuyển sang văn bản khác. Sẵn sàng phân tích mới.', 'info');
    } else if (!state.documentKey && nextKey) {
      state.documentKey = nextKey;
    }
    if (!state.refs.docTitle) return;
    state.refs.docTitle.textContent = ctx.detected ? cleanTrichYeu(ctx.trichYeu) : 'Chưa mở văn bản';
    state.refs.docTitle.title = ctx.detected ? cleanTrichYeu(ctx.trichYeu) : '';
    state.refs.sender.textContent = ctx.detected ? ctx.sender : '—';
    if(state.refs.docMeta) state.refs.docMeta.textContent = ctx.detected ? [ctx.symbol,ctx.documentDate].filter(Boolean).join(' · ') : '';
    setWorkflowUi();
    updatePrimaryAction();
    void maybeAutoClerkIncoming(ctx,nextKey);
    if (state.refs.ruleBtn) state.refs.ruleBtn.disabled = !ctx.detected || state.busy;
    // v0.19: mở/xử lý văn bản không tự gọi Gemini nền để tránh tranh CPU/RAM với iOffice.
  }

  function setWidgetCollapsed(collapsed, persist = true) {
    const value = Boolean(collapsed);
    if (!state.refs.card || !state.refs.body) return;
    state.refs.card.classList.toggle('collapsed', value);
    state.refs.body.classList.toggle('hidden', value);
    const header = state.root?.getElementById?.('dragHeader');
    if (header) {
      header.setAttribute('aria-expanded', value ? 'false' : 'true');
      header.title = value
        ? 'Bấm để mở Trợ lý phân luồng văn bản · kéo để di chuyển'
        : 'Bấm để thu gọn Trợ lý phân luồng văn bản · kéo để di chuyển';
    }
    if (persist) void safeStorageSet({ widgetCollapsed: value });
  }

  function enableDragging(host, header, onTap = null) {
    let pointerDown = false, dragging = false, startX = 0, startY = 0, startLeft = 0, startTop = 0;
    const MOVE_THRESHOLD = 5;
    header.addEventListener('pointerdown', (e) => {
      if (e.target.closest('button,a,input,select,textarea')) return;
      const rect = host.getBoundingClientRect();
      pointerDown = true;
      dragging = false;
      startX = e.clientX; startY = e.clientY; startLeft = rect.left; startTop = rect.top;
      header.setPointerCapture?.(e.pointerId);
      e.preventDefault();
    });
    header.addEventListener('pointermove', (e) => {
      if (!pointerDown) return;
      const dx = e.clientX - startX, dy = e.clientY - startY;
      if (!dragging && Math.hypot(dx, dy) < MOVE_THRESHOLD) return;
      if (!dragging) {
        dragging = true;
        const rect = host.getBoundingClientRect();
        host.style.right = 'auto'; host.style.bottom = 'auto';
        host.style.left = `${rect.left}px`; host.style.top = `${rect.top}px`;
        startLeft = rect.left; startTop = rect.top;
      }
      const card = host.getBoundingClientRect();
      const left = Math.max(0, Math.min(window.innerWidth - card.width, startLeft + dx));
      const top = Math.max(0, Math.min(window.innerHeight - 36, startTop + dy));
      host.style.left = `${left}px`; host.style.top = `${top}px`;
    });
    const finishPointer = (e, cancelled = false) => {
      if (!pointerDown) return;
      pointerDown = false;
      try { header.releasePointerCapture?.(e.pointerId); } catch (_) {}
      if (dragging) {
        dragging = false;
        void safeStorageSet({ widgetPosition: { left: parseInt(host.style.left, 10) || 0, top: parseInt(host.style.top, 10) || 0 } });
      } else if (!cancelled && typeof onTap === 'function') {
        onTap();
      }
    };
    header.addEventListener('pointerup', (e) => finishPointer(e, false));
    header.addEventListener('pointercancel', (e) => finishPointer(e, true));
    safeStorageGet({ widgetPosition: null }).then(({ widgetPosition }) => {
      if (!widgetPosition) return;
      host.style.right = 'auto'; host.style.bottom = 'auto';
      host.style.left = `${Math.max(0, Math.min(window.innerWidth - 330, widgetPosition.left || 0))}px`;
      host.style.top = `${Math.max(0, Math.min(window.innerHeight - 36, widgetPosition.top || 0))}px`;
    }).catch(() => {});
  }


  function foldRecipientText(value) {
    return normalizeText(value).toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/đ/g,'d').replace(/[^a-z0-9]+/g,' ').trim();
  }

  function recipientTextForControl(el) {
    const container = el?.closest?.('tr') || el?.closest?.('label,li,.row,.form-group') || el?.parentElement;
    return normalizeText(container?.innerText || el?.getAttribute?.('title') || el?.value || '');
  }

  function recipientKey(el){
    return normalizeText(el?.value || el?.dataset?.id || el?.id || '');
  }

  async function captureClerkRecipientDirectory(){
    const selectors='input[name="rd_unit_emp"],input[name="rd_unit_noibo_emp"],input[name="chk_unit_emp_xuly"],input[name="chk_unit_noibo_xuly"],input[name="chk_unit_emp_xem"],input[name="chk_unit_noibo_xem"]';
    const map=new Map();
    for(const el of document.querySelectorAll(selectors)){
      if(!controlVisible(el))continue;
      const key=recipientKey(el), name=recipientTextForControl(el);
      if(!key||!name)continue;
      if(!map.has(key))map.set(key,{key,name});
    }
    const list=[...map.values()].sort((a,b)=>a.name.localeCompare(b.name,'vi'));
    if(list.length)await safeStorageSet({clerkRecipientDirectory:list,clerkRecipientDirectoryUpdatedAt:Date.now()});
    return list;
  }

  function selectRecipientKeys(keys, selectors){
    const controls=[...document.querySelectorAll(selectors)].filter(controlVisible);
    const matched=[],unmatched=[];
    for(const key of keys||[]){
      const el=controls.find(x=>recipientKey(x)===key);
      if(el&&nativeSetChecked(el,true))matched.push({target:key,text:recipientTextForControl(el),value:recipientKey(el),score:1}); else unmatched.push(key);
    }
    return {matched,unmatched,totalControls:controls.length};
  }

  function applyChiefDefaultViewRecipients() {
    if (state.userRole !== 'chief') return {matched:[],unmatched:[],skipped:true};
    const ids = (state.chiefDefaultViewRecipientIds || []).slice(0,3).map(normalizeText).filter(Boolean);
    if (!ids.length) return {matched:[],unmatched:[],skipped:true};
    const selectors = [
      'input[name="chk_unit_emp_xem"]',
      'input[name="chk_unit_noibo_xem"]',
      'input[name="chkcanhanxem"]',
      'input[name="chk_canhan_xem"]',
      'input[name="chk_chuyentiep_ph"]'
    ].join(',');
    return selectRecipientKeys(ids, selectors);
  }

  async function waitApplyChiefDefaultViewRecipients(timeoutMs=3500) {
    if (state.userRole !== 'chief' || !(state.chiefDefaultViewRecipientIds || []).length) return {matched:[],unmatched:[],skipped:true};
    const started=performance.now();
    let result=applyChiefDefaultViewRecipients();
    while(result.unmatched?.length && performance.now()-started<timeoutMs){
      await sleepUi(120);
      result=applyChiefDefaultViewRecipients();
    }
    return result;
  }

  function recipientMatchScore(target, candidate) {
    const a=foldRecipientText(target), b=foldRecipientText(candidate);
    if (!a || !b) return 0;
    if (a === b) return 1;
    if (b.includes(a) || a.includes(b)) return .92;
    const stop=new Set(['tinh','dak','lak','xa','phuong','ubnd','uy','ban','nhan','dan','va','cua','the','so','phong']);
    const A=a.split(' ').filter(x=>x.length>1 && !stop.has(x));
    const B=new Set(b.split(' ').filter(x=>x.length>1 && !stop.has(x)));
    if (!A.length) return 0;
    const hit=A.filter(x=>B.has(x)).length;
    return hit/A.length;
  }

  function matchAndSelectRecipients(names, selectors) {
    const controls=[...document.querySelectorAll(selectors)].filter(controlVisible);
    const matched=[], unmatched=[];
    for (const target of names || []) {
      let best=null, score=0;
      for (const el of controls) {
        const text=recipientTextForControl(el);
        const s=recipientMatchScore(target,text);
        if (s>score) {score=s;best={el,text};}
      }
      if (best && score>=.72) {
        const ok=nativeSetChecked(best.el,true);
        if (ok) matched.push({target,text:best.text,value:best.el.value,score}); else unmatched.push(target);
      } else unmatched.push(target);
    }
    return {matched,unmatched,totalControls:controls.length};
  }

  async function waitForVisibleSelector(selector, timeoutMs=6000) {
    const started=performance.now();
    while(performance.now()-started<timeoutMs){
      const el=[...document.querySelectorAll(selector)].find(controlVisible);
      if(el)return el;
      await sleepUi(100);
    }
    return [...document.querySelectorAll(selector)].find(controlVisible)||null;
  }

  async function ensureClerkOutgoingRecipients() {
    const sel='input[name="vbdi_chk_donvi_truc"],input[name="vbdi_rd_unit_noibo_emp"]';
    if ([...document.querySelectorAll(sel)].some(controlVisible)) return true;
    const btn=document.querySelector('#btn_action_publish') || findActionElement(/^Ban\s*hành$/i,['#btn_action_publish']);
    if (!btn || !isElementVisible(btn)) return false;
    btn.click();
    return Boolean(await waitForVisibleSelector(sel,6500));
  }

  async function ensureClerkIncomingRecipients() {
    const sel='input[name="rd_unit_emp"],input[name="rd_unit_noibo_emp"]';
    if ([...document.querySelectorAll(sel)].some(controlVisible)) return true;
    let publish=document.querySelector('#btn_action_publish');
    if (!publish || !isElementVisible(publish)) {
      const open=document.querySelector('#btn_xuly') || findActionElement(/^Xử\s*lý$/i,['#btn_xuly']);
      if (open && isElementVisible(open)) { open.click(); await sleepUi(450); }
      publish=document.querySelector('#btn_action_publish');
    }
    if (publish && isElementVisible(publish)) { publish.click(); }
    return Boolean(await waitForVisibleSelector(sel,6500));
  }

  function dateToIsoToday() {
    const d=new Date();
    const z=n=>String(n).padStart(2,'0');
    return `${d.getFullYear()}-${z(d.getMonth()+1)}-${z(d.getDate())}`;
  }

  function firstControlValue(selectors) {
    for (const selector of selectors || []) {
      const el=document.querySelector(selector);
      const value=normalizeText(el?.value || el?.textContent || '');
      if(value)return value;
    }
    return '';
  }

  function validTrackerMeta(value) {
    const text=normalizeText(value || '');
    if(!text)return '';
    if(/^Chưa nhận diện/i.test(text))return '';
    return text;
  }

  function snapshotTrackerContext(ctx = {}) {
    // Giữ metadata của văn bản TRƯỚC khi mở/đóng modal Chuyển xử lý.
    // iOffice thay đổi DOM khi chuyển nên đọc lại sau khi bấm Chuyển có thể mất trích yếu/số ký hiệu.
    const current=ctx && typeof ctx==='object' ? ctx : {};
    const trichYeu=validTrackerMeta(current.trichYeu)
      || validTrackerMeta(firstControlValue(['#txt_trich_yeu','textarea[name="trichYeu"]']))
      || validTrackerMeta(cleanTrichYeu(findValueByLabels(['Trích yếu'])));
    const sender=validTrackerMeta(current.sender)
      || validTrackerMeta(firstControlValue(['#txt_coquan']))
      || validTrackerMeta(findValueByLabels(['Đơn vị ban hành','Cơ quan ban hành','Cơ quan gửi']));
    const symbol=validTrackerMeta(current.symbol)
      || validTrackerMeta(firstControlValue(['#txt_so']))
      || validTrackerMeta(findValueByLabels(['Số ký hiệu','Số, ký hiệu']));
    const documentDate=validTrackerMeta(current.documentDate)
      || validTrackerMeta(firstControlValue(['#txt_ngay_vanban']))
      || validTrackerMeta(findValueByLabels(['Ngày văn bản']));
    const arrivalDate=validTrackerMeta(current.arrivalDate)
      || validTrackerMeta(firstControlValue(['#txt_ngay_den']))
      || validTrackerMeta(findValueByLabels(['Ngày đến']));
    const documentId=validTrackerMeta(current.documentId)
      || validTrackerMeta(firstControlValue(['#idVB','#hide_docid']));
    return {
      ...current,
      documentId,
      trichYeu,
      sender,
      symbol,
      documentDate,
      arrivalDate,
      sourceUrl: current.sourceUrl || location.href
    };
  }

  function taskSyncKey(ctx, task, index) {
    // Khóa ổn định: cùng documentId + thứ tự nhiệm vụ sẽ cập nhật đúng dòng, không tạo trùng khi AI đổi câu chữ.
    const base=normalizeText(ctx?.documentId || ctx?.symbol || getDocumentKey(ctx) || 'ioffice').replace(/\s+/g,'_').slice(0,160);
    return `${base}#${index+1}`;
  }

  function buildTrackerTaskData(suggestion, ctx, task, index) {
    const snap=snapshotTrackerContext(ctx);
    const main=task.responsibleUnit || suggestion.mainUnit || '';
    return {
      syncKey:taskSyncKey(snap,task,index), documentId:snap.documentId||'', soKyHieu:snap.symbol||'', ngayVanBan:snap.documentDate||'', ngayDen:snap.arrivalDate||'',
      donViBanHanh:snap.sender||'', trichYeu:snap.trichYeu||'', nhiemVu:task.task||'', yKienChiDao:state.refs.instruction?.value || suggestion.instruction || '',
      hanXuLy:task.deadline||'', nguonHan:task.deadlineSource || 'Nội dung văn bản', canCuHan:task.deadlineEvidence||task.deadlineText||'', nhacTruocNgay:state.trackerReminderDays,
      xuLyChinh:main ? unitDisplayNameById(main) : '', phoiHop:(suggestion.coordinationUnits||[]).map(unitDisplayNameById), xemDeBiet:(suggestion.viewUnits||[]).map(unitDisplayNameById),
      trangThai:'Đang xử lý', ngayGiao:dateToIsoToday(), confidence:suggestion.confidence, linkIOfficeNguon:snap.sourceUrl||location.href,
      updateSource: task.manualOverride ? 'MANUAL' : 'AI', manualNote: task.manualOverride ? 'Người dùng chủ động chọn/chỉnh nhiệm vụ theo dõi trên tiện ích.' : '',
      ghiChu: task.manualOverride ? 'Tạo theo dõi theo lựa chọn người dùng.' : 'Tự động tạo từ iOffice AI sau khi chuyển văn bản thành công.'
    };
  }

  async function writeTrackedTasksToTracker(suggestion, ctx) {
    const tasks=trackingItemsFromUi(suggestion);
    if (!tasks.length) return {ok:true,count:0,skipped:true};
    if (!state.trackerEnabled) return {ok:false,count:0,disabled:true,error:'Sổ theo dõi chưa bật'};
    let count=0, queued=0; const errors=[];
    for(let i=0;i<tasks.length;i++){
      try{
        const res=await safeRuntimeSend({type:'TRACKER_UPSERT',data:buildTrackerTaskData(suggestion,ctx,tasks[i],i)});
        if(!res?.ok)throw new Error(res?.error||'Không ghi được Sổ');
        count++; if(res.queued===true || res.data?.queued===true) queued++;
      }catch(e){errors.push(e.message||String(e));}
    }
    return {ok:errors.length===0,count,queued,errors,error:errors.join(' | ')};
  }


  async function clickLeaderTransferAndWait() {
    const button=findTransferSubmitButton();
    if(!button) return {ok:false,error:'Không tìm thấy nút “Chuyển” trong cửa sổ Chuyển xử lý.'};
    const dialog=button.closest?.('[role="dialog"],.modal,.modal-dialog,.ui-dialog,.bootbox,.popup,.dialog');
    button.click();
    const started=performance.now();
    while(performance.now()-started<5000){
      await sleepUi(120);
      const buttonGone=!document.contains(button) || !isElementVisible(button);
      const dialogGone=dialog ? (!document.contains(dialog) || !isElementVisible(dialog)) : false;
      if(buttonGone || dialogGone) return {ok:true};
    }
    return {ok:false,error:'iOffice chưa xác nhận đã chuyển; chưa ghi Sổ để tránh tạo nhiệm vụ sai.'};
  }

  function clearRecipientControls(selector) {
    for(const el of document.querySelectorAll(selector)){
      if(controlVisible(el)&&el.checked)nativeSetChecked(el,false);
    }
  }

  async function applyClerkRecipients(workflow, suggestion, autoTriggered=false) {
    const outgoing=workflow==='clerk-outgoing';
    if(outgoing){
      const names=(suggestion.recipientNames||[]).map(normalizeText).filter(Boolean);
      if(!names.length)return setMessage('Không phát hiện được mục Nơi nhận trong file chính. Hãy bấm Đọc toàn bộ hoặc kiểm tra thủ công.','error');
      const ready=await ensureClerkOutgoingRecipients();
      if(!ready)return setMessage('Không mở được danh sách nơi nhận Ban hành.','error');
      const selector='input[name="vbdi_chk_donvi_truc"],input[name="vbdi_rd_unit_noibo_emp"]';
      clearRecipientControls(selector);
      const result=matchAndSelectRecipients(names,selector);
      state.workflowPhase='recipients-applied'; updatePrimaryAction();
      if(state.refs.modeResult){
        state.refs.modeResult.innerHTML=`<div class="mode-result-title">📬 Đã đối chiếu nơi nhận</div><div class="recipient-list">${result.matched.map(x=>`<div>✓ ${escapeHtml(x.target)} → ${escapeHtml(x.text)}</div>`).join('')}${result.unmatched.map(x=>`<div>⚠ Chưa khớp: ${escapeHtml(x)}</div>`).join('')}</div>`;
        state.refs.modeResult.classList.remove('hidden');
      }
      setMessage(`${result.matched.length}/${names.length} nơi nhận đã được chọn trên iOffice${result.unmatched.length?` · ${result.unmatched.length} mục cần kiểm tra`:''}. Kiểm tra lại rồi bấm Ban hành trên iOffice.`,result.unmatched.length?'info':'success');
      return;
    }

    const ready=await ensureClerkIncomingRecipients();
    if(!ready)return setMessage('Không mở được Thông tin nhận của văn bản đến.','error');
    await captureClerkRecipientDirectory();
    const cfg=await safeStorageGet({clerkIncomingMainRecipient:'',clerkIncomingCoordRecipients:[],clerkIncomingViewRecipients:[],clerkIncomingMainRecipientId:'',clerkIncomingCoordRecipientIds:[],clerkIncomingViewRecipientIds:[],clerkAutoSendIncoming:false});
    const main=normalizeText(cfg.clerkIncomingMainRecipient||'');
    const coord=(Array.isArray(cfg.clerkIncomingCoordRecipients)?cfg.clerkIncomingCoordRecipients:[]).map(normalizeText).filter(Boolean);
    const view=(Array.isArray(cfg.clerkIncomingViewRecipients)?cfg.clerkIncomingViewRecipients:[]).map(normalizeText).filter(Boolean);
    const mainId=normalizeText(cfg.clerkIncomingMainRecipientId||'');
    const coordIds=(Array.isArray(cfg.clerkIncomingCoordRecipientIds)?cfg.clerkIncomingCoordRecipientIds:[]).map(normalizeText).filter(Boolean);
    const viewIds=(Array.isArray(cfg.clerkIncomingViewRecipientIds)?cfg.clerkIncomingViewRecipientIds:[]).map(normalizeText).filter(Boolean);
    if(!main&&!coord.length&&!view.length&&!mainId&&!coordIds.length&&!viewIds.length){
      const detected=(suggestion.recipientNames||[]).filter(Boolean);
      if(state.refs.modeResult&&detected.length){
        state.refs.modeResult.innerHTML=`<div class="mode-result-title">📬 Nơi nhận nêu trực tiếp trong văn bản</div><div class="recipient-list">${detected.map(x=>`<div>• ${escapeHtml(x)}</div>`).join('')}</div><div class="mode-empty">Chưa có nhóm nhận mặc định. Vào ⚙ Cấu hình → Văn thư · Nhận nhanh văn bản đến.</div>`;
        state.refs.modeResult.classList.remove('hidden');
      }
      return setMessage('Chưa cấu hình nhóm nhận mặc định cho Văn thư · Văn bản đến. Tiện ích không tự đoán vai trò người nhận.','info');
    }
    const mainSel='input[name="rd_unit_emp"],input[name="rd_unit_noibo_emp"]';
    const coordSel='input[name="chk_unit_emp_xuly"],input[name="chk_unit_noibo_xuly"]';
    const viewSel='input[name="chk_unit_emp_xem"],input[name="chk_unit_noibo_xem"]';
    clearRecipientControls(`${mainSel},${coordSel},${viewSel}`);
    const resultMain=mainId?selectRecipientKeys([mainId],mainSel):(main?matchAndSelectRecipients([main],mainSel):{matched:[],unmatched:[]});
    const resultCoord=coordIds.length?selectRecipientKeys(coordIds,coordSel):(coord.length?matchAndSelectRecipients(coord,coordSel):{matched:[],unmatched:[]});
    const resultView=viewIds.length?selectRecipientKeys(viewIds,viewSel):(view.length?matchAndSelectRecipients(view,viewSel):{matched:[],unmatched:[]});
    const matched=[...resultMain.matched,...resultCoord.matched,...resultView.matched],unmatched=[...resultMain.unmatched,...resultCoord.unmatched,...resultView.unmatched];
    state.workflowPhase='recipients-applied'; updatePrimaryAction();
    if(state.refs.modeResult){
      state.refs.modeResult.innerHTML=`<div class="mode-result-title">📬 Nhóm nhận mặc định Văn thư</div><div class="recipient-list">${matched.map(x=>`<div>✓ ${escapeHtml(x.target)} → ${escapeHtml(x.text)}</div>`).join('')}${unmatched.map(x=>`<div>⚠ Chưa khớp: ${escapeHtml(x)}</div>`).join('')}</div>`;
      state.refs.modeResult.classList.remove('hidden');
    }
    const total=(mainId||main?1:0)+(coordIds.length||coord.length)+(viewIds.length||view.length);
    if(autoTriggered && cfg.clerkAutoSendIncoming && !unmatched.length && total>0){
      const sendBtn=document.querySelector('#btn_action_send') || findActionElement(/^Chuyển$/i,['#btn_action_send']);
      if(sendBtn&&isElementVisible(sendBtn)){ sendBtn.click(); setMessage(`✓ Đã áp dụng ${matched.length}/${total} nơi nhận và gửi lệnh Chuyển tự động.`, 'success'); return; }
    }
    setMessage(`${matched.length}/${total} người/đơn vị đã được chọn${unmatched.length?` · ${unmatched.length} mục cần kiểm tra`:''}. ${autoTriggered?'Kiểm tra trước khi Chuyển.':'Kiểm tra rồi bấm Chuyển trên iOffice.'}`,unmatched.length?'info':'success');
  }


  function collectIncomingSuggestionForApply() {
    const suggestion = {
      ...state.lastSuggestion,
      mainUnit: state.refs.mainSelect.value || null,
      coordinationUnits: getSelectedCodes(state.refs.coordBox),
      viewUnits: [],
      instruction: ensureVpProposalPrefix(state.refs.instruction.value)
    };
    syncExclusiveRoles();
    suggestion.coordinationUnits = getSelectedCodes(state.refs.coordBox).filter(x=>x!==suggestion.mainUnit);
    suggestion.viewUnits = [];

    const trackedNow = trackingItemsFromUi(suggestion);
    if (!suggestion.mainUnit && trackedNow.length===1 && trackedNow[0].responsibleUnit) {
      suggestion.mainUnit = trackedNow[0].responsibleUnit;
      if (state.refs.mainSelect) state.refs.mainSelect.value = suggestion.mainUnit;
      syncExclusiveRoles(); renderRoleChips();
    }
    if (!suggestion.mainUnit && suggestion.coordinationUnits.length) {
      suggestion.mainUnit = suggestion.coordinationUnits.shift();
      if (state.refs.mainSelect) state.refs.mainSelect.value = suggestion.mainUnit;
      syncExclusiveRoles(); renderRoleChips();
    }
    if (!suggestion.mainUnit) throw new Error('Mỗi văn bản phải có 1 đơn vị Xử lý chính để iOffice chuyển đến đầu mối tiếp nhận.');
    if (trackedNow.some(t=>t.responsibleUnit && t.responsibleUnit!==suggestion.mainUnit)) {
      throw new Error('XLC trong thẻ Nhiệm vụ phải trùng Xử lý chính của văn bản.');
    }
    return suggestion;
  }

  async function completeTransferAfterClick(suggestion, trackerContextSnapshot) {
    state.appliedKey=''; state.workflowPhase='transferred';
    state.pendingAppliedSuggestion=null; state.pendingTrackerContextSnapshot=null;
    const selectedTrack=trackingItemsFromUi(suggestion);
    let trackerText='';
    if(selectedTrack.length){
      const tracked=await writeTrackedTasksToTracker(suggestion,trackerContextSnapshot);
      if(tracked.ok) {
        const meta=[trackerContextSnapshot.symbol, trackerContextSnapshot.trichYeu].filter(Boolean).join(' · ');
        trackerText=tracked.queued
          ? ` · ✓ Đã lưu ${tracked.count} nhiệm vụ vào hàng chờ đồng bộ Sổ${meta?` (${meta.slice(0,120)})`:''}`
          : ` · ✓ Đã tạo ${tracked.count} nhiệm vụ trong Sổ theo dõi${meta?` (${meta.slice(0,120)})`:''}`;
      }
      else if(tracked.disabled) trackerText=' · ⚠ Đã chọn theo dõi nhưng Sổ theo dõi chưa bật';
      else trackerText=` · ⚠ Chuyển thành công nhưng ghi Sổ lỗi: ${tracked.error}`;
    }
    setMessage(`✓ Đã chuyển văn bản${trackerText}`, trackerText.includes('lỗi')?'info':'success');
  }

  async function applyCurrentSuggestion(transferNow=true) {
    if(state.analyzedKey!==getDocumentKey(extractDocumentContext()))return setMessage('Văn bản đã thay đổi. Hãy phân tích lại.','error');
    if (!state.lastSuggestion) return setMessage('Chưa có kết quả phân tích để áp dụng.', 'error');
    if (state.busy || state.updateLocked) return;
    const workflow=currentWorkflow();
    if (['leader-outgoing','chief-outgoing'].includes(workflow)) return setMessage('Văn bản đi ở vai trò này chỉ kiểm tra; không tự ký hoặc ban hành.', 'info');
    if (workflow.startsWith('clerk-')) return applyClerkRecipients(workflow,state.lastSuggestion);

    let suggestion;
    try { suggestion = collectIncomingSuggestionForApply(); }
    catch(e){ return setMessage(e.message,'error'); }

    // Chụp metadata nguồn trước khi iOffice mở modal.
    const trackerContextSnapshot=snapshotTrackerContext(state.lastContext || extractDocumentContext());

    state.workflowPhase='apply';
    if(state.refs.suggestBtn){
      state.refs.suggestBtn.disabled=true;
      state.refs.suggestBtn.textContent=transferNow?'⏳ Đang áp dụng & chuyển…':'⏳ Đang áp dụng…';
      state.refs.suggestBtn.className='primary-btn apply-state';
    }
    if(state.refs.applyOnlyBtn) state.refs.applyOnlyBtn.disabled=true;
    try{
      const opened=await ensureProcessingForm(suggestion);
      if(!opened){setMessage('Không mở được cửa sổ Chuyển xử lý hoặc danh sách đơn vị chưa tải xong.','error');return;}
      await sleepUi(120);
      let report=applySuggestion(suggestion);

      // Chánh Văn phòng: thêm tối đa 3 lãnh đạo xem mặc định từ danh bạ iOffice, nếu control cá nhân đang có trên form.
      const chiefView=await waitApplyChiefDefaultViewRecipients();
      if(state.userRole==='chief' && chiefView.unmatched?.length){
        report.warnings.push(`Chưa chọn được ${chiefView.unmatched.length} lãnh đạo xem mặc định của Chánh Văn phòng.`);
      }

      const nonBlocking=report.warnings.filter(x=>/Không tìm thấy ô Hạn xử lý/.test(x));
      let blocking=report.warnings.filter(x=>!/Không tìm thấy ô Hạn xử lý/.test(x));
      if(blocking.length){
        await sleepUi(350);
        if(await waitForSuggestionControls(suggestion,2500)) {
          report=applySuggestion(suggestion);
          const retryChief=await waitApplyChiefDefaultViewRecipients(1800);
          if(state.userRole==='chief' && retryChief.unmatched?.length) report.warnings.push(`Chưa chọn được ${retryChief.unmatched.length} lãnh đạo xem mặc định của Chánh Văn phòng.`);
        }
        blocking=report.warnings.filter(x=>!/Không tìm thấy ô Hạn xử lý/.test(x));
      }
      if(blocking.length){setMessage(blocking.join(' '),'error');return;}
      if(nonBlocking.length) addProgress(nonBlocking.join(' '),'warn','deadline-field');

      if(!transferNow){
        state.pendingAppliedSuggestion={...suggestion};
        state.pendingTrackerContextSnapshot={...trackerContextSnapshot};
        state.workflowPhase='transfer';
        setMessage('✓ Đã áp dụng phân công và VP đề xuất lên iOffice. Kiểm tra lại rồi bấm Chuyển.', 'success');
        return;
      }

      setMessage('Đã áp dụng phân công và VP đề xuất. Đang chuyển văn bản…','info');
      const moved=await clickLeaderTransferAndWait();
      if(!moved.ok){state.workflowPhase='apply';setMessage(moved.error,'error');return;}
      await completeTransferAfterClick(suggestion,trackerContextSnapshot);
    }finally{
      if(state.refs.applyOnlyBtn) state.refs.applyOnlyBtn.disabled=false;
      updatePrimaryAction();
    }
  }

  async function finalizeCurrentTransfer() {
    if(state.busy || state.updateLocked)return;
    const currentKey=getDocumentKey(extractDocumentContext());
    if(state.analyzedKey!==currentKey)return setMessage('Văn bản đã thay đổi. Hãy phân tích lại.','error');
    const suggestion=state.pendingAppliedSuggestion;
    const snap=state.pendingTrackerContextSnapshot;
    if(!suggestion || !snap) return applyCurrentSuggestion(true);
    if(state.refs.suggestBtn){state.refs.suggestBtn.disabled=true;state.refs.suggestBtn.textContent='⏳ Đang chuyển…';}
    try{
      const moved=await clickLeaderTransferAndWait();
      if(!moved.ok){setMessage(moved.error,'error');return;}
      await completeTransferAfterClick(suggestion,snap);
    } finally { updatePrimaryAction(); }
  }

  function createWidget() {
    if (document.getElementById(HOST_ID)) return;
    const host = document.createElement('div');
    host.id = HOST_ID;
    host.style.cssText = 'position:fixed;right:18px;bottom:18px;z-index:2147483647;visibility:hidden';
    document.documentElement.appendChild(host);
    const shadow = host.attachShadow({ mode: 'open' });
    state.root = shadow;

    shadow.innerHTML = `
      <style>
        :host{all:initial}*{box-sizing:border-box}.hidden{display:none!important}.card{width:430px;height:690px;min-width:360px;min-height:360px;max-width:min(760px,calc(100vw - 20px));max-height:calc(100vh - 20px);overflow:hidden;resize:both;display:flex;flex-direction:column;border-radius:15px;background:#fff;border:1px solid rgba(0,0,0,.12);box-shadow:0 18px 60px rgba(0,0,0,.28);font-family:Arial,Helvetica,sans-serif;color:#172033}.card.collapsed{height:auto!important;min-height:0;resize:none}.card.collapsed .body{display:none!important}
        .header{display:flex;align-items:center;justify-content:space-between;gap:8px;padding:9px 10px;background:linear-gradient(135deg,#0759c8,#1188d8);color:#fff;user-select:none;cursor:grab;touch-action:none}.header:active{cursor:grabbing}.title{display:flex;align-items:center;gap:6px;min-width:0;font-size:13px;font-weight:700;line-height:1.2}.version{font-size:9px;opacity:.76;font-weight:500}.workflow-badge{font-size:9px;font-weight:800;padding:3px 6px;border-radius:999px;background:rgba(255,255,255,.18);white-space:nowrap}.header-role{width:104px!important;height:29px;padding:4px 7px!important;border:1px solid rgba(255,255,255,.8)!important;background:#fff!important;color:#0759c8!important;font-size:9px!important;font-weight:900!important}.header-role option{background:#fff;color:#172033}.head-actions{display:flex;gap:6px}.icon-btn{width:29px;height:29px;border:0;border-radius:9px;color:#fff;background:rgba(255,255,255,.17);cursor:pointer}.icon-btn:hover{background:rgba(255,255,255,.26)}
        .body{padding:11px;overflow:auto;flex:1;min-height:0;max-height:none}.body.hidden{display:none}.meta{padding:9px 10px;background:#f7f9fc;border:1px solid #e4e9f1;border-radius:10px}.doc{font-size:12px;line-height:1.42;color:#1d2939;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;max-height:35px}.doc b{font-weight:800;color:#334155}.sender-line{font-size:10px;color:#64748b;margin-top:5px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.sender-sep{margin:0 4px;color:#cbd5e1}
        .hero-actions{display:flex;flex-wrap:nowrap;gap:6px;margin-top:8px}.hero-actions .primary-btn{width:auto;flex:1 1 auto;min-width:0}.apply-only-btn{border:1px solid #16834d;border-radius:10px;background:#fff;color:#16834d;font-size:11px;font-weight:900;padding:0 12px;cursor:pointer;white-space:nowrap;min-height:40px}.apply-only-btn:hover{background:#f0fdf4}.apply-only-btn:disabled{opacity:.55;cursor:not-allowed}.primary-btn{width:100%;border:0;border-radius:10px;padding:11px 12px;background:#0866cf;color:#fff;font-weight:700;cursor:pointer;box-shadow:0 4px 12px rgba(8,102,207,.2)}.primary-btn:hover{filter:brightness(.97)}.primary-btn:disabled{opacity:.52;cursor:not-allowed}.primary-btn.analyzed{background:#138a4b;box-shadow:0 4px 12px rgba(19,138,75,.18)}.primary-btn.busy{background:#64748b}.primary-btn.apply-state{background:#16834d;box-shadow:0 4px 12px rgba(22,131,77,.2)}.primary-btn.transfer-state{background:#0f766e;box-shadow:0 4px 12px rgba(15,118,110,.2)}.rule-btn{width:100%;border:1px solid #c9d8e5;border-radius:10px;padding:10px 9px;background:#fff;color:#34546d;font-weight:750;font-size:11px;cursor:pointer}.rule-btn:hover{background:#f5f9fc}.rule-btn:disabled{opacity:.5;cursor:not-allowed}.apply-btn{border:0;border-radius:10px;background:#16834d;color:#fff;font-size:11px;font-weight:800;padding:0 12px;cursor:pointer;white-space:nowrap}.apply-btn:hover{filter:brightness(.97)}.apply-btn:disabled{opacity:.55;cursor:not-allowed}.reanalyze{width:40px;border:1px solid #cfd7e4;border-radius:10px;background:#fff;color:#435167;font-size:16px;cursor:pointer}.stop-btn{width:52px;border:1px solid #fecaca;border-radius:10px;background:#fff1f2;color:#b42318;font-size:10px;font-weight:800;cursor:pointer}.stop-btn:hover{background:#ffe4e6}.finalize-btn{border:0;border-radius:10px;background:#0f766e;color:#fff;font-size:11px;font-weight:800;padding:0 12px;cursor:pointer;white-space:nowrap}.finalize-btn:hover{filter:brightness(.96)}.finalize-btn:disabled{opacity:.55;cursor:not-allowed}
        details{margin-top:8px;border:1px solid #e4e9f1;border-radius:9px;background:#fafbfd}summary{cursor:pointer;padding:7px 9px;font-size:10.5px;font-weight:700;color:#667085}.source{padding:0 9px 8px;font-size:9.5px;line-height:1.45;color:#667085;max-height:145px;overflow:auto}.signal-score{margin-top:4px;color:#255a98}
        .section{margin-top:10px}.section-head{display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:5px}.label{font-size:11px;font-weight:700;color:#475467}.hint{font-size:9px;color:#98a2b3}select,textarea{width:100%;border:1px solid #d0d7e2;border-radius:9px;padding:8px;font:12px Arial,sans-serif;background:#fff;color:#172033;outline:none}select:focus,textarea:focus{border-color:#7ab8f3;box-shadow:0 0 0 3px rgba(8,102,207,.08)}textarea{min-height:76px;resize:vertical;line-height:1.45}.instruction-section .label{font-size:12.5px;font-weight:800;color:#1f3f66}.instruction-section textarea{min-height:96px;font-size:13px;line-height:1.58;padding:10px 11px;resize:none;overflow:hidden;background:#fffefb;border-color:#c9d6e3}
        .main-role-section{--confidence-color:#0866cf;padding:10px;border:1px solid color-mix(in srgb,var(--confidence-color) 42%,#d8e5f4);border-left:5px solid var(--confidence-color);border-radius:11px;background:linear-gradient(135deg,color-mix(in srgb,var(--confidence-color) 8%,#fff),#f8fbff);box-shadow:0 3px 12px color-mix(in srgb,var(--confidence-color) 10%,transparent)}.main-role-section .label{font-size:12px;color:#174f8e}.main-role-section select{font-weight:700;border-color:#86bff6;background:#fff}.confidence-meter{display:flex;align-items:center;gap:6px;min-width:104px}.confidence-track{position:relative;width:66px;height:8px;border-radius:999px;background:#e2e8f0;overflow:hidden}.confidence-fill{width:0;height:100%;border-radius:inherit;background:#cbd5e1;transition:width .25s ease,background .25s ease}.confidence-value{min-width:30px;text-align:right;font-size:10px;font-weight:800;color:#64748b}.confidence-value.high{color:#15803d}.confidence-value.mid{color:#a16207}.confidence-value.low{color:#b91c1c}.role-box{display:flex;align-items:center;gap:6px;flex-wrap:wrap;min-height:38px;padding:6px;border:1px solid #dce3ec;border-radius:9px;background:#fbfcfe}.selected-chips{display:flex;gap:5px;flex-wrap:wrap;flex:1;min-width:0}.role-empty{font-size:10px;color:#98a2b3;padding:3px}.role-chip{display:inline-flex;align-items:center;max-width:100%;background:#eaf3ff;color:#245d9d;border:1px solid #d6e8ff;border-radius:999px;padding:5px 9px;font-size:9.8px;font-weight:600;cursor:pointer;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.role-chip:hover{background:#dcecff;border-color:#bdd8fa}.add-role{border:1px dashed #a9bdd6;border-radius:8px;background:#fff;color:#2563a7;padding:6px 9px;font-size:10px;font-weight:700;cursor:pointer;white-space:nowrap}.hidden-store{display:none}
        .analysis{margin-top:9px;border:1px solid #b9d9fb;border-radius:11px;background:linear-gradient(180deg,#f2f8ff,#fbfdff);padding:10px}.analysis.hidden{display:none}.analysis-meta{font-size:9.6px;font-weight:700;color:#64748b;background:#eaf2fb;border-radius:7px;padding:5px 7px;margin-bottom:7px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.analysis-title{display:none}.analysis-routing{display:none}.summary-label{font-weight:800;color:#334155}.review{font-size:11.5px;font-weight:700;margin-top:4px}.review.ok{color:#176b3d}.review.warn{color:#a36a00}.reason{margin-top:6px;font-size:12.4px;color:#4b5d73;line-height:1.52}.chips{display:flex;flex-wrap:wrap;gap:4px;margin-top:7px}.chips.hidden{display:none}.chip{background:#eaf2ff;color:#285e9d;padding:3px 6px;border-radius:10px;font-size:9.2px}.muted{color:#8b94a4;font-size:9px}
        .ai-mode-wrap{margin:7px 0 2px}.ai-mode-switch{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:4px;padding:4px;border:1px solid #d8e2ef;background:#f3f6fa;border-radius:10px}.ai-mode-btn{border:0;background:transparent;color:#617087;border-radius:7px;padding:7px 5px;font-size:9.7px;font-weight:800;cursor:pointer;transition:.16s ease}.ai-mode-btn:hover{background:#e8f1fb;color:#245d9d}.ai-mode-btn.active{background:#0b72d7;color:#fff;box-shadow:0 2px 7px rgba(11,114,215,.22)}.ai-mode-hint{margin-top:4px;text-align:right;font-size:8.5px;color:#8a96a8}.web-import{margin-top:5px;border:1px solid #efd397;background:#fff7e6;color:#8a5a00;border-radius:8px;padding:6px 8px;font-size:9.5px;font-weight:700;cursor:pointer}.web-import:hover{background:#ffefc7}.message{margin-top:7px;padding:8px 9px;border-radius:9px;font-size:10.6px;font-weight:700;line-height:1.42;border:1px solid transparent}.message.info{border-color:#d5e7fb}.message.success{border-color:#ccebd9}.message.error{border-color:#f3caca}.message.info{background:#eef5ff;color:#255a98}.message.success{background:#eaf8f0;color:#16663a}.message.error{background:#fff0f0;color:#a23535}.safety{margin-top:7px;font-size:8.8px;color:#8b5b12;background:#fff7e8;padding:6px 7px;border-radius:7px}
        .deadline-card{margin-top:8px}.task-card-title{display:flex;align-items:center;justify-content:space-between;padding:8px 10px;background:#0f766e;color:#fff;border-radius:10px 10px 0 0;font-size:11px;font-weight:900}.task-scope{padding:7px 9px;background:#ecfdf5;border:1px solid #bbf7d0;border-top:0;color:#166534;font-size:9.5px;line-height:1.4}.track-item{padding:8px 9px;border:1px solid #d7e4de;border-top:0;background:#fff}.track-item:last-of-type{border-radius:0 0 10px 10px}.track-head{display:flex;justify-content:space-between;align-items:center;gap:7px}.track-toggle{font-size:10.5px;color:#0f5132;display:flex;align-items:center;gap:4px}.track-badge{font-size:8.8px;font-weight:800;color:#b45309;background:#fff7ed;padding:3px 6px;border-radius:999px}.track-text{margin-top:6px;min-height:48px!important;max-height:58px!important;resize:none!important;font-size:11.5px!important;font-weight:700;background:#fbfefc!important}.track-fields{margin-top:6px;display:flex;align-items:center;justify-content:space-between;gap:8px;font-size:9.5px;color:#64748b}.track-fields input{width:132px;padding:5px 6px;border:1px solid #d0d7e2;border-radius:7px}.track-unit-select{max-width:155px;height:29px;border:1px solid #cbd5e1;border-radius:7px;background:#fff;padding:3px 22px 3px 6px;font-size:10px;color:#334155}.track-unit{max-width:58%;display:flex;align-items:center;gap:5px;white-space:nowrap}.track-unit{max-width:54%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.track-evidence{margin-top:5px;font-size:8.8px;color:#7c6f54;line-height:1.35}.track-note{margin-top:5px;font-size:8.7px;color:#64748b}.track-online{font-size:8.7px;color:#dcfce7}.track-offline{font-size:8.7px;color:#fee2e2}.fallback-actions{display:flex;gap:5px;flex-wrap:wrap;margin-top:6px}.fallback-actions button{border:1px solid #cbd5e1;background:#fff;border-radius:8px;padding:6px 8px;font-size:9.5px;font-weight:800;color:#334155;cursor:pointer}.fallback-actions button:hover{background:#f1f5f9}.input-audit{margin-top:7px;border:1px solid #dde5ed;border-radius:10px;padding:8px 9px;background:#fbfcfe}.input-audit.pending{color:#667085}.input-audit.ok{background:#effaf4;border-color:#cce9d8}.input-audit.warn{background:#fff8e8;border-color:#f0d59a}.input-audit-head{font-size:10.5px;font-weight:800;line-height:1.4}.input-audit-files{display:grid;gap:4px;margin-top:6px;max-height:105px;overflow:auto}.input-file{display:grid;grid-template-columns:14px minmax(0,1fr);column-gap:5px;align-items:start;font-size:9.5px;padding:4px 5px;border-radius:6px;background:#fff8}.input-file span{grid-row:1/3}.input-file b{font-weight:700;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.input-file small{grid-column:2;color:#667085;font-size:8.7px;line-height:1.35}.input-file.ok span{color:#15803d}.input-file.bad span{color:#b7791f}
        .workflow-strip{display:flex;align-items:center;gap:7px;margin:8px 0 2px}.workflow-role{width:118px;min-height:32px;padding:5px 26px 5px 8px;border-radius:9px;font-size:10.5px;font-weight:800;background:#fff}.workflow-badge{flex:1;min-width:0;padding:7px 9px;border:1px solid #cfe0dc;border-radius:9px;background:#eef8f5;color:#17675f;font-size:10.5px;font-weight:800;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.read-all-btn{width:100%;margin-top:6px;border:1px solid #b9d4e8;border-radius:8px;background:#f7fbff;color:#245d8f;padding:6px 8px;font-size:10px;font-weight:800;cursor:pointer}.deadline-card{margin-top:9px}.deadline-task{border:2px solid #d7e4ef;border-left-width:6px;border-radius:11px;background:#f8fbfd;padding:10px 11px;margin-top:7px}.deadline-task.soon{border-color:#f2c94c;background:#fffbed}.deadline-task.urgent{border-color:#f59e0b;background:#fff7e6}.deadline-task.overdue{border-color:#dc2626;background:#fff1f2}.deadline-kicker{font-size:10px;font-weight:900;color:#8a5200;letter-spacing:.2px}.deadline-date{margin-top:3px;font-size:13px;font-weight:900;color:#7c2d12}.deadline-date strong{font-size:19px;line-height:1.2;color:#b42318;font-weight:950;letter-spacing:.2px}.deadline-state{font-size:11px;font-weight:900;color:#b45309;margin-top:3px}.deadline-reminder{margin-top:4px;font-size:10.5px;font-weight:700;color:#475569}.deadline-task.overdue .deadline-state{color:#b91c1c}.deadline-tasktext,.deadline-evidence{font-size:10.5px;line-height:1.45;color:#475569;margin-top:6px}.tracker-plan{margin-top:7px;padding:8px 9px;border-radius:9px;font-size:10.5px;line-height:1.4}.tracker-plan.ok{background:#eaf8f0;color:#16663a;border:1px solid #ccebd9}.tracker-plan.warn{background:#fff8e8;color:#8a5a00;border:1px solid #f0d59a}.mode-result{margin-top:9px;border:1px solid #d9e2ec;border-radius:10px;background:#fbfcfe;padding:9px 10px;font-size:10.5px}.mode-result-title{font-weight:900;color:#334155;margin-bottom:5px}.review-summary{line-height:1.5;color:#475569}.review-issue{display:flex;flex-direction:column;gap:2px;margin-top:6px;padding:6px 7px;border-radius:7px;background:#fff}.review-issue.high{border-left:4px solid #dc2626}.review-issue.medium{border-left:4px solid #f59e0b}.review-issue.low{border-left:4px solid #60a5fa}.review-issue small{color:#64748b}.recipient-list{display:grid;gap:3px;color:#334155;line-height:1.4}.mode-empty{color:#64748b}.info-only{padding:8px 9px;border-radius:8px;background:#eef7ff;color:#285e9d;line-height:1.5}.toast-inline{font-weight:800}.tracker-candidate{margin-top:9px;padding:8px 9px;border:1px solid #c8ddce;border-radius:9px;background:#f2faf4;color:#28523a}.tracker-candidate-text{margin-top:4px;line-height:1.4}.tracker-candidate-score{margin-top:3px;font-size:9.5px;color:#64748b}.tracker-complete-btn{margin-top:7px;border:0;border-radius:8px;background:#15803d;color:#fff;padding:7px 9px;font-size:10px;font-weight:850;cursor:pointer}.tracker-complete-btn:disabled{opacity:.65}
                .picker{position:absolute;inset:0;display:flex;align-items:flex-end;justify-content:center;background:rgba(15,23,42,.26);z-index:10;border-radius:15px;overflow:hidden}.picker.hidden{display:none}.picker-panel{width:100%;max-height:72%;display:flex;flex-direction:column;background:#fff;border-radius:14px 14px 0 0;box-shadow:0 -14px 38px rgba(0,0,0,.16);padding:10px}.picker-head{display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:7px}.picker-head b{font-size:12px}.picker-close{border:0;background:#f1f4f8;border-radius:8px;width:30px;height:30px;cursor:pointer}.picker-search{width:100%;border:1px solid #d0d7e2;border-radius:8px;padding:8px;font-size:11px;margin-bottom:6px}.picker-list{overflow:auto}.picker-row{display:grid;grid-template-columns:20px 1fr;gap:7px;align-items:center;padding:7px 4px;border-bottom:1px solid #f0f2f5;cursor:pointer}.picker-row b{display:block;font-size:10.5px;font-weight:600}.picker-row small{display:block;font-size:8.5px;color:#98a2b3;margin-top:2px}
        .card{font-family:system-ui,-apple-system,"Segoe UI",sans-serif;width:400px;height:690px;border-radius:16px;box-shadow:0 14px 48px #163c3433;border-color:#d4e3df}.header{background:#087d77;padding:8px 10px;min-height:42px}.title{font-size:13px;line-height:1.2}.version{font-size:9px}.body{padding:10px}.doc{font-size:13px;line-height:1.45;max-height:39px}.meta-label{font-size:9px}.sender-line{font-size:11px}.label,.main-role-section .label{font-size:12px}.primary-btn{background:#087d77;font-size:13px;min-height:40px}.message{font-size:11px;font-weight:500}.analysis-meta{font-size:10.5px;white-space:normal;line-height:1.5}.reason{font-size:12.5px}.role-chip{font-size:11px;min-height:30px}.role-empty,.add-role{font-size:11px}.add-role{min-height:32px}.ai-mode-btn{font-size:10.5px;min-height:32px}.ai-mode-hint{font-size:9.5px}.stop-btn{font-size:11px;min-width:52px;height:40px}select,textarea{font:12.5px/1.45 system-ui,sans-serif;min-height:38px}.source{font-size:10.5px;max-height:165px}.progress-row{display:grid;grid-template-columns:42px 12px 1fr;gap:5px;padding:4px 0;border-bottom:1px solid #e5ecec}.progress-time{font-variant-numeric:tabular-nums;color:#708087}.progress-row.warn{color:#9b670c}.progress-row.error{color:#aa3535}.progress-row.success{color:#25714a}summary{font-size:11.5px;padding:8px 9px}.safety{font-size:9.5px;line-height:1.45}.picker-row{padding:10px 5px}.picker-row b{font-size:12px}.picker-row small{font-size:10.5px}.picker-search{font-size:12px}.picker-head b{font-size:13px}.hero-actions{position:sticky;top:-10px;background:#fff;padding:6px 0;z-index:2;display:flex;flex-wrap:nowrap;gap:6px}.hero-actions .primary-btn{width:auto;flex:1 1 auto;min-width:0}.apply-only-btn{border:1px solid #16834d;border-radius:10px;background:#fff;color:#16834d;font-size:11px;font-weight:900;padding:0 12px;cursor:pointer;white-space:nowrap;min-height:40px}.apply-only-btn:hover{background:#f0fdf4}.apply-only-btn:disabled{opacity:.55;cursor:not-allowed}.reanalyze{width:40px;min-width:40px;height:40px}.icon-btn{min-width:28px;min-height:28px;width:28px;height:28px}.hint{font-size:9.5px}button:focus-visible,select:focus-visible,textarea:focus-visible,input:focus-visible{outline:3px solid #75c8bc;outline-offset:2px}@media(prefers-reduced-motion:reduce){*{transition:none!important}}
        /* v0.16.2: giao diện gọn theo luồng Phân tích → Áp dụng → Chuyển */
        .hero-actions{align-items:stretch}.primary-btn{background:#1976d2!important;box-shadow:0 4px 12px rgba(25,118,210,.20)!important}.primary-btn.apply-state{background:#d97706!important;box-shadow:0 4px 12px rgba(217,119,6,.20)!important}.primary-btn.transfer-state{background:#15803d!important;box-shadow:0 4px 12px rgba(21,128,61,.20)!important}.primary-btn.busy{background:#64748b!important;box-shadow:none!important}.mode-select{width:146px;min-width:146px;max-width:146px;height:40px;min-height:40px;padding:0 26px 0 9px;border:1px solid #cbd5e1;border-radius:10px;background:#f8fafc;color:#334155;font-size:10.5px;font-weight:750;cursor:pointer;box-shadow:none}.mode-select:hover{border-color:#94a3b8;background:#fff}.mode-select:disabled{opacity:.65;cursor:not-allowed}.ai-info{margin-top:7px;border:1px solid #d7e2ec;border-radius:10px;background:#f8fbfd;overflow:hidden}.ai-info.pending{border-color:#d7e2ec}.ai-info.ok{border-color:#c9e5d5;background:#f5fbf7}.ai-info.warn{border-color:#f0d59a;background:#fffaf0}.ai-info-summary{display:flex;align-items:center;justify-content:space-between;gap:8px;padding:8px 9px;list-style:none;font-size:10.5px;font-weight:800;color:#475569}.ai-info-summary::-webkit-details-marker{display:none}.ai-info-title{min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.ai-info-chevron{flex:0 0 auto;color:#64748b;font-size:12px;transition:transform .16s ease}.ai-info[open] .ai-info-chevron{transform:rotate(180deg)}.ai-info-body{padding:0 8px 8px}.ai-info-stats{font-size:10px;font-weight:700;line-height:1.45;color:#475569;padding:6px 7px;margin-bottom:5px;background:rgba(255,255,255,.68);border-radius:7px}.ai-info .analysis-meta{margin:0 0 6px;padding:5px 7px;font-size:9.5px;line-height:1.4;background:#edf3f8;color:#64748b;border-radius:7px}.ai-info .input-audit-files{margin-top:0;max-height:145px}.analysis{padding:10px 11px}.review{font-size:12px}.reason{font-size:14px;line-height:1.62;color:#425466}.summary-label{font-size:14px;color:#1f3f66}.chips{display:none!important}.progress-details{margin-top:12px;margin-bottom:2px;background:#fafbfd}.progress-details summary{color:#64748b}.message{padding:7px 9px}.section{margin-top:9px}
      </style>
      <div class="card">
        <div class="header" id="dragHeader" role="button" tabindex="0" aria-expanded="true" title="Bấm để thu gọn Trợ lý phân luồng văn bản · kéo để di chuyển">
          <div class="title">📄 iOffice AI · Ea Ly <span class="version">v${VERSION}</span><span class="workflow-badge" id="workflowBadge">Lãnh đạo · VB đến</span></div>
          <div class="head-actions"><select class="header-role" id="roleSelect" aria-label="Vai trò"><option value="leader">Lãnh đạo</option><option value="chief">Chánh VP</option><option value="clerk">Văn thư</option></select><button class="icon-btn" id="settings" title="Cấu hình" aria-label="Cấu hình">⚙</button></div>
        </div>
        <div class="body" id="body">
          <div class="meta">
            <div class="doc"><b>Trích yếu:</b> <span id="docTitle">Chưa mở văn bản</span></div>
            <div class="sender-line"><span id="sender">—</span><span class="sender-sep">·</span><span id="docMeta"></span></div>
          </div>
          <div class="message info" id="message" role="status" aria-live="polite">Sẵn sàng. Chọn cách phân tích rồi bấm Phân tích.</div>
          <details class="ai-info pending" id="inputAudit"><summary class="ai-info-summary"><span class="ai-info-title" id="inputAuditText">Gemini Web · chưa đọc tệp</span><span class="ai-info-chevron">⌄</span></summary><div class="ai-info-body"><div class="ai-info-stats" id="inputAuditDetail">Chưa kiểm tra nội dung tệp.</div><div class="analysis-meta" id="analysisMeta"></div><div class="input-audit-files" id="inputAuditFiles"></div><button class="read-all-btn hidden" id="readAllBtn">Đọc toàn bộ</button></div></details>
          <div class="hero-actions"><button class="apply-only-btn hidden" id="applyOnlyBtn">Áp dụng</button><button class="primary-btn" id="suggestBtn">Phân tích</button><select class="mode-select" id="modeSelect" aria-label="Cách phân tích" title="Chọn cách phân tích"><option value="gemini-web">Gemini Web</option><option value="chatgpt-web">ChatGPT Web</option><option value="api">API</option></select><button class="stop-btn hidden" id="stopBtn" title="Dừng tiến trình hiện tại">Dừng</button><button class="reanalyze hidden" id="reanalyzeBtn" title="Phân tích lại theo cách vừa dùng">↻</button></div><div class="fallback-actions hidden" id="fallbackActions"><button data-mode="gemini-web">Dùng Gemini</button><button data-mode="chatgpt-web">Dùng ChatGPT</button><button data-mode="api">Dùng API</button></div><button class="web-import hidden" id="importWebBtn">📋 Nhận kết quả Web AI</button>
          <div class="analysis hidden" id="analysisPanel">
            <div class="review warn" id="review">Chưa phân tích</div><div class="reason"><b class="summary-label">Tóm tắt:</b> <span id="reason"></span></div><div class="chips hidden" id="signalList"></div>
          </div>
          <div class="deadline-card hidden" id="deadlineCard"></div>
          <div class="mode-result hidden" id="modeResult"></div>
          <div class="section main-role-section" id="mainRoleSection"><div class="section-head"><span class="label">1. Xử lý chính</span><div class="confidence-meter" title="Độ tin cậy của đề xuất xử lý chính"><div class="confidence-track"><div class="confidence-fill" id="confidenceFill"></div></div><span class="confidence-value" id="confidenceValue">—</span></div></div><select id="mainSelect" aria-label="Đơn vị xử lý chính"></select></div>
          <div class="section" id="coordSection"><div class="section-head"><span class="label">2. Phối hợp</span><span class="hint">nhiều đơn vị</span></div><div class="role-box"><div class="selected-chips" id="coordChips"></div><button class="add-role" id="addCoord">＋ Thêm</button></div><div class="hidden-store" id="coordBox"></div></div>
          <div class="section" id="viewSection"><div class="section-head"><span class="label">3. Xem để biết</span><span class="hint">nhiều đơn vị</span></div><div class="role-box"><div class="selected-chips" id="viewChips"></div><button class="add-role" id="addView">＋ Thêm</button></div><div class="hidden-store" id="viewBox"></div></div>
          <div class="section instruction-section" id="instructionSection"><div class="section-head"><span class="label" id="instructionLabel">Dự thảo ý kiến chỉ đạo</span></div><textarea id="instruction" aria-label="Dự thảo ý kiến chỉ đạo" placeholder="VP đề xuất: Giao đơn vị chủ trì/tiếp nhận, nêu rõ việc phải làm và hạn nếu có"></textarea></div>
          <details class="progress-details" id="progressDetails"><summary id="progressSummary">▸ Tiến trình xử lý</summary><div class="source" id="source"><div class="progress-empty">Chưa chạy phân tích.</div></div></details>
        </div>
        <div class="picker hidden" id="picker"><div class="picker-panel"><div class="picker-head"><b id="pickerTitle">Chọn đơn vị</b><button class="picker-close" id="pickerClose">×</button></div><input class="picker-search" id="pickerSearch" placeholder="Tìm tên đơn vị hoặc mã…"><div class="picker-list" id="pickerList"></div></div></div>
      </div>`;

    state.refs = {
      card: shadow.querySelector('.card'), body: shadow.getElementById('body'), docTitle: shadow.getElementById('docTitle'), sender: shadow.getElementById('sender'), docMeta: shadow.getElementById('docMeta'), roleSelect: shadow.getElementById('roleSelect'), workflowBadge: shadow.getElementById('workflowBadge'),
      suggestBtn: shadow.getElementById('suggestBtn'), applyOnlyBtn: shadow.getElementById('applyOnlyBtn'), ruleBtn: shadow.getElementById('ruleBtn'), stopBtn: shadow.getElementById('stopBtn'), reanalyzeBtn: shadow.getElementById('reanalyzeBtn'), source: shadow.getElementById('source'),
      progressDetails: shadow.getElementById('progressDetails'), progressSummary: shadow.getElementById('progressSummary'),
      mainSelect: shadow.getElementById('mainSelect'), coordBox: shadow.getElementById('coordBox'), viewBox: shadow.getElementById('viewBox'),
      coordChips: shadow.getElementById('coordChips'), viewChips: shadow.getElementById('viewChips'), instruction: shadow.getElementById('instruction'),
      analysisPanel: shadow.getElementById('analysisPanel'), analysisMeta: shadow.getElementById('analysisMeta'), analysisTitle: shadow.getElementById('analysisTitle'), analysisRouting: shadow.getElementById('analysisRouting'), review: shadow.getElementById('review'),
      confidenceValue: shadow.getElementById('confidenceValue'), confidenceFill: shadow.getElementById('confidenceFill'), mainRoleSection: shadow.getElementById('mainRoleSection'), coordSection: shadow.getElementById('coordSection'), viewSection: shadow.getElementById('viewSection'), instructionSection: shadow.getElementById('instructionSection'), instructionLabel: shadow.getElementById('instructionLabel'), deadlineCard: shadow.getElementById('deadlineCard'), modeResult: shadow.getElementById('modeResult'),
      reason: shadow.getElementById('reason'), signalList: shadow.getElementById('signalList'), message: shadow.getElementById('message'),
      picker: shadow.getElementById('picker'), pickerTitle: shadow.getElementById('pickerTitle'), pickerSearch: shadow.getElementById('pickerSearch'), pickerList: shadow.getElementById('pickerList'),
      importWebBtn: shadow.getElementById('importWebBtn'), modeSelect: shadow.getElementById('modeSelect'), fallbackActions: shadow.getElementById('fallbackActions'),
      inputAudit: shadow.getElementById('inputAudit'), aiInfoDetails: shadow.getElementById('inputAudit'), aiInfoSummary: shadow.getElementById('inputAuditText'), inputAuditText: shadow.getElementById('inputAuditText'), inputAuditDetail: shadow.getElementById('inputAuditDetail'), inputAuditFiles: shadow.getElementById('inputAuditFiles'), readAllBtn: shadow.getElementById('readAllBtn')
    };

    renderInputAudit(null);
    shadow.getElementById('settings').addEventListener('click', () => { void safeRuntimeSend({ type: 'OPEN_OPTIONS' }, { quiet:true }); });
    shadow.getElementById('suggestBtn').addEventListener('click', () => void handlePrimaryAction());
    state.refs.applyOnlyBtn?.addEventListener('click', () => void applyCurrentSuggestion(false));
    state.refs.ruleBtn?.addEventListener('click', runRuleAnalysis);
    state.refs.reanalyzeBtn.addEventListener('click', rerunLastAnalysis);
    state.refs.stopBtn?.addEventListener('click', stopCurrentAnalysis);
    state.refs.modeSelect?.addEventListener('change', (e) => setAnalysisMode(e.target.value));
    state.refs.fallbackActions?.querySelectorAll('[data-mode]').forEach(b=>b.addEventListener('click',()=>void runFallbackMode(b.dataset.mode)));
    state.refs.roleSelect?.addEventListener('change', async (e) => {
      if (state.busy || state.updateLocked) { e.target.value = state.userRole; return; }
      const next = ['leader','chief','clerk'].includes(e.target.value) ? e.target.value : 'leader';
      if (next === state.userRole) return;
      state.userRole = next;
      await safeStorageSet({ userRole: next });
      setMessage(`Đã đổi vai trò: ${next==='clerk'?'Văn thư':next==='chief'?'Chánh Văn phòng':'Lãnh đạo'} · đang tải lại iOffice…`, 'info');
      setTimeout(() => location.reload(), 180);
    });
    state.refs.readAllBtn?.addEventListener('click', async () => {
      if (state.busy) return;
      state.forceReadAllOnce = true; state.lastPrep = null; state.prepKey = ''; state.workflowPhase = 'analyze'; state.lastSuggestion = null; state.analyzedKey = '';
      setMessage('Đang đọc toàn bộ tệp cho lần phân tích này…', 'info');
      await runSelectedAnalysis();
    });
    state.refs.importWebBtn.addEventListener('click', importWebResult);
    shadow.getElementById('addCoord').addEventListener('click', () => openRolePicker('coord'));
    shadow.getElementById('addView').addEventListener('click', () => openRolePicker('view'));
    shadow.addEventListener('keydown',e=>{if(e.key==='Escape')closeRolePicker();});
    shadow.getElementById('pickerClose').addEventListener('click', closeRolePicker);
    state.refs.picker.addEventListener('click', (e) => { if (e.target === state.refs.picker) closeRolePicker(); });
    state.refs.pickerSearch.addEventListener('input', renderPickerList);
    state.refs.mainSelect.addEventListener('change', () => { syncExclusiveRoles(); renderRoleChips(); });
    state.refs.instruction?.addEventListener('input', autoSizeInstruction);
    requestAnimationFrame(autoSizeInstruction);

    const header = shadow.getElementById('dragHeader');
    const toggleFromHeader = () => setWidgetCollapsed(!state.refs.card.classList.contains('collapsed'), true);
    enableDragging(host, header, toggleFromHeader);
    header.addEventListener('keydown', (e) => {
      if ((e.key === 'Enter' || e.key === ' ') && !e.target.closest('button')) {
        e.preventDefault();
        toggleFromHeader();
      }
    });
    safeStorageGet({ widgetSize: null, widgetCollapsed: false }).then(({ widgetSize, widgetCollapsed }) => {
      if (widgetSize && state.refs.card) {
        const w = clamp(widgetSize.width, 330, Math.min(760, window.innerWidth - 20));
        const h = clamp(widgetSize.height, 360, window.innerHeight - 20);
        state.refs.card.style.width = `${w}px`;
        state.refs.card.style.height = `${h}px`;
      }
      setWidgetCollapsed(widgetCollapsed === true, false);
      host.style.visibility = 'visible';
    }).catch(() => { setWidgetCollapsed(false, false); host.style.visibility = 'visible'; });
    if (window.ResizeObserver && state.refs.card) {
      let sizeTimer = null;
      const ro = new ResizeObserver(() => {
        if (state.refs.card.classList.contains('collapsed')) return;
        clearTimeout(sizeTimer);
        sizeTimer = setTimeout(() => {
          if (!chromeContextAlive()) { try { ro.disconnect(); } catch (_) {} return; }
          if (!state.refs.card?.isConnected) return;
          const rect = state.refs.card.getBoundingClientRect();
          void safeStorageSet({ widgetSize: { width: Math.round(rect.width), height: Math.round(rect.height) } });
        }, 250);
      });
      ro.observe(state.refs.card);
    }
    safeStorageGet({ analysisMode: 'gemini-web', fallbackAnalysisMode:'chatgpt-web', userRole: 'leader', trackerEnabled: false, trackerReminderDays: 3, chiefDefaultViewRecipientIds: [] }).then((cfg) => {
      state.analysisMode = normalizeAnalysisMode(cfg.analysisMode);
      state.fallbackAnalysisMode = ['gemini-web','chatgpt-web','api','none'].includes(cfg.fallbackAnalysisMode)?cfg.fallbackAnalysisMode:'chatgpt-web';
      state.userRole = ['leader','chief','clerk'].includes(cfg.userRole) ? cfg.userRole : 'leader';
      state.chiefDefaultViewRecipientIds = Array.isArray(cfg.chiefDefaultViewRecipientIds) ? cfg.chiefDefaultViewRecipientIds : [];
      state.trackerEnabled = cfg.trackerEnabled === true;
      state.trackerReminderDays = Math.max(0, Math.min(30, Number(cfg.trackerReminderDays) || 3));
      updateAnalysisModeUi(); setWorkflowUi();
    }).catch(() => { updateAnalysisModeUi(); setWorkflowUi(); });
    refreshUnitOptions(true);
    updateDetection();
  }

  async function init() {
    const { iofficeAssistantEnabled = true } = await safeStorageGet({ iofficeAssistantEnabled: true });
    if (iofficeAssistantEnabled === false) return;
    await loadRules();
    if (chromeContextAlive()) {
      try { chrome.runtime.onMessage.addListener((message) => {
        if (message?.type === 'IOFFICE_GEMINI_JOB_EVENT') {
          handleGeminiJobEvent(message);
          return false;
        }
      }); } catch (error) { markExtensionContextInvalid(error); }
    }
    createWidget();
    if (chromeContextAlive()) {
      try { chrome.storage.onChanged.addListener((changes, areaName) => {
        if (areaName === 'local' && changes.analysisMode?.newValue) setAnalysisMode(changes.analysisMode.newValue, false);
        if (areaName === 'local' && changes.userRole?.newValue) { const next=['leader','chief','clerk'].includes(changes.userRole.newValue)?changes.userRole.newValue:'leader'; if(next!==state.userRole){state.userRole=next; setTimeout(()=>location.reload(),120);} }
        if (areaName === 'local' && changes.chiefDefaultViewRecipientIds) state.chiefDefaultViewRecipientIds = Array.isArray(changes.chiefDefaultViewRecipientIds.newValue) ? changes.chiefDefaultViewRecipientIds.newValue : [];
        if (areaName === 'local' && changes.trackerEnabled) { state.trackerEnabled = changes.trackerEnabled.newValue === true; if (state.lastSuggestion) renderDeadlineCard(state.lastSuggestion); }
        if (areaName === 'local' && changes.trackerReminderDays) { state.trackerReminderDays = Math.max(0, Math.min(30, Number(changes.trackerReminderDays.newValue) || 3)); if (state.lastSuggestion) renderDeadlineCard(state.lastSuggestion); }
        if (areaName === 'local' && changes.routingRulesCustom) {
          loadRules().then(() => { refreshUnitOptions(true); renderRoleChips(); }).catch(() => {});
        }
      }); } catch (error) { markExtensionContextInvalid(error); }
    }
    // v0.19: chỉ quét lại khi dấu hiệu văn bản thật sự thay đổi. Không poll 2,5 giây,
    // không chạy 3 lần sau mỗi click và bỏ qua mọi mutation do chính widget tạo ra.
    let detectionTimer = null;
    let lastQuickKey = '';
    const quickValue = (selectors) => {
      for (const sel of selectors) {
        const el = document.querySelector(sel);
        const value = normalizeText(el?.value || el?.textContent || '');
        if (value) return value.slice(0, 220);
      }
      return '';
    };
    const quickKey = () => [
      location.pathname, location.hash,
      quickValue(['#idVB','#hide_docid','#txt_idedit']),
      quickValue(['#txt_so','#hide_sokyhieu','input[id^="vbdi_sokyhieu_"]']),
      quickValue(['#txt_trich_yeu','#TRICH_YEU']),
      normalizeText(document.querySelector('#thongtinvb div.download')?.textContent || '').slice(0, 180)
    ].join('|');
    const scheduleDetection = (delay = 150, force = false) => {
      clearTimeout(detectionTimer);
      detectionTimer = setTimeout(() => {
        if (document.hidden || state.busy) return;
        const key = quickKey();
        if (!force && key === lastQuickKey) return;
        lastQuickKey = key;
        updateDetection();
      }, delay);
    };
    const ownHost = () => document.getElementById(HOST_ID);
    const mutationOutsideWidget = (mutations) => {
      const host = ownHost();
      const selector='#div_thongtin_chitiet,#modal_detail_doc_popup,#rightContentDLK,#idVB,#hide_docid,#txt_idedit,#txt_trich_yeu,#TRICH_YEU,#txt_so,#hide_sokyhieu,#thongtinvb,#btn_xuly,#btn_vdi_savedoc,#btn_action_publish';
      const relevant=n=>{
        if(!(n instanceof Element))return false;
        if(host&&(n===host||host.contains(n)))return false;
        try{return n.matches(selector)||Boolean(n.querySelector(selector))||Boolean(n.closest('#div_thongtin_chitiet,#modal_detail_doc_popup,#rightContentDLK,#thongtinvb'));}catch(_){return false;}
      };
      for (const m of mutations) {
        if (host && (m.target === host || host.contains(m.target))) continue;
        if(relevant(m.target))return true;
        for(const n of m.addedNodes||[])if(relevant(n))return true;
        for(const n of m.removedNodes||[])if(relevant(n))return true;
      }
      return false;
    };
    const observer = new MutationObserver((mutations) => {
      if (mutationOutsideWidget(mutations)) scheduleDetection(160, false);
    });
    if (document.body) observer.observe(document.body, { childList: true, subtree: true });
    document.addEventListener('visibilitychange',()=>{ if(!document.hidden) scheduleDetection(80, true); });
    document.addEventListener('click',(ev)=>{
      const host = ownHost();
      const target = ev.target instanceof Element ? ev.target : null;
      if (!target || (host && (target === host || host.contains(target)))) return;
      // Chỉ một lần cập nhật nhẹ sau thao tác iOffice; quickKey sẽ chặn quét nếu vẫn cùng văn bản.
      scheduleDetection(180, false);
    },true);
  }

  init();

  chrome.runtime.onMessage.addListener((m, sender, reply) => {
    if(m?.type==='IOFFICE_UPDATE_LOCK') {
      if(state.busy) { reply({ok:false}); return; }
      state.updateLocked=true;
      reply({ok:true});
    }
    if(m?.type==='IOFFICE_UPDATE_UNLOCK') { state.updateLocked=false; reply({ok:true}); }
  });
})();
