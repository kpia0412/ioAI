importScripts('providers.js', 'core.js');

const CATALOG = globalThis.IOFFICE_PROVIDER_CATALOG;
const PROVIDER_IDS = Object.keys(CATALOG);

function defaultProviderConfigs() {
  const out = {};
  for (const [id, p] of Object.entries(CATALOG)) {
    out[id] = {
      apiKey: '',
      model: p.defaultModel || '',
      baseUrl: p.baseUrl || '',
      authMode: 'bearer',
      customHeaderName: '',
      customHeaderValue: '',
      deployment: '',
      apiVersion: '2025-04-01-preview'
    };
  }
  return out;
}

const DEFAULT_SETTINGS = {
  providerOrder: ['gemini', 'openai', 'anthropic', 'none'],
  retriesPerProvider: 1,
  requestTimeoutMs: 45000,
  fallbackRules: false,
  providerConfigs: defaultProviderConfigs(),
  webHandoffTarget: 'gemini',
  webHandoffEnabled: true,
  webHandoffAutoSend: true,
  webHandoffOpenActive: true,
  webHandoffKeepTab: true,
  webGeminiAutoClose: false,
  webGeminiReuseTab: true,
  webGeminiWorkerWindow: false,
  analysisMode: 'gemini-web',
  fallbackAnalysisMode: 'chatgpt-web',
  iofficeAssistantEnabled: true,
  webGeminiTimeoutMs: 150000,
  webGeminiMaxTurns: 3,
  webGeminiForeground: false,
  webGeminiFirstForeground: true,
  userRole: 'leader',
  readerMode: 'primary',
  readerConcurrency: 0, readerIncludeRelated: false, readerDeduplicateContent: true, readerScanEnabled: false, readerTimeoutMs: 5000, readerMaxFileSizeMb: 10, aiRequireCompleteFiles: true,
  trackerEnabled: false, trackerApiUrl: '', trackerToken: '', trackerReminderDays: 3,
  clerkIncomingMainRecipient: '', clerkIncomingCoordRecipients: [], clerkIncomingViewRecipients: [],
  clerkIncomingMainRecipientId: '', clerkIncomingCoordRecipientIds: [], clerkIncomingViewRecipientIds: [],
  clerkAutoApplyIncoming: false, clerkAutoSendIncoming: false, clerkRecipientDirectory: [],
  chiefDefaultViewRecipientIds: []
};

const ROUTING_SCHEMA = {
  type: 'object',
  properties: {
    workflow: { type: 'string' },
    actionRequired: { type: 'boolean' },
    mainUnit: { type: 'string' },
    coordinationUnits: { type: 'array', items: { type: 'string' } },
    viewUnits: { type: 'array', items: { type: 'string' } },
    instruction: { type: 'string' },
    tasks: { type: 'array', items: { type:'object', properties:{ task:{type:'string'}, deadline:{type:'string'}, deadlineText:{type:'string'}, deadlineEvidence:{type:'string'}, deadlineSource:{type:'string'}, responsibleUnit:{type:'string'}, scope:{type:'string'}, trackRecommended:{type:'boolean'} }, required:['task','deadline','deadlineText','deadlineEvidence','deadlineSource','responsibleUnit'] } },
    taskScope: { type:'string' },
    trackRecommended: { type:'boolean' },
    trackingReason: { type:'string' },
    recipientNames: { type: 'array', items: { type: 'string' } },
    reviewSummary: { type: 'string' },
    reviewIssues: { type: 'array', items: { type:'object', properties:{ severity:{type:'string'}, category:{type:'string'}, detail:{type:'string'}, evidence:{type:'string'} }, required:['severity','category','detail','evidence'] } },
    reason: { type: 'string' },
    confidence: { type: 'number' },
    requiresReview: { type: 'boolean' },
    signals: { type: 'array', items: { type: 'string' } }
  },
  required: ['mainUnit','coordinationUnits','viewUnits','instruction','reason','confidence','requiresReview','signals']
};

let defaultRoutingRulesCache = null;

function deepMerge(base, extra) {
  if (!extra || typeof extra !== 'object' || Array.isArray(extra)) return base;
  const out = { ...base };
  for (const [k, v] of Object.entries(extra)) {
    if (v && typeof v === 'object' && !Array.isArray(v) && base?.[k] && typeof base[k] === 'object' && !Array.isArray(base[k])) {
      out[k] = deepMerge(base[k], v);
    } else {
      out[k] = v;
    }
  }
  return out;
}

async function migrateSettings() {
  const raw = await chrome.storage.local.get(null);
  const oldCache=Object.keys(raw).filter(k=>k.startsWith('ioffice_reader_cache_'));
  if(oldCache.length)await chrome.storage.local.remove(oldCache);
  const base = DEFAULT_SETTINGS;
  let configs = deepMerge(defaultProviderConfigs(), raw.providerConfigs || {});

  // Migrate v0.5 keys if present.
  if (raw.geminiApiKey) configs.gemini.apiKey = raw.geminiApiKey;
  if (raw.geminiModel) configs.gemini.model = raw.geminiModel;
  if (raw.openaiApiKey) configs.openai.apiKey = raw.openaiApiKey;
  if (raw.openaiModel) configs.openai.model = raw.openaiModel;
  if (raw.anthropicApiKey) configs.anthropic.apiKey = raw.anthropicApiKey;
  if (raw.anthropicModel) configs.anthropic.model = raw.anthropicModel;
  if (raw.gatewayUrl) configs.gateway.baseUrl = raw.gatewayUrl;

  let order = raw.providerOrder;
  if (!Array.isArray(order)) {
    order = [raw.primaryProvider || 'gemini', raw.fallbackProvider1 || 'openai', raw.fallbackProvider2 || 'anthropic', 'none'];
  }
  order = [...order, 'none', 'none', 'none', 'none'].slice(0, 4);

  await chrome.storage.local.set({
    providerOrder: order,
    retriesPerProvider: Number.isFinite(Number(raw.retriesPerProvider)) ? Number(raw.retriesPerProvider) : base.retriesPerProvider,
    requestTimeoutMs: Number.isFinite(Number(raw.requestTimeoutMs)) ? Number(raw.requestTimeoutMs) : base.requestTimeoutMs,
    fallbackRules: false,
    providerConfigs: configs,
    webHandoffTarget: raw.webHandoffTarget || 'gemini',
    webHandoffEnabled: raw.webHandoffEnabled !== false,
    webHandoffAutoSend: raw.webHandoffAutoSend !== false,
    webHandoffOpenActive: raw.webHandoffOpenActive !== false,
    webHandoffKeepTab: raw.webHandoffKeepTab !== false,
    webGeminiAutoClose: false,
    webGeminiReuseTab: true,
    webGeminiWorkerWindow: false,
    analysisMode: ['gemini-web','chatgpt-web','api'].includes(raw.analysisMode) ? raw.analysisMode : 'gemini-web',
    fallbackAnalysisMode: ['gemini-web','chatgpt-web','api','none'].includes(raw.fallbackAnalysisMode) ? raw.fallbackAnalysisMode : 'chatgpt-web',
    iofficeAssistantEnabled: raw.iofficeAssistantEnabled !== false,
    webGeminiTimeoutMs: Number.isFinite(Number(raw.webGeminiTimeoutMs)) ? Number(raw.webGeminiTimeoutMs) : 150000,
    webGeminiMaxTurns: Math.max(1, Math.min(10, Number(raw.webGeminiMaxTurns) || 3)),
    // Giữ lựa chọn người dùng; mặc định false ở DEFAULT_SETTINGS để Gemini chạy nền nhanh như v0.8.
    webGeminiForeground: raw.webGeminiForeground === true,
    webGeminiFirstForeground: raw.webGeminiFirstForeground !== false,
    readerConcurrency: Number.isFinite(Number(raw.readerConcurrency)) ? Math.max(0, Math.min(6, Number(raw.readerConcurrency))) : 0,
    userRole: ['leader','chief','clerk'].includes(raw.userRole) ? raw.userRole : 'leader',
    readerMode: ['primary','all'].includes(raw.readerMode) ? raw.readerMode : 'primary',
    readerTimeoutMs: !Number.isFinite(Number(raw.readerTimeoutMs)) ? 5000 : Math.max(2000, Math.min(60000, Number(raw.readerTimeoutMs))),
    // Chỉ bật Văn bản liên quan khi người dùng chủ động chọn trong Cài đặt.
    readerIncludeRelated: raw.readerIncludeRelated === true,
    readerDeduplicateContent: raw.readerDeduplicateContent !== false,
    readerMaxFileSizeMb: Number.isFinite(Number(raw.readerMaxFileSizeMb)) ? Math.max(1, Math.min(50, Number(raw.readerMaxFileSizeMb))) : 10,
    readerScanEnabled: false,
    aiRequireCompleteFiles: raw.aiRequireCompleteFiles !== false,
    trackerEnabled: raw.trackerEnabled === true,
    trackerApiUrl: String(raw.trackerApiUrl || ''),
    trackerToken: String(raw.trackerToken || ''),
    trackerReminderDays: Math.max(0, Math.min(30, Number(raw.trackerReminderDays) || 3)),
    clerkIncomingMainRecipient: String(raw.clerkIncomingMainRecipient || ''),
    clerkIncomingCoordRecipients: Array.isArray(raw.clerkIncomingCoordRecipients) ? raw.clerkIncomingCoordRecipients.map(String) : [],
    clerkIncomingViewRecipients: Array.isArray(raw.clerkIncomingViewRecipients) ? raw.clerkIncomingViewRecipients.map(String) : [],
    clerkIncomingMainRecipientId: String(raw.clerkIncomingMainRecipientId || ''),
    clerkIncomingCoordRecipientIds: Array.isArray(raw.clerkIncomingCoordRecipientIds) ? raw.clerkIncomingCoordRecipientIds.map(String) : [],
    clerkIncomingViewRecipientIds: Array.isArray(raw.clerkIncomingViewRecipientIds) ? raw.clerkIncomingViewRecipientIds.map(String) : [],
    clerkAutoApplyIncoming: raw.clerkAutoApplyIncoming === true,
    clerkAutoSendIncoming: raw.clerkAutoSendIncoming === true,
    clerkRecipientDirectory: Array.isArray(raw.clerkRecipientDirectory) ? raw.clerkRecipientDirectory : [],
    chiefDefaultViewRecipientIds: Array.isArray(raw.chiefDefaultViewRecipientIds) ? raw.chiefDefaultViewRecipientIds.map(String).slice(0,3) : []
  });
  await chrome.storage.local.remove(['geminiApiKey','openaiApiKey','anthropicApiKey','geminiModel','openaiModel','anthropicModel','gatewayUrl','iofficeGeminiReuseState']);
}

async function syncAssistantAction(enabled = null) {
  let isEnabled = enabled;
  if (isEnabled == null) {
    const raw = await chrome.storage.local.get({ iofficeAssistantEnabled: true });
    isEnabled = raw.iofficeAssistantEnabled !== false;
  }
  await Promise.allSettled([
    chrome.action.setBadgeText({ text: isEnabled ? 'ON' : 'OFF' }),
    chrome.action.setBadgeBackgroundColor({ color: isEnabled ? '#087d77' : '#64748b' }),
    chrome.action.setTitle({ title: isEnabled
      ? 'iOffice AI đang bật · bấm để tắt và tự tải lại iOffice'
      : 'iOffice AI đang tắt · bấm để bật và tự tải lại iOffice' })
  ]);
}

async function reloadIofficeTabs(preferredTab = null) {
  const matches = /^https:\/\/ioffice\.vnptdaklak\.vn\/qlvbdh_dlk\//i;
  const ids = new Set();
  if (preferredTab?.id != null && matches.test(String(preferredTab.url || ''))) ids.add(preferredTab.id);
  try {
    const tabs = await chrome.tabs.query({ url: 'https://ioffice.vnptdaklak.vn/qlvbdh_dlk/*' });
    for (const tab of tabs || []) if (tab?.id != null) ids.add(tab.id);
  } catch (_) {}
  await Promise.allSettled([...ids].map((id) => chrome.tabs.reload(id)));
}

chrome.runtime.onInstalled.addListener(() => {
  migrateSettings().then(() => syncAssistantAction()).catch(console.error);
});
chrome.runtime.onStartup.addListener(() => {
  cleanupJobs().catch(console.error);
  syncAssistantAction().catch(console.error);
  flushTrackerPending().catch(() => {});
});
chrome.action.onClicked.addListener(async (tab) => {
  try {
    const raw = await chrome.storage.local.get({ iofficeAssistantEnabled: true });
    const next = raw.iofficeAssistantEnabled === false;
    await chrome.storage.local.set({ iofficeAssistantEnabled: next });
    await syncAssistantAction(next);
    await reloadIofficeTabs(tab);
  } catch (error) {
    console.error('Không bật/tắt được iOffice AI:', error);
  }
});
chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName === 'local' && changes.iofficeAssistantEnabled) {
    syncAssistantAction(changes.iofficeAssistantEnabled.newValue !== false).catch(() => {});
  }
});

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const uniq = (items) => [...new Set((items || []).filter(Boolean))];
const safeNumber = (v, fallback) => Number.isFinite(Number(v)) ? Number(v) : fallback;
const trimSlash = (s) => String(s || '').replace(/\/+$/, '');

async function getSettings() {
  const raw = await chrome.storage.local.get(DEFAULT_SETTINGS);
  return {
    ...DEFAULT_SETTINGS,
    ...raw,
    providerConfigs: deepMerge(defaultProviderConfigs(), raw.providerConfigs || {})
  };
}

async function getDefaultRoutingRules() {
  if (defaultRoutingRulesCache) return defaultRoutingRulesCache;
  const response = await fetch(chrome.runtime.getURL('routing-rules.json'));
  if (!response.ok) throw new Error(`Không đọc được routing-rules.json (HTTP ${response.status})`);
  defaultRoutingRulesCache = await response.json();
  return defaultRoutingRulesCache;
}

async function getRoutingRules() {
  const defaults = await getDefaultRoutingRules();
  const raw = await chrome.storage.local.get({ routingRulesCustom: null });
  const custom = raw.routingRulesCustom;
  if (!custom || typeof custom !== 'object' || !Array.isArray(custom.units) || !Array.isArray(custom.rules)) return defaults;
  return { ...defaults, ...custom, policy: { ...(defaults.policy || {}), ...(custom.policy || {}) }, legalBasis: Array.isArray(custom.legalBasis) ? custom.legalBasis : defaults.legalBasis };
}

function buildPrompt(payload, requestId='') { return IOfficeCore.prompt(payload, requestId); }

function extractJson(text) {
  let value = String(text || '').trim().replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/i, '').trim();
  try { return JSON.parse(value); } catch (_) {}
  const start = value.indexOf('{'), end = value.lastIndexOf('}');
  if (start >= 0 && end > start) {
    try { return JSON.parse(value.slice(start, end + 1)); } catch (_) {}
  }
  throw new Error('AI không trả JSON hợp lệ.');
}

function validateAndClean(result, payload, meta) {
  const unitMap = new Map((payload.availableUnits || []).map((u) => [u.id, u.name]));
  const allowed = new Set(unitMap.keys());
  if (!IOfficeCore.routingObject(result)) throw new Error('AI trả thiếu trường hoặc sai kiểu JSON.');
  const rawMain = result.mainUnit == null || result.mainUnit === '' ? null : String(result.mainUnit);
  if (rawMain && !allowed.has(rawMain)) throw new Error(`AI trả XLC không hợp lệ: ${rawMain}`);
  if (!Array.isArray(result.coordinationUnits) || !Array.isArray(result.viewUnits)) throw new Error('AI trả sai cấu trúc PH/Xem.');
  if ([...result.coordinationUnits,...result.viewUnits].some(id => !allowed.has(id))) throw new Error('AI trả mã đơn vị PH/Xem không hợp lệ.');
  let mainUnit = rawMain;
  let coordinationUnits = uniq(result.coordinationUnits).filter((id) => allowed.has(id) && id !== mainUnit);
  let viewUnits = uniq(result.viewUnits).filter((id) => allowed.has(id) && id !== mainUnit && !coordinationUnits.includes(id));
  const incomingWorkflow = ['leader-incoming','chief-incoming'].includes(String(payload.workflow||''));
  if (incomingWorkflow) {
    viewUnits = [];
    if (!mainUnit && coordinationUnits.length) {
      mainUnit = coordinationUnits[0];
      coordinationUnits = coordinationUnits.slice(1);
    }
  }
  const rawConfidence = Number(result.confidence);
  if (!Number.isFinite(rawConfidence)) throw new Error('AI không trả confidence hợp lệ.');
  if (typeof result.requiresReview !== 'boolean') throw new Error('AI không trả requiresReview hợp lệ.');
  const incomplete = payload.context?.documentBundle?.requiresReviewForUnreadable === true;
  const repaired = coordinationUnits.length !== result.coordinationUnits.length || viewUnits.length !== result.viewUnits.length;
  const confidence = Math.min(incomplete ? 0.69 : 1, Math.max(0, rawConfidence));
  const cleanTask = (task, index) => {
    task = task && typeof task === 'object' ? task : {};
    const unit = typeof task.responsibleUnit === 'string' && allowed.has(task.responsibleUnit) ? task.responsibleUnit : (mainUnit || null);
    const deadline = /^\d{4}-\d{2}-\d{2}$/.test(String(task.deadline || '')) ? String(task.deadline) : null;
    return {
      index: index + 1,
      task: String(task.task || '').trim(),
      deadline,
      deadlineText: String(task.deadlineText || '').trim(),
      deadlineEvidence: String(task.deadlineEvidence || '').trim(),
      deadlineSource: String(task.deadlineSource || (deadline ? 'document' : 'none')).trim(),
      responsibleUnit: unit
    };
  };
  const tasks = (Array.isArray(result.tasks) ? result.tasks : []).map(cleanTask).filter(t => t.task || t.deadline);
  const actionRequired = typeof result.actionRequired === 'boolean' ? result.actionRequired : Boolean(mainUnit || tasks.length);
  const recipientNames = uniq((Array.isArray(result.recipientNames) ? result.recipientNames : []).map(x => String(x || '').trim())).slice(0, 80);
  const reviewIssues = (Array.isArray(result.reviewIssues) ? result.reviewIssues : []).slice(0, 30).map(x => ({
    severity: ['high','medium','low'].includes(String(x?.severity || '').toLowerCase()) ? String(x.severity).toLowerCase() : 'low',
    category: String(x?.category || '').trim(), detail: String(x?.detail || '').trim(), evidence: String(x?.evidence || '').trim()
  })).filter(x => x.detail);
  return {
    workflow: String(result.workflow || payload.workflow || 'leader-incoming'),
    actionRequired,
    mainUnit, coordinationUnits, viewUnits,
    instruction: String(result.instruction || '').trim(),
    tasks,
    recipientNames,
    reviewSummary: String(result.reviewSummary || '').trim(),
    reviewIssues,
    reason: String(result.reason || '').trim(),
    confidence,
    requiresReview: result.requiresReview || incomplete || repaired || (incomingWorkflow && !mainUnit),
    signals: uniq([...(repaired ? ['Đã loại đơn vị trùng vai trò; cần kiểm tra lại.'] : []), ...(Array.isArray(result.signals) ? result.signals.map(String) : [])]).slice(0, 8),
    provider: meta.provider,
    providerLabel: meta.providerLabel,
    model: meta.model,
    primaryProvider: meta.primaryProvider,
    fallbackUsed: meta.provider !== meta.primaryProvider,
    attemptCount: meta.attemptCount,
    triedProviders: meta.triedProviders,
    promptChars: meta.promptChars,
    usageMetadata: meta.usageMetadata || null,
    source: `ai-${meta.provider}`
  };
}

function classifyError(status, message = '') {
  const text = String(message || '').toLowerCase();
  return {
    retryable: [408,409,425,429,500,502,503,504].includes(status) || /high demand|temporar|unavailable|resource exhausted|rate limit|overload|timeout|deadline|try again/.test(text),
    auth: [401,403].includes(status) || /api key|invalid key|permission denied|unauth|forbidden|credential/.test(text),
    model: status === 404 || /model.*not found|unknown model|does not exist|not supported/.test(text)
  };
}

async function fetchJson(url, init, timeoutMs, parentSignal) {
  const u=new URL(url);
  if(!await chrome.permissions.contains({origins:[u.protocol+'//'+u.hostname+'/*']}))throw new Error('Mở Cấu hình, cấp quyền cho máy chủ API rồi thử lại.');
  const controller = new AbortController();
  const abort=()=>controller.abort();
  if(parentSignal?.aborted)throw new Error('Đã dừng phân tích.');
  parentSignal?.addEventListener('abort',abort,{once:true});
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(url, { ...init, signal: controller.signal });
    const text = await response.text();
    let data = {};
    try { data = text ? JSON.parse(text) : {}; } catch (_) { data = { raw: text }; }
    if (!response.ok) {
      const message = data?.error?.message || data?.message || data?.detail || data?.raw || `HTTP ${response.status}`;
      const error = new Error(String(message).slice(0, 1200));
      error.httpStatus = response.status;
      error.kind = classifyError(response.status, message);
      throw error;
    }
    return data;
  } catch (error) {
    if(parentSignal?.aborted)throw new Error('Đã dừng phân tích.');
    if (error?.name === 'AbortError') {
      const timeout = new Error(`Timeout sau ${Math.round(timeoutMs / 1000)} giây.`);
      timeout.kind = { retryable: true, auth: false, model: false };
      throw timeout;
    }
    if (!error.kind) error.kind = { retryable: true, auth: false, model: false };
    throw error;
  } finally { clearTimeout(timer); parentSignal?.removeEventListener('abort',abort); }
}

function authHeaders(providerId, cfg) {
  const headers = { 'Content-Type': 'application/json' };
  if (providerId === 'anthropic') return headers;
  if (cfg.customHeaderName && cfg.customHeaderValue) headers[cfg.customHeaderName] = cfg.customHeaderValue;
  if (cfg.authMode === 'none' || !cfg.apiKey) return headers;
  if (cfg.authMode === 'x-api-key') headers['x-api-key'] = cfg.apiKey;
  else headers.Authorization = `Bearer ${cfg.apiKey}`;
  return headers;
}

async function callGemini(prompt, cfg, timeout, payload = null) {
  if (!cfg.apiKey) throw new Error('Chưa cấu hình API key Gemini.');
  if (!cfg.model) throw new Error('Chưa chọn model Gemini.');
  const scans = extractScanAttachments(payload || {});
  const parts = [{ text: prompt }];
  for (const file of scans) {
    parts.push({ inlineData: { mimeType: file.mimeType || 'application/pdf', data: file.base64 } });
  }
  const data = await fetchJson(`${trimSlash(cfg.baseUrl || CATALOG.gemini.baseUrl)}/models/${encodeURIComponent(cfg.model)}:generateContent`, {
    method: 'POST', headers: { 'Content-Type': 'application/json', 'x-goog-api-key': cfg.apiKey },
    body: JSON.stringify({ contents: [{ role: 'user', parts }], generationConfig: { responseFormat: { text: { mimeType: 'application/json', schema: ROUTING_SCHEMA } } } })
  }, timeout, cfg._signal);
  const text = data?.candidates?.[0]?.content?.parts?.map((p) => p.text || '').join('') || '';
  if (!text) throw new Error('Gemini không trả nội dung.');
  return { parsed: extractJson(text), model: cfg.model, usageMetadata: data?.usageMetadata || null };
}

async function callAnthropic(prompt, cfg, timeout) {
  if (!cfg.apiKey) throw new Error('Chưa cấu hình API key Anthropic.');
  if (!cfg.model) throw new Error('Chưa chọn model Anthropic.');
  const data = await fetchJson(`${trimSlash(cfg.baseUrl || CATALOG.anthropic.baseUrl)}/messages`, {
    method: 'POST', headers: { 'Content-Type': 'application/json', 'x-api-key': cfg.apiKey, 'anthropic-version': '2023-06-01' },
    body: JSON.stringify({ model: cfg.model, max_tokens: 1600, messages: [{ role: 'user', content: prompt }] })
  }, timeout, cfg._signal);
  const text = (data?.content || []).filter((x) => x?.type === 'text').map((x) => x.text || '').join('');
  if (!text) throw new Error('Anthropic không trả nội dung text.');
  return { parsed: extractJson(text), model: cfg.model, usageMetadata: data?.usage || null };
}

async function callOpenAIResponses(prompt, cfg, timeout) {
  if (!cfg.apiKey) throw new Error('Chưa cấu hình API key.');
  if (!cfg.model) throw new Error('Chưa chọn model.');
  const data = await fetchJson(`${trimSlash(cfg.baseUrl)}/responses`, {
    method: 'POST', headers: authHeaders('openai', cfg), body: JSON.stringify({ model: cfg.model, input: prompt })
  }, timeout, cfg._signal);
  let text = data?.output_text || '';
  if (!text && Array.isArray(data?.output)) text = data.output.flatMap((i) => i?.content || []).map((p) => p?.text || '').join('');
  if (!text) throw new Error('API không trả nội dung text.');
  return { parsed: extractJson(text), model: cfg.model, usageMetadata: data?.usage || null };
}

async function callOpenAIChat(providerId, prompt, cfg, timeout) {
  if (CATALOG[providerId]?.needsKey && !cfg.apiKey) throw new Error('Chưa cấu hình API key.');
  if (!cfg.model) throw new Error('Chưa chọn model.');
  if (!cfg.baseUrl) throw new Error('Chưa cấu hình Base URL.');
  const data = await fetchJson(`${trimSlash(cfg.baseUrl)}/chat/completions`, {
    method: 'POST', headers: authHeaders(providerId, cfg),
    body: JSON.stringify({ model: cfg.model, messages: [{ role: 'user', content: prompt }] })
  }, timeout, cfg._signal);
  const text = data?.choices?.[0]?.message?.content || data?.choices?.[0]?.text || '';
  if (!text) throw new Error('API không trả nội dung text.');
  return { parsed: extractJson(text), model: cfg.model, usageMetadata: data?.usage || null };
}

async function callOllama(prompt, cfg, timeout) {
  if (!cfg.model) throw new Error('Chưa chọn model Ollama.');
  const base = trimSlash(cfg.baseUrl || CATALOG.ollama.baseUrl);
  const data = await fetchJson(`${base}/api/chat`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ model: cfg.model, stream: false, messages: [{ role: 'user', content: prompt }] })
  }, timeout, cfg._signal);
  const text = data?.message?.content || data?.response || '';
  if (!text) throw new Error('Ollama không trả nội dung.');
  return { parsed: extractJson(text), model: cfg.model, usageMetadata: null };
}

async function callAzure(prompt, cfg, timeout) {
  if (!cfg.apiKey) throw new Error('Chưa cấu hình Azure API key.');
  if (!cfg.baseUrl || !cfg.deployment) throw new Error('Azure cần Endpoint và Deployment.');
  const apiVersion = encodeURIComponent(cfg.apiVersion || '2025-04-01-preview');
  const url = `${trimSlash(cfg.baseUrl)}/openai/deployments/${encodeURIComponent(cfg.deployment)}/chat/completions?api-version=${apiVersion}`;
  const data = await fetchJson(url, {
    method: 'POST', headers: { 'Content-Type': 'application/json', 'api-key': cfg.apiKey },
    body: JSON.stringify({ messages: [{ role: 'user', content: prompt }] })
  }, timeout, cfg._signal);
  const text = data?.choices?.[0]?.message?.content || '';
  if (!text) throw new Error('Azure OpenAI không trả nội dung.');
  return { parsed: extractJson(text), model: cfg.deployment, usageMetadata: data?.usage || null };
}

async function callGateway(payload, cfg, timeout) {
  if (!cfg.baseUrl) throw new Error('Chưa cấu hình Local/Internal Gateway.');
  const data = await fetchJson(cfg.baseUrl, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) }, Math.max(timeout, 90000), cfg._signal);
  return { parsed: data, model: data?.model || 'gateway', usageMetadata: data?.usageMetadata || null, alreadyValidated: true };
}

async function callProvider(providerId, prompt, payload, cfg, timeout) {
  const type = CATALOG[providerId]?.type;
  if (type === 'gemini') return callGemini(prompt, cfg, timeout, payload);
  if (type === 'anthropic') return callAnthropic(prompt, cfg, timeout);
  if (type === 'openai-responses') return callOpenAIResponses(prompt, cfg, timeout);
  if (type === 'openai-chat') return callOpenAIChat(providerId, prompt, cfg, timeout);
  if (type === 'ollama') return callOllama(prompt, cfg, timeout);
  if (type === 'azure-openai') return callAzure(prompt, cfg, timeout);
  if (type === 'gateway') return callGateway(payload, cfg, timeout);
  throw new Error(`Chưa hỗ trợ provider ${providerId}`);
}

function providerConfigured(id, cfg) {
  const p = CATALOG[id];
  if (!p) return false;
  if (p.type === 'gateway') return Boolean(cfg.baseUrl);
  if (p.type === 'azure-openai') return Boolean(cfg.apiKey && cfg.baseUrl && cfg.deployment);
  if (p.type === 'ollama' || id === 'lmstudio') return Boolean(cfg.baseUrl && cfg.model);
  if (id === 'custom') return Boolean(cfg.baseUrl && cfg.model && (!p.needsKey || cfg.apiKey || cfg.authMode === 'none'));
  return Boolean(cfg.model && (!p.needsKey || cfg.apiKey));
}

function backoffMs(i) { return [900, 2200, 4500][Math.min(i, 2)]; }

const apiRequests=new Map();
async function analyze(payload, signal) {
  const settings = await getSettings();
  const retries = Math.max(0, Math.min(2, safeNumber(settings.retriesPerProvider, 1)));
  const timeout = Math.max(10000, Math.min(120000, safeNumber(settings.requestTimeoutMs, 45000)));
  const order = uniq(settings.providerOrder || []).filter((id) => id && id !== 'none' && CATALOG[id]);
  if (!order.length) throw new Error('Chưa chọn nhà cung cấp AI trong Cấu hình.');
  const prompt = buildPrompt(payload);
  const errors = [], triedProviders = [];
  let attemptCount = 0;

  for (const providerId of order) {
    if(signal?.aborted)throw new Error('Đã dừng phân tích.');
    const cfg = {...(settings.providerConfigs?.[providerId] || {}), _signal:signal};
    if(extractScanAttachments(payload).length && !['gemini','gateway'].includes(CATALOG[providerId]?.type)){errors.push(CATALOG[providerId].label+': không hỗ trợ PDF scan trong phiên bản này');continue;}
    if (!providerConfigured(providerId, cfg)) {
      errors.push(`${CATALOG[providerId].label}: chưa cấu hình đủ key/model/endpoint`);
      continue;
    }
    triedProviders.push(providerId);
    for (let attempt = 1; attempt <= retries + 1; attempt++) {
      if(signal?.aborted)throw new Error('Đã dừng phân tích.');
      attemptCount++;
      try {
        const response = await callProvider(providerId, prompt, payload, cfg, timeout);
        return validateAndClean(response.parsed, payload, { provider: providerId, providerLabel: CATALOG[providerId].label, model: response.model, primaryProvider: order[0], attemptCount, triedProviders: [...triedProviders], promptChars: prompt.length, usageMetadata: response.usageMetadata });
      } catch (error) {
        if(signal?.aborted)throw new Error('Đã dừng phân tích.');
        errors.push(`${CATALOG[providerId].label}: ${error.message}`);
        const retryable = error?.kind?.retryable !== false && !error?.kind?.auth && !error?.kind?.model;
        if (retryable && attempt <= retries) { await sleep(backoffMs(attempt - 1)); continue; }
        break;
      }
    }
  }
  throw new Error(`Các AI đã cấu hình đều thất bại. ${errors.slice(-8).join(' | ')}`);
}



function tabMessage(tabId, message) {
  return new Promise((resolve, reject) => {
    chrome.tabs.sendMessage(tabId, message, (response) => {
      if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
      else resolve(response);
    });
  });
}

async function waitForWebBridge(tabId, timeoutMs = 45000, signal) {
  const started = Date.now();
  let lastError = null;
  while (Date.now() - started < timeoutMs) {
    if(signal?.aborted)throw new Error('Đã dừng phân tích.');
    try {
      const response = await tabMessage(tabId, { type: 'IOFFICE_WEB_BRIDGE_PING' });
      if (response?.ok && response.version === IOfficeCore.VERSION) return response;
    } catch (error) { lastError = error; }
    await sleep(180);
  }
  throw new Error(`Không kết nối được Web Bridge${lastError ? `: ${lastError.message}` : ''}`);
}

const handoffs=new Map();
async function startWebHandoff(target, payload, sourceTabId) {
  const settings = await getSettings();
  if (settings.webHandoffEnabled === false) throw new Error('Web Bridge đang tắt trong Cấu hình.');
  if(extractScanAttachments(payload).length)throw new Error('Phiên này có PDF scan. Hãy chọn Gemini Web hoặc Gemini API để gửi được tệp gốc.');
  const webTarget = target === 'gemini' ? 'gemini' : 'chatgpt';
  const url = webTarget === 'gemini' ? 'https://gemini.google.com/app' : 'https://chatgpt.com/';
  const prompt = buildPrompt(payload);
  handoffs.get(sourceTabId)?.controller.abort();
  const controller=new AbortController(),jobId=createWebJobId();
  const owned={controller,jobId,tabId:null};handoffs.set(sourceTabId,owned);
  const tab = await chrome.tabs.create({ url, active: settings.webHandoffOpenActive !== false });owned.tabId=tab.id;
  try {
    await waitForWebBridge(tab.id, 30000,controller.signal);
    if(controller.signal.aborted)throw new Error('Đã dừng phân tích.');
    const result = await tabMessage(tab.id, {
      type: 'IOFFICE_WEB_BRIDGE_SEND',
      jobId,
      target: webTarget,
      prompt,
      autoSend: settings.webHandoffAutoSend !== false
    });
    if (!result?.ok) throw new Error(result?.error || 'Không điền được câu hỏi vào Web AI.');

    return {
      ok: true,
      target: webTarget,
      tabId: tab.id,
      autoSent: Boolean(result.autoSent),
      promptChars: prompt.length,
      message: result.autoSent ? 'Đã mở tab và gửi câu hỏi.' : 'Đã mở tab và điền câu hỏi; hãy bấm Gửi trên trang AI.'
    };
  } catch (error) {
    try { await chrome.tabs.update(tab.id, { active: true }); } catch (_) {}
    throw error;
  } finally {if(handoffs.get(sourceTabId)===owned)handoffs.delete(sourceTabId);}
}


const WEB_JOB_PREFIX='iofficeGeminiJob:';
const WEB_TAB_PREFIX='iofficeGeminiTab:';
const volatileJobAttachments=new Map();
const webJobKey=id=>WEB_JOB_PREFIX+id, webTabKey=id=>WEB_TAB_PREFIX+id;
const terminal=job=>!job || ['done','error','cancelled'].includes(job.status);
const locks=new Map();
let warmFlight=null,startFlight=null;
const createWebJobId=()=>`gweb_${crypto.randomUUID()}`;
async function serial(key,fn){const before=locks.get(key)||Promise.resolve();const p=before.catch(()=>{}).then(fn);locks.set(key,p);try{return await p;}finally{if(locks.get(key)===p)locks.delete(key);}}
function extractScanAttachments(payload){return(payload?.context?.documentBundle?.scanAttachments||[]).filter(x=>x.base64&&x.name).slice(0,3);}
function stripScanAttachmentData(payload){const b=payload.context?.documentBundle;return b?{...payload,context:{...payload.context,documentBundle:{...b,scanAttachments:(b.scanAttachments||[]).map(({base64,...meta})=>meta)}}}:payload;}
async function readWebJob(id){return(await chrome.storage.session.get(webJobKey(id)))[webJobKey(id)]||null;}
async function updateWebJob(id,patch){return serial(id,async()=>{const j=await readWebJob(id);if(terminal(j))return j;Object.assign(j,patch);await chrome.storage.session.set({[webJobKey(id)]:j});return j;});}
async function getJobForTab(id){const map=await chrome.storage.session.get(webTabKey(id));return map[webTabKey(id)]?readWebJob(map[webTabKey(id)]):null;}
async function releaseTab(job){await serial('tab:'+job.tabId,async()=>{const map=await chrome.storage.session.get(webTabKey(job.tabId));if(map[webTabKey(job.tabId)]===job.jobId)await chrome.storage.session.remove(webTabKey(job.tabId));});}
async function reuseState(){return(await chrome.storage.session.get('geminiOwnedTab')).geminiOwnedTab||null;}
async function rememberGeminiTab(tab, patch={}) {
  if(!tab?.id || !String(tab.url||'').startsWith('https://gemini.google.com/')) return;
  const prev=await reuseState();
  const same=Number(prev?.tabId)===Number(tab.id);
  await chrome.storage.session.set({geminiOwnedTab:{tabId:tab.id,turns:same?Math.max(0,Number(prev?.turns)||0):0,reset:same?!!prev?.reset:false,url:tab.url,lastUsedAt:Date.now(),...patch}});
}
async function findReusableGeminiTab(sourceTabId) {
  const saved=await reuseState();
  if(saved?.tabId){
    try{const tab=await chrome.tabs.get(saved.tabId);if(String(tab.url||'').startsWith('https://gemini.google.com/'))return tab;}catch(_){}
  }
  const tabs=await chrome.tabs.query({url:['https://gemini.google.com/*']});
  if(!tabs.length)return null;
  let source=null;try{source=sourceTabId?await chrome.tabs.get(sourceTabId):null;}catch(_){}
  const sameWindow=source?tabs.filter(t=>t.windowId===source.windowId):[];
  const pool=sameWindow.length?sameWindow:tabs;
  const tab=[...pool].sort((a,b)=>Number(b.lastAccessed||0)-Number(a.lastAccessed||0))[0];
  await rememberGeminiTab(tab);
  return tab;
}
async function putGeminiNextToSource(tab, sourceTabId) {
  if(!tab?.id || !sourceTabId)return tab;
  let source=null;try{source=await chrome.tabs.get(sourceTabId);}catch(_){return tab;}
  try{
    const desired=Math.max(0,Number(source.index||0)+1);
    if(tab.windowId!==source.windowId || tab.index!==desired)tab=await chrome.tabs.move(tab.id,{windowId:source.windowId,index:desired});
  }catch(_){}
  try{await chrome.tabs.update(tab.id,{autoDiscardable:false});}catch(_){}
  try{return await chrome.tabs.get(tab.id);}catch(_){return tab;}
}
async function pushGeminiJobEvent(job,kind,extra={}){if(!job?.sourceTabId)return;try{await tabMessage(job.sourceTabId,{type:'IOFFICE_GEMINI_JOB_EVENT',jobId:job.jobId,kind,status:job.status,phase:job.phase||'',phaseMessage:job.phaseMessage||'',elapsedMs:Date.now()-job.createdAt,...extra});}catch(_){}}
async function ensureWarmGeminiTab(sourceTabId,{foregroundLoad=false}={}){
  if(warmFlight)return warmFlight;
  warmFlight=(async()=>{
    if((await getSettings()).webHandoffEnabled===false)throw new Error('Web AI đang tắt trong Cấu hình.');
    let tab=await findReusableGeminiTab(sourceTabId);
    let reused=!!tab;
    if(tab)tab=await putGeminiNextToSource(tab,sourceTabId);
    if(!tab){
      let source;try{source=sourceTabId?await chrome.tabs.get(sourceTabId):null;}catch(_){}
      tab=await chrome.tabs.create({url:'https://gemini.google.com/app',active:foregroundLoad===true,...(source?{windowId:source.windowId,index:Math.max(0,source.index+1)}:{})});
      reused=false;
      await rememberGeminiTab(tab,{turns:0,reset:false});
    }
    try{await chrome.tabs.update(tab.id,{autoDiscardable:false});}catch(_){}
    if(foregroundLoad){try{await chrome.tabs.update(tab.id,{active:true});}catch(_){}}
    if(tab.discarded){try{await chrome.tabs.reload(tab.id);}catch(_){}}
    let ping;try{ping=await tabMessage(tab.id,{type:'IOFFICE_WEB_BRIDGE_PING'});}catch(_){}
    if(!ping?.ok || ping.version!==IOfficeCore.VERSION){
      // Chỉ reload khi bridge cũ/thiếu; không reload tab ấm ở mỗi lần phân tích.
      if(reused){try{await chrome.tabs.reload(tab.id);}catch(_){}}
      await waitForWebBridge(tab.id,reused?15000:30000);
    }
    try{tab=await chrome.tabs.get(tab.id);}catch(_){}
    await rememberGeminiTab(tab);
    return{tab,reused};
  })();
  try{return await warmFlight;}finally{warmFlight=null;}
}
async function prewarmGeminiForSession(sourceTabId){
  const settings=await getSettings();
  const key='geminiFirstForegroundDoneV21';
  let first=false;
  try{first=(await chrome.storage.session.get({[key]:false}))[key]!==true;}catch(_){first=true;}
  const foregroundLoad=settings.webGeminiFirstForeground!==false && first;
  const result=await ensureWarmGeminiTab(sourceTabId,{foregroundLoad});
  if(foregroundLoad){
    try{await chrome.storage.session.set({[key]:true});}catch(_){}
    // Tab đã được mở ra trước đủ để Chrome khởi tạo Gemini/bridge. Sau đó trả người dùng về iOffice;
    // các lần phân tích sau dùng lại tab ấm và chạy nền.
    if(settings.webGeminiForeground!==true && sourceTabId){
      try{await chrome.tabs.update(sourceTabId,{active:true});}catch(_){}
    }
  }
  return {...result,firstForeground:foregroundLoad};
}

async function cleanupJobs(){
  const all=await chrome.storage.session.get(null),remove=[];
  for(const [key,j]of Object.entries(all)){
    if(key.startsWith('cancel:')&&Date.now()-Number(j)>600000)remove.push(key);
    if(!key.startsWith(WEB_JOB_PREFIX))continue;
    if(terminal(j)&&Date.now()-(j.completedAt||j.createdAt)>600000)remove.push(key);
    else if(!terminal(j)&&Date.now()>j.deadline)await cancelGeminiWebJob(j.jobId,'Phiên Gemini đã quá thời gian chờ.');
  }
  if(remove.length)await chrome.storage.session.remove(remove);
}
async function startGeminiWebAutomation(payload,sourceTabId,requestId){
  if(startFlight)throw new Error('Đang chuẩn bị một phiên Gemini. Vui lòng đợi.');
  startFlight=true;
  try{
    await cleanupJobs();const settings=await getSettings();
    if(settings.webHandoffEnabled===false)throw new Error('Web AI đang tắt trong Cấu hình.');
    if(!/^gweb_[a-zA-Z0-9_-]{8,80}$/.test(requestId||''))throw new Error('Mã phiên không hợp lệ.');
    const jobId=requestId;
    const cancelledKey='cancel:'+jobId;
    if((await chrome.storage.session.get(cancelledKey))[cancelledKey])throw new Error('Đã dừng phân tích.');
    const {tab,reused}=await ensureWarmGeminiTab(sourceTabId);
    if((await chrome.storage.session.get(cancelledKey))[cancelledKey]){await chrome.storage.session.remove(cancelledKey);throw new Error('Đã dừng phân tích.');}
    const existing=await getJobForTab(tab.id);
    if(!terminal(existing))throw new Error('Gemini đang xử lý văn bản ở tab iOffice khác.');
    const saved=await reuseState(),turns=saved?.turns||0,maxTurns=Math.max(1,Math.min(10,Number(settings.webGeminiMaxTurns)||3));
    const rotate=turns>=maxTurns||!!saved?.reset;
    const safePayload=stripScanAttachmentData(payload),attachments=extractScanAttachments(payload);
    if(attachments.length)volatileJobAttachments.set(jobId,attachments);
    let newChatBeforeSend=rotate;
    // PDF scan không được lưu vào storage.session (có thể vượt quota). Nếu cần xoay chat, mở /app trước khi tạo job rồi mới gửi file trực tiếp.
    if(rotate && attachments.length){
      await chrome.tabs.update(tab.id,{url:'https://gemini.google.com/app'});
      await waitForWebBridge(tab.id,30000);
      newChatBeforeSend=false;
    }
    const prompt=buildPrompt(safePayload,jobId);
    const timeoutMs=Math.max(30000,Math.min(240000,Number(settings.webGeminiTimeoutMs)||150000));
    const job={jobId,tabId:tab.id,sourceTabId,payload:safePayload,hasAttachments:attachments.length>0,createdAt:Date.now(),deadline:Date.now()+timeoutMs+90000,timeoutMs,status:'running',phase:'sending',phaseMessage:'Đang gửi văn bản tới Gemini',promptChars:prompt.length,rotate,foreground:settings.webGeminiForeground===true,resumeAfterReload:false};
    await chrome.storage.session.set({[webJobKey(jobId)]:job,[webTabKey(tab.id)]:jobId});
    // Persist the counted turn before sending; failures force a new chat next time.
    await rememberGeminiTab(tab,{turns:(rotate?0:turns)+1,reset:false});
    try{
      if(job.foreground)await chrome.tabs.update(tab.id,{active:true});
      if((await chrome.storage.session.get(cancelledKey))[cancelledKey]){await cancelGeminiWebJob(jobId);throw new Error('Đã dừng phân tích.');}
      const r=await tabMessage(tab.id,{type:'IOFFICE_GEMINI_AUTORUN',jobId,prompt,timeoutMs,attachments,newChatBeforeSend});
      if(!r?.ok)throw new Error(r?.error||'Không khởi động được Gemini.');
    }catch(e){await failGeminiWebJob({jobId,error:e.message},{tab:{id:tab.id}});throw e;}
    await pushGeminiJobEvent(job,'progress');
    return{jobId,tabId:tab.id,reused,message:rotate?'Gemini đang chuẩn bị ngữ cảnh mới.':`Gemini đang phân tích · lượt ${(rotate?0:turns)+1}/${maxTurns}.`};
  }finally{startFlight=null;}
}
async function handleWebBridgeReady(sender,platform){
  const tabId=sender?.tab?.id;if(!tabId||platform!=='gemini')return{ok:true,autoRun:false};
  const job=await getJobForTab(tabId);
  if(terminal(job)||!job.resumeAfterReload)return{ok:true,autoRun:false};
  // Chỉ nối lại bước gửi trước khi prompt đã được gửi. Không tự gửi lại sau khi Gemini đã nhận prompt.
  if(['sent','waiting','done'].includes(job.phase))return{ok:true,autoRun:false};
  const prompt=buildPrompt(job.payload||{},job.jobId);
  const updated=await updateWebJob(job.jobId,{resumeAfterReload:false,phase:'sending',phaseMessage:'Gemini đã tải xong · đang dán văn bản',promptChars:prompt.length});
  await pushGeminiJobEvent(updated||job,'progress');
  const attachments=volatileJobAttachments.get(job.jobId)||[];
  if(job.hasAttachments&&!attachments.length)return{ok:false,autoRun:false,error:'PDF scan cần gửi lại vì service worker vừa khởi động lại. Hãy bấm Phân tích lại.'};
  return{ok:true,autoRun:true,jobId:job.jobId,prompt,timeoutMs:job.timeoutMs||150000,attachments,newChatBeforeSend:false};
}
async function assertOwner(id,sender){const j=await readWebJob(id);if(j&&j.sourceTabId!==sender?.tab?.id)throw new Error('Phiên không thuộc tab iOffice này.');return j;}
async function returnToSource(job){
  if(!job.foreground)return;
  try{const tab=await chrome.tabs.get(job.tabId);if(tab.active)await chrome.tabs.update(job.sourceTabId,{active:true});}catch(_){}
}
async function completeGeminiWebJob(m,sender){
  return serial(m.jobId,async()=>{
    const job=await readWebJob(m.jobId);
    if(!job||job.tabId!==sender?.tab?.id)throw new Error('Kết quả không khớp tab Gemini.');
    if(terminal(job))return{ok:true,ignored:true};
    const parsed=IOfficeCore.parseRouting(m.text,m.jobId);if(!parsed)throw new Error('JSON thiếu trường bắt buộc hoặc không đúng mã phiên.');
    const result=validateAndClean(parsed,job.payload,{provider:'gemini-web-auto',providerLabel:'Gemini Web',model:'Theo lựa chọn trên Gemini',primaryProvider:'gemini-web-auto',attemptCount:1,triedProviders:['gemini-web-auto'],promptChars:job.promptChars+String(m.text).length,usageMetadata:null});
    Object.assign(job,{status:'done',phase:'done',phaseMessage:'Đã nhận kết quả Gemini',completedAt:Date.now(),result});
    await chrome.storage.session.set({[webJobKey(job.jobId)]:job});volatileJobAttachments.delete(job.jobId);await releaseTab(job);
    await pushGeminiJobEvent(job,'done',{result});await returnToSource(job);return{ok:true};
  });
}
async function failGeminiWebJob(m,sender){
  const job=await readWebJob(m.jobId);if(terminal(job))return{ok:true};
  if(job.tabId!==sender?.tab?.id)return{ok:false};
  const error=String(m.error||'Gemini không hoàn tất.').slice(0,1000);
  const updated=await updateWebJob(job.jobId,{status:'error',phase:'error',phaseMessage:error,error,completedAt:Date.now()});
  if(updated?.status==='error'){volatileJobAttachments.delete(job.jobId);await releaseTab(job);try{await rememberGeminiTab(await chrome.tabs.get(job.tabId),{turns:0,reset:true});}catch(_){}await pushGeminiJobEvent(updated,'error',{error});await returnToSource(job);}
  return{ok:true};
}
async function updateGeminiWebProgress(m,sender){
  const j=await readWebJob(m.jobId);if(terminal(j)||j.tabId!==sender?.tab?.id)return{ok:false};
  const updated=await updateWebJob(j.jobId,{phase:String(m.phase||'waiting').slice(0,50),phaseMessage:String(m.phaseMessage||'').slice(0,300)});
  if(!terminal(updated))await pushGeminiJobEvent(updated,'progress');return{ok:true};
}
async function cancelGeminiWebJob(id,error=''){
  return serial(id,async()=>{
    const j=await readWebJob(id);if(!j){await chrome.storage.session.set({['cancel:'+id]:Date.now()});return{ok:true};}
    if(terminal(j))return{ok:true};
    Object.assign(j,{status:error?'error':'cancelled',phase:error?'error':'cancelled',phaseMessage:error||'Đã dừng phân tích.',error,completedAt:Date.now()});
    await chrome.storage.session.set({[webJobKey(id)]:j});
    volatileJobAttachments.delete(id);await tabMessage(j.tabId,{type:'IOFFICE_GEMINI_CANCEL',jobId:id}).catch(()=>{});await releaseTab(j);
    try{await rememberGeminiTab(await chrome.tabs.get(j.tabId),{turns:0,reset:true});}catch(_){}
    await pushGeminiJobEvent(j,error?'error':'cancelled',{error});await returnToSource(j);return{ok:true};
  });
}
async function getGeminiWebJobStatus(id){
  let j=await readWebJob(id);if(!j)throw new Error('Không tìm thấy phiên Gemini.');
  if(!terminal(j)&&Date.now()>j.deadline){await cancelGeminiWebJob(id,'Gemini đã quá thời gian chờ.');j=await readWebJob(id);}
  return{jobId:id,status:j.status,phase:j.phase,phaseMessage:j.phaseMessage,error:j.error,result:j.result,elapsedMs:Date.now()-j.createdAt,tabId:j.tabId};
}
async function consumeGeminiWebJob(id){const j=await readWebJob(id);if(j&&!terminal(j))return{ok:false};if(j)await releaseTab(j);await chrome.storage.session.remove([webJobKey(id),'cancel:'+id]);return{ok:true};}
chrome.tabs.onUpdated.addListener((id,change)=>{
  if(!change.url&&!change.status)return;
  (async()=>{
    const j=await getJobForTab(id);if(terminal(j))return;
    const url=String(change.url||'');
    if(url && !url.startsWith('https://gemini.google.com/')){
      await failGeminiWebJob({jobId:j.jobId,error:'Gemini đã chuyển sang trang khác. Hãy mở lại Gemini và phân tích lại.'},{tab:{id}});
      return;
    }
    if(change.status==='loading'){
      // Gemini mở cuộc trò chuyện mới có thể làm tab loading/full navigation. Đây là trạng thái hợp lệ trước khi gửi.
      if(['sent','waiting'].includes(j.phase)){
        await failGeminiWebJob({jobId:j.jobId,error:'Tab Gemini tải lại sau khi đã gửi văn bản. Hãy phân tích lại để tránh gửi trùng.'},{tab:{id}});
      }else{
        const updated=await updateWebJob(j.jobId,{resumeAfterReload:true,phase:'reloading',phaseMessage:'Gemini đang chuyển cuộc trò chuyện · sẽ tự dán lại khi tải xong'});
        if(updated&&!terminal(updated))await pushGeminiJobEvent(updated,'progress');
      }
    }
  })().catch(()=>{});
});
chrome.tabs.onRemoved.addListener(id=>{
  (async()=>{
    const saved=await reuseState();if(saved?.tabId===id)await chrome.storage.session.remove('geminiOwnedTab');
    const all=await chrome.storage.session.get(null);
    for(const[key,j]of Object.entries(all))if(key.startsWith(WEB_JOB_PREFIX)&&!terminal(j)&&(j.tabId===id||j.sourceTabId===id))await cancelGeminiWebJob(j.jobId,'Tab đang xử lý đã đóng.');
  })().catch(()=>{});
});

function importWebResult(target, text, payload) {
  const parsed = extractJson(text);
  const label = target === 'gemini' ? 'Gemini Web' : 'ChatGPT Web';
  return validateAndClean(parsed, payload, {
    provider: target === 'gemini' ? 'gemini-web' : 'chatgpt-web',
    providerLabel: label,
    model: label,
    primaryProvider: target === 'gemini' ? 'gemini-web' : 'chatgpt-web',
    attemptCount: 1,
    triedProviders: [target === 'gemini' ? 'gemini-web' : 'chatgpt-web'],
    promptChars: 0,
    usageMetadata: null
  });
}

async function listModels(providerId, cfg) {
  const p = CATALOG[providerId];
  if (!p) throw new Error('Provider không hợp lệ.');
  if (!p.canListModels) throw new Error('Provider này không hỗ trợ tải danh sách model tự động.');

  if (p.type === 'gemini') {
    if (!cfg.apiKey) throw new Error('Cần Gemini API key để tải danh sách model.');
    const data = await fetchJson(`${trimSlash(cfg.baseUrl || p.baseUrl)}/models?pageSize=1000`, { method: 'GET', headers: {'x-goog-api-key':cfg.apiKey} }, 30000);
    return (data.models || []).filter((m) => !m.supportedGenerationMethods || m.supportedGenerationMethods.includes('generateContent')).map((m) => ({ id: String(m.name || '').replace(/^models\//, ''), label: m.displayName || m.name })).filter((x) => x.id);
  }

  if (p.type === 'anthropic') {
    if (!cfg.apiKey) throw new Error('Cần Anthropic API key.');
    const data = await fetchJson(`${trimSlash(cfg.baseUrl || p.baseUrl)}/models?limit=1000`, { method: 'GET', headers: { 'x-api-key': cfg.apiKey, 'anthropic-version': '2023-06-01' } }, 30000);
    return (data.data || []).map((m) => ({ id: m.id, label: m.display_name || m.id })).filter((x) => x.id);
  }

  if (p.type === 'ollama') {
    const data = await fetchJson(`${trimSlash(cfg.baseUrl || p.baseUrl)}/api/tags`, { method: 'GET' }, 15000);
    return (data.models || []).map((m) => ({ id: m.name || m.model, label: m.name || m.model })).filter((x) => x.id);
  }

  if (p.type === 'azure-openai' || p.type === 'gateway') throw new Error('Không có endpoint model-list chuẩn cho cấu hình này.');

  if (!cfg.baseUrl) throw new Error('Chưa có Base URL.');
  if (p.needsKey && !cfg.apiKey) throw new Error('Chưa có API key.');
  const headers = authHeaders(providerId, cfg);
  const data = await fetchJson(`${trimSlash(cfg.baseUrl)}/models`, { method: 'GET', headers }, 30000);
  const list = data.data || data.models || [];
  return list.map((m) => ({ id: typeof m === 'string' ? m : (m.id || m.name || m.model), label: typeof m === 'string' ? m : (m.name || m.id || m.model) })).filter((x) => x.id);
}

async function testProvider(providerId, cfg) {
  const p = CATALOG[providerId];
  if (!p) throw new Error('Provider không hợp lệ.');
  if (p.type === 'gateway') {
    const base = String(cfg.baseUrl || '').replace(/\/analyze\/?$/, '');
    try { await fetchJson(`${trimSlash(base)}/health`, { method: 'GET' }, 10000); return { ok: true, message: 'Gateway phản hồi health-check.' }; }
    catch (_) { throw new Error('Không xác minh được /health của gateway. Kiểm tra địa chỉ và máy chủ.'); }
  }
  if (p.canListModels) {
    const models = await listModels(providerId, cfg);
    return { ok: true, message: `Kết nối được · thấy ${models.length} model.`, models: models.slice(0, 300) };
  }
  if (p.type === 'azure-openai') {
    if (!providerConfigured(providerId, cfg)) throw new Error('Azure cần key + endpoint + deployment.');
    return { ok: true, message: 'Cấu hình Azure đủ trường bắt buộc; sẽ xác minh thật ở lần phân tích.' };
  }
  return { ok: true, message: 'Cấu hình hợp lệ.' };
}


function trackerOrigin(url) {
  const u = new URL(String(url || '').trim());
  if (u.protocol !== 'https:') throw new Error('Web App Sổ theo dõi phải dùng HTTPS.');
  return `${u.protocol}//${u.hostname}/*`;
}


const TRACKER_CACHE_KEY = 'trackerClientCacheV4';
const TRACKER_OLD_CACHE_KEY = 'trackerClientCacheV3';
const TRACKER_PENDING_KEY = 'trackerPendingSyncV4';
const TRACKER_OLD_PENDING_KEY = 'trackerPendingSyncV3';
const TRACKER_CACHE_TTL_MS = 10 * 60 * 1000;

async function getTrackerCache() {
  const raw = await chrome.storage.local.get({ [TRACKER_CACHE_KEY]: null, [TRACKER_OLD_CACHE_KEY]: null });
  const c = raw[TRACKER_CACHE_KEY] || raw[TRACKER_OLD_CACHE_KEY];
  if (!raw[TRACKER_CACHE_KEY] && c?.tasks) await chrome.storage.local.set({[TRACKER_CACHE_KEY]:c});
  if (c && Array.isArray(c.tasks)) return { updatedAt: Number(c.updatedAt || 0), tasks: c.tasks };
  return { updatedAt: 0, tasks: [] };
}

async function setTrackerCache(tasks, generatedAt = '') {
  const cache = { updatedAt: Date.now(), generatedAt: String(generatedAt || ''), tasks: Array.isArray(tasks) ? tasks : [] };
  await chrome.storage.local.set({ [TRACKER_CACHE_KEY]: cache });
  return cache;
}

async function refreshTrackerCache(force = false) {
  const current = await getTrackerCache();
  if (!force && current.updatedAt && Date.now() - current.updatedAt < TRACKER_CACHE_TTL_MS) return current;
  const out = await trackerCall('listClientCache', { clientVersion: chrome.runtime.getManifest().version });
  return setTrackerCache(out?.tasks || [], out?.generatedAt || '');
}

async function patchTrackerCache(taskId, patch = {}) {
  taskId = String(taskId || '');
  if (!taskId) return;
  const c = await getTrackerCache();
  let changed = false;
  const tasks = c.tasks.map(t => {
    if (String(t?.taskId || '') !== taskId) return t;
    changed = true;
    return { ...t, ...patch };
  });
  if (changed) await chrome.storage.local.set({ [TRACKER_CACHE_KEY]: { ...c, updatedAt: Date.now(), tasks } });
}

function trackerQueueableError(error) {
  const m = String(error?.message || error || '').toLowerCase();
  if (!m) return false;
  if (/unauthorized|token|unknown_action|chưa cấu hình|chưa nhập|chưa bật|quyền truy cập/.test(m)) return false;
  return /network|failed to fetch|fetch|timeout|không phản hồi|abort|load failed|internet|connection|http 5\d\d/.test(m);
}

async function enqueueTrackerAction(action, data) {
  const raw = await chrome.storage.local.get({ [TRACKER_PENDING_KEY]: [], [TRACKER_OLD_PENDING_KEY]: [] });
  const queue = Array.isArray(raw[TRACKER_PENDING_KEY]) && raw[TRACKER_PENDING_KEY].length ? raw[TRACKER_PENDING_KEY] : (Array.isArray(raw[TRACKER_OLD_PENDING_KEY]) ? raw[TRACKER_OLD_PENDING_KEY] : []);
  const key = `${action}|${String(data?.taskId || data?.syncKey || data?.sourceSymbol || data?.soKyHieu || data?.documentId || '')}|${String(data?.resultSymbol || '')}`;
  if (!queue.some(x => x.key === key)) {
    queue.push({ key, action, data, createdAt: Date.now(), attempts: 0 });
    await chrome.storage.local.set({ [TRACKER_PENDING_KEY]: queue.slice(-100) });
    if (raw[TRACKER_OLD_PENDING_KEY]?.length) await chrome.storage.local.remove(TRACKER_OLD_PENDING_KEY);
  }
  try { chrome.alarms.create('trackerPendingSyncV4', { periodInMinutes: 2 }); } catch (_) {}
  return { ok: true, queued: true, action, taskId: String(data?.taskId || '') };
}

async function trackerActionWithQueue(action, data) {
  try {
    const out = await trackerCall(action, data || {});
    const taskId = String(data?.taskId || out?.taskId || '');
    if (taskId) {
      if (action === 'markSigned') await patchTrackerCache(taskId, { businessStatus: out?.businessStatus || 'WAITING_PUBLISH', signedAt: data?.signedAt || new Date().toISOString(), resultSymbol: data?.resultSymbol || '' });
      if (action === 'markPublished') await patchTrackerCache(taskId, { businessStatus: out?.businessStatus || 'COMPLETED', publishedAt: data?.publishedAt || new Date().toISOString(), completedAt: data?.publishedAt || new Date().toISOString(), resultSymbol: data?.resultSymbol || out?.resultSymbol || '', completionResult: out?.completionResult || '' });
      if (action === 'manualUpdateTask') await patchTrackerCache(taskId, { businessStatus: out?.businessStatus || data?.businessStatus || data?.status || '', resultSymbol: data?.resultSymbol || out?.resultSymbol || '', completionResult: out?.completionResult || '', updateSource:'MANUAL' });
    }
    return { ok: true, data: out };
  } catch (e) {
    if (trackerQueueableError(e)) {
      const q = await enqueueTrackerAction(action, data || {});
      return { ok: true, queued: true, data: q };
    }
    throw e;
  }
}

async function flushTrackerPending() {
  const raw = await chrome.storage.local.get({ [TRACKER_PENDING_KEY]: [], [TRACKER_OLD_PENDING_KEY]: [] });
  const queue = Array.isArray(raw[TRACKER_PENDING_KEY]) && raw[TRACKER_PENDING_KEY].length ? raw[TRACKER_PENDING_KEY] : (Array.isArray(raw[TRACKER_OLD_PENDING_KEY]) ? raw[TRACKER_OLD_PENDING_KEY] : []);
  if (!queue.length) return { ok: true, flushed: 0, remaining: 0 };
  const remain = [];
  let flushed = 0;
  for (const item of queue) {
    try {
      const out = await trackerCall(item.action, item.data || {});
      flushed++;
      const taskId = String(item.data?.taskId || out?.taskId || '');
      if (taskId && item.action === 'markSigned') await patchTrackerCache(taskId, { businessStatus: out?.businessStatus || 'WAITING_PUBLISH', signedAt: item.data?.signedAt || '' });
      if (taskId && item.action === 'markPublished') await patchTrackerCache(taskId, { businessStatus: out?.businessStatus || 'COMPLETED', resultSymbol: item.data?.resultSymbol || out?.resultSymbol || '', completedAt: item.data?.publishedAt || '', completionResult: out?.completionResult || '' });
      if (taskId && item.action === 'manualUpdateTask') await patchTrackerCache(taskId, { businessStatus: out?.businessStatus || item.data?.businessStatus || item.data?.status || '', updateSource:'MANUAL' });
    } catch (e) {
      remain.push({ ...item, attempts: Number(item.attempts || 0) + 1, lastError: String(e?.message || e), lastAttemptAt: Date.now() });
    }
  }
  await chrome.storage.local.set({ [TRACKER_PENDING_KEY]: remain });
  if (raw[TRACKER_OLD_PENDING_KEY]?.length) await chrome.storage.local.remove(TRACKER_OLD_PENDING_KEY);
  if (!remain.length) { try { chrome.alarms.clear('trackerPendingSyncV4'); } catch (_) {} }
  return { ok: true, flushed, remaining: remain.length };
}

try {
  chrome.alarms.onAlarm.addListener(alarm => {
    if (alarm?.name === 'trackerPendingSyncV4') flushTrackerPending().catch(() => {});
  });
} catch (_) {}

async function trackerCall(action, data = null) {
  const settings = await getSettings();
  if (!settings.trackerEnabled) throw new Error('Chưa bật kết nối Sổ theo dõi.');
  const url = String(settings.trackerApiUrl || '').trim();
  const token = String(settings.trackerToken || '').trim();
  if (!url) throw new Error('Chưa cấu hình URL Apps Script Web App.');
  if (!token) throw new Error('Chưa nhập mã truy cập Sổ theo dõi.');
  const origin = trackerOrigin(url);
  if (!await chrome.permissions.contains({ origins:[origin] })) throw new Error('Chưa cấp quyền truy cập Apps Script. Mở Cấu hình và bấm Kiểm tra kết nối.');
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 12000);
  try {
    const response = await fetch(url, {
      method:'POST',
      headers:{'Content-Type':'text/plain;charset=utf-8'},
      body:JSON.stringify({ action, token, data }),
      redirect:'follow', signal:controller.signal
    });
    const text = await response.text();
    let out = {};
    try { out = JSON.parse(text); } catch (_) { throw new Error(`Apps Script không trả JSON hợp lệ: ${text.slice(0,220)}`); }
    if (!response.ok || out?.ok === false) throw new Error(out?.error || `HTTP ${response.status}`);
    return out;
  } catch (e) {
    if (e?.name === 'AbortError') throw new Error('Sổ theo dõi không phản hồi sau 12 giây.');
    throw e;
  } finally { clearTimeout(timer); }
}

async function checkRelease(url){
  const u=new URL(url);if(u.protocol!=='https:'||u.username||u.password)throw new Error('Địa chỉ cập nhật phải là HTTPS.');
  if(!await chrome.permissions.contains({origins:[u.origin+'/*']}))throw new Error('Chưa cấp quyền đọc địa chỉ cập nhật.');
  const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),12000);
  try{
    const r=await fetch(u.href,{signal:controller.signal,credentials:'omit',cache:'no-store',redirect:'error'});
    if(!r.ok)throw new Error('Không tải được thông tin cập nhật (HTTP '+r.status+').');
    const reader=r.body.getReader();let bytes=0,parts=[];
    while(true){const {done,value}=await reader.read();if(done)break;bytes+=value.length;if(bytes>65536){await reader.cancel();throw new Error('Tệp cập nhật quá lớn.');}parts.push(value);}
    const joined=new Uint8Array(bytes);let offset=0;for(const part of parts){joined.set(part,offset);offset+=part.length;}
    return IOfficeCore.releaseInfo(JSON.parse(new TextDecoder().decode(joined)),chrome.runtime.getManifest().version);
  }finally{clearTimeout(timer);}
}
async function checkStoreUpdate(){
  const result=await chrome.runtime.requestUpdateCheck();
  return {message:result.status==='update_available'?`Chrome đã tìm thấy bản ${result.version}. Bản cập nhật được Chrome quản lý.`:result.status==='throttled'?'Chrome vừa kiểm tra gần đây. Hãy thử lại sau.':'Chrome chưa tìm thấy bản mới. Nếu đang dùng Load unpacked, hãy tải gói mới và tải lại tiện ích.',status:result.status};
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (sender.id !== chrome.runtime.id) return;
  const url = sender.url || sender.tab?.url || '';
  const isOptions = url.startsWith(chrome.runtime.getURL(''));
  const isOffice = url.startsWith('https://ioffice.vnptdaklak.vn/qlvbdh_dlk/');
  const isGemini = url.startsWith('https://gemini.google.com/');
  const type = message?.type || '';
  if (iofficeUpdateApplying && ['AI_ANALYZE','WEB_AUTOMATION_START','WEB_AUTOMATION_PREWARM'].includes(type)) { sendResponse({ok:false,error:'Đang cập nhật tiện ích. Vui lòng chờ.'}); return; }
  const fromGemini = ['WEB_AUTOMATION_RESULT','WEB_AUTOMATION_PROGRESS','WEB_AUTOMATION_ERROR','WEB_BRIDGE_READY'].includes(type);
  if (fromGemini ? !isGemini : (!isOptions && !isOffice)) return;
  if (['AI_LIST_MODELS','AI_TEST_PROVIDER','CHECK_RELEASE','CHECK_STORE_UPDATE','TRACKER_TEST'].includes(type) && !isOptions) return;

  if(type==='CHECK_RELEASE'||type==='CHECK_STORE_UPDATE'){(type==='CHECK_RELEASE'?checkRelease(message.url):checkStoreUpdate()).then(data=>sendResponse({ok:true,data})).catch(e=>sendResponse({ok:false,error:e.message}));return true;}
  if (type === 'TRACKER_TEST') { trackerCall('ping', { clientVersion: chrome.runtime.getManifest().version }).then(async data=>{ try{await refreshTrackerCache(true);}catch(_){} sendResponse({ok:true,data}); }).catch(e=>sendResponse({ok:false,error:e.message})); return true; }
  if (type === 'TRACKER_CACHE_REFRESH') { refreshTrackerCache(message.data?.force === true).then(cache=>sendResponse({ok:true,cache})).catch(e=>sendResponse({ok:false,error:e.message})); return true; }
  if (type === 'TRACKER_UPSERT') { trackerActionWithQueue('createTask', message.data || {}).then(r=>{sendResponse(r);if(!r?.queued)refreshTrackerCache(true).catch(()=>{});}).catch(e=>sendResponse({ok:false,error:e.message})); return true; }
  if (type === 'TRACKER_LIST_OPEN') { trackerCall('listOpenTasks', message.data || {}).then(data=>sendResponse({ok:true,data})).catch(e=>sendResponse({ok:false,error:e.message})); return true; }
  if (type === 'TRACKER_COMPLETE') { trackerActionWithQueue('completeTask', message.data || {}).then(r=>sendResponse(r)).catch(e=>sendResponse({ok:false,error:e.message})); return true; }
  if (type === 'TRACKER_MATCH') { trackerCall('matchTask', message.data || {}).then(data=>sendResponse({ok:true,data})).catch(e=>sendResponse({ok:false,error:e.message})); return true; }
  if (type === 'TRACKER_MARK_SIGNED') { trackerActionWithQueue('markSigned', message.data || {}).then(r=>sendResponse(r)).catch(e=>sendResponse({ok:false,error:e.message})); return true; }
  if (type === 'TRACKER_MARK_PUBLISHED') { trackerActionWithQueue('markPublished', message.data || {}).then(r=>sendResponse(r)).catch(e=>sendResponse({ok:false,error:e.message})); return true; }
  if (type === 'TRACKER_GET') { trackerCall('getTask', message.data || {}).then(data=>sendResponse({ok:true,data})).catch(e=>sendResponse({ok:false,error:e.message})); return true; }
  if (type === 'TRACKER_SYNC_PUBLIC') { trackerCall('syncPublic', message.data || {}).then(data=>sendResponse({ok:true,data})).catch(e=>sendResponse({ok:false,error:e.message})); return true; }
  if (type === 'TRACKER_MANUAL_UPDATE') { trackerActionWithQueue('manualUpdateTask', message.data || {}).then(r=>sendResponse(r)).catch(e=>sendResponse({ok:false,error:e.message})); return true; }
  if (message?.type === 'GET_ROUTING_RULES') {
    getRoutingRules().then((rules) => sendResponse({ ok: true, rules })).catch((error) => sendResponse({ ok: false, error: error?.message || String(error) }));
    return true;
  }
  if(message?.type==='AI_CANCEL'){const id=sender.tab?.id;apiRequests.get(id)?.abort();const h=handoffs.get(id);if(h){h.controller.abort();if(h.tabId)tabMessage(h.tabId,{type:'IOFFICE_GEMINI_CANCEL',jobId:h.jobId}).catch(()=>{});}sendResponse({ok:true});return;}
  if (message?.type === 'AI_ANALYZE') {
    const tabId=sender.tab?.id;
    apiRequests.get(tabId)?.abort();const c=new AbortController();apiRequests.set(tabId,c);
    analyze(message.payload || {},c.signal).then((data) => sendResponse({ ok: true, data })).catch((error) => sendResponse({ ok: false, error: error?.message || String(error) })).finally(()=>{if(apiRequests.get(tabId)===c)apiRequests.delete(tabId);});
    return true;
  }
  if (message?.type === 'AI_LIST_MODELS') {
    listModels(message.providerId, message.config || {}).then((models) => sendResponse({ ok: true, models })).catch((error) => sendResponse({ ok: false, error: error?.message || String(error) }));
    return true;
  }
  if (message?.type === 'AI_TEST_PROVIDER') {
    testProvider(message.providerId, message.config || {}).then((data) => sendResponse({ ok: true, data })).catch((error) => sendResponse({ ok: false, error: error?.message || String(error) }));
    return true;
  }
  if (message?.type === 'WEB_BRIDGE_READY') {
    handleWebBridgeReady(sender,message.platform)
      .then(sendResponse)
      .catch((error)=>sendResponse({ok:false,error:error?.message||String(error)}));
    return true;
  }
  if (message?.type === 'WEB_AUTOMATION_PREWARM') {
    prewarmGeminiForSession(sender?.tab?.id)
      .then(({ tab, reused, firstForeground }) => sendResponse({ ok: true, data: { tabId: tab?.id || null, reused, firstForeground } }))
      .catch((error) => sendResponse({ ok: false, error: error?.message || String(error) }));
    return true;
  }
  if (message?.type === 'WEB_AUTOMATION_START') {
    startGeminiWebAutomation(message.payload || {}, sender?.tab?.id, message.jobId)
      .then((data) => sendResponse({ ok: true, data }))
      .catch((error) => sendResponse({ ok: false, error: error?.message || String(error) }));
    return true;
  }
  if (message?.type === 'WEB_AUTOMATION_RESULT') {
    completeGeminiWebJob(message, sender)
      .then(sendResponse)
      .catch((error) => sendResponse({ ok: false, error: error?.message || String(error) }));
    return true;
  }
  if (message?.type === 'WEB_AUTOMATION_ERROR') {
    failGeminiWebJob(message, sender)
      .then(sendResponse)
      .catch(() => sendResponse({ ok: false }));
    return true;
  }
  if (message?.type === 'WEB_AUTOMATION_PROGRESS') {
    updateGeminiWebProgress(message, sender)
      .then(sendResponse)
      .catch(() => sendResponse({ ok: false }));
    return true;
  }
  if (message?.type === 'WEB_AUTOMATION_CANCEL') {
    assertOwner(message.jobId, sender).then(() => cancelGeminiWebJob(message.jobId))
      .then(sendResponse)
      .catch(() => sendResponse({ ok: false }));
    return true;
  }
  if (message?.type === 'WEB_AUTOMATION_STATUS') {
    assertOwner(message.jobId, sender).then(() => getGeminiWebJobStatus(message.jobId))
      .then((data) => sendResponse({ ok: true, data }))
      .catch((error) => sendResponse({ ok: false, error: error?.message || String(error) }));
    return true;
  }
  if (message?.type === 'WEB_AUTOMATION_CONSUME') {
    assertOwner(message.jobId, sender).then(() => consumeGeminiWebJob(message.jobId))
      .then(sendResponse)
      .catch(() => sendResponse({ ok: false }));
    return true;
  }
  if (message?.type === 'WEB_HANDOFF_START') {
    startWebHandoff(message.target, message.payload || {}, sender.tab?.id).then((data) => sendResponse({ ok: true, data })).catch((error) => sendResponse({ ok: false, error: error?.message || String(error) }));
    return true;
  }
  if (message?.type === 'WEB_HANDOFF_IMPORT') {
    try { sendResponse({ ok: true, data: importWebResult(message.target, message.text || '', message.payload || {}) }); }
    catch (error) { sendResponse({ ok: false, error: error?.message || String(error) }); }
    return false;
  }
  if (message?.type === 'OPEN_OPTIONS') {
    chrome.runtime.openOptionsPage(); sendResponse({ ok: true });
  }
});

importScripts('update-manager.js');
