'use strict';
const $=id=>document.getElementById(id);
const API_PROVIDER='gemini-openai';
const API_BASE_URL='https://generativelanguage.googleapis.com/v1beta/openai/';
const API_MODELS=[
  {id:'gemini-3.5-flash-lite',label:'Gemini 3.5 Flash-Lite'},
  {id:'gemini-3.1-flash-lite',label:'Gemini 3.1 Flash-Lite'},
  {id:'gemini-3.8-flash',label:'Gemini 3.8 Flash'}
];
const MODEL_IDS=API_MODELS.map(x=>x.id);
const DEFAULT_CHAIN=[
  {id:'route-primary-35',enabled:true,model:'gemini-3.5-flash-lite',keyMode:'primary',apiKey:''},
  {id:'route-primary-31',enabled:true,model:'gemini-3.1-flash-lite',keyMode:'primary',apiKey:''},
  {id:'route-primary-38',enabled:true,model:'gemini-3.8-flash',keyMode:'primary',apiKey:''}
];
const defaults={
  analysisMode:'api',readerTimeoutMs:5000,readerMaxFileSizeMb:10,readerConcurrency:0,
  trackerApiUrl:'',trackerToken:'',instructionPrefixEnabled:false,instructionPrefixText:'VP đề xuất:',
  providerConfigs:{},apiFallbackChain:DEFAULT_CHAIN,aiRulePack:null,aiRulePackVersion:'',aiRulePackSource:'embedded',
  aiRulePackUpdatedAt:0,ruleAutoUpdate:true,qualityEscalationEnabled:true
};
let current={...defaults},chain=[],activeRulePack=null,recipientData=null,recipientUnlocked=false,recipientDirectory=[];

function msg(t,ok=true){const el=$('msg');if(!el)return;el.textContent=t;el.className='msg '+(ok?'ok':'err');}
function runtime(m){return new Promise(resolve=>{try{chrome.runtime.sendMessage(m,r=>resolve(chrome.runtime.lastError?{ok:false,error:chrome.runtime.lastError.message}:(r||{ok:false,error:'Không có phản hồi'})));}catch(e){resolve({ok:false,error:e.message});}});}
function routeId(){return 'route-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,7);}
function cloneDefaultChain(){return DEFAULT_CHAIN.map(x=>({...x}));}
function normalizeChain(raw){const arr=Array.isArray(raw)&&raw.length?raw:cloneDefaultChain(),out=[];for(const x of arr.slice(0,8)){if(!x||typeof x!=='object')continue;const model=MODEL_IDS.includes(String(x.model||''))?String(x.model):MODEL_IDS[0],keyMode=x.keyMode==='custom'?'custom':'primary';out.push({id:String(x.id||routeId()),enabled:x.enabled!==false,model,keyMode,apiKey:keyMode==='custom'?String(x.apiKey||''):''});}return out.length?out:cloneDefaultChain();}
function geminiCfg(){const cfg=current.providerConfigs?.[API_PROVIDER]||{},legacyCustom=current.providerConfigs?.custom||{},legacyGemini=current.providerConfigs?.gemini||{},googleCustom=/generativelanguage\.googleapis\.com\/v1beta\/openai/i.test(String(legacyCustom.baseUrl||''));return {model:MODEL_IDS.includes(cfg.model)?cfg.model:MODEL_IDS[0],apiKey:cfg.apiKey||(googleCustom?legacyCustom.apiKey:'')||legacyGemini.apiKey||''};}
function maskKey(key){const s=String(key||'');return s.length<8?'••••':`${s.slice(0,4)}••••${s.slice(-3)}`;}
function modelOptions(selected){return API_MODELS.map(m=>`<option value="${m.id}" ${m.id===selected?'selected':''}>${m.label}</option>`).join('');}
function esc(v){return String(v??'').replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;');}
function toggleSecret(input,button){if(!input)return;const show=input.type==='password';input.type=show?'text':'password';if(button)button.textContent=show?'🙈':'👁';}
document.addEventListener('click',e=>{const b=e.target.closest('[data-secret-target]');if(b){toggleSecret($(b.dataset.secretTarget),b);return;}const dyn=e.target.closest('[data-secret-dynamic]');if(dyn){const input=dyn.closest('.secret-wrap')?.querySelector('input');toggleSecret(input,dyn);}});

function renderChain(){
  const box=$('apiChain');if(!box)return;
  box.innerHTML=chain.map((r,i)=>`<div class="api-route" data-route-id="${esc(r.id)}">
    <div class="api-route-priority">${i+1}</div>
    <label class="api-route-enabled" title="Bật/tắt tuyến"><input type="checkbox" data-f="enabled" ${r.enabled?'checked':''}><span>Bật</span></label>
    <div class="api-route-field"><label>Model</label><select data-f="model">${modelOptions(r.model)}</select></div>
    <div class="api-route-field"><label>API key</label><select data-f="keyMode"><option value="primary" ${r.keyMode==='primary'?'selected':''}>Key chính</option><option value="custom" ${r.keyMode==='custom'?'selected':''}>Key riêng</option></select></div>
    <div class="api-route-field api-route-key ${r.keyMode==='custom'?'':'hidden'}"><label>Key riêng</label><div class="secret-wrap"><input data-f="apiKey" type="password" autocomplete="off" value="${esc(r.apiKey||'')}" placeholder="API key dự phòng"><button class="secret-toggle" type="button" data-secret-dynamic title="Hiện/ẩn mã">👁</button></div></div>
    <div class="api-route-actions"><button class="mini" data-act="test">Test</button><button class="mini" data-act="up" ${i===0?'disabled':''}>↑</button><button class="mini" data-act="down" ${i===chain.length-1?'disabled':''}>↓</button><button class="mini danger" data-act="delete" ${chain.length<=1?'disabled':''}>×</button></div>
    <div class="api-route-status" data-status>${r.keyMode==='custom'&&r.apiKey?`Key riêng ${maskKey(r.apiKey)}`:(r.keyMode==='primary'?'Dùng API key chính':'')}</div>
  </div>`).join('');
  $('apiChainCount').textContent=`${chain.filter(x=>x.enabled).length}/${chain.length} tuyến bật`;
}
function syncRouteFromDom(row){const r=chain.find(x=>x.id===row?.dataset?.routeId);if(!r)return null;r.enabled=!!row.querySelector('[data-f="enabled"]')?.checked;r.model=row.querySelector('[data-f="model"]')?.value||r.model;r.keyMode=row.querySelector('[data-f="keyMode"]')?.value==='custom'?'custom':'primary';r.apiKey=r.keyMode==='custom'?(row.querySelector('[data-f="apiKey"]')?.value||'').trim():'';return r;}
function effectiveRouteConfig(r){return {apiKey:r.keyMode==='custom'?r.apiKey:$('apiKey').value.trim(),model:r.model,baseUrl:API_BASE_URL,authMode:'bearer'};}
async function testRoute(r,row=null){const status=row?.querySelector('[data-status]');if(status){status.textContent='Đang kiểm tra…';status.className='api-route-status checking';}try{const cfg=effectiveRouteConfig(r);if(!cfg.apiKey)throw new Error(r.keyMode==='custom'?'Chưa nhập key riêng.':'Chưa nhập key chính.');const res=await runtime({type:'AI_TEST_API_ROUTE',config:cfg});if(!res?.ok)throw new Error(res?.error||'Không kết nối được API/model.');if(status){status.textContent=`✓ OK · ${r.model}`;status.className='api-route-status ok';}return {ok:true};}catch(e){if(status){status.textContent='✕ '+e.message;status.className='api-route-status err';}return {ok:false,error:e.message};}}
function validateTrackerUrl(url){const u=new URL(String(url||'').trim());if(u.protocol!=='https:'||u.hostname!=='script.google.com'||!/^\/macros\/s\/[^/]+\/exec$/.test(u.pathname)||u.username||u.password)throw new Error('URL phải dạng https://script.google.com/macros/s/.../exec');return u.origin+u.pathname;}
function downloadJson(filename,obj){const blob=new Blob([JSON.stringify(obj,null,2)],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=filename;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1200);}
function parseEditor(){const text=$('rulePackEditor')?.value||'';if(!text.trim())throw new Error('Rule Pack đang trống.');return JSON.parse(text);}
function setRuleStatus(text,kind=''){const el=$('rulePackStatus');if(!el)return;el.textContent=text;el.className='status '+kind;}
function renderRulePackInfo(data){activeRulePack=data?.active||globalThis.IOfficeRulePack.defaultPack();$('rulePackVersion').value=data?.version||activeRulePack.version||'';$('rulePackSource').value=data?.source==='embedded'?'Mặc định':data?.source==='manual'?'Đã nhập':'Internet/local';$('rulePackEditor').value=JSON.stringify(activeRulePack,null,2);const ar=activeRulePack.inputPolicy?.additionalReadPolicy||{};$('rulePackSummary').textContent=`${activeRulePack.name||'Rule Pack'} · ${activeRulePack.units?.length||0} đầu mối · phụ lục ${ar.mode==='off'?'tắt':'đọc theo nhiệm vụ/hạn'}.`;}
async function loadRulePack(){const r=await runtime({type:'RULE_PACK_GET'});if(!r?.ok)throw new Error(r?.error||'Không tải được Rule Pack.');renderRulePackInfo(r.data);return r.data;}
async function validateEditor(){try{const r=await runtime({type:'RULE_PACK_VALIDATE',pack:parseEditor()});if(!r?.ok)throw new Error(r?.error||'Rule Pack không hợp lệ.');const t=r.data.tests;setRuleStatus(`✓ Hợp lệ · ${r.data.units} đầu mối · Rule ${r.data.version}${t?` · tests ${t.passed}/${t.total}`:''}`,'ok');return true;}catch(e){setRuleStatus('✕ '+e.message,'err');return false;}}


function setRecipientStatus(text,kind=''){const el=$('recipientStatus');if(!el)return;el.textContent=text;el.className='status '+kind;}
function recipientBindingMap(){return new Map((recipientData?.bindings||[]).map(x=>[String(x.roleKey||''),x]));}
function peopleForRole(role){
  const exact=recipientDirectory.filter(x=>String(x.parentUnit||'').toUpperCase()===String(role.unitId||'').toUpperCase());
  return exact.length?exact:recipientDirectory;
}
function renderRecipientBindings(){
  const box=$('recipientBindings');if(!box||!recipientData?.rules)return;
  const map=recipientBindingMap();
  const roles=recipientData.rules.roles||[];
  box.innerHTML=roles.map(role=>{
    const b=map.get(role.key)||{},people=peopleForRole(role);
    const options=['<option value="">— Không gắn cá nhân —</option>',...people.map(p=>`<option value="${esc(p.key||'')}" ${(p.key||'')===(b.personKey||'')?'selected':''}>${esc(p.name||p.key)}${p.parentName?` · ${esc(p.parentName)}`:''}</option>`)].join('');
    return `<div class="recipient-row ${recipientUnlocked?'':'locked'}" data-role-key="${esc(role.key)}"><div class="rr-key">${esc(role.key)}</div><div class="rr-role"><b>${esc(role.label||role.key)}</b><br><small>${esc((role.topics||[]).slice(0,5).join(', '))}</small></div><div><span class="rr-person">${esc(b.personName||'Chưa gắn người')}</span><select data-role-select ${recipientUnlocked?'':'disabled'}>${options}</select></div></div>`;
  }).join('');
  $('recipientUnlock').textContent=recipientUnlocked?'🔓 Khóa chỉnh sửa':'🔒 Mở khóa chỉnh sửa';
  $('recipientSave').disabled=!recipientUnlocked;
}
async function loadRecipientRules(){
  const r=await runtime({type:'RECIPIENT_RULES_GET'});if(!r?.ok)throw new Error(r?.error||'Không tải được Recipient Rules.');
  recipientData=r.data||{};
  const store=await chrome.storage.local.get({leaderWatcherDirectory:[]});recipientDirectory=Array.isArray(store.leaderWatcherDirectory)?store.leaderWatcherDirectory:[];
  $('recipientRulesVersion').value=recipientData.rules?.version||'';
  $('recipientRulesSource').value=recipientData.meta?.phase==='installed'?'Internet':'Đang áp dụng';
  renderRecipientBindings();
  return recipientData;
}
function collectRecipientBindings(){
  const old=recipientBindingMap(),out=[];
  for(const row of [...document.querySelectorAll('.recipient-row')]){
    const roleKey=row.dataset.roleKey,personKey=row.querySelector('[data-role-select]')?.value||'';if(!personKey)continue;
    const meta=recipientDirectory.find(x=>String(x.key||'')===personKey)||old.get(roleKey)||{};
    out.push({roleKey,personKey,personName:String(meta.name||meta.personName||''),parentUnit:String(meta.parentUnit||''),parentName:String(meta.parentName||''),enabled:true});
  }
  return out;
}
async function saveRecipientBindings(){
  const bindings=collectRecipientBindings();const r=await runtime({type:'RECIPIENT_BINDINGS_SET',bindings});if(!r?.ok)throw new Error(r?.error||'Không lưu được map người nhận.');
  recipientData.bindings=r.data||bindings;recipientUnlocked=false;renderRecipientBindings();setRecipientStatus(`✓ Đã lưu ${recipientData.bindings.length} gắn người cục bộ. Tên/ID không gửi AI.`,'ok');
}

async function load(){
  current=await chrome.storage.local.get(defaults);$('version').textContent='v'+chrome.runtime.getManifest().version;
  $('analysisMode').value=['api','gemini-web','chatgpt-web'].includes(current.analysisMode)?current.analysisMode:'api';
  $('instructionPrefixEnabled').checked=current.instructionPrefixEnabled===true;$('instructionPrefixText').value=current.instructionPrefixText||'VP đề xuất:';
  $('trackerApiUrl').value=current.trackerApiUrl||'';$('trackerToken').value=current.trackerToken||'';
  $('readerTimeoutSec').value=String(Math.round((current.readerTimeoutMs||5000)/1000));$('readerMaxFileSizeMb').value=String(current.readerMaxFileSizeMb||10);$('qualityEscalationEnabled').checked=current.qualityEscalationEnabled!==false;
  const cpu=await runtime({type:'SYSTEM_CPU_INFO'}),logical=Math.max(1,Number(cpu?.data?.numOfProcessors||navigator.hardwareConcurrency||1)),sel=$('readerConcurrency');
  sel.innerHTML='<option value="0">Tự động tối đa theo CPU</option>'+Array.from({length:logical},(_,i)=>`<option value="${i+1}">${i+1} luồng</option>`).join('');sel.value=String(Math.max(0,Math.min(logical,Number(current.readerConcurrency)||0)));
  const model=String(cpu?.data?.modelName||'CPU không xác định').trim(),arch=String(cpu?.data?.archName||'').trim();$('cpuInfo').textContent=`CPU: ${model}${arch?` · ${arch}`:''} · ${logical} luồng logic · tự động tối đa.`;
  const cfg=geminiCfg();$('apiBaseUrl').value=API_BASE_URL;$('apiKey').value=cfg.apiKey;chain=normalizeChain(current.apiFallbackChain);renderChain();await loadRulePack();await loadRecipientRules();
}

$('apiChain')?.addEventListener('change',e=>{const row=e.target.closest('.api-route');if(!row)return;syncRouteFromDom(row);if(e.target.dataset.f==='keyMode')renderChain();else $('apiChainCount').textContent=`${chain.filter(x=>x.enabled).length}/${chain.length} tuyến bật`;});
$('apiChain')?.addEventListener('input',e=>{const row=e.target.closest('.api-route');if(row)syncRouteFromDom(row);});
$('apiChain')?.addEventListener('click',async e=>{const b=e.target.closest('[data-act]');if(!b)return;const row=b.closest('.api-route'),idx=chain.findIndex(x=>x.id===row.dataset.routeId);if(idx<0)return;syncRouteFromDom(row);const act=b.dataset.act;if(act==='up'&&idx>0)[chain[idx-1],chain[idx]]=[chain[idx],chain[idx-1]];else if(act==='down'&&idx<chain.length-1)[chain[idx+1],chain[idx]]=[chain[idx],chain[idx+1]];else if(act==='delete'&&chain.length>1)chain.splice(idx,1);else if(act==='test'){await testRoute(chain[idx],row);return;}renderChain();});
$('addSameKeyRoute')?.addEventListener('click',()=>{if(chain.length>=8)return msg('Tối đa 8 tuyến API.',false);const used=new Set(chain.filter(x=>x.keyMode==='primary').map(x=>x.model)),model=MODEL_IDS.find(x=>!used.has(x))||MODEL_IDS[0];chain.push({id:routeId(),enabled:true,model,keyMode:'primary',apiKey:''});renderChain();});
$('addCustomKeyRoute')?.addEventListener('click',()=>{if(chain.length>=8)return msg('Tối đa 8 tuyến API.',false);chain.push({id:routeId(),enabled:true,model:MODEL_IDS[0],keyMode:'custom',apiKey:''});renderChain();});
$('testApiChain')?.addEventListener('click',async()=>{const el=$('apiStatus');el.textContent='Đang kiểm tra…';el.className='status';for(const row of [...document.querySelectorAll('.api-route')])syncRouteFromDom(row);const enabled=chain.filter(x=>x.enabled);if(!enabled.length){el.textContent='✕ Chưa bật tuyến API nào.';el.className='status err';return;}let ok=0;for(const r of enabled){const row=document.querySelector(`.api-route[data-route-id="${CSS.escape(r.id)}"]`),rs=await testRoute(r,row);if(rs.ok)ok++;}el.textContent=ok===enabled.length?`✓ ${ok}/${enabled.length} tuyến sẵn sàng.`:`⚠ ${ok}/${enabled.length} tuyến sẵn sàng.`;el.className='status '+(ok===enabled.length?'ok':'err');});

$('validateRulePack')?.addEventListener('click',validateEditor);
$('exportRulePack')?.addEventListener('click',()=>{try{const pack=parseEditor();globalThis.IOfficeRulePack.validate(pack);downloadJson(`ea-ly-rules-${pack.version}.json`,pack);setRuleStatus('✓ Đã xuất Rule JSON.','ok');}catch(e){setRuleStatus('✕ '+e.message,'err');}});
$('importRulePack')?.addEventListener('click',()=>$('importRulePackFile')?.click());
$('importRulePackFile')?.addEventListener('change',async e=>{try{const file=e.target.files?.[0];if(!file)return;const pack=globalThis.IOfficeRulePack.validate(JSON.parse(await file.text()));const r=await runtime({type:'RULE_PACK_SET_MANUAL',pack});if(!r?.ok)throw new Error(r?.error||'Không áp dụng được Rule Pack.');setRuleStatus(`✓ Đã nhập và áp dụng Rule ${r.data.version}.`,'ok');await loadRulePack();}catch(err){setRuleStatus('✕ '+err.message,'err');}finally{e.target.value='';}});
$('restoreRulePack')?.addEventListener('click',async()=>{if(!confirm('Khôi phục Rule Pack mặc định 1.0?'))return;const r=await runtime({type:'RULE_PACK_RESTORE_DEFAULT'});if(!r?.ok)return setRuleStatus('✕ '+(r?.error||'Không khôi phục được.'),'err');setRuleStatus(`✓ Đã khôi phục Rule ${r.data.version}.`,'ok');await loadRulePack();});


$('recipientUnlock')?.addEventListener('click',()=>{recipientUnlocked=!recipientUnlocked;renderRecipientBindings();setRecipientStatus(recipientUnlocked?'Đang mở khóa chỉnh sửa. Chọn người rồi bấm Lưu gắn người.':'Đã khóa chỉnh sửa.','ok');});
$('recipientSave')?.addEventListener('click',async()=>{try{await saveRecipientBindings();}catch(e){setRecipientStatus('✕ '+e.message,'err');}});
$('recipientExport')?.addEventListener('click',()=>{if(!recipientData)return;if(!confirm('File xuất map cục bộ có tên/ID người dùng iOffice. Chỉ lưu nội bộ, không đưa lên GitHub công khai. Tiếp tục?'))return;downloadJson(`ea-ly-recipient-local-bindings-${recipientData.rules?.version||'1.0.0'}.json`,{format:'ioffice-recipient-local-bindings-v1',recipientRulesVersion:recipientData.rules?.version||'',bindings:recipientData.bindings||[]});setRecipientStatus('✓ Đã xuất map cục bộ.','ok');});
$('recipientImport')?.addEventListener('click',()=>$('recipientImportFile')?.click());
$('recipientImportFile')?.addEventListener('change',async e=>{try{const f=e.target.files?.[0];if(!f)return;const data=JSON.parse(await f.text());if(data?.format!=='ioffice-recipient-local-bindings-v1'||!Array.isArray(data.bindings))throw new Error('File map cục bộ sai format.');const r=await runtime({type:'RECIPIENT_BINDINGS_SET',bindings:data.bindings});if(!r?.ok)throw new Error(r?.error||'Không nhập được map.');await loadRecipientRules();setRecipientStatus(`✓ Đã nhập ${r.data?.length||0} gắn người.`,'ok');}catch(err){setRecipientStatus('✕ '+err.message,'err');}finally{e.target.value='';}});

$('testTracker')?.addEventListener('click',async()=>{const el=$('trackerStatus');el.textContent='Đang kiểm tra kết nối API Tracker…';el.className='status';try{const rawUrl=$('trackerApiUrl').value.trim(),token=$('trackerToken').value.trim();if(!rawUrl||!token)throw new Error('Nhập đủ URL Web App và TOKEN.');const url=validateTrackerUrl(rawUrl);$('trackerApiUrl').value=url;await chrome.storage.local.set({trackerApiUrl:url,trackerToken:token});const r=await runtime({type:'TRACKER_TEST'});if(!r?.ok)throw new Error(r?.error||'Không kết nối được Tracker.');el.textContent=`✓ Kết nối Tracker ${r.data?.version||''} · API OK · ${Number(r.data?.taskCount||0)} nhiệm vụ đang mở.`;el.className='status ok';}catch(e){el.textContent='✕ '+e.message;el.className='status err';}});

$('save')?.addEventListener('click',async()=>{try{
  for(const row of [...document.querySelectorAll('.api-route')])syncRouteFromDom(row);
  const apiKey=$('apiKey').value.trim(),enabledRoutes=chain.filter(x=>x.enabled);if(!enabledRoutes.length)throw new Error('Cần bật ít nhất 1 tuyến API.');if(enabledRoutes.some(x=>x.keyMode==='primary')&&!apiKey)throw new Error('Chưa nhập API key chính.');if(enabledRoutes.some(x=>x.keyMode==='custom'&&!x.apiKey))throw new Error('Có tuyến key riêng nhưng chưa nhập key.');
  const providerConfigs={...(current.providerConfigs||{})};providerConfigs[API_PROVIDER]={...(providerConfigs[API_PROVIDER]||{}),model:enabledRoutes[0].model,baseUrl:API_BASE_URL,apiKey,authMode:'bearer'};
  let trackerApiUrl=$('trackerApiUrl').value.trim(),trackerToken=$('trackerToken').value.trim();if((trackerApiUrl&&!trackerToken)||(!trackerApiUrl&&trackerToken))throw new Error('Tracker cần nhập đủ URL và TOKEN.');if(trackerApiUrl)trackerApiUrl=validateTrackerUrl(trackerApiUrl);
  const settings={userRole:'leader',aiAnalysisEnabled:true,analysisMode:$('analysisMode').value,fallbackAnalysisMode:'none',webAiEnabled:true,webGeminiForeground:false,webGeminiFirstForeground:false,webChatgptForeground:false,webChatgptFirstForeground:false,webGeminiMaxTurns:3,webChatgptMaxTurns:3,webGeminiTimeoutMs:150000,webChatgptTimeoutMs:150000,aiRequireCompleteFiles:false,readerMode:'primary',readerTimeoutMs:Math.max(2000,Math.min(60000,Number($('readerTimeoutSec').value||5)*1000)),readerMaxFileSizeMb:Math.max(1,Math.min(50,Number($('readerMaxFileSizeMb').value||10))),readerIncludeRelated:false,readerConcurrency:Math.max(0,Math.min(64,Number($('readerConcurrency')?.value||0))),readerDeduplicateContent:true,readerScanEnabled:false,qualityEscalationEnabled:$('qualityEscalationEnabled').checked!==false,trackerApiUrl,trackerToken,instructionPrefixEnabled:$('instructionPrefixEnabled').checked,instructionPrefixText:String($('instructionPrefixText').value||'VP đề xuất:').trim(),providerOrder:[API_PROVIDER,'none','none','none'],providerConfigs,apiFallbackChain:normalizeChain(chain),retriesPerProvider:1,requestTimeoutMs:45000};
  await chrome.storage.local.set(settings);await chrome.storage.local.remove(['trackerEnabled','trackerReminderDays']);current={...current,...settings};msg(`✓ Đã lưu · ${enabledRoutes.length} tuyến API · đang tải lại…`,true);$('save').disabled=true;$('save').textContent='Đã lưu';setTimeout(()=>location.reload(),650);
}catch(e){msg(e.message,false);}});


chrome.storage.onChanged.addListener((changes,area)=>{if(area==='local'&&(changes.recipientRules||changes.recipientRulesMeta||changes.recipientLocalBindings||changes.leaderWatcherDirectory))void loadRecipientRules().catch(()=>{});});

load().catch(e=>msg('Không tải được cấu hình: '+e.message,false));
