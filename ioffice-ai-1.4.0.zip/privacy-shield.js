(() => {
  'use strict';

  const VERSION='1.0.0';
  const SECRET_RE=/(^|\n)\s*(TUYỆT\s*MẬT|TỐI\s*MẬT|MẬT)\s*(?=\n|$)/iu;
  const clone=v=>v==null?v:JSON.parse(JSON.stringify(v));
  const statsTemplate=()=>({persons:0,addresses:0,phones:0,emails:0,ids:0,dob:0,bankAccounts:0,fileNames:0,other:0,total:0,blockedSecret:false});

  function token(type,index){return `⟦${type}_${String(index).padStart(2,'0')}⟧`;}
  function put(ctx,type,value){
    const raw=String(value||''); if(!raw.trim())return raw;
    const key=token(type,(ctx.counts[type]||0)+1); ctx.counts[type]=(ctx.counts[type]||0)+1;
    ctx.map[key]=raw;
    const statKey={PERSON:'persons',ADDRESS:'addresses',PHONE:'phones',EMAIL:'emails',ID:'ids',DOB:'dob',BANK:'bankAccounts',FILE:'fileNames'}[type]||'other';
    ctx.stats[statKey]++;ctx.stats.total++;
    return key;
  }
  function replaceWith(text,re,ctx,type,group=0){return String(text).replace(re,(...args)=>{const full=args[0];const g=group?args[group]:full;const replacement=put(ctx,type,g);return group?full.replace(g,replacement):replacement;});}

  function protectText(input,ctx){
    let s=String(input??''); if(!s)return s;
    // Email and phone are high-confidence patterns.
    s=replaceWith(s,/\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b/giu,ctx,'EMAIL');
    s=replaceWith(s,/(?<!\d)(?:\+?84|0)(?:[ .-]?\d){8,10}(?!\d)/g,ctx,'PHONE');
    // CCCD/CMND/passport only when the surrounding label makes the meaning clear.
    s=replaceWith(s,/\b(?:CCCD|CMND|Căn\s*cước(?:\s*công\s*dân)?|Số\s*định\s*danh|ĐDCN|Hộ\s*chiếu)\s*(?:số|:|-)?\s*([A-Z0-9]{6,20})\b/giu,ctx,'ID',1);
    s=replaceWith(s,/\b(?:BHXH|BHYT|mã\s*số\s*thuế)\s*(?:số|:|-)?\s*([A-Z0-9.-]{6,24})\b/giu,ctx,'ID',1);
    // Bank account only with explicit banking context to avoid masking document numbers.
    s=replaceWith(s,/\b(?:số\s*tài\s*khoản|tài\s*khoản\s*ngân\s*hàng|STK)\s*(?:số|:|-)?\s*([0-9]{6,24})\b/giu,ctx,'BANK',1);
    // Date of birth / born date.
    s=replaceWith(s,/\b(?:ngày\s*sinh|sinh\s*ngày|DOB)\s*(?:[:|-])?\s*((?:\d{1,2}[\/.-]){2}\d{2,4})\b/giu,ctx,'DOB',1);
    // Address-like phrases. Keep the label and replace only the value up to line/sentence punctuation.
    s=replaceWith(s,/(?:^|[\s,;(])(?:địa\s*chỉ(?:\s*thường\s*trú|\s*liên\s*hệ)?|nơi\s*cư\s*trú|thường\s*trú|tạm\s*trú|trú\s*tại|nơi\s*ở\s*hiện\s*tại)\s*(?:[:|-])?\s*([^\n;]{5,180}?)(?=\s*(?:[,;.]?\s*(?:SĐT|điện\s*thoại|email|CCCD|CMND|Căn\s*cước|ngày\s*sinh|sinh\s*ngày)\b|[;\n]|$))/giu,ctx,'ADDRESS',1);
    // Person names only when anchored by person-specific labels/titles; do not broadly mask organization names.
    s=replaceWith(s,/(?:^|[ \t,;(])(?:ông|bà|anh|chị|đồng[ \t]*chí|họ[ \t]*và[ \t]*tên|họ[ \t]*tên|người[ \t]*đại[ \t]*diện|người[ \t]*kiến[ \t]*nghị|người[ \t]*sử[ \t]*dụng[ \t]*đất|chủ[ \t]*sử[ \t]*dụng|công[ \t]*dân)[ \t]*(?:[:|-])?[ \t]*([A-ZĐÀÁÂÃÈÉÊÌÍÒÓÔÕÙÚĂẠẢẤẦẨẪẬẮẰẲẴẶẸẺẼỀẾỂỄỆỈỊỌỎỐỒỔỖỘỚỜỞỠỢỤỦỨỪỬỮỰỲỴỶỸ][\p{L}'’-]*(?:[ \t]+[A-ZĐÀÁÂÃÈÉÊÌÍÒÓÔÕÙÚĂẠẢẤẦẨẪẬẮẰẲẴẶẸẺẼỀẾỂỄỆỈỊỌỎỐỒỔỖỘỚỜỞỠỢỤỦỨỪỬỮỰỲỴỶỸ][\p{L}'’-]*){1,5})/giu,ctx,'PERSON',1);
    return s;
  }

  function looksLikePersonalSender(v){
    const s=String(v||'').trim();if(!s||/(ubnd|ủy ban|sở |phòng |ban |trung tâm|công an|bộ |cục |chi cục|trường |công ty|doanh nghiệp|văn phòng|hđnd|đảng ủy)/iu.test(s))return false;
    return /^(?:[A-ZĐÀÁÂÃÈÉÊÌÍÒÓÔÕÙÚĂẠẢẤẦẨẪẬẮẰẲẴẶẸẺẼỀẾỂỄỆỈỊỌỎỐỒỔỖỘỚỜỞỠỢỤỦỨỪỬỮỰỲỴỶỸ][\p{L}'’-]*[ \t]+){1,4}[A-ZĐÀÁÂÃÈÉÊÌÍÒÓÔÕÙÚĂẠẢẤẦẨẪẬẮẰẲẴẶẸẺẼỀẾỂỄỆỈỊỌỎỐỒỔỖỘỚỜỞỠỢỤỦỨỪỬỮỰỲỴỶỸ][\p{L}'’-]*$/u.test(s);
  }
  function walk(value,ctx,key=''){
    if(typeof value==='string'){
      if((key==='attachmentNames'||key==='name'||key==='signingFileName')&&/\.(?:pdf|docx?|xlsx?|pptx?|rar|zip|7z)$/i.test(value.trim()))return put(ctx,'FILE',value.trim());
      if(/personName|fullName|hoTen|họTên/i.test(key))return put(ctx,'PERSON',value);
      if(key==='sender'&&looksLikePersonalSender(value))return put(ctx,'PERSON',value);
      return protectText(value,ctx);
    }
    if(Array.isArray(value))return value.map(v=>walk(v,ctx,key));
    if(value&&typeof value==='object'){
      const out={};
      for(const [k,v] of Object.entries(value)){
        // Raw binary PDF/base64 never belongs in the text anonymizer.
        if(k==='base64')out[k]=v;
        else out[k]=walk(v,ctx,k);
      }
      return out;
    }
    return value;
  }

  function detectSecret(value){
    let found=false;
    const visit=v=>{if(found||v==null)return;if(typeof v==='string'){if(SECRET_RE.test(v))found=true;return;}if(Array.isArray(v)){for(const x of v)visit(x);return;}if(typeof v==='object'){for(const [k,x] of Object.entries(v)){if(k!=='base64')visit(x);}}};
    visit(value);return found;
  }

  function protect(value){
    const ctx={map:{},counts:{},stats:statsTemplate()};
    if(detectSecret(value)){ctx.stats.blockedSecret=true;return {value:clone(value),map:{},stats:ctx.stats,blocked:true,reason:'Phát hiện dấu mức độ bí mật nhà nước (MẬT/TỐI MẬT/TUYỆT MẬT). Không gửi nội dung ra AI bên ngoài.'};}
    const safe=walk(clone(value),ctx);
    return {value:safe,map:ctx.map,stats:ctx.stats,blocked:false,reason:''};
  }

  function restoreText(text,map){
    let s=String(text??'');
    const entries=Object.entries(map||{});
    for(let pass=0;pass<4;pass++){let before=s;for(const [k,v] of entries)s=s.split(k).join(String(v));if(s===before)break;}
    return s;
  }
  function restore(value,map){
    if(typeof value==='string')return restoreText(value,map);
    if(Array.isArray(value))return value.map(v=>restore(v,map));
    if(value&&typeof value==='object'){const out={};for(const [k,v] of Object.entries(value))out[k]=restore(v,map);return out;}
    return value;
  }

  globalThis.IOfficePrivacyShield=Object.freeze({VERSION,protect,restore,restoreText,detectSecret});
})();
