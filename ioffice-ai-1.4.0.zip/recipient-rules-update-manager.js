(() => {
  'use strict';
  const URL='https://kpia0412.github.io/ioAI/recipient-rules.json';
  const ALARM='ioffice-recipient-rules-update';
  const PERIOD_MIN=15;
  const RULES_KEY='recipientRules';
  const META_KEY='recipientRulesMeta';
  const AUTO_KEY='recipientRulesAutoUpdate';
  const BINDINGS_KEY='recipientLocalBindings';
  const now=()=>Date.now();

  function validVersion(v){return /^\d+(?:\.\d+){2}$/.test(String(v||''));}
  function validate(data){
    if(!data||data.format!=='ioffice-recipient-rules-v1')throw new Error('recipient-rules.json sai format.');
    if(!validVersion(data.version))throw new Error('Version recipient-rules không hợp lệ.');
    const seen=new Set();
    const roles=(Array.isArray(data.roles)?data.roles:[]).map((r,i)=>{
      const key=String(r?.key||'').trim(),unitId=String(r?.unitId||'').trim();
      if(!/^(?:U\d+|DUUBND)-R\d+$/i.test(key))throw new Error(`Role #${i+1} có key không hợp lệ.`);
      if(!/^(?:U\d+|DUUBND)$/i.test(unitId))throw new Error(`Role ${key} có unitId không hợp lệ.`);
      if(seen.has(key))throw new Error(`Trùng role ${key}.`);seen.add(key);
      return {key,unitId,label:String(r.label||key).trim().slice(0,160),topics:(Array.isArray(r.topics)?r.topics:[]).map(x=>String(x).trim()).filter(Boolean).slice(0,40)};
    });
    return {format:data.format,version:String(data.version),name:String(data.name||'Recipient Roles').slice(0,120),updatedAt:String(data.updatedAt||''),minConfidence:Math.max(.7,Math.min(.98,Number(data.minConfidence)||.85)),policy:{alwaysKeepMainUnit:true,additionalRecipientOnly:true,requireSameUnit:true,neverSendPersonNameToAI:true,fallbackToUnitOnly:true,...(data.policy||{})},roles};
  }
  async function fetchJson(url=URL){const c=new AbortController(),timer=setTimeout(()=>c.abort(),15000);try{const r=await fetch(url,{cache:'no-store',signal:c.signal,headers:{Accept:'application/json'}});if(!r.ok)throw new Error(`HTTP ${r.status}`);return validate(JSON.parse(await r.text()));}finally{clearTimeout(timer);}}
  async function embedded(){const r=await fetch(chrome.runtime.getURL('recipient-rules.json'),{cache:'no-store'});if(!r.ok)throw new Error('Không đọc được recipient-rules mặc định.');return validate(await r.json());}
  async function current(){const raw=await chrome.storage.local.get({[RULES_KEY]:null,[META_KEY]:{},[AUTO_KEY]:true,[BINDINGS_KEY]:[]});const rules=raw[RULES_KEY]?validate(raw[RULES_KEY]):await embedded();return {rules,meta:raw[META_KEY]||{},auto:raw[AUTO_KEY]!==false,bindings:Array.isArray(raw[BINDINGS_KEY])?raw[BINDINGS_KEY]:[]};}
  async function setMeta(patch){const raw=await chrome.storage.local.get({[META_KEY]:{}});const next={...(raw[META_KEY]||{}),...patch};await chrome.storage.local.set({[META_KEY]:next});return next;}
  async function check(){const cur=await current();await setMeta({phase:'checking',error:'',checkedAt:now(),currentVersion:cur.rules.version});try{const remote=await fetchJson();const newer=globalThis.IOfficeCore.compareVersions(remote.version,cur.rules.version)>0;return await setMeta({phase:newer?'available':'current',newer,version:remote.version,currentVersion:cur.rules.version,error:'',checkedAt:now(),url:URL});}catch(e){return await setMeta({phase:'error',newer:false,error:e.message,checkedAt:now(),currentVersion:cur.rules.version,url:URL});}}
  async function apply(){const remote=await fetchJson();await chrome.storage.local.set({[RULES_KEY]:remote});await setMeta({phase:'installed',newer:false,version:remote.version,currentVersion:remote.version,error:'',installedAt:now(),url:URL});return remote;}
  async function autoCycle(){const cur=await current();if(!cur.auto)return {ok:true,skipped:true};const st=await check();if(st.newer){try{return {ok:true,rules:await apply()};}catch(e){await setMeta({phase:'error',error:e.message});return {ok:false,error:e.message};}}return {ok:true,state:st};}
  async function ensureAlarm(){if(!await chrome.alarms.get(ALARM))await chrome.alarms.create(ALARM,{delayInMinutes:2,periodInMinutes:PERIOD_MIN});}

  function sanitizeBindings(bindings,rules){const roles=new Map((rules.roles||[]).map(r=>[r.key,r]));return (Array.isArray(bindings)?bindings:[]).map(x=>({roleKey:String(x?.roleKey||''),personKey:String(x?.personKey||''),personName:String(x?.personName||''),parentUnit:String(x?.parentUnit||''),parentName:String(x?.parentName||''),enabled:x?.enabled!==false})).filter(x=>{const role=roles.get(x.roleKey);if(!role||!x.personKey)return false;const p=String(x.parentUnit||'').toUpperCase();if(/^(?:U\d+|DUUBND)$/.test(p)&&p!==String(role.unitId||'').toUpperCase())return false;return true;});}
  async function getAiCandidates(){const cur=await current();const bound=new Set(sanitizeBindings(cur.bindings,cur.rules).filter(x=>x.enabled).map(x=>x.roleKey));return (cur.rules.roles||[]).filter(r=>bound.has(r.key)).map(r=>({key:r.key,unitId:r.unitId,label:r.label,topics:r.topics}));}
  async function getBinding(roleKey){const cur=await current();return sanitizeBindings(cur.bindings,cur.rules).find(x=>x.enabled&&x.roleKey===String(roleKey||''))||null;}
  async function setBindings(bindings){const cur=await current();const clean=sanitizeBindings(bindings,cur.rules);await chrome.storage.local.set({[BINDINGS_KEY]:clean});return clean;}

  chrome.alarms.onAlarm.addListener(a=>{if(a.name===ALARM)autoCycle().catch(()=>{});});
  chrome.runtime.onStartup.addListener(()=>{ensureAlarm().then(autoCycle).catch(()=>{});});
  chrome.runtime.onInstalled.addListener(()=>{ensureAlarm().then(autoCycle).catch(()=>{});});
  ensureAlarm().catch(()=>{});

  chrome.runtime.onMessage.addListener((m,_s,reply)=>{
    const t=m?.type;if(!t||!t.startsWith('RECIPIENT_'))return;
    (async()=>{
      if(t==='RECIPIENT_RULES_GET'){const cur=await current();return {ok:true,data:{rules:cur.rules,meta:cur.meta,auto:cur.auto,bindings:sanitizeBindings(cur.bindings,cur.rules),url:URL}};}
      if(t==='RECIPIENT_UPDATE_CHECK')return {ok:true,data:await check()};
      if(t==='RECIPIENT_UPDATE_APPLY')return {ok:true,data:await apply()};
      if(t==='RECIPIENT_AUTO_SET'){await chrome.storage.local.set({[AUTO_KEY]:m.enabled!==false});return {ok:true};}
      if(t==='RECIPIENT_BINDINGS_SET')return {ok:true,data:await setBindings(m.bindings)};
      if(t==='RECIPIENT_BINDING_GET')return {ok:true,data:await getBinding(m.roleKey)};
      throw new Error('Lệnh recipient không hỗ trợ.');
    })().then(reply).catch(e=>reply({ok:false,error:e.message}));return true;
  });

  globalThis.IOfficeRecipientRulesManager=Object.freeze({current,getAiCandidates,getBinding,setBindings,check,apply,validate});
})();
