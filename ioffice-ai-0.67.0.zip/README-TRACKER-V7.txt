iOffice AI 0.64.0 — Tracker 7.0.17

DANH MỤC ĐẦU MỐI
- Văn phòng
- Phòng Kinh tế
- Phòng VH-XH
- Trung tâm PVHCC
- Trung tâm Cung ứng
- Công an
- BCHQS
- HĐND
- Đảng ủy UBND

LƯU Ý
- Trạm Y tế, THCS, Tiểu học, Mẫu giáo không còn là đơn vị phân luồng/Tracker độc lập; quy về Phòng VH-XH.
- Đảng ủy UBND khác Đảng ủy xã; tiện ích chỉ chọn Đảng ủy UBND khi văn bản giao đích danh Đảng ủy/Đảng bộ UBND.
- Nâng Tracker 7.0.16 -> 7.0.17: thay Code.gs, Save, Deploy New version; giữ URL /exec + TOKEN; KHÔNG chạy setupFreshV7().
