(() => {
  const status = document.getElementById('internetStatus');
  const check = document.getElementById('internetCheck');
  const apply = document.getElementById('internetApply');
  const auto = document.getElementById('internetAuto');
  const feed = document.getElementById('internetFeed');
  const meta = document.getElementById('internetMeta');
  if (!status || !check || !apply || !auto) return;

  const fmtTime = value => {
    if (!value) return '';
    try { return new Date(Number(value)).toLocaleString('vi-VN', { hour12: false }); }
    catch (_) { return ''; }
  };

  async function getAuto() {
    const x = await chrome.storage.local.get({ internetAutoUpdate: true });
    return x.internetAutoUpdate !== false;
  }

  async function render(s = {}) {
    const autoOn = await getAuto();
    auto.checked = autoOn;
    const current = chrome.runtime.getManifest().version;
    const when = fmtTime(s.checkedAt);
    const autoText = autoOn ? 'Tự động: BẬT · kiểm tra mỗi 5 phút' : 'Tự động: TẮT';
    if (meta) meta.textContent = `Bản đang dùng: ${current} · ${autoText}${when ? ` · Kiểm tra gần nhất: ${when}` : ''}`;
    if (feed) feed.textContent = s.feed || 'https://kpia0412.github.io/ioAI/latest.json';

    let text = 'Chưa kiểm tra cập nhật.';
    let cls = 'status';
    if (s.phase === 'checking') text = 'Đang kiểm tra phiên bản mới trên GitHub…';
    else if (s.phase === 'applying') { text = `Đang tải và cài iOffice AI ${s.version || ''}… Vui lòng giữ Chrome mở.`; cls += ' ok'; }
    else if (s.phase === 'restarting') { text = `Đã tải xong ${s.current || s.version || ''}. Đang nạp lại tiện ích và iOffice…`; cls += ' ok'; }
    else if (s.phase === 'waiting') { text = `Đã phát hiện bản ${s.version || ''}. ${s.waitReason || 'Đang chờ thời điểm an toàn để tự cập nhật.'}`; cls += ' ok'; }
    else if (s.phase === 'installed') { text = `✓ Đã cập nhật tự động lên ${s.current || current}.`; cls += ' ok'; }
    else if (s.error) { text = s.error; cls += ' err'; }
    else if (s.newer) { text = autoOn ? `Có bản ${s.version}. Hệ thống sẽ tự tải và cài khi iOffice không bận/chưa có nội dung chưa lưu.` : `Có bản ${s.version}. Tự động đang tắt.`; cls += ' ok'; }
    else if (s.current) { text = `Đang là bản mới nhất (${s.current}).`; cls += ' ok'; }

    status.textContent = text;
    status.className = cls;
    apply.hidden = !s.newer;
    apply.textContent='Đồng ý cập nhật ngay';
    const busy = ['checking', 'applying', 'restarting'].includes(s.phase);
    apply.disabled = busy;
    check.disabled = busy;
    auto.disabled = s.phase === 'applying' || s.phase === 'restarting';
  }

  async function run(type) {
    check.disabled = apply.disabled = true;
    try {
      const r = await chrome.runtime.sendMessage({ type, forceDirty: type==='INTERNET_UPDATE_APPLY' });
      if (!r?.ok) throw new Error(r?.error || 'Không có phản hồi từ bộ cập nhật.');
    } catch (e) {
      status.textContent = e.message;
      status.className = 'status err';
    } finally {
      check.disabled = apply.disabled = false;
    }
  }

  check.onclick = () => run('INTERNET_UPDATE_CHECK');
  apply.onclick = () => {if(confirm('Cập nhật ngay và tải lại các tab iOffice? Nội dung chưa lưu có thể mất.'))run('INTERNET_UPDATE_APPLY');};
  auto.addEventListener('change', async () => {
    await chrome.storage.local.set({ internetAutoUpdate: auto.checked });
    const { internetUpdate = {} } = await chrome.storage.local.get('internetUpdate');
    await render(internetUpdate);
    if (auto.checked) run('INTERNET_UPDATE_AUTO_NOW');
  });

  chrome.storage.local.get('internetUpdate').then(x => render(x.internetUpdate || {}));
  chrome.storage.onChanged.addListener((c, area) => {
    if (area === 'local' && (c.internetUpdate || c.internetAutoUpdate)) {
      chrome.storage.local.get('internetUpdate').then(x => render(x.internetUpdate || {}));
    }
  });
})();
