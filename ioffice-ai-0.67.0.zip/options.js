'use strict';
const $=id=>document.getElementById(id);
const API_PROVIDER='gemini-openai';
const API_BASE_URL='https://generativelanguage.googleapis.com/v1beta/openai/';
const API_MODELS=[
  {id:'gemini-3.5-flash-lite',label:'Gemini 3.5 Flash-Lite'},
  {id:'gemini-3.1-flash-lite',label:'Gemini 3.1 Flash-Lite'},
  {id:'gemini-3.8-flash',label:'Gemini 3.8 Flash'}
];
const MODEL_IDS=API_MODELS.map(x=>x.id);
const DEFAULT_CHAIN=[
  {id:'route-primary-35',enabled:true,model:'gemini-3.5-flash-lite',keyMode:'primary',apiKey:''},
  {id:'route-primary-31',enabled:true,model:'gemini-3.1-flash-lite',keyMode:'primary',apiKey:''},
  {id:'route-primary-38',enabled:true,model:'gemini-3.8-flash',keyMode:'primary',apiKey:''}
];
const defaults={
  analysisMode:'api',fallbackAnalysisMode:'none',aiRequireCompleteFiles:true,webAiEnabled:true,
  webGeminiMaxTurns:3,webChatgptMaxTurns:3,webGeminiTimeoutMs:150000,webChatgptTimeoutMs:150000,
  readerMode:'primary',readerTimeoutMs:5000,readerMaxFileSizeMb:10,readerIncludeRelated:false,
  trackerEnabled:false,trackerApiUrl:'',trackerToken:'',trackerReminderDays:3,
  instructionPrefixEnabled:false,instructionPrefixText:'VP đề xuất:',aiCustomRulesIncoming:'',aiCustomRulesOutgoing:'',providerOrder:[API_PROVIDER,'none','none','none'],providerConfigs:{},apiFallbackChain:DEFAULT_CHAIN
};
let current={...defaults},chain=[];
function msg(t,ok=true){$('msg').textContent=t;$('msg').className='msg '+(ok?'ok':'err');}
function runtime(m){return new Promise(resolve=>{try{chrome.runtime.sendMessage(m,r=>resolve(chrome.runtime.lastError?{ok:false,error:chrome.runtime.lastError.message}:(r||{ok:false})));}catch(e){resolve({ok:false,error:e.message});}});}
function routeId(){return 'route-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,7);}
function cloneDefaultChain(){return DEFAULT_CHAIN.map(x=>({...x}));}
function normalizeChain(raw){
  const arr=Array.isArray(raw)&&raw.length?raw:cloneDefaultChain();
  const out=[];
  for(const x of arr.slice(0,8)){
    if(!x||typeof x!=='object')continue;
    const model=MODEL_IDS.includes(String(x.model||''))?String(x.model):'gemini-3.5-flash-lite';
    const keyMode=x.keyMode==='custom'?'custom':'primary';
    out.push({id:String(x.id||routeId()),enabled:x.enabled!==false,model,keyMode,apiKey:keyMode==='custom'?String(x.apiKey||''):''});
  }
  return out.length?out:cloneDefaultChain();
}
function geminiCfg(){
  const cfg=current.providerConfigs?.[API_PROVIDER]||{};
  const legacyCustom=current.providerConfigs?.custom||{};
  const legacyGemini=current.providerConfigs?.gemini||{};
  const googleCustom=/generativelanguage\.googleapis\.com\/v1beta\/openai/i.test(String(legacyCustom.baseUrl||''));
  return {model:MODEL_IDS.includes(cfg.model)?cfg.model:'gemini-3.5-flash-lite',baseUrl:API_BASE_URL,apiKey:cfg.apiKey||(googleCustom?legacyCustom.apiKey:'')||legacyGemini.apiKey||''};
}
function maskKey(key){const s=String(key||'');return s.length<8?'••••':`${s.slice(0,4)}••••${s.slice(-3)}`;}
function modelOptions(selected){return API_MODELS.map(m=>`<option value="${m.id}" ${m.id===selected?'selected':''}>${m.label}</option>`).join('');}
function renderChain(){
  const box=$('apiChain');if(!box)return;
  box.innerHTML=chain.map((r,i)=>`<div class="api-route" data-route-id="${r.id}">
    <div class="api-route-priority">${i+1}</div>
    <label class="api-route-enabled" title="Bật/tắt tuyến này"><input type="checkbox" data-f="enabled" ${r.enabled?'checked':''}><span>Bật</span></label>
    <div class="api-route-field"><label>Model</label><select data-f="model">${modelOptions(r.model)}</select></div>
    <div class="api-route-field"><label>API key</label><select data-f="keyMode"><option value="primary" ${r.keyMode==='primary'?'selected':''}>Dùng key chính</option><option value="custom" ${r.keyMode==='custom'?'selected':''}>Key riêng</option></select></div>
    <div class="api-route-field api-route-key ${r.keyMode==='custom'?'':'hidden'}"><label>Key riêng</label><input data-f="apiKey" type="password" autocomplete="off" value="${String(r.apiKey||'').replace(/&/g,'&amp;').replace(/"/g,'&quot;')}" placeholder="API key dự phòng"></div>
    <div class="api-route-actions"><button class="mini" data-act="test" title="Kiểm tra tuyến">Test</button><button class="mini" data-act="up" ${i===0?'disabled':''}>↑</button><button class="mini" data-act="down" ${i===chain.length-1?'disabled':''}>↓</button><button class="mini danger" data-act="delete" ${chain.length<=1?'disabled':''}>×</button></div>
    <div class="api-route-status" data-status>${r.keyMode==='custom'&&r.apiKey?`Key riêng ${maskKey(r.apiKey)}`:(r.keyMode==='primary'?'Dùng API key chính':'')}</div>
  </div>`).join('');
  $('apiChainCount').textContent=`${chain.filter(x=>x.enabled).length}/${chain.length} tuyến bật`;
}
function syncRouteFromDom(row){
  const id=row?.dataset?.routeId;const r=chain.find(x=>x.id===id);if(!r)return null;
  r.enabled=!!row.querySelector('[data-f="enabled"]')?.checked;
  r.model=row.querySelector('[data-f="model"]')?.value||r.model;
  r.keyMode=row.querySelector('[data-f="keyMode"]')?.value==='custom'?'custom':'primary';
  r.apiKey=r.keyMode==='custom'?(row.querySelector('[data-f="apiKey"]')?.value||'').trim():'';
  return r;
}
function effectiveRouteConfig(r){return {apiKey:r.keyMode==='custom'?r.apiKey:$('apiKey').value.trim(),model:r.model,baseUrl:API_BASE_URL,authMode:'bearer'};}
async function ensureOriginPermission(url){const u=new URL(url);const origin=`${u.protocol}//${u.hostname}/*`;return (await chrome.permissions.contains({origins:[origin]}))||await chrome.permissions.request({origins:[origin]});}
async function testRoute(r,row=null){
  const status=row?.querySelector('[data-status]');if(status){status.textContent='Đang kiểm tra…';status.className='api-route-status checking';}
  try{
    const cfg=effectiveRouteConfig(r);if(!cfg.apiKey)throw new Error(r.keyMode==='custom'?'Chưa nhập API key riêng.':'Chưa nhập API key chính.');
    if(!(await ensureOriginPermission(API_BASE_URL)))throw new Error('Chưa cấp quyền máy chủ API.');
    const res=await runtime({type:'AI_TEST_API_ROUTE',config:cfg});if(!res?.ok)throw new Error(res?.error||'Không kết nối được API/model.');
    if(status){status.textContent=`✓ OK · ${r.model}`;status.className='api-route-status ok';}
    return {ok:true};
  }catch(e){if(status){status.textContent='✕ '+e.message;status.className='api-route-status err';}return {ok:false,error:e.message};}
}
async function load(){
  current=await chrome.storage.local.get(defaults);
  $('version').textContent='v'+chrome.runtime.getManifest().version;
  $('analysisMode').value=['api','gemini-web','chatgpt-web'].includes(current.analysisMode)?current.analysisMode:'api';
  $('aiRequireCompleteFiles').checked=current.aiRequireCompleteFiles!==false;
  $('instructionPrefixEnabled').checked=current.instructionPrefixEnabled===true;$('instructionPrefixText').value=current.instructionPrefixText||'VP đề xuất:';
  $('aiCustomRulesIncoming').value=String(current.aiCustomRulesIncoming||'');$('aiCustomRulesOutgoing').value=String(current.aiCustomRulesOutgoing||'');
  $('trackerApiUrl').value=current.trackerApiUrl||'';$('trackerToken').value=current.trackerToken||'';$('trackerReminderDays').value=String(current.trackerReminderDays||3);
  $('readerTimeoutSec').value=String(Math.round((current.readerTimeoutMs||5000)/1000));$('readerMaxFileSizeMb').value=String(current.readerMaxFileSizeMb||10);
  const cfg=geminiCfg();$('apiBaseUrl').value=API_BASE_URL;$('apiKey').value=cfg.apiKey;
  chain=normalizeChain(current.apiFallbackChain);renderChain();
}
function ruleExportPayload(){return {format:'ioffice-ai-prompt-rules-v1',version:1,exportedAt:new Date().toISOString(),incomingRules:String($('aiCustomRulesIncoming')?.value||''),outgoingRules:String($('aiCustomRulesOutgoing')?.value||'')}}
function downloadJson(filename,obj){const blob=new Blob([JSON.stringify(obj,null,2)],{type:'application/json'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=filename;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1200);}
function validateImportedRules(obj){if(!obj||typeof obj!=='object')throw new Error('Tệp JSON không hợp lệ.');if(obj.format!=='ioffice-ai-prompt-rules-v1')throw new Error('Không đúng định dạng quy tắc iOffice AI.');const incoming=String(obj.incomingRules||'');const outgoing=String(obj.outgoingRules||'');if(incoming.length>20000||outgoing.length>20000)throw new Error('Mỗi bộ quy tắc tối đa 20.000 ký tự.');return {incoming,outgoing};}
async function ensureTrackerPermission(url){if(!url)return false;const u=new URL(url);if(u.protocol!=='https:'||u.hostname!=='script.google.com'||!/^\/macros\/s\/[^/]+\/exec$/.test(u.pathname)||u.username||u.password)throw new Error('Nhập URL Apps Script dạng https://script.google.com/macros/s/.../exec.');const origins=[`${u.protocol}//${u.hostname}/*`,'https://script.googleusercontent.com/*'];const miss=[];for(const origin of origins)if(!(await chrome.permissions.contains({origins:[origin]})))miss.push(origin);return !miss.length||await chrome.permissions.request({origins:miss});}
$('apiChain')?.addEventListener('change',e=>{const row=e.target.closest('.api-route');if(!row)return;const r=syncRouteFromDom(row);if(e.target.dataset.f==='keyMode')renderChain();else $('apiChainCount').textContent=`${chain.filter(x=>x.enabled).length}/${chain.length} tuyến bật`;});
$('apiChain')?.addEventListener('input',e=>{const row=e.target.closest('.api-route');if(row)syncRouteFromDom(row);});
$('apiChain')?.addEventListener('click',async e=>{const b=e.target.closest('[data-act]');if(!b)return;const row=b.closest('.api-route');const idx=chain.findIndex(x=>x.id===row.dataset.routeId);if(idx<0)return;syncRouteFromDom(row);const act=b.dataset.act;if(act==='up'&&idx>0)[chain[idx-1],chain[idx]]=[chain[idx],chain[idx-1]];else if(act==='down'&&idx<chain.length-1)[chain[idx+1],chain[idx]]=[chain[idx],chain[idx+1]];else if(act==='delete'&&chain.length>1)chain.splice(idx,1);else if(act==='test'){await testRoute(chain[idx],row);return;}renderChain();});
$('addSameKeyRoute')?.addEventListener('click',()=>{if(chain.length>=8)return msg('Tối đa 8 tuyến API.',false);const used=new Set(chain.filter(x=>x.keyMode==='primary').map(x=>x.model));const model=MODEL_IDS.find(x=>!used.has(x))||MODEL_IDS[0];chain.push({id:routeId(),enabled:true,model,keyMode:'primary',apiKey:''});renderChain();});
$('addCustomKeyRoute')?.addEventListener('click',()=>{if(chain.length>=8)return msg('Tối đa 8 tuyến API.',false);chain.push({id:routeId(),enabled:true,model:'gemini-3.5-flash-lite',keyMode:'custom',apiKey:''});renderChain();});
$('testApiChain')?.addEventListener('click',async()=>{const el=$('apiStatus');el.textContent='Đang kiểm tra chuỗi API…';el.className='status';for(const row of [...document.querySelectorAll('.api-route')])syncRouteFromDom(row);const enabled=chain.filter(x=>x.enabled);if(!enabled.length){el.textContent='✕ Chưa bật tuyến API nào.';el.className='status err';return;}let ok=0;for(const r of enabled){const row=document.querySelector(`.api-route[data-route-id="${CSS.escape(r.id)}"]`);const rs=await testRoute(r,row);if(rs.ok)ok++;}el.textContent=ok===enabled.length?`✓ Toàn bộ ${ok} tuyến API đều sẵn sàng.`:`⚠ ${ok}/${enabled.length} tuyến API sẵn sàng. Kiểm tra các dòng màu đỏ.`;el.className='status '+(ok===enabled.length?'ok':'err');});
$('exportAiRules')?.addEventListener('click',()=>{try{downloadJson(`ioffice-ai-rules-${new Date().toISOString().slice(0,10)}.json`,ruleExportPayload());const el=$('aiRulesStatus');el.textContent='✓ Đã xuất quy tắc tùy chỉnh.';el.className='status ok';}catch(e){const el=$('aiRulesStatus');el.textContent='✕ '+e.message;el.className='status err';}});
$('importAiRules')?.addEventListener('click',()=>$('importAiRulesFile')?.click());
$('importAiRulesFile')?.addEventListener('change',async e=>{const el=$('aiRulesStatus');try{const file=e.target.files?.[0];if(!file)return;const obj=JSON.parse(await file.text());const rules=validateImportedRules(obj);$('aiCustomRulesIncoming').value=rules.incoming;$('aiCustomRulesOutgoing').value=rules.outgoing;el.textContent='✓ Đã nhập quy tắc. Bấm “Lưu cấu hình” để áp dụng.';el.className='status ok';}catch(err){el.textContent='✕ '+err.message;el.className='status err';}finally{e.target.value='';}});
$('clearAiRules')?.addEventListener('click',()=>{if(!confirm('Xóa toàn bộ quy tắc AI tùy chỉnh? Quy tắc mặc định của tiện ích vẫn được giữ.'))return;$('aiCustomRulesIncoming').value='';$('aiCustomRulesOutgoing').value='';const el=$('aiRulesStatus');el.textContent='Đã xóa nội dung tùy chỉnh. Bấm “Lưu cấu hình” để áp dụng.';el.className='status';});
$('testTracker')?.addEventListener('click',async()=>{const el=$('trackerStatus');el.textContent='Đang kiểm tra…';el.className='status';try{const url=$('trackerApiUrl').value.trim(),token=$('trackerToken').value.trim();if(!url||!token)throw new Error('Nhập URL Web App và TOKEN trước.');if(!(await ensureTrackerPermission(url)))throw new Error('Chưa cấp quyền Apps Script.');await chrome.storage.local.set({trackerEnabled:true,trackerApiUrl:url,trackerToken:token});const r=await runtime({type:'TRACKER_TEST'});if(!r?.ok)throw new Error(r?.error||'Không kết nối được Sổ.');el.textContent=`✓ Đã kết nối Tracker ${r.data?.version||''}`;el.className='status ok';}catch(e){el.textContent='✕ '+e.message;el.className='status err';}});
$('save')?.addEventListener('click',async()=>{try{
  for(const row of [...document.querySelectorAll('.api-route')])syncRouteFromDom(row);
  const apiKey=$('apiKey').value.trim(),enabledRoutes=chain.filter(x=>x.enabled);
  if(!enabledRoutes.length)throw new Error('Cần bật ít nhất 1 tuyến API.');
  if(enabledRoutes.some(x=>x.keyMode==='primary')&&!apiKey)throw new Error('Có tuyến dùng API key chính nhưng chưa nhập key chính.');
  const badCustom=enabledRoutes.find(x=>x.keyMode==='custom'&&!x.apiKey);if(badCustom)throw new Error('Có tuyến API key riêng đang bật nhưng chưa nhập key.');
  const providerConfigs={...(current.providerConfigs||{})};providerConfigs[API_PROVIDER]={...(providerConfigs[API_PROVIDER]||{}),model:enabledRoutes[0].model,baseUrl:API_BASE_URL,apiKey,authMode:'bearer'};
  const trackerApiUrl=$('trackerApiUrl').value.trim(),trackerToken=$('trackerToken').value.trim();const trackerEnabled=Boolean(trackerApiUrl&&trackerToken);
  if((trackerApiUrl&&!trackerToken)||(!trackerApiUrl&&trackerToken))throw new Error('Sổ theo dõi cần nhập đủ cả URL Web App và TOKEN.');
  if(trackerEnabled&&!(await ensureTrackerPermission(trackerApiUrl)))throw new Error('Chưa cấp quyền Apps Script.');
  if($('analysisMode').value==='api'){if(!(await ensureOriginPermission(API_BASE_URL)))throw new Error('Chưa cấp quyền máy chủ API.');}
  const settings={userRole:'leader',aiAnalysisEnabled:true,analysisMode:$('analysisMode').value,fallbackAnalysisMode:'none',webAiEnabled:true,webGeminiForeground:false,webGeminiFirstForeground:false,webChatgptForeground:false,webChatgptFirstForeground:false,webGeminiMaxTurns:3,webChatgptMaxTurns:3,webGeminiTimeoutMs:150000,webChatgptTimeoutMs:150000,aiRequireCompleteFiles:$('aiRequireCompleteFiles').checked,readerMode:'primary',readerTimeoutMs:Math.max(2000,Math.min(60000,Number($('readerTimeoutSec').value||5)*1000)),readerMaxFileSizeMb:Math.max(1,Math.min(50,Number($('readerMaxFileSizeMb').value||10))),readerIncludeRelated:false,readerConcurrency:0,readerDeduplicateContent:true,readerScanEnabled:false,trackerEnabled,trackerApiUrl,trackerToken,trackerReminderDays:Number($('trackerReminderDays').value||3),instructionPrefixEnabled:$('instructionPrefixEnabled').checked,instructionPrefixText:String($('instructionPrefixText').value||'VP đề xuất:').trim(),aiCustomRulesIncoming:String($('aiCustomRulesIncoming').value||'').slice(0,20000),aiCustomRulesOutgoing:String($('aiCustomRulesOutgoing').value||'').slice(0,20000),providerOrder:[API_PROVIDER,'none','none','none'],providerConfigs,apiFallbackChain:normalizeChain(chain),retriesPerProvider:1,requestTimeoutMs:45000};
  await chrome.storage.local.set(settings);current={...current,...settings};msg(`✓ Đã lưu cấu hình · ${enabledRoutes.length} tuyến API đang bật · đang tải lại…`,true);const saveBtn=$('save');if(saveBtn){saveBtn.disabled=true;saveBtn.textContent='Đã lưu';}setTimeout(()=>location.reload(),700);
}catch(e){msg(e.message,false);}});
load().catch(e=>msg('Không tải được cấu hình: '+e.message,false));
