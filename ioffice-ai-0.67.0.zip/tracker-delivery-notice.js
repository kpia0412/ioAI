(() => {
  if (window.top !== window) return;

  const host = document.createElement('div');
  host.style.cssText = 'position:fixed;bottom:9px;left:9px;z-index:2147483646;max-width:min(400px,calc(100vw - 18px));pointer-events:none';
  const root = host.attachShadow({ mode: 'closed' });
  document.documentElement.append(host);

  let expanded = false;
  let items = [];
  let generation = 0;
  let toastTimer = 0;
  let dismissedToastId = '';

  const SUCCESS_TOAST_MS = 6500;
  const labels = {
    awaiting_transfer: 'Chờ xác nhận đã chuyển iOffice',
    queued: 'Đã lưu · chờ gửi ngầm',
    sending: 'Đang gửi ngầm…',
    sent: 'Đã gửi hoàn tất vào Sổ',
    failed: 'Gửi thất bại',
    unknown: 'Chưa xác định kết quả · cần kiểm tra',
    cancelled: 'Đã hủy lượt gửi'
  };

  const isDone = status => ['sent', 'cancelled'].includes(status);
  const updatedMs = item => {
    const n = Date.parse(item?.updatedAt || '');
    return Number.isFinite(n) ? n : 0;
  };

  function shouldShowToast(item) {
    if (!item || dismissedToastId === item.id) return false;
    if (!isDone(item.status)) return true;
    if (item.status !== 'sent') return false;
    const at = updatedMs(item);
    return at > 0 && Date.now() - at < SUCCESS_TOAST_MS;
  }

  function scheduleToastHide(item) {
    clearTimeout(toastTimer);
    if (!item || item.status !== 'sent') return;
    const left = Math.max(0, SUCCESS_TOAST_MS - (Date.now() - updatedMs(item)) + 80);
    if (left > 0) toastTimer = setTimeout(() => render(), left);
  }

  function render() {
    clearTimeout(toastTimer);
    root.replaceChildren();
    if (!items.length) return;

    const style = document.createElement('style');
    style.textContent = `
      :host{font:12px/1.35 Arial,Helvetica,sans-serif;color:#17365d}
      section{pointer-events:auto;background:#fff;border:1px solid #b6c9dc;border-radius:10px;box-shadow:0 3px 14px #0002;padding:5px;max-width:100%}
      section.compact{display:inline-flex;align-items:center;gap:5px;padding:3px 4px;border-radius:9px}
      button{font:700 11px Arial,Helvetica,sans-serif;cursor:pointer;border:1px solid #bdcddd;border-radius:6px;padding:5px 7px;background:#edf5ff;color:#17365d;margin:2px}
      button.history-toggle{font-size:9.5px;padding:3px 6px;margin:0;white-space:nowrap;background:#f5f9fd} button.clear-history{font-size:9.5px;padding:3px 6px;margin:0;background:#fff7f7;color:#b42318;border-color:#fecaca}
      button.toast-close{font-size:12px;line-height:1;padding:3px 5px;margin:0 0 0 2px;background:#fff;border-color:#dbe5ee;color:#64748b}
      .badge{display:inline-flex;align-items:center;justify-content:center;min-width:15px;height:15px;border-radius:999px;padding:0 4px;background:#fff3cd;color:#8a5a00;font:800 9px Arial}
      .toast{display:flex;align-items:center;gap:5px;max-width:300px;padding:2px 3px 2px 2px;overflow:hidden}
      .toast-text{min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-size:11px;font-weight:700}
      .sent{color:#15803d}.unknown,.failed{color:#b42318}.sending,.queued,.awaiting_transfer{color:#a16207}
      .head{display:flex;align-items:center;justify-content:space-between;gap:7px;margin-bottom:3px}
      .list{max-height:300px;overflow:auto;min-width:min(360px,calc(100vw - 34px))}
      article{border-top:1px solid #dfe7ef;padding:7px 2px;overflow-wrap:anywhere}
      article:first-child{border-top:0}
      .row-head{display:flex;align-items:flex-start;justify-content:space-between;gap:8px}
      .row-status{font-size:11px;font-weight:800;text-align:right}
      .task{margin-top:3px;font-size:11.5px}
      small{display:block;color:#64748b;font-size:10.5px;margin-top:2px}
    `;
    root.append(style);

    const pending = items.filter(x => !isDone(x.status)).length;
    const latest = items[0];
    const box = document.createElement('section');
    if (!expanded) box.className = 'compact';
    root.append(box);

    if (!expanded) {
      const title = document.createElement('button');
      title.className = 'history-toggle';
      title.title = 'Mở lịch sử gửi Sổ';
      title.textContent = '📨 Sổ';
      title.onclick = () => { expanded = true; render(); };
      box.append(title);
      if (pending) {
        const badge = document.createElement('span');
        badge.className = 'badge';
        badge.textContent = String(pending);
        badge.title = `${pending} lượt gửi cần chú ý`;
        box.append(badge);
      }
      if (shouldShowToast(latest)) {
        const toast = document.createElement('div');
        toast.className = `toast ${latest.status}`;
        const text = document.createElement('div');
        text.className = 'toast-text';
        const name = (latest.data?.sourceNo || latest.data?.sourceSubject || 'Văn bản').slice(0, 62);
        text.textContent = `${name} · ${labels[latest.status] || latest.status}`;
        text.setAttribute('role', 'status');
        const close = document.createElement('button');
        close.className = 'toast-close';
        close.textContent = '×';
        close.title = 'Ẩn thông báo';
        close.onclick = e => { e.stopPropagation(); dismissedToastId = latest.id || ''; render(); };
        toast.append(text, close);
        box.append(toast);
        scheduleToastHide(latest);
      }
      return;
    }

    const head = document.createElement('div');
    head.className = 'head';
    const title = document.createElement('button');
    title.className = 'history-toggle';
    title.textContent = `📨 Lịch sử${pending ? ` · ${pending}` : ''} ▾`;
    title.onclick = () => { expanded = false; render(); };
    const tools = document.createElement('div');
    const clear = document.createElement('button');
    clear.className = 'clear-history';
    clear.textContent = 'Xóa tất cả';
    clear.title = 'Xóa các bản ghi lịch sử đã kết thúc trên tiện ích; không xóa nhiệm vụ trong Sổ';
    clear.onclick = async () => {
      if (!confirm('Xóa toàn bộ lịch sử gửi Sổ đã kết thúc trên tiện ích này?\n\nCác lượt đang chờ/đang gửi vẫn được giữ. Nhiệm vụ trong Sổ theo dõi/Google Sheets không bị xóa.')) return;
      clear.disabled = true;
      await send('TRACKER_DELIVERY_CLEAR_HISTORY');
      dismissedToastId = '';
      await refresh();
    };
    const close = document.createElement('button');
    close.className = 'toast-close';
    close.textContent = '×';
    close.title = 'Thu gọn';
    close.onclick = () => { expanded = false; render(); };
    tools.append(clear, close);
    head.append(title, tools);
    box.append(head);

    const list = document.createElement('div');
    list.className = 'list';
    box.append(list);

    for (const item of items) {
      const row = document.createElement('article');
      const rowHead = document.createElement('div');
      rowHead.className = 'row-head';
      const name = document.createElement('b');
      name.textContent = item.data?.sourceNo || item.data?.sourceSubject || 'Văn bản';
      const status = document.createElement('div');
      status.className = `row-status ${item.status}`;
      status.textContent = labels[item.status] || item.status;
      rowHead.append(name, status);
      row.append(rowHead);

      const meta = document.createElement('small');
      meta.textContent = new Date(item.updatedAt).toLocaleString('vi-VN') + (item.taskId ? ` · Mã: ${item.taskId}` : '');
      row.append(meta);

      if (item.data?.taskText) {
        const task = document.createElement('div');
        task.className = 'task';
        task.textContent = item.data.taskText;
        row.append(task);
      }
      if (item.error) {
        const err = document.createElement('small');
        err.textContent = item.error;
        row.append(err);
      }

      const add = (label, action) => {
        const b = document.createElement('button');
        b.textContent = label;
        b.onclick = async () => { b.disabled = true; try { await action(); } finally { await refresh(); } };
        row.append(b);
      };
      if (item.status === 'awaiting_transfer') {
        add('Đã chuyển · Gửi Sổ', async () => {
          if (confirm(`Chỉ xác nhận nếu văn bản ${item.data?.sourceNo || 'này'} đã chuyển thành công trên iOffice. Gửi nhiệm vụ đã lưu vào Sổ?`)) {
            await send('TRACKER_DELIVERY_COMMIT', { id: item.id });
          }
        });
        add('Hủy', () => send('TRACKER_DELIVERY_CANCEL', { id: item.id }));
      }
      if (['sent', 'failed', 'unknown'].includes(item.status)) add('Mở Sổ', () => send('TRACKER_OPEN_MANAGE'));
      list.append(row);
    }
  }

  async function send(type, data) {
    try {
      const r = await chrome.runtime.sendMessage({ type, data });
      if (!r?.ok) alert(r?.error || 'Chưa thực hiện được.');
      return r;
    } catch (e) {
      alert(e.message);
    }
  }

  async function refresh() {
    const run = ++generation;
    try {
      const r = await chrome.runtime.sendMessage({ type: 'TRACKER_DELIVERY_LIST' });
      if (run !== generation) return;
      const next = r?.ok ? r.items : [];
      const prevLatest = items[0]?.id;
      items = next;
      if (items[0]?.id && items[0].id !== prevLatest) dismissedToastId = '';
      render();
    } catch (_) {}
  }

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && Object.keys(changes).some(k => k.startsWith('trackerDeliveryV1:') || ['trackerToken', 'trackerApiUrl', 'trackerEnabled'].includes(k))) {
      void refresh();
    }
  });
  void refresh();
})();
