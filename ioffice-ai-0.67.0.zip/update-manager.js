/* Internet updater v2 - automatic update for unpacked Chrome extension.
 * Native helper is installed once on Windows and writes the new extension files in place.
 */
let iofficeUpdateApplying = false;
let iofficeUpdateCheck = null;
const UPDATE_HOST = 'vn.ealy.ioffice_updater';
const UPDATE_ALARM = 'ioffice-internet-update';
const UPDATE_PERIOD_MINUTES = 5;
const UPDATE_PENDING_RELOAD_KEY = 'internetUpdatePendingReload';

function nativeUpdate(message) {
  return new Promise((resolve, reject) => {
    const port = chrome.runtime.connectNative(UPDATE_HOST);
    let done = false;
    port.onMessage.addListener(reply => {
      if (done) return;
      done = true;
      try { port.disconnect(); } catch (_) {}
      reply?.ok ? resolve(reply) : reject(new Error(reply?.error || 'Bộ cập nhật Windows không trả kết quả hợp lệ.'));
    });
    port.onDisconnect.addListener(() => {
      const error = chrome.runtime.lastError;
      if (!done) {
        done = true;
        reject(new Error(error?.message || 'Mất kết nối bộ cập nhật Windows.'));
      }
    });
    port.postMessage(message);
  });
}

async function updateState(patch) {
  const { internetUpdate = {} } = await chrome.storage.local.get('internetUpdate');
  const next = { ...internetUpdate, ...patch };
  await chrome.storage.local.set({ internetUpdate: next });
  return next;
}

async function autoUpdateEnabled() {
  const x = await chrome.storage.local.get({ internetAutoUpdate: true });
  if (typeof x.internetAutoUpdate !== 'boolean') {
    await chrome.storage.local.set({ internetAutoUpdate: true });
    return true;
  }
  return x.internetAutoUpdate;
}

async function checkInternetUpdate() {
  if (iofficeUpdateApplying) return (await chrome.storage.local.get('internetUpdate')).internetUpdate || {};
  if (iofficeUpdateCheck) return iofficeUpdateCheck;
  iofficeUpdateCheck = (async () => {
    await updateState({ phase: 'checking', error: '', waitReason: '' });
    try {
      const data = await nativeUpdate({ command: 'check' });
      return await updateState({
        ...data,
        phase: data.newer ? 'available' : 'current',
        error: '',
        waitReason: '',
        checkedAt: Date.now()
      });
    } catch (e) {
      return await updateState({
        phase: 'error',
        error: 'Không kiểm tra được GitHub. Kiểm tra Internet hoặc bộ hỗ trợ Windows. Chi tiết: ' + e.message,
        checkedAt: Date.now()
      });
    }
  })();
  try { return await iofficeUpdateCheck; }
  finally { iofficeUpdateCheck = null; }
}

function automaticDeferredMessage(error) {
  const s = String(error?.message || error || '');
  if (/đang phân tích|Web AI/i.test(s)) return 'Đang có phiên phân tích AI; sẽ tự thử lại sau.';
  if (/chưa lưu|đang nhập|thay đổi chưa gửi/i.test(s)) return 'Có nội dung đang nhập/chưa gửi trên iOffice; sẽ tự cập nhật sau khi trang an toàn.';
  if (/làm mới các tab iOffice/i.test(s)) return 'Có tab iOffice cũ chưa nạp bộ cập nhật mới; hãy F5 tab đó một lần.';
  if (/đang đọc tệp|đang phân tích/i.test(s)) return 'Một tab iOffice đang xử lý; sẽ tự thử lại.';
  return s || 'Chưa thể cập nhật ngay; sẽ tự thử lại.';
}

async function applyInternetUpdate({ automatic = false, forceDirty = false } = {}) {
  if (iofficeUpdateApplying) {
    if (automatic) return { ok: false, deferred: true, reason: 'Đang có lượt cập nhật khác.' };
    throw new Error('Đang cập nhật, vui lòng chờ.');
  }
  iofficeUpdateApplying = true;
  const locked = [];
  let applied = false;
  try {
    if(await globalThis.IOfficeTrackerDeliveryBusy?.()) throw new Error('Đang gửi nhiệm vụ vào Sổ. Chờ kết quả gửi rồi cập nhật.');
    if (apiRequests.size || (await webAiActiveJobCount()) > 0)
      throw new Error('Đang phân tích AI. Hãy chờ xong rồi cập nhật.');

    const session = await chrome.storage.session.get(null);
    if (Object.entries(session).some(([k, v]) => k.startsWith(WEB_JOB_PREFIX) && v && !terminal(v) && Date.now() < v.deadline))
      throw new Error('Web AI đang phân tích. Hãy chờ xong rồi cập nhật.');

    const tabs = await chrome.tabs.query({ url: 'https://ioffice.vnptdaklak.vn/qlvbdh_dlk/*' });
    for (const tab of tabs) {
      if (!tab?.id || tab.discarded || /\/web\/viewer\.jsp/.test(tab.url || '')) continue;
      let reply;
      try {
        reply = await chrome.tabs.sendMessage(tab.id, { type: 'IOFFICE_UPDATE_LOCK', automatic, forceDirty: !automatic && forceDirty });
      } catch (_) {
        throw new Error('Hãy làm mới các tab iOffice trước lần cập nhật này.');
      }
      if (!reply?.ok) {
        if (reply?.reason === 'dirty') throw new Error('Có thay đổi chưa gửi hoặc nội dung đang nhập trên iOffice.');
        throw new Error('Một tab iOffice đang đọc tệp hoặc đang phân tích.');
      }
      locked.push(tab.id);
    }

    const { internetUpdate: release } = await chrome.storage.local.get('internetUpdate');
    if (!release?.newer || !release.sha256) throw new Error('Chưa có bản mới hợp lệ để cập nhật.');

    await updateState({ phase: 'applying', error: '', waitReason: '', automatic, applyStartedAt: Date.now() });
    const result = await nativeUpdate({ command: 'apply', version: release.version, sha256: release.sha256 });
    if (!result.applied) throw new Error('Bộ cập nhật chưa thay được phiên bản.');

    applied = true;
    await chrome.storage.local.set({
      [UPDATE_PENDING_RELOAD_KEY]: {
        version: result.version,
        tabs: locked,
        createdAt: Date.now(),
        automatic: Boolean(automatic)
      }
    });
    await updateState({
      phase: 'restarting',
      newer: false,
      current: result.version,
      error: '',
      waitReason: '',
      automatic,
      installedAt: Date.now()
    });

    // Files have already been replaced safely. Reload the extension so the new service worker starts.
    // The new worker will refresh only the iOffice tabs that were explicitly locked as safe.
    chrome.runtime.reload();
    return { ok: true, version: result.version };
  } catch (e) {
    if (automatic) {
      const reason = automaticDeferredMessage(e);
      await updateState({ phase: 'waiting', error: '', waitReason: reason, deferredAt: Date.now(), automatic: true });
      return { ok: false, deferred: true, reason };
    }
    await updateState({ phase: 'error', error: e.message, waitReason: '' });
    throw e;
  } finally {
    if (!applied) {
      iofficeUpdateApplying = false;
      await Promise.allSettled(locked.map(id => chrome.tabs.sendMessage(id, { type: 'IOFFICE_UPDATE_UNLOCK' })));
    }
  }
}

async function automaticUpdateCycle(source = 'alarm') {
  if (iofficeUpdateApplying) return;
  const enabled = await autoUpdateEnabled();
  const state = await checkInternetUpdate();
  if (!enabled || !state?.newer) return state;
  const result = await applyInternetUpdate({ automatic: true });
  return { ...state, autoResult: result, source };
}

async function ensureUpdateAlarm() {
  const existing = await chrome.alarms.get(UPDATE_ALARM);
  if (!existing) {
    await chrome.alarms.create(UPDATE_ALARM, { delayInMinutes: 1, periodInMinutes: UPDATE_PERIOD_MINUTES });
  }
}

async function finishPendingReload() {
  const data = await chrome.storage.local.get(UPDATE_PENDING_RELOAD_KEY);
  const pending = data[UPDATE_PENDING_RELOAD_KEY];
  if (!pending) return;
  if (!pending.createdAt || Date.now() - Number(pending.createdAt) > 15 * 60 * 1000) {
    await chrome.storage.local.remove(UPDATE_PENDING_RELOAD_KEY);
    return;
  }

  // The extension is now running the new files. Refresh only tabs that were checked as safe before replacement.
  await new Promise(resolve => setTimeout(resolve, 700));
  const refreshed = [];
  for (const id of Array.isArray(pending.tabs) ? pending.tabs : []) {
    try {
      const tab = await chrome.tabs.get(id);
      if (/^https:\/\/ioffice\.vnptdaklak\.vn\/qlvbdh_dlk\//.test(tab.url || '')) {
        await chrome.tabs.reload(id);
        refreshed.push(id);
      }
    } catch (_) {}
  }
  await chrome.storage.local.remove(UPDATE_PENDING_RELOAD_KEY);
  await updateState({
    phase: 'installed',
    current: pending.version || chrome.runtime.getManifest().version,
    newer: false,
    error: '',
    waitReason: '',
    automatic: Boolean(pending.automatic),
    justUpdatedAt: Date.now(),
    refreshedTabs: refreshed.length
  });
}

chrome.alarms.onAlarm.addListener(alarm => {
  if (alarm.name === UPDATE_ALARM) automaticUpdateCycle('alarm').catch(console.error);
});

chrome.runtime.onStartup.addListener(() => {
  ensureUpdateAlarm().then(() => automaticUpdateCycle('startup')).catch(console.error);
});

chrome.runtime.onInstalled.addListener(() => {
  ensureUpdateAlarm().then(() => automaticUpdateCycle('installed')).catch(console.error);
});

ensureUpdateAlarm().catch(console.error);
autoUpdateEnabled().catch(console.error);
finishPendingReload().catch(console.error);

chrome.runtime.onMessage.addListener((m, s, reply) => {
  if (!['INTERNET_UPDATE_CHECK', 'INTERNET_UPDATE_APPLY', 'INTERNET_UPDATE_OPTIONS', 'INTERNET_UPDATE_AUTO_NOW'].includes(m?.type)) return;
  const options = s.url === chrome.runtime.getURL('options.html');
  const office = s.id === chrome.runtime.id && /^https:\/\/ioffice\.vnptdaklak\.vn\/qlvbdh_dlk\//.test(s.url || '');
  if (s.id !== chrome.runtime.id || (!options && !office)) return;

  if (m.type === 'INTERNET_UPDATE_OPTIONS') {
    chrome.runtime.openOptionsPage();
    reply({ ok: true });
    return;
  }

  let task;
  if (m.type === 'INTERNET_UPDATE_CHECK') task = checkInternetUpdate();
  else if (m.type === 'INTERNET_UPDATE_APPLY') task = applyInternetUpdate({ automatic: false, forceDirty: m.forceDirty === true });
  else task = automaticUpdateCycle('manual-enable');

  task.then(data => reply({ ok: true, data })).catch(e => reply({ ok: false, error: e.message }));
  return true;
});
